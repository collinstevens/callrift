import json
from pathlib import Path
import subprocess
import tempfile

root=Path(tempfile.mkdtemp(prefix='callrift-delegate-copy-'))
(root/'App.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>',encoding='utf-8')
(root/'Flow.cs').write_text('public delegate int Copied(); public static class Flow { public static int Entry(System.Func<int> action) { var copy = new Copied(action); return copy(); } }',encoding='utf-8')
for args in [['init','--initial-branch=main'],['add','.'],['commit','--no-gpg-sign','-m','test: reproduce delegate copy']]:
 result=subprocess.run(['git',*args],cwd=root,capture_output=True)
 assert result.returncode==0,result.stderr.decode('utf-8')
artifacts=Path('artifacts').resolve()
for mode in ['source','msbuild']:
 command=['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe',str(artifacts.parent/'src/Callrift.Cli/bin/Debug/net11.0/callrift.dll'),'tree','HEAD','--entry','Flow.Entry','--externals','--format','json']
 if mode=='msbuild':command+=['--project','App.csproj']
 result=subprocess.run(command,cwd=root,capture_output=True,timeout=180)
 (artifacts/f'delegate-copy-{mode}-before.json').write_bytes(result.stdout)
 (artifacts/f'delegate-copy-{mode}-before.err').write_bytes(result.stderr)
 assert result.returncode==0,result.stderr.decode('utf-8')
 d=json.loads(result.stdout)
 print(mode,'diagnostics',d['diagnostics'],flush=True)
print('fixture',str(root),flush=True)
