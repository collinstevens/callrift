from pathlib import Path
import collections
import hashlib
import json
import subprocess

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
probe = root / 'next-candidate-root-audit'
core = '6819e35eeb92f251bec0be4e9d13377dabda8d9ac904a6955e9c6a8d67b31e62'
assert digest(probe / 'build/bin/Check/debug/Callrift.Core.dll') == core
build = (root / 'next-candidate-root-audit-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in build and '0 Error(s)' in build
evidence = []
for cache, name, expected_changes, expected_roots in [
    ('orchardcore', 'orchardcore-esmodule-localization', 47, [378, 388]),
    ('aspnetcore', 'aspnetcore-stream-cts-disposal', 5, [1201, 1201])
]:
    config_path = probe / (cache + '.json')
    config = json.loads(config_path.read_text(encoding='utf-8'))
    report_path = Path(config['output'])
    report = json.loads(report_path.read_text(encoding='utf-8'))
    changed = {value['key']: value for value in report['changes']}
    assert len(changed) == expected_changes
    sides = []
    for side, count in zip(report['sides'], expected_roots):
        assert len(side['witnesses']) == count
        for witness in side['witnesses']:
            assert witness['entry'] is not None and witness['changedTarget'] in changed
            assert witness['hops'] == len(witness['edges'])
            current = witness['entry']
            for key in witness['edges']:
                assert key == current
                edge = side['usedEdges'][key]
                assert edge['From'] == current
                current = edge['To']
            assert current == witness['changedTarget']
        sides.append({
            'side': side['side'],
            'roots': count,
            'allRootsHaveGraphWitness': True,
            'sharedWitnessEdges': len(side['usedEdges']),
            'hopCounts': dict(sorted(collections.Counter(witness['hops'] for witness in side['witnesses']).items())),
            'callbackEdges': sum(edge['Relation'] == 'callback' or any(ancestor['Relation'] == 'callback' for ancestor in edge['Ancestors']) for edge in side['usedEdges'].values()),
            'possibleDispatchEdges': sum(edge['PossibleContextTargets'] > 0 for edge in side['usedEdges'].values())
        })
    source_blobs = {}
    if cache == 'orchardcore':
        expectations = json.loads((root / 'orchardcore-esmodule-source-expectations.json').read_text(encoding='utf-8'))
        expected_paths = {record['path'] for record in expectations['productionCSharpFiles']}
        actual_paths = {record['location']['Path'] for record in report['changes']}
        extra_paths = {
            'src/OrchardCore/OrchardCore.Localization.Abstractions/JSLocalizerExtensions.cs',
            'src/OrchardCore/OrchardCore/Shell/Builders/ShellContainerFactory.cs'
        }
        assert actual_paths == expected_paths | extra_paths
        extra = [record for record in report['changes'] if record['location']['Path'] in extra_paths]
        assert len(extra) == 2
        assert all(not record['added'] and not record['removed'] and not record['bodyChanged'] and not record['signatureChanged'] for record in extra)
        for path in sorted(extra_paths):
            blobs = [subprocess.check_output(['git', '-C', config['repository'], 'rev-parse', config[side] + ':' + path], text=True).strip() for side in ['before', 'after']]
            assert blobs[0] == blobs[1]
            source_blobs[path] = blobs[0]
        interpretation = 'All 31 independently reviewed changed production files contribute changed graph members. Two unchanged source methods also change through dispatch: JSLocalizerExtensions.GetMergedLocalizations invokes IJSLocalizer.GetLocalizations inside its nested foreach loops, and ShellContainerFactory.CreateContainerAsync invokes startup.ConfigureServices at line 134. The ten new IJSLocalizer implementations and renamed Contents startup supply independent reasons for those target-set changes. Graph witnesses explain all 378 before and 388 after roots, including the eleven added constructors and one removed constructor. These witnesses use the candidate graph and are not independent proof of feasible runtime execution.'
    else:
        assert all(record['bodyChanged'] and not record['signatureChanged'] and not record['added'] and not record['removed'] and record['location']['Path'] == 'src/SignalR/server/Core/src/Internal/DefaultHubDispatcher.cs' for record in report['changes'])
        assert all(record['label'].endswith('.StreamAsync') for record in report['changes'])
        interpretation = 'The only five changed graph members are StreamAsync and its four contextual instantiations. All 1201 before and after roots have graph witnesses to that source edit. Broad possible dispatch, missing argument-value flow, and deferred callback bodies connect distant sample entry points. The prior 31-hop witness is conservative graph connectivity, not runtime execution evidence. The separate HttpResponse initializer CLI tree retains a callback ancestor around the disposal branch; the earlier flattened probe had omitted that ancestor from its display.'
    evidence.append({'case': name, 'coreSha256': core, 'configSha256': digest(config_path), 'viewSha256': digest(Path(config['view'])), 'reportSha256': digest(report_path), 'changedMembers': len(changed), 'sides': sides, 'unchangedDispatchCallerBlobs': source_blobs, 'interpretation': interpretation, 'graphConnectivityEvidenceOnly': True, 'accepted': False})
proof = {'sources': {path.as_posix(): digest(path) for path in [probe / 'Program.cs', probe / 'Check.csproj']}, 'binaries': {path.relative_to(probe).as_posix(): digest(path) for path in (probe / 'build/bin/Check/debug').glob('*') if path.is_file()}, 'cases': evidence}
(root / 'next-candidate-root-audits-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Recorded complete graph witnesses for both candidates with source-change checks and explicit runtime-proof limits.')
