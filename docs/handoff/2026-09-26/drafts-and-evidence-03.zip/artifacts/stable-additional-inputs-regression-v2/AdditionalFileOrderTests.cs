using System.Text.Json;
using Callrift.Scenarios;
using Xunit;

namespace Callrift.Workspaces;

public sealed class AdditionalFileOrderTests
{
    [Fact]
    public async Task DeclaredAdditionalFileOrderAndMetadataSurviveFreshProcesses()
    {
        var before = new Dictionary<string, string>
        {
            ["App/App.csproj"] = """
                <Project Sdk="Microsoft.NET.Sdk">
                  <PropertyGroup><TargetFramework>net10.0</TargetFramework></PropertyGroup>
                  <ItemGroup>
                    <ProjectReference Include="../Generator/Generator.csproj" OutputItemType="Analyzer" ReferenceOutputAssembly="false" />
                    <AdditionalFiles Include="z.flow;a.flow;m.flow;b.flow" Kind="calls" />
                    <CompilerVisibleItemMetadata Include="AdditionalFiles" MetadataName="Kind" />
                  </ItemGroup>
                </Project>
                """,
            ["App/Sink.cs"] = "public static class Sink { public static void Z() {} public static void A() {} public static void M() {} public static void B() {} public static void C() {} }",
            ["App/z.flow"] = "Z",
            ["App/a.flow"] = "A",
            ["App/m.flow"] = "M",
            ["App/b.flow"] = "B",
            ["Generator/Generator.csproj"] = "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><TargetFramework>netstandard2.0</TargetFramework><LangVersion>latest</LangVersion></PropertyGroup><ItemGroup><PackageReference Include=\"Microsoft.CodeAnalysis.CSharp\" Version=\"4.14.0\" /></ItemGroup></Project>",
            ["Generator/FlowGenerator.cs"] = """
                using System.Linq;
                using Microsoft.CodeAnalysis;
                [Generator]
                public sealed class FlowGenerator : IIncrementalGenerator
                {
                    public void Initialize(IncrementalGeneratorInitializationContext context)
                    {
                        var calls = context.AdditionalTextsProvider.Combine(context.AnalyzerConfigOptionsProvider).Select((input, cancellationToken) =>
                        {
                            var file = input.Left;
                            if (!input.Right.GetOptions(file).TryGetValue("build_metadata.AdditionalFiles.Kind", out var kind) || kind != "calls")
                                throw new System.InvalidOperationException("Additional-file metadata was lost");
                            return "Sink." + file.GetText(cancellationToken).ToString().Trim() + "();";
                        }).Collect();
                        context.RegisterSourceOutput(calls, (output, entries) => output.AddSource("Flow.g.cs", "public static class Flow { public static void Run() { " + string.Join(" ", entries) + " } }"));
                    }
                }
                """
        };
        var after = new Dictionary<string, string>(before) { ["App/b.flow"] = "C" };
        await using var fixture = await GitFixture.CreateAsync(new Scenario("additional-file-order", "Generator inputs retain evaluated order and metadata across processes.", before, after, []));
        string? previous = null;
        for (var attempt = 0; attempt < 3; attempt++)
        {
            string[] restore = attempt == 0 ? [] : ["--no-restore"];
            var output = await fixture.RunAsync(["tree", fixture.After, "--entry", "Flow.Run", "--project", "App/App.csproj", "--format", "json", .. restore]);
            Assert.True(output.StartsWith("exit: 0\n", StringComparison.Ordinal), output);
            using var document = Parse(output);
            Assert.Empty(document.RootElement.GetProperty("diagnostics").EnumerateArray());
            var root = Assert.Single(document.RootElement.GetProperty("trees").EnumerateArray());
            Assert.Equal(new[] { "Sink.Z", "Sink.A", "Sink.M", "Sink.C" }, root.GetProperty("children").EnumerateArray().Select(node => node.GetProperty("label").GetString()));
            if (previous is not null) Assert.Equal(previous, output);
            previous = output;
        }
        foreach (var format in new[] { "text", "md" })
        {
            var output = await fixture.RunAsync("tree", fixture.After, "--entry", "Flow.Run", "--project", "App/App.csproj", "--no-restore", "--format", format);
            Assert.True(output.StartsWith("exit: 0\n", StringComparison.Ordinal), output);
            var positions = new[] { "Sink.Z", "Sink.A", "Sink.M", "Sink.C" }.Select(label => output.IndexOf(label, StringComparison.Ordinal)).ToArray();
            Assert.All(positions, position => Assert.True(position >= 0));
            Assert.Equal(positions.Order(), positions);
        }
        var diff = await fixture.RunAsync("diff", fixture.Before, fixture.After, "--entry", "Flow.Run", "--project", "App/App.csproj", "--format", "json");
        Assert.True(diff.StartsWith("exit: 0\n", StringComparison.Ordinal), diff);
        using var changed = Parse(diff);
        Assert.Empty(changed.RootElement.GetProperty("diagnostics").EnumerateArray());
        var children = Assert.Single(changed.RootElement.GetProperty("trees").EnumerateArray()).GetProperty("children").EnumerateArray().ToArray();
        Assert.Equal("removed", children.Single(node => node.GetProperty("label").GetString() == "Sink.B").GetProperty("change").GetString());
        Assert.Equal("added", children.Single(node => node.GetProperty("label").GetString() == "Sink.C").GetProperty("change").GetString());
        Assert.All(children.Where(node => new[] { "Sink.Z", "Sink.A", "Sink.M" }.Contains(node.GetProperty("label").GetString())), node => Assert.Equal("unchanged", node.GetProperty("change").GetString()));
    }

    private static JsonDocument Parse(string output) => JsonDocument.Parse(output.Split("stdout:\n", StringSplitOptions.None)[1].Split("stderr:\n", StringSplitOptions.None)[0]);
}
