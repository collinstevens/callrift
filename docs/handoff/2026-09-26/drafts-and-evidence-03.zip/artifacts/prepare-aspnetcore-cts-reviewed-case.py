from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
identifier = 'aspnetcore-stream-cts-disposal'
directory = root / (identifier + '-reviewed-corpus')
assert not directory.exists()
directory.mkdir()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
review_path = root / 'aspnetcore-cts-automatic-review.json'
review = json.loads(review_path.read_text(encoding='utf-8'))
assert review['reviewed'] and review['repeatPending'] and not review['accepted']
for name, expected in review['files'].items():
    assert digest(Path(name)) == expected
for name in ['Check.csproj', 'RealWorldCaseTests.cs']:
    shutil.copy2(root / 'static-coalesce-initialization-corpus' / name, directory / name)
(directory / 'real-world-cases/reviews').mkdir(parents=True)
(directory / 'Snapshots').mkdir()
entry = {
    'id': identifier,
    'repository': 'https://github.com/dotnet/aspnetcore.git',
    'cacheName': 'aspnetcore',
    'before': review['before'], 'after': review['after'],
    'license': 'MIT', 'licenseFile': 'LICENSE.txt',
    'beforeLicenseBlob': review['licenseBlobs'][0], 'afterLicenseBlob': review['licenseBlobs'][1],
    'reason': 'Dispose a rejected SignalR streaming invocation cancellation source before its early return while preserving ownership of the existing invocation',
    'tags': ['branch-guard', 'exception-path', 'async', 'resource-cleanup', 'cross-project', 'automatic-roots'],
    'options': [],
    'knownIssue': 'issues/aspnetcore-source-coverage.md',
    'review': 'reviews/' + identifier + '.md',
    'routine': False,
    'views': [
        {'id': 'source-roots', 'routine': False, 'options': ['--depth', '1']},
        {'id': 'source-focused', 'routine': False, 'options': ['--entry', 'DefaultHubDispatcher<THub>.StreamAsync', '--depth', '3', '--externals']}
    ]
}
(directory / 'real-world-cases/manifest.json').write_text(json.dumps([entry], indent=2) + '\n', encoding='utf-8', newline='\n')
draft_path = root / (identifier + '-review.md')
shutil.copy2(draft_path, directory / 'real-world-cases' / entry['review'])
snapshots = {}
for view in entry['views']:
    source_stem = identifier + '-static-candidate-' + view['id']
    target_stem = identifier + '-' + view['id']
    formats = []
    for format in ['text', 'md']:
        stdout = (root / (source_stem + '.' + format)).read_text(encoding='utf-8')
        stderr = (root / (source_stem + '.' + format + '.stderr')).read_text(encoding='utf-8')
        formats.append(f'format: {format}\nexit: 0\nstdout:\n{stdout}stderr:\n{stderr}')
    text_path = directory / 'Snapshots' / (target_stem + '.verified.txt')
    text_path.write_bytes(b'\xef\xbb\xbf' + '\n'.join(formats).encode('utf-8'))
    stdout = (root / (source_stem + '.json')).read_text(encoding='utf-8')
    stderr = (root / (source_stem + ('.json.stderr' if view['id'] == 'source-focused' else '.stderr'))).read_text(encoding='utf-8')
    json_path = directory / 'Snapshots' / (target_stem + '-json.verified.txt')
    json_path.write_bytes(b'\xef\xbb\xbf' + f'exit: 0\nstdout:\n{stdout}stderr:\n{stderr}'.encode('utf-8'))
    for path in [text_path, json_path]:
        snapshots[path.name] = digest(path)
(root / (identifier + '-manifest-draft.json')).write_text(json.dumps(entry, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / (directory.name + '-reviews.json')).write_text(json.dumps({'views': [identifier + '-' + view['id'] for view in entry['views']], 'reviews': {path.name: digest(path) for path in [review_path, draft_path, root / 'aspnetcore-cts-focused-json-review.json', root / 'next-candidate-root-audits-evidence.json']}, 'snapshots': snapshots}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared two source views and four independently reviewed snapshots in an isolated repeat harness.')
