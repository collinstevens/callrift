from pathlib import Path

root = Path(__file__).resolve().parent.parent
target = root / 'artifacts/generic-context-limit-trace'
target.mkdir(exist_ok=True)
source = (root / 'artifacts/generic-context-core/Graph/ContextGraph.cs').read_text(encoding='utf-8')
source = source.replace('internal static class ContextGraph', 'internal static class TracedContextGraph')
source = source.replace('var additional = 0;', 'var additional = 0;\n        var parents = new Dictionary<string, string?>(StringComparer.Ordinal);')
source = source.replace('InvocationContext Add(InvocationContext frame)', 'InvocationContext Add(InvocationContext frame, string? parent = null)')
source = source.replace('omitted.Add(frame.Key);', '''if (omitted.Add(frame.Key))
                {
                    var path = new List<string> { frame.Identity };
                    for (var current = parent; current is not null && path.Count < 64; current = parents.GetValueOrDefault(current)) path.Add(current);
                    path.Reverse();
                    Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new { Limit = graph.Members[frame.Key].Label, Reason = additional >= 65536 ? "states" : "type-shape", States = additional, Path = path }));
                }''')
source = source.replace('frames.Add(frame.Identity, frame);', 'frames.Add(frame.Identity, frame);\n            parents.Add(frame.Identity, parent);')
source = source.replace('requested.Select(Add)', 'requested.Select(target => Add(target, frame.Identity))')
source = source.replace('key = Add(target).Identity;', 'key = Add(target, frame.Identity).Identity;')
(target / 'TracedContextGraph.cs').write_text(source, encoding='utf-8')
print('Prepared trace-only copy; production prototype unchanged.')
