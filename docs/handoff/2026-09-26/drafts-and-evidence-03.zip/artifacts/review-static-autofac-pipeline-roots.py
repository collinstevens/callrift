import collections
import json
import re
import subprocess
from static_review_support import root, snapshots, manifest, document, flatten, clean, rendered, digest, schema, initializer_evidence, jsonschema

case = manifest['autofac-pipeline-callbacks']
name = case['id'] + '-msbuild-roots'
before_path, after_path = [snapshots / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
before, after = document(before_path), document(after_path)
jsonschema.validate(after, schema)
assert before['diagnostics'] == after['diagnostics']
identity = lambda node: (node['after'] or node['before'])['symbolId']
old = {identity(node): node for node in before['trees']}
new = {identity(node): node for node in after['trees']}
assert not old.keys() - new.keys()
added = {key: new[key] for key in new.keys() - old.keys()}
assert {node['label'] for node in added.values()} == {'ServicePipelines.IsDefaultMiddleware', 'StronglyTypedMetaRegistrationSource.CreateMetaRegistration'}
changed_targets = ['MetaRegistrationSource.ResolveInstance', 'Container.ResolveComponent', 'LifetimeScope.ResolveComponent', 'DefaultResolveRequestContext.ResolveComponent', 'DecoratorContext.ResolveComponent']
changed_count = collections.Counter()
for key in old:
    left, right = clean(old[key]), clean(new[key])
    for node in flatten(right['children']):
        if node['label'] in ['⇢ ' + target for target in changed_targets] and node['change'] == 'modified' and node['detail'] == 'changes below depth limit':
            node['change'], node['detail'] = 'unchanged', 'depth limit'
            changed_count[node['label']] += 1
    assert left == right, key
assert changed_count == collections.Counter({'⇢ ' + target: 1 for target in changed_targets})
def shape(node):
    return [node['label'], node['change'], node['detail'], (node['after'] or node['before'])['relation'], [shape(child) for child in node['children']]]
dispatch = [['⇢ ' + target, 'modified', 'changes below depth limit', 'definition', []] for target in changed_targets[1:]]
expected_shapes = {
    'ServicePipelines.IsDefaultMiddleware': ['ServicePipelines.IsDefaultMiddleware', 'unchanged', None, 'definition', [['possible initialization of ServicePipelines', 'unchanged', None, 'branch', [['initialization of ServicePipelines', 'modified', 'changes below depth limit', 'call', []]]]]],
    'StronglyTypedMetaRegistrationSource.CreateMetaRegistration': ['StronglyTypedMetaRegistrationSource.CreateMetaRegistration', 'unchanged', None, 'definition', [
        ['MetadataViewProvider.GetMetadataViewProvider', 'unchanged', 'depth limit', 'call', []],
        ['RegistrationBuilder.ForDelegate', 'unchanged', 'depth limit', 'call', [
            ['new ResolveRequest', 'unchanged', None, 'callback', []],
            ['IComponentContext.ResolveComponent', 'unchanged', None, 'callback', dispatch],
            ['new Meta<T, TMetadata>', 'unchanged', None, 'callback', []]]],
        ['IRegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.As → RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.As', 'unchanged', 'depth limit', 'call', []],
        ['RegistrationExtensions.Targeting', 'unchanged', None, 'call', []],
        ['RegistrationBuilder.CreateRegistration', 'unchanged', 'depth limit', 'call', []]]]}
source_path = root / 'static-root-source-review/autofac-report.json'
source_report = json.loads(source_path.read_text(encoding='utf-8'))
assert source_report['checks'] == 44 and source_report['failed'] == 0
source_key = lambda value: json.dumps({name: value[name] for name in ['revision', 'definition', 'signature', 'callSites']}, sort_keys=True)
source_proven = {source_key(record['check']) for record in source_report['records'] if record['passed']}
for node in added.values():
    assert shape(node) == expected_shapes[node['label']]
    for member in flatten([node]):
        assert member['before'] == member['after']
        for side in ['before', 'after']:
            value = member[side]
            if value['origin'] == 'source' and value['definition'] is not None and not value['symbolId'].endswith('..cctor()'):
                assert source_key({'revision': case[side], 'definition': value['definition'], 'signature': value['signature'], 'callSites': value['callSites']}) in source_proven
branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
assert collections.Counter(node['label'] for node in branches) == {'possible initialization of ServicePipelines': 1, 'possible initialization of ReflectionCacheSet': 1, 'possible initialization of DefaultPropertySelector': 6, 'possible initialization of ResolveRequest': 10, 'possible initialization of ResolutionValueExtensions': 1}
initializer_key, initializer_proven = initializer_evidence(case['id'])
for branch in branches:
    assert branch['kind'] == 'branch' and branch['change'] == 'unchanged' and branch['omission'] is None and len(branch['children']) == 1
    initializer = branch['children'][0]
    assert initializer['children'] == []
    assert initializer['omission'] == ({'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if initializer['label'] in ['initialization of ServicePipelines', 'initialization of DefaultPropertySelector'] else None)
    for side in ['before', 'after']:
        value, structural = initializer[side], branch[side]
        assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['callSites'] == value['callSites']
        assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
        check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
        assert initializer_key(check) in initializer_proven
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
source_expectations = {
    'src/Autofac/Core/Resolving/Pipeline/ServicePipelines.cs': ['DefaultServicePipeline { get; } = new ResolvePipelineBuilder(PipelineType.Service).UseRange(DefaultMiddleware).Build();', 'foreach (var defaultItem in DefaultMiddleware)'],
    'src/Autofac/Features/Metadata/StronglyTypedMetaRegistrationSource.cs': ['.ForDelegate((c, p) =>', 'return new Meta<T, TMetadata>((T)c.ResolveComponent(new ResolveRequest(valueService, implementation, p)), metadata);'],
    'src/Autofac/Features/Metadata/MetaRegistrationSource.cs': ['=> new Meta<T>((T)ctx.ResolveComponent(request), request.Registration.Target.Metadata);'],
    'src/Autofac/Core/Resolving/ResolveOperation.cs': ['request.Registration.Sharing == InstanceSharing.Shared &&', 'request.ResolvePipeline == ServicePipelines.DefaultServicePipeline &&']}
blobs = {}
for path, snippets in source_expectations.items():
    blobs[path] = {}
    for side in ['before', 'after']:
        text = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
        assert all(snippet in text for snippet in snippets)
        blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
path_runs_file = root / 'static-autofac-root-path-review/runs.json'
path_runs = json.loads(path_runs_file.read_text(encoding='utf-8'))
assert len(path_runs['runs']) == 4 and all(run['exitCode'] == 0 for run in path_runs['runs'])
for run in path_runs['runs']:
    from pathlib import Path
    path = Path(run['output'])
    assert digest(path) == run['sha256']
    value = json.loads(path.read_text(encoding='utf-8'))
    jsonschema.validate(value, schema)
    assert len(value['paths']) == (1 if run['entry'] == 'ServicePipelines.IsDefaultMiddleware' else 4)
    for chain in value['paths']:
        nodes = list(flatten([chain]))
        assert nodes[0]['label'] == run['entry'] and nodes[-1]['label'] == 'ResolvePipelineBuilder.BuildPipeline'
        expected_boundary = len(nodes) == 15 and nodes[3]['label'] == '⇢ Container.ResolveComponent'
        assert all(node['omission'] is None for node in nodes[:-1])
        assert nodes[-1]['omission'] == ({'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if expected_boundary else None)
        assert len(nodes) - 1 <= 14
        assert any(node['label'] == 'possible initialization of ServicePipelines' for node in nodes)
        if run['entry'].startswith('StronglyTyped'):
            assert any(node['label'] == 'if (request.Registration.Sharing == InstanceSharing.Shared)' for node in nodes)
            assert any((node['after'] or node['before'])['relation'] == 'callback' for node in nodes)
def has_changes(node):
    return node['change'] != 'unchanged' or any(has_changes(child) for child in node['children'])
def blocks(text, document):
    values = text.strip('\n').split('\n\n')
    nodes = [node for node in document['trees'] if has_changes(node)]
    assert len(values) == len(nodes)
    return {identity(node): value for node, value in zip(nodes, values)}
before_text_path, after_text_path = [snapshots / (name + '.' + suffix + '.txt') for suffix in ['verified', 'received']]
old_stdout, old_stderr = rendered(before_text_path)
new_stdout, new_stderr = rendered(after_text_path)
assert old_stderr == new_stderr
old_blocks, new_blocks = blocks(old_stdout, before), blocks(new_stdout, after)
normalize = lambda block: [(line[0], re.sub(r'^[ │├└─]*', '', line[2:])) for line in block.splitlines() if 'possible initialization of ' not in line]
factory_shifts = 0
for key in old_blocks:
    left, right = normalize(old_blocks[key]), normalize(new_blocks[key])
    if 'LazyWithMetadataRegistrationSource.CreateLazyRegistration' in key:
        additions = [(' ', 'IComponentContext.ResolveComponent')] + [('~', '⇢ ' + target + ' (changes below depth limit)') for target in changed_targets[1:]]
        for line in additions:
            assert right.count(line) == 1
            right.remove(line)
    right = [(' ', '⇢ MetaRegistrationSource.ResolveInstance (depth limit)') if line == ('~', '⇢ MetaRegistrationSource.ResolveInstance (changes below depth limit)') else line for line in right]
    if left != right:
        assert len(left) == len(right)
        differences = [(a, b) for a, b in zip(left, right) if a != b]
        assert differences == [((' ', 'Enforce.ArgumentTypeIsFunction (depth limit)'), (' ', '…'))]
        factory_shifts += 1
assert factory_shifts == 1
assert len(new_blocks.keys() - old_blocks.keys()) == 2
expected_rendered_roots = {
    'ServicePipelines.IsDefaultMiddleware': '  ServicePipelines.IsDefaultMiddleware\n  └─ possible initialization of ServicePipelines\n~    └─ initialization of ServicePipelines (changes below depth limit)',
    'StronglyTypedMetaRegistrationSource.CreateMetaRegistration': '  StronglyTypedMetaRegistrationSource.CreateMetaRegistration\n  ├─ MetadataViewProvider.GetMetadataViewProvider (depth limit)\n  ├─ RegistrationBuilder.ForDelegate (depth limit)\n  │  ├─ new ResolveRequest\n  │  ├─ IComponentContext.ResolveComponent ↑ as above\n  │  └─ new Meta<T, TMetadata>\n  ├─ IRegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.As → RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.As (depth limit)\n  ├─ RegistrationExtensions.Targeting\n  └─ …'
}
for key, node in added.items():
    assert new_blocks[key] == expected_rendered_roots[node['label']]
proof = {'view': name, 'newRoots': sorted(added), 'initializerBranches': 19, 'reviewedExistingNodeChanges': dict(changed_count), 'sourceRootReportSha256': digest(source_path), 'sourceRootReviewerSha256': digest(root / 'static-root-source-review/Program.cs'), 'sourceBlobs': blobs, 'cliReachEvidenceSha256': digest(path_runs_file), 'schemaV1': True, 'textMarkdownParity': True, 'files': {path.name: digest(path) for path in [after_path, after_text_path]}, 'repeatStatus': 'pending', 'review': 'Two new roots and five newly marked dispatch targets reach the changed pipeline builder through ServicePipelines initialization. The metadata root retains possible callback and dispatch semantics and the shared-instance guard. All old JSON fields remain unchanged outside initializer branches, IDs, and the five independently explained depth-change markers. Rendered shared-root differences are limited to the verified callback expansion and known initializer/context additions.'}
proof['reachBoundaryReview'] = 'In both modes, the Container path reaches BuildPipeline at depth 14. Only the target body is truncated; every preceding edge is present. The other three metadata paths and the direct initializer path reach the target before that boundary.'
proof['renderedRootReview'] = 'Both new root blocks were read in full and checked against independently inspected source. The metadata callback references the earlier expanded IComponentContext.ResolveComponent subtree; CreateRegistration is elided as unchanged context.'
(root / 'static-autofac-pipeline-restored-roots-review.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed restored Autofac pipeline roots: two new roots, nineteen initializer branches, five depth-change markers, and preserved remaining output.')
