from pathlib import Path
import json
import subprocess
root = Path('artifacts/constructor-object-batch2-source-review')
review = json.loads(Path('artifacts/constructor-object-batch2-focused-review.json').read_text(encoding='utf-8'))
for item in review['reviews']:
    view = item['view']
    with (root / (view + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(root / 'bin/Release/net11.0/Check.dll'), str(root / (view + '.json')), str(root / (view + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, view
    report = json.loads((root / (view + '-report.json')).read_text(encoding='utf-8'))
    assert report['verified'] == item['sourceChecks']
    print(json.dumps({'view': view, 'verified': report['verified']}), flush=True)
