from pathlib import Path
import hashlib
import json
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-six-view-corpus'
snapshots = directory / 'Snapshots'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
def flatten(nodes):
    for node in nodes:
        yield node
        yield from flatten(node['children'])
def existing(value):
    if isinstance(value, dict):
        return {key: existing(item) for key, item in value.items() if key != 'id'}
    if isinstance(value, list):
        return [existing(item) for item in value if not (isinstance(item, dict) and item.get('kind') == 'branch' and item.get('label', '').startswith('possible initialization of '))]
    return value
def key(value):
    return json.dumps({name: value[name] for name in ['revision', 'symbolId', 'definition', 'callSites']}, sort_keys=True)
proven = {}
for path in (root / 'static-initializer-source-review').glob('*-report.json'):
    report = json.loads(path.read_text(encoding='utf-8'))
    for record in report['records']:
        if record['passed']:
            proven[key(record['check'])] = {'report': path.as_posix(), 'sha256': digest(path), 'record': record}
generated_path = root / 'static-generated-initializer-review/ocelot-custom-json-merge-report.json'
for record in json.loads(generated_path.read_text(encoding='utf-8'))['records']:
    assert record['verified']
    proven[key(record['check'])] = {'report': generated_path.as_posix(), 'sha256': digest(generated_path), 'record': record}
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
validator = jsonschema.validators.validator_for(schema)(schema)
counts = {
    'ocelot-custom-json-merge-msbuild-focused': 3,
    'ocelot-custom-json-merge-source-focused': 2,
    'ocelot-custom-json-merge-msbuild-roots': 2,
    'ocelot-route-claims-keys-source-roots': 1,
    'polly-caller-cancellation-msbuild-roots': 6,
    'polly-executor-continuations-msbuild-roots': 6
}
records = []
for name, expected_count in counts.items():
    before_path = snapshots / (name + '-json.verified.txt')
    after_path = snapshots / (name + '-json.received.txt')
    before, after = load(before_path), load(after_path)
    validator.validate(after)
    assert existing(before) == existing(after), name
    case = next(case for case in manifest if name.startswith(case['id'] + '-'))
    branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
    assert len(branches) == expected_count
    proof = []
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['detail'] is None and branch['omission'] is None
        assert len(branch['children']) == 1
        initializer = branch['children'][0]
        label = initializer['label']
        assert branch['label'] == 'possible ' + label and initializer['kind'] == 'call'
        assert initializer['change'] == ('added' if label == 'initialization of ConfigurationBuilderExtensions' else 'unchanged')
        if label == 'initialization of RegexGlobal':
            assert initializer['detail'] is None and initializer['omission'] is None
            assert [node['label'] for node in initializer['children']] == ['TimeSpan.FromMilliseconds', 'AppDomain.CurrentDomain.SetData']
            for index, call in enumerate(initializer['children']):
                assert call['kind'] == 'call' and call['change'] == 'unchanged' and call['detail'] is None and call['children'] == [] and call['omission'] is None
                for side in ['before', 'after']:
                    value = call[side]
                    suffix = ['System.TimeSpan.FromMilliseconds(long)', 'System.AppDomain.SetData(string,object)'][index]
                    assert value['symbolId'].endswith('::' + suffix) and value['targetIds'] == [value['symbolId']]
                    assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'metadata' and value['relation'] == 'call'
                    assert value['definition'] is None and value['signature'] is None and value['candidates'] == []
                    assert value['callSites'] == [{'path': 'src/Infrastructure/RegexGlobal.cs', 'startLine': [10, 11][index], 'startColumn': [31, 9][index], 'endLine': [10, 11][index], 'endColumn': [89, 92][index]}]
        elif label == 'initialization of ConfigurationBuilderExtensions':
            assert initializer['detail'] is None and initializer['omission'] is None and initializer['children'] == []
        else:
            assert label in ['initialization of SubConfigRegex_10', 'initialization of DiscoverySteps', 'initialization of VoidResult']
            assert initializer['detail'] == 'depth limit' and initializer['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and initializer['children'] == []
        for side in ['before', 'after']:
            value = initializer[side]
            structural = branch[side]
            if value is None:
                assert side == 'before' and label == 'initialization of ConfigurationBuilderExtensions' and structural is None
                continue
            assert structural['symbolId'] is None and structural['signature'] is None and structural['definition'] is None and structural['targetIds'] == [] and structural['candidates'] is None
            assert structural['binding'] == 'structural' and structural['dispatch'] == 'none' and structural['origin'] == 'structural'
            assert structural['relation'] == ('callback' if name.startswith('polly-') else 'branch')
            assert structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call'
            assert value['targetIds'] == [value['symbolId']] and value['candidates'] == []
            check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
            evidence = proven[key(check)]
            record = evidence['record']
            if 'constructors' in record:
                assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in record['constructors']]
            else:
                assert value['signature'] == record['type'] + '.' + record['type'].split('.')[-1] + '() -> void'
            proof.append({'node': initializer['id'], 'side': side, 'sourceReport': evidence['report'], 'sourceReportSha256': evidence['sha256']})
    text_path = snapshots / (name + '.received.txt')
    text = text_path.read_text(encoding='utf-8-sig')
    plain = text.split('format: text\nexit: 0\nstdout:\n')[1].split('stderr:\n')[0]
    markdown = text.split('format: md\nexit: 0\nstdout:\n```diff\n')[1].split('```\nstderr:\n')[0]
    assert plain == markdown
    if name.startswith('polly-'):
        assert plain.count('possible initialization of VoidResult') == 2
        assert plain.count('↑ as above') == 7
    records.append({'view': name, 'initializerBranches': len(branches), 'allPriorJsonPreservedExceptNodeIds': True, 'schemaV1': True, 'textMarkdownParity': True,
        'independentSourceEvidence': proof, 'files': {path.name: digest(path) for path in [after_path, text_path]}})
trx = next((root / 'static-initialization-six-view-corpus-results').glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['failed'] == '6'
assert all('VerifyException' in result.find('.//{*}Message').text for result in tree.findall('.//{*}UnitTestResult'))
review = {'core': 'c01ef7a99c7b63140172838a97f7690dee7df9ae47293a9a5e55cececa6f1525', 'views': records, 'firstRunTrxSha256': digest(trx), 'repeatStatus': 'pending'}
(root / 'static-six-view-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
target = root / 'static-initialization-six-view-repeat'
assert not target.exists()
shutil.copytree(directory, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
for record in records:
    for name, expected in record['files'].items():
        assert digest(snapshots / name) == expected
        shutil.copy2(snapshots / name, target / 'Snapshots' / name.replace('.received.', '.verified.'))
print('Reviewed six complete views and 20 initializer branches; copied only their twelve reviewed snapshots into an isolated repeat.')
