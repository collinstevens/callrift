import collections
import json
import pathlib
import sys

sys.stdout.reconfigure(encoding='utf-8')
root = pathlib.Path(__file__).resolve().parent.parent
snapshots = root / 'tests/Callrift.RealWorldCases/Snapshots'

def read(file):
    text = file.read_text(encoding='utf-8-sig')
    return json.loads(text.split('stdout:\n', 1)[1].split('stderr:\n', 1)[0])

def changes(old, new, path=''):
    if type(old) is not type(new):
        yield path, old, new
    elif isinstance(old, dict):
        assert old.keys() == new.keys(), path
        for key in old:
            yield from changes(old[key], new[key], path + '.' + key)
    elif isinstance(old, list):
        assert len(old) == len(new), (path, len(old), len(new))
        for index, (left, right) in enumerate(zip(old, new)):
            yield from changes(left, right, path + '[' + str(index) + ']')
    elif old != new:
        yield path, old, new

for file in sorted(snapshots.glob('*-json.received.txt')):
    differences = list(changes(read(file.with_name(file.name.replace('.received.', '.verified.'))), read(file)))
    assert all(path.rsplit('.', 1)[-1] in {'message', 'label'} for path, _, _ in differences), file.name
    print(file.name, dict(collections.Counter(path.rsplit('.', 1)[-1] for path, _, _ in differences)))
    for path, old, new in differences:
        print(path, repr(old), '=>', repr(new))
