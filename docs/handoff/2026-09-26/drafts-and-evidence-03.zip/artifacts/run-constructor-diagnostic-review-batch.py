from pathlib import Path
import json
import subprocess
import time

directory = Path('artifacts/constructor-diagnostic-source-review')
jobs = json.loads((directory / 'batch-jobs.json').read_text(encoding='utf-8'))
for name in jobs:
    start = time.monotonic()
    with (directory / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(directory / 'bin/Debug/net11.0/Check.dll'), str(directory / (name + '.json')), str(directory / (name + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, name
    report = json.loads((directory / (name + '-report.json')).read_text(encoding='utf-8'))
    print(json.dumps({'case': name, 'seconds': round(time.monotonic() - start, 2), 'diagnosticCount': report['diagnosticCount'], 'provenMissingBaseCount': report['provenMissingBaseCount'], 'unmatched': report['unmatched']}), flush=True)
