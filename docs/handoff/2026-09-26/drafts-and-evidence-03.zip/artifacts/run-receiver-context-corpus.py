from pathlib import Path
import json
import shutil
import subprocess
import time
import xml.etree.ElementTree as ElementTree

root = Path.cwd()
folder = root / 'artifacts/generic-context-reviewed-corpus-results'
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
deadline = time.monotonic() + 7200
print('Waiting for the reviewed generic-context corpus repeat.', flush=True)
while True:
    runs = list(folder.glob('*.trx'))
    if runs:
        try:
            run = ElementTree.parse(runs[0])
            results = run.findall('.//t:UnitTestResult', namespace)
            if len(results) == 81:
                break
        except ElementTree.ParseError:
            pass
    if time.monotonic() > deadline:
        raise TimeoutError('The prerequisite corpus repeat did not complete.')
    time.sleep(10)
failures = [result.attrib['testName'] for result in results if result.attrib['outcome'] != 'Passed']
expected = 'Callrift.RealWorldCases.RealWorldCaseTests.ReviewedView(id: "autofac-any-key-cache", viewId: "source-roots")'
assert failures == [expected], failures
dotnet = 'C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe'
for suffix in ['', '-json']:
    name = 'autofac-any-key-cache-source-roots' + suffix + '.verified.txt'
    shutil.copyfile(root / 'tests/Callrift.RealWorldCases/Snapshots' / name, root / 'artifacts/generic-context-reviewed-corpus/Snapshots' / name)
with (root / 'artifacts/generic-context-reviewed-autofac-repeat.log').open('w', encoding='utf-8', newline='\n') as output:
    command = [dotnet, 'vstest', str(root / 'artifacts/generic-context-reviewed-corpus/build/bin/Check/debug/Callrift.RealWorldCases.Tests.dll'), '--TestCaseFilter:DisplayName~autofac-any-key-cache&DisplayName~source-roots', '--logger:trx', '--ResultsDirectory:' + str(root / 'artifacts/generic-context-reviewed-autofac-results')]
    code = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT).returncode
assert code == 0, 'The exact-core Autofac repeat did not pass.'
report = {'fullRun': str(runs[0].relative_to(root)), 'fullRunPassed': 80, 'fullRunExpectedBaselineMismatch': expected, 'exactCoreAutofacRepeatPassed': True, 'all81ReviewedViewsVerified': True}
(root / 'artifacts/generic-context-reviewed-corpus-completion.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report), flush=True)
print('Starting the isolated receiver-context corpus trial.', flush=True)
with (root / 'artifacts/receiver-context-corpus.log').open('w', encoding='utf-8', newline='\n') as output:
    command = [dotnet, 'vstest', str(root / 'artifacts/receiver-context-corpus/build/bin/Check/debug/Callrift.RealWorldCases.Tests.dll'), '--logger:trx', '--ResultsDirectory:' + str(root / 'artifacts/receiver-context-corpus-results')]
    code = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT).returncode
raise SystemExit(code)
