from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path('artifacts')
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
inventory_path = root / 'static-initialization-corpus-review-inventory.json'
inventory = json.loads(inventory_path.read_text(encoding='utf-8'))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
batch = int(sys.argv[1]) if len(sys.argv) > 1 else 2
for kind, source_name in [('initializer', 'static-initializer-source-review'), ('diagnostic', 'static-diagnostic-source-batch-review')]:
    source = root / source_name
    target = root / ('static-' + kind + '-source-batch' + str(batch) + '-review')
    previous = [root / ('static-' + kind + '-source-batch' + str(number) + '-review') for number in range(2, batch)]
    assert not target.exists()
    target.mkdir()
    for name in ['Program.cs', 'Check.csproj']:
        shutil.copy2(source / name, target / name)
    shutil.copytree(source / 'build/bin/Check/debug', target / 'ready')
    jobs = []
    for case in manifest:
        views = [view for view in inventory['views'] if view['caseId'] == case['id']]
        config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName']}
        if kind == 'initializer':
            old = []
            for folder in [source, *previous]:
                old_path = folder / (case['id'] + '.json')
                if old_path.exists():
                    old.extend(json.loads(old_path.read_text(encoding='utf-8'))['checks'])
            key = lambda value: json.dumps({k: value[k] for k in ['revision', 'symbolId', 'definition', 'callSites']}, sort_keys=True)
            known = {key(value) for value in old}
            checks = {}
            for view in views:
                for occurrence in view['initializerOccurrences']:
                    for side in ['before', 'after']:
                        value = occurrence[side]
                        if value is None:
                            continue
                        check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
                        if key(check) not in known:
                            checks[key(check)] = check
            if not checks:
                continue
            config['checks'] = list(checks.values())
        else:
            views = [view for view in views if '-source-' in view['view'] or ('-msbuild' not in view['view'] and '-source-' not in view['view'])]
            known = set()
            for folder in [source, root / 'static-diagnostic-source-refined-review', *previous]:
                for old_path in folder.glob('*.json'):
                    old = json.loads(old_path.read_text(encoding='utf-8'))
                    if isinstance(old, dict) and old.get('repository') == config['repository'] and old.get('revisions') == [case['before'], case['after']]:
                        known.update(json.dumps(value, sort_keys=True) for value in old.get('diagnostics', []))
            unique = {json.dumps(value, sort_keys=True): value for view in views for value in view['addedDiagnostics'] if json.dumps(value, sort_keys=True) not in known}
            if not unique:
                continue
            config.update(revisions=[case['before'], case['after']], diagnostics=list(unique.values()), views=[view['view'] for view in views])
        (target / (case['id'] + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
        jobs.append(case['id'])
    (target / 'jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8', newline='\n')
    files = {p.relative_to(target).as_posix(): digest(p) for p in target.rglob('*') if p.is_file()}
    (root / (target.name + '-inputs.json')).write_text(json.dumps({'inventorySha256': digest(inventory_path), 'files': files}, indent=2) + '\n', encoding='utf-8', newline='\n')
    driver = (root / ('run-static-initializer-source-review.py' if kind == 'initializer' else 'run-static-diagnostic-batch.py')).read_text(encoding='utf-8')
    driver = driver.replace(source_name, target.name).replace('build/bin/Check/debug/Check.dll', 'ready/Check.dll')
    (root / ('run-static-' + kind + '-batch' + str(batch) + '.py')).write_text(driver, encoding='utf-8', newline='\n')
    print(json.dumps({'kind': kind, 'jobs': jobs}))
