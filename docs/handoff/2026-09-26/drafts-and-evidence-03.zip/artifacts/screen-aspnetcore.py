from pathlib import Path
import json,subprocess,time
root=Path.cwd(); entries=json.loads((root/'artifacts/aspnetcore-candidates.json').read_text(encoding='utf-8'))
cli=root/'artifacts/variance-ocelot-cli/callrift.dll'
for entry in [entries[3],entries[4],entries[0],entries[1],entries[2]]:
 stem=root/'artifacts'/('aspnetcore-'+entry['after'][:7]+'-source-roots-trial')
 started=time.monotonic()
 with stem.with_suffix('.json').open('wb') as stdout,stem.with_suffix('.err').open('wb') as stderr:
  process=subprocess.Popen(['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe',str(cli),'diff',entry['before'],entry['after'],'--depth','1','--format','json','--color','never'],cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore',stdout=stdout,stderr=stderr)
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait();raise
 assert code==0,stem.with_suffix('.err').read_text(encoding='utf-8')
 data=json.loads(stem.with_suffix('.json').read_text(encoding='utf-8'))
 print(entry['after'][:7],'roots',len(data['trees']),'diagnostics',len(data['diagnostics']),'elapsed',round(time.monotonic()-started,1),flush=True)
