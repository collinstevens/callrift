from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import document, flatten, rendered, manifest, schema, jsonschema

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus/Snapshots'
name = 'ocelot-route-claims-keys-msbuild-focused'
case = manifest['ocelot-route-claims-keys']
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/ocelot'
source_path = 'src/DependencyInjection/OcelotBuilder.cs'
expression = 'customBuilder ??= AddDefaultAspNetServices'
source = subprocess.check_output(['git', '-C', repository, 'show', case['after'] + ':' + source_path]).decode('utf-8-sig')
assert source.splitlines()[53].strip() == expression + ';'
blob = subprocess.check_output(['git', '-C', repository, 'rev-parse', case['after'] + ':' + source_path], text=True).strip()
before_path, after_path = [directory / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
before, after = document(before_path), document(after_path)
jsonschema.validate(after, schema)
is_new_guard = lambda node: node.get('label') == 'if (customBuilder is null)' and node.get('after') is not None
branches = [node for node in flatten(after['trees']) if is_new_guard(node)]
assert len(branches) == 1
branch = branches[0]
assert branch['kind'] == 'branch' and branch['change'] == 'added' and branch['before'] is None and branch['detail'] is None and branch['omission'] is None
location = {'path': source_path, 'startLine': 54, 'startColumn': 9, 'endLine': 54, 'endColumn': 9 + len(expression)}
assert branch['after'] == {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}
assert len(branch['children']) == 1 and branch['children'][0]['label'] == 'callback'

def normalized(value, unwrap=False):
    if isinstance(value, list):
        return [item for node in value for item in (normalized(node['children'], True) if unwrap and isinstance(node, dict) and is_new_guard(node) else [normalized(node, unwrap)])]
    if isinstance(value, dict):
        return {key: normalized(item, unwrap) for key, item in value.items() if key != 'id'}
    return value

expected = copy.deepcopy(before)
depth_nodes = [node for node in flatten(expected['trees']) if node['label'] == 'OcelotBuilder.AddDefaultAspNetServices' and node['change'] == 'added']
assert len(depth_nodes) == 1
node = depth_nodes[0]
assert node['detail'] is None and node['omission'] is None
assert [child['label'] for child in node['children']] == ['Services.AddMiddlewareAnalysis', 'Services.AddMiddlewareAnalysis().AddWebEncoders', 'builder.AddApplicationPart', 'builder.AddApplicationPart(assembly).AddControllersAsServices', 'builder.AddApplicationPart(assembly).AddControllersAsServices().AddNewtonsoftJson']
node.update(detail='changes below depth limit', omission={'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}, children=[])
assert normalized(expected) == normalized(after, True)
before_text_path, after_text_path = [directory / (name + '.' + suffix + '.txt') for suffix in ['verified', 'received']]
old_text, old_error = rendered(before_text_path)
new_text, new_error = rendered(after_text_path)
assert old_error == new_error
old = '+ ├─ callback\n+ │  └─ OcelotBuilder.AddDefaultAspNetServices\n+ │     ├─ Services.AddMiddlewareAnalysis\n+ │     ├─ Services.AddMiddlewareAnalysis().AddWebEncoders\n+ │     ├─ builder.AddApplicationPart\n+ │     ├─ builder.AddApplicationPart(assembly).AddControllersAsServices\n+ │     └─ builder.AddApplicationPart(assembly).AddControllersAsServices().AddNewtonsoftJson\n'
new = '+ ├─ if (customBuilder is null)\n+ │  └─ callback\n+ │     └─ OcelotBuilder.AddDefaultAspNetServices (changes below depth limit)\n'
assert old_text.count(old) == 1 and old_text.replace(old, new) == new_text
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
proof = {
    'view': name,
    'snapshotDirectory': directory.as_posix(),
    'afterRevision': case['after'],
    'sourcePath': source_path,
    'sourceBlob': blob,
    'conditionalBranch': branch['label'],
    'depthChanges': 1,
    'schemaV1': True,
    'allOtherPriorJsonPreservedExceptTraversalIds': True,
    'textAndMarkdownExactExpectedEdits': True,
    'review': 'The constructor selects its default method-group callback only if customBuilder is null. The new guard matches the exact after-source assignment span. The existing before-only coalescing-expression branch remains untouched. The added structural level puts the default callback method at the selected depth bound; its known changed descendants produce changes-below-depth-limit. Unwrapping only the new guard and applying this one explicit depth omission preserves every other JSON field except traversal IDs. Callback relationships, invocation order, source evidence, root matching, diagnostics and the existing before branch remain unchanged. Text and Markdown replace exactly the expanded added callback with the guard and depth-limited callback.',
    'files': {path.name: digest(path) for path in [after_path, after_text_path]},
    'baselineFiles': {path.name: digest(path) for path in [before_path, before_text_path]},
    'repeatStatus': 'pending'
}
(root / 'static-coalesce-ocelot-claims-restored-review.json').write_text(json.dumps({'views': [proof]}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed conditional default callback, existing before guard, and one exact depth omission.')
