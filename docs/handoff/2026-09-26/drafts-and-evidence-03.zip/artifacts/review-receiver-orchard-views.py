from pathlib import Path
import collections
import copy
import hashlib
import json
import re
import subprocess

directory = Path('artifacts/receiver-context-delegate-corpus/Snapshots')
trace_directory = Path('artifacts/receiver-context-review-trace')

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def canonical(value):
    value = copy.deepcopy(value)
    names = {node['id']: 'n' + str(index) for index, node in enumerate(nodes(value['trees']))}
    def replace(part):
        if isinstance(part, dict):
            for key, child in part.items():
                if key in ['id', 'referenceId'] and isinstance(child, str):
                    part[key] = names[child]
                else:
                    replace(child)
        elif isinstance(part, list):
            for child in part:
                replace(child)
    replace(value)
    return value

reports = []
for mode, counts in [('source', (82, 87)), ('msbuild', (31, 34))]:
    name = 'orchardcore-workflow-startup-' + mode + '-focused'
    before = read(directory / (name + '-json.verified.txt'))
    after = read(directory / (name + '-json.received.txt'))
    candidates = [copy.deepcopy(before), copy.deepcopy(after)]
    for index, candidate in enumerate(candidates):
        selected = [node for node in nodes(candidate['trees']) if node['label'] in ['IDisplayDriver<TModel, TDisplayContext, TEditorContext, TUpdateContext>.BuildEditorAsync', 'IDisplayResult.ApplyAsync']]
        assert len(selected) == 2
        assert len(selected[0]['children']) == counts[index]
        assert len(selected[1]['children']) == (2 if index == 0 else 4)
        for call in selected:
            seen = set()
            kept = []
            for node in call['children']:
                assert node['change'] == 'unchanged' and not node['children']
                assert node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
                key = json.dumps({key: value for key, value in node.items() if key != 'id'}, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    kept.append(node)
            assert len(kept) == 2
            call['children'] = kept
    if mode == 'source':
        removed = [diagnostic for diagnostic in before['diagnostics'] if diagnostic['code'] == 'generic-context-limit']
        assert len(removed) == 41
        assert [diagnostic for diagnostic in before['diagnostics'] if diagnostic['code'] != 'generic-context-limit'] == after['diagnostics']
        candidates[0]['diagnostics'] = after['diagnostics']
        candidates[0]['analysis']['limitations'].remove('generic-context-limit')
    assert canonical(candidates[0]) == canonical(candidates[1]), name
    text_path = directory / (name + '.received.txt')
    before_text = (directory / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    if mode == 'msbuild':
        assert not text_path.exists()
    else:
        after_text = text_path.read_text(encoding='utf-8-sig')
        pattern = r'format: (text|md)\nexit: 0\nstdout:\n(.*?)stderr:\n(.*?)(?=\nformat: (?:text|md)\n|\Z)'
        old_formats = re.findall(pattern, before_text, re.S)
        new_formats = re.findall(pattern, after_text, re.S)
        assert len(old_formats) == len(new_formats) == 2
        expected_error = ''.join((f"{d['location']['path']}:{d['location']['startLine']}: " if d.get('location') else '') + d['code'] + ': ' + d['message'] + '\n' for d in after['diagnostics'][:8])
        expected_error += f"{len(after['diagnostics']) - 8} additional diagnostics; use --diagnostics full.\n"
        for old, new in zip(old_formats, new_formats):
            assert old[:2] == new[:2]
            assert new[2].strip() == expected_error.strip()
    old_trace = Path('artifacts/generic-context-orchard-' + ('source-' if mode == 'source' else '') + 'bindings.log')
    old_targets = {json.loads(line)['Key'] for line in old_trace.read_text(encoding='utf-8-sig').splitlines()[1:]}
    trace_reviews = []
    for side in ['before', 'after']:
        path = trace_directory / ('orchard-workflow-' + mode + '-' + side + '.jsonl')
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        members = {row['Key']: row for row in rows[1:]}
        root = next(row for row in members.values() if row['Label'] == 'DisplayManager<TModel>.BuildEditorAsync' and 'IActivity<>' in row['Key'])
        call = next(call for call in root['Calls'] if call['Label'].startswith('IDisplayDriver'))
        assert len(call['Targets']) == counts[1]
        assert {target.split(';this=')[0] for target in call['Targets']} == old_targets
        groups = collections.defaultdict(list)
        for target in call['Targets']:
            groups[target.split(';this=')[0]].append(target)
        duplicates = [values for values in groups.values() if len(values) > 1]
        assert len(duplicates) == (5 if mode == 'source' else 3)
        assert all(len(values) == 2 for values in duplicates)
        allowed = ['ActivityDisplayDriver<', 'SectionDisplayDriver<', 'SectionDisplayDriverBase<']
        if mode == 'source':
            allowed.append('NotifyUserTaskActivityDisplayDriver<')
        assert all(any(label in target.split(';this=')[1] for label in allowed) for values in duplicates for target in values)
        shape_call = next(call for call in root['Calls'] if call['Label'] == 'IDisplayResult.ApplyAsync')
        assert len(shape_call['Targets']) == 4
        shape_targets = [target for target in shape_call['Targets'] if 'Views.ShapeResult.ApplyAsync' in target]
        assert len(shape_targets) == 3
        for target in shape_targets:
            implementation = next(call for call in members[target]['Calls'] if call['Label'] == 'ShapeResult.ApplyImplementationAsync')
            assert len(implementation['Targets']) == 1
            assert implementation['Targets'][0].split(';this=')[1] == target.split(';this=')[1]
        trace_reviews.append({**rows[0], 'side': side, 'duplicateDriverContexts': len(duplicates), 'shapeContexts': 3, 'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    reports.append({'view': name, 'driverContextsBefore': counts[0], 'driverContextsAfter': counts[1], 'shapeContexts': 3,
                    'existingGenericBindingsExactAfterRemovingReceiverIdentity': True,
                    'otherJsonExactAfterRemovingIdenticalDepthLimitedInstancesAndLimits': True,
                    'stdoutExact': True, 'removedLimits': 41 if mode == 'source' else 0,
                    'jsonSha256': hashlib.sha256((directory / (name + '-json.received.txt')).read_bytes()).hexdigest(),
                    'traces': trace_reviews})

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
revisions = ['0e50949dad6637c7e17214baeaa44df6f6be2dd8', 'ee892e7e9fb30305110504bf553dcf4265e6c02a']
paths = ['src/OrchardCore/OrchardCore.DisplayManagement/Handlers/DisplayDriver.cs', 'src/OrchardCore/OrchardCore.DisplayManagement/Views/ShapeResult.cs', 'src/OrchardCore/OrchardCore.DisplayManagement/Entities/SectionDisplayDriver.cs', 'src/OrchardCore/OrchardCore.DisplayManagement/Entities/SectionDisplayDriverBase.cs', 'src/OrchardCore/OrchardCore.Workflows.Abstractions/Display/ActivityDisplayDriver.cs', 'src/OrchardCore.Modules/OrchardCore.Notifications/Drivers/NotifyUserTaskActivityDisplayDriver.cs']
blobs = {}
for path in paths:
    ids = [subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip() for revision in revisions]
    assert ids[0] == ids[1]
    blobs[path] = ids[0]
report = {'coreSha256': hashlib.sha256((trace_directory / 'build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(), 'reviewedViews': reports, 'unchangedReviewedSourceBlobs': blobs, 'promoted': False}
Path('artifacts/receiver-context-orchard-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reports), 'promoted': False}))
