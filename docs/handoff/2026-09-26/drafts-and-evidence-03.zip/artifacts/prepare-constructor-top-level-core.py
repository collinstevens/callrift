from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/constructor-initialization-core'
target = root / 'artifacts/constructor-top-level-core'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(root / 'artifacts/constructor-top-level-original-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
path = target / 'Analysis/ConstructorBindings.cs'
content = path.read_text(encoding='utf-8')
old = 'var first = type.DeclaringSyntaxReferences[0];'
new = 'var first = type.DeclaringSyntaxReferences.First(reference => reference.GetSyntax(cancellationToken) is TypeDeclarationSyntax);'
assert content.count(old) == 1
path.write_text(content.replace(old, new), encoding='utf-8', newline='\n')
print('Prepared isolated top-level declaration correction; frozen constructor validation remains unchanged.')
