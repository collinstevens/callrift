```diff
  src/OrchardCore.Cms.Web/Program.cs::<top-level>
  ├─ HostBuilderExtensions.UseNLogHost
~ ├─ ServiceExtensions.AddOrchardCms (changes below depth limit)
  ├─ OrchardCoreBuilderExtensions.AddSetupFeatures (depth limit)
  └─ ApplicationBuilderExtensions.UseOrchardCore (depth limit)

  AdminMenuFilter.OnResultExecutionAsync
  ├─ …
  ├─ new NavigationArguments (depth limit)
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~ ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  └─ if (navigation is Shape shape)

  DashboardController.Index
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!(model.CanManageDashboard))
  └─ if (model.CanManageDashboard || await _authorizationService.AuthorizeAsync(User, Permissions.Acce…
     ├─ DashboardController.GetDashboardWidgetsAsync (depth limit)
     ├─ IAdminDashboardService.GetWidgetsAsync → AdminDashboardService.GetWidgetsAsync
     └─ foreach (var widget in widgets)
        ├─ if (!model.CanManageDashboard)
        ├─ new DashboardWrapper (depth limit)
~       └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  DashboardController.Manage
  ├─ …
  ├─ foreach (var ctd in widgetContentTypes.Values.OrderBy(x => x.DisplayName))
  ├─ IAdminDashboardService.GetWidgetsAsync → AdminDashboardService.GetWidgetsAsync
  ├─ foreach (var widget in widgets)
  │  ├─ if (!(!widgetContentTypes.ContainsKey(widget.ContentType)))
  │  ├─ new DashboardWrapper (depth limit)
~ │  └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ new AdminDashboardViewModel

  DashboardController.Update
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync ×2 (changes below depth limit)
  └─ foreach (var contentItem in latestItems)

  Migrations.CreateAsync
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  MenuController.List
  ├─ …
  ├─ Pager.GetStartIndex
  ├─ catch (Exception ex)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new AdminMenuListViewModel (depth limit)
  └─ results.Select

  NodeController.Create
  ├─ …
  ├─ IAdminMenuService.GetAdminMenuById → AdminMenuService.GetAdminMenuById
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.AdminNodeType) is not null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  NodeController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == type) is not null)
  ├─ new AdminNodeEditViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  NodeController.Edit
  ├─ …
  ├─ IAdminMenuService.GetAdminMenuById → AdminMenuService.GetAdminMenuById
  ├─ AdminMenu.GetMenuItemById (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ NotifierExtensions.ErrorAsync (depth limit)

  NodeController.Edit
  ├─ …
  ├─ AdminMenu.GetMenuItemById (depth limit)
  ├─ new AdminNodeEditViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  NodeController.List
  ├─ …
  ├─ IAdminMenuService.GetAdminMenuListAsync → AdminMenuService.GetAdminMenuListAsync (depth limit)
  ├─ IAdminMenuService.GetAdminMenuById → AdminMenuService.GetAdminMenuById
~ └─ NodeController.BuildDisplayViewModel (changes below depth limit)

+ new AdminMenuJSLocalizer

  AliasPartRazorHelperExtensions.GetContentItemByAliasAsync
  ├─ …
  ├─ if (latest)
  ├─ else (!(latest))
~ └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)

  AdminController.Display
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IAuditTrailManager.GetEventAsync → AuditTrailManager.GetEventAsync
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  └─ new AuditTrailItemViewModel

  AdminController.Index
  ├─ …
  ├─ new Pager (depth limit)
  ├─ IAuditTrailAdminListQueryService.QueryAsync → DefaultAuditTrailAdminListQueryService.QueryAsync (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var auditTrailEvent in result.Events)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync [interceptor in AdminController.Index] (changes below depth limit)

  AdminController.IndexFilterPOST
~ └─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync ×2 (changes below depth limit)

  AutoSetupMiddleware.InvokeAsync
  ├─ if (_setupOptions is not null)
  └─ if (_setupOptions is not null && _shellSettings.IsUninitialized())
     ├─ DistributedLockExtensions.TryAcquireAutoSetupLockAsync (depth limit)
     ├─ ShellSettingsExtensions.IsUninitialized
     └─ if (_shellSettings.IsUninitialized())
        ├─ IShellSettingsManager.LoadSettingsAsync
~       │  ├─ ⇢ ShellSettingsManager.LoadSettingsAsync (changes below depth limit)
        │  └─ ⇢ SingleShellSettingsManager.LoadSettingsAsync (depth limit)
        ├─ if (settings != null)
        │  ├─ ShellSettingsExtensions.AsDisposable
        │  ├─ ShellSettingsExtensions.IsUninitialized
        │  └─ if (!settings.IsUninitialized())
~       │     └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
~       ├─ IAutoSetupService.SetupTenantAsync → AutoSetupService.SetupTenantAsync (changes below depth limit)
        └─ if (isSuccess)
           └─ if (_setupOptions.IsDefault)
              └─ foreach (var setupOptions in _options.Tenants)
                 └─ if (_setupOptions != setupOptions)
~                   └─ IAutoSetupService.CreateTenantSettingsAsync → AutoSetupService.CreateTenantSettingsAsync (changes below depth limit)

  AutoroutePartRazorHelperExtensions.GetContentItemBySlugAsync
  ├─ …
  ├─ if (latest)
  ├─ else (!(latest))
~ └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ ShellFeaturesManagerExtensions.IsFeatureEnabledAsync (depth limit)
~    └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  AzureAISearchIndexSettingsMigrations.UpdateFrom1
  ├─ ShellSettingsExtensions.IsInitializing
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     ├─ AzureAISearchIndexSettingsMigrations.GetDefaultSearchFields
     └─ foreach (var indexObject in indexesObject)
~       ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
        ├─ IIndexNameProvider.GetFullIndexName
        ├─ if (properties is not null && properties.Count > 0)
        ├─ …
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ EntityExtensions.Put (depth limit)
~       ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
        └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Azure AI Search")

  BackgroundTaskController.Index
  ├─ …
  ├─ _backgroundTasks.Select
  ├─ new Pager (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new BackgroundTaskIndexViewModel
  └─ Pager.GetStartIndex

  ContentPickerAdminController.SearchContentItems
  ├─ …
  ├─ if (fieldSettings.DisplayedStereotypes != null && fieldSettings.DisplayedStereotypes.Length > 0)
  ├─ new ContentPickerSearchContext
  ├─ IContentPickerResultProvider.Search
~ │  ├─ ⇢ DefaultContentPickerResultProvider.Search (changes below depth limit)
  │  ├─ ⇢ LuceneContentPickerResultProvider.Search (depth limit)
  │  └─ ⇢ ElasticsearchContentPickerResultProvider.Search (depth limit)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ foreach (var result in results)

  LocalizationSetContentPickerAdminController.SearchLocalizationSets
  ├─ IContentDefinitionManager.GetPartDefinitionAsync → ContentDefinitionManager.GetPartDefinitionAsync (depth limit)
  ├─ if (partFieldDefinition is not null)
~ ├─ IContentLocalizationManager.DeduplicateContentItemsAsync → DefaultContentLocalizationManager.DeduplicateContentItemsAsync (changes below depth limit)
  └─ foreach (var contentItem in cleanedContentItems)
     ├─ possible initialization of CommonPermissions
     ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
     └─ if (await _authorizationService.AuthorizeAsync(_httpContextAccessor.HttpContext.User, CommonPermi…
        ├─ new VueMultiselectItemViewModel
        ├─ ContentItem.ToString
~       └─ ContentManagerExtensions.HasPublishedVersionAsync (changes below depth limit)

  new HtmlFieldQueryObjectType
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
~    └─ HtmlFieldQueryObjectType.RenderHtml (changes below depth limit)

+ new ContentFieldsJSLocalizer

  AdminController.Localize
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of ContentLocalizationPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ …
  ├─ IContentLocalizationManager.GetContentItemAsync → DefaultContentLocalizationManager.GetContentItemAsync
  ├─ if (alreadyLocalizedContent != null)
  ├─ try
~ │  ├─ IContentLocalizationManager.LocalizeAsync → DefaultContentLocalizationManager.LocalizeAsync (changes below depth limit)
  │  └─ NotifierExtensions.InformationAsync (depth limit)
  └─ catch (InvalidOperationException)

  ContentCulturePickerController.RedirectToLocalizedContent
  ├─ ILocalizationService.GetSupportedCulturesAsync
~ │  ├─ ⇢ LocalizationService.GetSupportedCulturesAsync (changes below depth limit)
~ │  └─ ⇢ DefaultLocalizationService.GetSupportedCulturesAsync (changes below depth limit)
  ├─ if (supportedCultures.Any(t => t == targetCulture))
  └─ ControllerBaseExtensions.LocalRedirect (depth limit)

  PreviewController.Display
  ├─ …
  ├─ possible initialization of ContentPreviewFeature
  ├─ IContentManagerSession.Store → DefaultContentManagerSession.Store
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  PreviewController.Draft
  ├─ …
  ├─ possible initialization of ContentPreviewFeature
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ new PreviewAspect
~ ├─ IContentManager.PopulateAspectAsync → DefaultContentManager.PopulateAspectAsync (changes below depth limit)
  ├─ new PreviewDraft
  ├─ possible initialization of JOptions
  └─ …

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.GetTypeAsync (depth limit)
~ └─ IContentDefinitionDisplayManager.BuildTypeEditorAsync → DefaultContentDefinitionDisplayManager.BuildTypeEditorAsync (changes below depth limit)

  AdminController.EditField
  ├─ …
  ├─ ContentPartFieldSettingsExtensions.DisplayMode (depth limit)
  ├─ ContentPartFieldSettingsExtensions.DisplayName (depth limit)
~ └─ IContentDefinitionDisplayManager.BuildPartFieldEditorAsync → DefaultContentDefinitionDisplayManager.BuildPartFieldEditorAsync (changes below depth limit)

  AdminController.EditFieldPOST
  ├─ …
  ├─ IContentDefinitionManager.LoadPartDefinitionAsync → ContentDefinitionManager.LoadPartDefinitionAsync (depth limit)
  ├─ ContentPartFieldSettingsExtensions.DisplayName (depth limit)
  ├─ if (field.DisplayName() != viewModel.DisplayName)
  │  ├─ AdminController.LoadPartAsync (depth limit)
  │  ├─ (await LoadPartAsync(partViewModel.Name)).PartDefinition.Fields.Any
  │  ├─ if (!ModelState.IsValid)
~ │  │  ├─ IContentDefinitionDisplayManager.UpdatePartFieldEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartFieldEditorAsync (changes below depth limit)
  │  │  └─ IDocumentStore.CancelAsync
  │  └─ NotifierExtensions.InformationAsync (depth limit)
  ├─ new AlterFieldContext
  ├─ IContentDefinitionService.AlterFieldAsync → ContentDefinitionService.AlterFieldAsync (depth limit)
  ├─ IContentDefinitionManager.LoadPartDefinitionAsync → ContentDefinitionManager.LoadPartDefinitionAsync (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdatePartFieldEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartFieldEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ else (!(!ModelState.IsValid))
  └─ …

  AdminController.EditPart
  ├─ …
  ├─ IContentDefinitionManager.GetPartDefinitionAsync → ContentDefinitionManager.GetPartDefinitionAsync (depth limit)
  ├─ new EditPartViewModel (depth limit)
~ └─ IContentDefinitionDisplayManager.BuildPartEditorAsync → DefaultContentDefinitionDisplayManager.BuildPartEditorAsync (changes below depth limit)

  AdminController.EditPartPOST
  ├─ …
  ├─ IContentDefinitionManager.LoadPartDefinitionAsync → ContentDefinitionManager.LoadPartDefinitionAsync (depth limit)
  ├─ new EditPartViewModel (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdatePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  └─ else (!(!ModelState.IsValid))

  AdminController.EditPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IContentDefinitionManager.LoadTypeDefinitionAsync → ContentDefinitionManager.LoadTypeDefinitionAsync (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdateTypeEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypeEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  └─ else (!(!ModelState.IsValid))

  AdminController.EditTypePart
  ├─ …
  ├─ ContentTypePartExtensions.DisplayName (depth limit)
  ├─ ContentTypePartExtensions.Description (depth limit)
~ └─ IContentDefinitionDisplayManager.BuildTypePartEditorAsync → DefaultContentDefinitionDisplayManager.BuildTypePartEditorAsync (changes below depth limit)

  AdminController.EditTypePartPOST
  ├─ …
  ├─ IContentDefinitionManager.LoadTypeDefinitionAsync → ContentDefinitionManager.LoadTypeDefinitionAsync (depth limit)
  ├─ ContentPartSettingsExtensions.IsReusable (depth limit)
  ├─ if (part.PartDefinition.IsReusable())
  │  ├─ ContentTypePartExtensions.DisplayName (depth limit)
  │  └─ if (part.DisplayName() != viewModel.DisplayName)
  │     ├─ typeDefinition.Parts.Any
  │     └─ if (!ModelState.IsValid)
~ │        ├─ IContentDefinitionDisplayManager.UpdateTypePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypePartEditorAsync (changes below depth limit)
  │        └─ IDocumentStore.CancelAsync
  ├─ else (!(part.PartDefinition.IsReusable()))
  ├─ new AlterTypePartContext
  ├─ IContentDefinitionService.AlterTypePartAsync → ContentDefinitionService.AlterTypePartAsync (depth limit)
  ├─ IContentDefinitionManager.LoadTypeDefinitionAsync → ContentDefinitionManager.LoadTypeDefinitionAsync (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdateTypePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypePartEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  └─ else (!(!ModelState.IsValid))

  ContentRazorHelperExtensions.GetContentItemByHandleAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemByHandleAsync (changes below depth limit)

  ContentRazorHelperExtensions.GetContentItemByIdAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemByIdAsync (changes below depth limit)

  ContentRazorHelperExtensions.GetContentItemsByIdAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemsByIdAsync (changes below depth limit)

- new AdminMenuDataLocalizationStartup
- └─ new StartupBase

  AuditTrailContentController.Display
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ContentItemExtensions.TryGet (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AuditTrailContentController.Restore
  ├─ …
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IContentManager.RestoreAsync → DefaultContentManager.RestoreAsync (changes below depth limit)
  ├─ if (!result.Succeeded)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  ContentOrchardHelperExtensions.EditForLinkAsync
  ├─ ContentOrchardHelperExtensions.MakeHtmlHelper
~ ├─ ContentManagerExtensions.PopulateAspectAsync (changes below depth limit)
  └─ metadata.EditorRouteValues["action"].ToString

  AdminController.Clone
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ try
~ │  └─ IContentManager.CloneAsync → DefaultContentManager.CloneAsync (changes below depth limit)
  ├─ catch (InvalidOperationException)
  ├─ NotifierExtensions.InformationAsync (depth limit)
  └─ …

  AdminController.Create
  ├─ …
  ├─ AdminController.CurrentUserId
  ├─ AuthorizationServiceExtensions.AuthorizeContentTypeAsync (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.CreateAndPublishPOST
  ├─ …
  ├─ AdminController.CurrentUserId
  ├─ AuthorizationServiceExtensions.AuthorizeContentTypeAsync (depth limit)
  └─ AdminController.CreateInternalAsync (changes below depth limit)
~    ├─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
     └─ if (await _contentManager.PublishAsync(contentItem))

  AdminController.CreatePOST
  └─ AdminController.CreateInternalAsync (changes below depth limit)
~    ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
     ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
     └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Delete
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  ├─ if (removed)
  ├─ else (!(removed))
  └─ …

  AdminController.DiscardDraft
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ ├─ IContentManager.DiscardDraftAsync → DefaultContentManager.DiscardDraftAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
  └─ …

  AdminController.Display
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  AdminController.Edit
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.EditAndPublishPOST
~ └─ AdminController.PublishOrUnpublishAsync (changes below depth limit)

  AdminController.EditAndUnpublishPOST
~ └─ AdminController.PublishOrUnpublishAsync (changes below depth limit)

  AdminController.EditPOST
  └─ AdminController.EditInternalAsync (changes below depth limit)
~    ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
     ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
     └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.List
  ├─ …
  ├─ IContentsAdminListQueryService.QueryAsync → DefaultContentsAdminListQueryService.QueryAsync (depth limit)
  ├─ new Pager (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ Pager.GetStartIndex
  ├─ ContentQueryExtensions.ListAsync (depth limit)
  ├─ foreach (var contentItem in pageOfContentItems)
~ │  └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync [interceptor in AdminController.List] (changes below depth limit)

  AdminController.ListFilterPOST
~ └─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)

  AdminController.ListPOST
  └─ if (itemIds.Length > 0)
     ├─ ContentQueryOfTIndexExtensions.ListAsync (depth limit)
     ├─ case ContentsBulkAction.PublishNow:
     │  ├─ foreach (var item in checkedContentItems)
     │  │  ├─ possible initialization of CommonPermissions
     │  │  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
     │  │  ├─ if (await _authorizationService.AuthorizeAsync(User, CommonPermissions.PublishContent, item)is va…
     │  │  │  └─ if (authorized)
~    │  │  │     └─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
     │  │  └─ if (await _authorizationService.AuthorizeAsync(User, CommonPermissions.PublishContent, item)is va…
     │  └─ NotifierExtensions.SuccessAsync (depth limit)
     ├─ case ContentsBulkAction.Unpublish:
     │  ├─ foreach (var item in checkedContentItems)
     │  │  ├─ possible initialization of CommonPermissions
     │  │  ├─ AdminController.IsAuthorizedAsync (depth limit)
     │  │  ├─ if (await IsAuthorizedAsync(CommonPermissions.PublishContent, item)is var authorized)
     │  │  │  └─ if (authorized)
~    │  │  │     └─ IContentManager.UnpublishAsync → DefaultContentManager.UnpublishAsync (changes below depth limit)
     │  │  └─ if (await IsAuthorizedAsync(CommonPermissions.PublishContent, item)is var authorized && !(authori…
     │  └─ NotifierExtensions.SuccessAsync (depth limit)
     └─ case ContentsBulkAction.Remove:
        ├─ foreach (var item in checkedContentItems)
        │  ├─ possible initialization of CommonPermissions
        │  ├─ AdminController.IsAuthorizedAsync (depth limit)
        │  ├─ if (await IsAuthorizedAsync(CommonPermissions.DeleteContent, item)is var authorized)
        │  │  └─ if (authorized)
~       │  │     └─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
        │  └─ if (await IsAuthorizedAsync(CommonPermissions.DeleteContent, item)is var authorized && !(authoriz…
        └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Publish
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ ├─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ if (published)
  └─ …

  AdminController.Remove
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (contentItem != null)
~ │  ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  │  ├─ if (removed)
  │  └─ else (!(removed))
  └─ if (Url.IsLocalUrl(returnUrl))

  AdminController.Unpublish
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AdminController.IsAuthorizedAsync (depth limit)
~ ├─ IContentManager.UnpublishAsync → DefaultContentManager.UnpublishAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ if (unpublished)
  └─ …

  ItemController.Display
~ ├─ ContentManagerExtensions.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, CommonPermissions.ViewContent, contentItem))
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  ItemController.Preview
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, CommonPermissions.PreviewContent, contentIt…
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

+ new DataLocalizationAdminMenuStartup
+ └─ new StartupBase

  AddToDeploymentPlanController.AddContentItem
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (await _authorizationService.AuthorizeAsync(User, DeploymentPermissions.ManageDeploymentPlan))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ …

  DownloadController.Display
  ├─ …
  ├─ if (latest == false)
  ├─ else (!(latest == false))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ …

  DownloadController.Download
  ├─ …
  ├─ if (latest == false)
  ├─ else (!(latest == false))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of CommonPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ …

  ExportContentToDeploymentTargetMigrations.CreateAsync
~ ├─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)
  ├─ IDeploymentPlanService.GetAllDeploymentPlansAsync → DeploymentPlanService.GetAllDeploymentPlansAsync (depth limit)
  └─ if (exportContentToDeploymentTargetPlan != null)

  CreateEndpoint.HandleAsync
  ├─ …
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  │  ├─ …
  │  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.PublishContent…
  │  ├─ ContentItemExtensions.Merge (depth limit)
~ │  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (changes below depth limit)
  │  ├─ if (result.Succeeded)
~ │  │  └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  │  └─ else (!(result.Succeeded))
  ├─ else (!(contentItem == null))
  │  ├─ …
  │  ├─ possible initialization of CreateEndpoint
  │  ├─ ContentItemExtensions.Merge (depth limit)
~ │  ├─ IContentManager.UpdateAsync → DefaultContentManager.UpdateAsync (changes below depth limit)
~ │  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (changes below depth limit)
  │  └─ if (!result.Succeeded)
  ├─ if (!draft)
~ │  └─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  └─ else (!(!draft))
~    └─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)

  DeleteEndpoint.HandleAsync
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.DeleteContent,…
~ └─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)

  GetEndpoint.HandleAsync
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.ViewContent, c…

  new ContentMethodsProvider
  ├─ …
  ├─ callback
  ├─ new GlobalMethod
  ├─ callback ×2
  │  └─ callback
~ │     └─ ContentMethodsProvider.CreateContentItemAsync (changes below depth limit)
  ├─ new GlobalMethod
  ├─ callback ×2
  │  └─ callback
~ │     └─ ContentMethodsProvider.UpdateContentItemAsync (changes below depth limit)
  ├─ new GlobalMethod
  └─ callback ×2
     └─ callback
~       └─ ContentMethodsProvider.DeleteContentItemAsync (changes below depth limit)

  DisplayContentItemViewComponent.InvokeAsync
  ├─ if (contentItemId != null)
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  AdminController.IndexPOST
  ├─ …
  ├─ new CorsSettings
  ├─ CorsService.UpdateSettingsAsync (depth limit)
~ ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

+ new CorsJSLocalizer

  AdminController.GetAllowedCulturesJson
~ └─ AdminController.GetAllowedCulturesAsync (changes below depth limit)

  AdminController.GetStatisticsJson
  ├─ possible initialization of DataLocalizationPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ AdminController.GetStatisticsAsync (changes below depth limit)

  AdminController.GetStrings
  ├─ possible initialization of DataLocalizationPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ AdminController.GetTranslatableStringsAsync (changes below depth limit)

  AdminController.Index
~ ├─ AdminController.HasAnyTranslationPermissionAsync (changes below depth limit)
~ ├─ AdminController.GetAllowedCulturesAsync (changes below depth limit)
  ├─ new TranslationEditorViewModel
~ └─ AdminController.GetTranslatableStringsAsync (changes below depth limit)

  AdminController.Statistics
  ├─ possible initialization of DataLocalizationPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ AdminController.GetStatisticsAsync (changes below depth limit)

  ExportRemoteInstanceController.Execute
  ├─ …
  ├─ new RecipeDescriptor
  ├─ new DeploymentPlanResult (depth limit)
~ ├─ IDeploymentManager.ExecuteDeploymentPlanAsync → DeploymentManager.ExecuteDeploymentPlanAsync (changes below depth limit)
  ├─ try
  └─ if (!string.IsNullOrEmpty(returnUrl))

  ImportRemoteInstanceController.Import
  ├─ …
  ├─ ITempDirectoryProvider.GetTempFileName → DefaultTempDirectoryProvider.GetTempFileName ×2 (depth limit)
  ├─ try
  │  ├─ …
  │  ├─ new FileCreatingContext
  │  ├─ FileCreationService.CreateAsync (depth limit)
~ │  └─ IDeploymentManager.ImportDeploymentPackageAsync → DeploymentManager.ImportDeploymentPackageAsync (changes below depth limit)
  ├─ catch (RecipeExecutionException e)
  └─ catch (Exception e)

  RemoteClientController.Index
  ├─ …
  ├─ RemoteClientService.GetRemoteClientListAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ new RemoteClientIndexViewModel (depth limit)

  RemoteInstanceController.Index
  ├─ …
  ├─ RemoteInstanceService.GetRemoteInstanceListAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ new RemoteInstanceIndexViewModel (depth limit)

  DeploymentPlanController.Display
  ├─ possible initialization of DeploymentPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ foreach (var step in deploymentPlan.DeploymentSteps)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ foreach (var factory in _factories.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
  │  ├─ IDeploymentStepFactory.Create
~ │  ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  │  ├─ new DisplayDeploymentPlanThumbnailViewModel
  │  └─ StringExtensions.HtmlClassify (depth limit)
  ├─ new DisplayDeploymentPlanViewModel
  └─ thumbnails.Where(x => !string.IsNullOrWhiteSpace(x.Category)).Select

  DeploymentPlanController.Index
  ├─ …
  ├─ new Pager (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new DeploymentPlanIndexViewModel (depth limit)
  └─ results.Select

  ExportFileController.Execute
  ├─ …
  ├─ new RecipeDescriptor
  ├─ new DeploymentPlanResult (depth limit)
~ └─ IDeploymentManager.ExecuteDeploymentPlanAsync → DeploymentManager.ExecuteDeploymentPlanAsync (changes below depth limit)

  ImportController.Import
  ├─ possible initialization of DeploymentPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (importedPackage != null)
  │  ├─ ITempDirectoryProvider.GetTempFileName → DefaultTempDirectoryProvider.GetTempFileName ×2 (depth limit)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ if (!fileCreatingResult.Succeeded)
  │  │  ├─ else (!(importedPackage.FileName.EndsWith(".zip")))
~ │  │  ├─ IDeploymentManager.ImportDeploymentPackageAsync → DeploymentManager.ImportDeploymentPackageAsync (changes below depth limit)
  │  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  │  ├─ catch (RecipeExecutionException e)
  │  └─ catch (Exception e)
  └─ else (!(importedPackage != null))

  ImportController.Json
  ├─ …
  ├─ possible initialization of JOptions
  ├─ StringExtensions.IsJson
  └─ if (ModelState.IsValid)
     ├─ ITempDirectoryProvider.CreateTempSubdirectory → DefaultTempDirectoryProvider.CreateTempSubdirectory (depth limit)
     └─ try
~       ├─ IDeploymentManager.ImportDeploymentPackageAsync → DeploymentManager.ImportDeploymentPackageAsync (changes below depth limit)
        └─ NotifierExtensions.SuccessAsync (depth limit)

  StepController.Create
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.DeploymentStepType) is not null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  StepController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == type) is not null)
  ├─ new EditDeploymentPlanStepViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  StepController.Edit
  ├─ possible initialization of DeploymentPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ NotifierExtensions.ErrorAsync (depth limit)

  StepController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ new EditDeploymentPlanStepViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.QueryIndex
  ├─ …
  ├─ new AdminQueryViewModel
  ├─ else (!(string.IsNullOrWhiteSpace(query)))
~ └─ AdminController.Query (changes below depth limit)

  ElasticsearchApiController.Content
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.QueryElasticApi))
~ └─ ElasticsearchApiController.ElasticQueryApiAsync (changes below depth limit)

  ElasticsearchApiController.ContentPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.QueryElasticApi))
~ └─ ElasticsearchApiController.ElasticQueryApiAsync (changes below depth limit)

  ElasticsearchApiController.Documents
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.QueryElasticApi))
~ └─ ElasticsearchApiController.ElasticQueryApiAsync (changes below depth limit)

  ElasticsearchApiController.DocumentsPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.QueryElasticApi))
~ └─ ElasticsearchApiController.ElasticQueryApiAsync (changes below depth limit)

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  IndexingMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     ├─ IndexingMigrations.GetDefaultSearchFields
     ├─ foreach (var indexObject in indexesObject)
     │  ├─ IIndexNameProvider.GetFullIndexName
~    │  ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
     │  ├─ while (await indexProfileManager.FindByNameAsync(indexProfile.Name)is not null)
     │  ├─ EntityExtensions.GetOrCreate (depth limit)
     │  ├─ …
     │  ├─ EntityExtensions.GetOrCreate (depth limit)
     │  ├─ EntityExtensions.Put (depth limit)
~    │  ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
     │  └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Elasticsearch")
~    ├─ IndexingMigrations.UpdateLegacyAnalyzerNameAsync (changes below depth limit)
     └─ IndexingMigrations.EnsureDefaultSearchSiteSettingAsync (depth limit)

  IndexingMigrations.UpdateFrom1
  └─ ShellScope.AddDeferredTask (depth limit)
~    └─ IndexingMigrations.UpdateLegacyAnalyzerNameAsync (changes below depth limit)

  EmailMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
     ├─ if (!(!string.IsNullOrEmpty(smtpSettings.DefaultSender)))
     └─ if (!string.IsNullOrEmpty(smtpSettings.DefaultSender) || scope.ServiceProvider.GetService<IOption…
~       └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  WidgetMigrations.CreateAsync
  ├─ ContentDefinitionManagerExtensions.AlterPartDefinitionAsync (depth limit)
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  AdminController.Disable
  ├─ possible initialization of FeaturesPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.ExecuteAsync (changes below depth limit)
~ │  ├─ FeatureService.GetAvailableFeature (changes below depth limit)
  │  ├─ if (!isProxy && id == FeaturesConstants.FeatureId)
~ │  └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit)
  │     └─ AdminController.NotifyAsync (depth limit)
  └─ AdminController.GetNextUrl (depth limit)

  AdminController.Enable
  ├─ possible initialization of FeaturesPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.ExecuteAsync (changes below depth limit)
~ │  ├─ FeatureService.GetAvailableFeature (changes below depth limit)
~ │  └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit) ↑ as above
  └─ AdminController.GetNextUrl (depth limit)

  AdminController.Features
  ├─ possible initialization of FeaturesPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ if (ModelState.IsValid)
     └─ AdminController.ExecuteAsync (changes below depth limit)
~       ├─ FeatureService.GetAvailableFeatures (changes below depth limit)
~       └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit) ↑ as above

  AdminController.Features
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ new FeaturesViewModel
  └─ AdminController.ExecuteAsync (changes below depth limit)
~    └─ FeatureService.GetModuleFeaturesAsync (changes below depth limit)

  ModuleService.DisableFeaturesAsync
~ └─ ModuleService.DisableFeaturesAsync (changes below depth limit)

  ModuleService.EnableFeaturesAsync
~ └─ ModuleService.EnableFeaturesAsync (changes below depth limit)

  FeedController.Index
  ├─ new FeedContext (depth limit)
  ├─ _feedFormatProviders.Select
  ├─ foreach (var provider in _feedQueryProviders)
~ │  └─ IFeedQueryProvider.MatchAsync → ListFeedQuery.MatchAsync (changes below depth limit)
  └─ IFeedBuilder.ProcessAsync → RssFeedBuilder.ProcessAsync
~    ├─ IFeedQuery.ExecuteAsync → ListFeedQuery.ExecuteAsync (changes below depth limit)
~    ├─ IFeedItemBuilder.PopulateAsync → CommonFeedItemBuilder.PopulateAsync (changes below depth limit)
     └─ foreach (var contextualizer in context.Response.Contextualizers)

  AdminController.BuildEditor
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ if (flowMetadata)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  └─ new BuildEditorViewModel

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

+ new FormsJSLocalizer

  new HtmlBodyQueryObjectType
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
~    └─ HtmlBodyQueryObjectType.RenderHtml (changes below depth limit)

  AdminController.Create
  ├─ …
  ├─ new IndexProfileKey
  ├─ if (!_indexingOptions.Sources.TryGetValue(new IndexProfileKey(providerName, type), out var service))
~ ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ new IndexProfileKey
  ├─ if (!_indexingOptions.Sources.TryGetValue(new IndexProfileKey(providerName, type), out var service))
~ ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IIndexProfileManager.ValidateAsync → DefaultIndexProfileManager.ValidateAsync (depth limit)
  └─ if (ModelState.IsValid)
     ├─ if (indexManager is null)
~    ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
     ├─ IIndexManager.CreateAsync
     ├─ if (!await indexManager.CreateAsync(indexProfile))
~    ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
     └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Edit
  ├─ …
  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
  ├─ new ModelViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.EditPost
  ├─ …
  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IIndexProfileManager.ValidateAsync → DefaultIndexProfileManager.ValidateAsync (depth limit)
  └─ if (ModelState.IsValid)
~    ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
     └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Index
  ├─ …
  ├─ _indexingOptions.Sources.Select(x => new { Source = x.Key, ProviderName = x.Value.ProviderName, }).OrderBy(x => x.ProviderName, StringComparer.OrdinalIgnoreCase).ThenBy(x => x.Source.Type).GroupBy(x => x.ProviderName, StringComparer.OrdinalIgnoreCase).Select
  ├─ new AdminIndexViewModel (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ foreach (var record in result.Models)
     ├─ new ModelEntry<T>
~    └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)

  AdminController.IndexPost
  ├─ possible initialization of IndexingPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ if (itemIds?.Any() == true)
     ├─ case IndexingEntityAction.Remove:
     ├─ case IndexingEntityAction.Reset:
     │  ├─ foreach (var id in itemIds)
     │  │  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
     │  │  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~    │  │  ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~    │  │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
     │  ├─ if (resetCounter == 0)
     │  └─ else (!(resetCounter == 0))
     ├─ case IndexingEntityAction.Synchronize:
     │  ├─ foreach (var id in itemIds)
     │  │  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
~    │  │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
     │  ├─ if (synchronizedCounter == 0)
     │  └─ else (!(synchronizedCounter == 0))
     └─ case IndexingEntityAction.Rebuild:
        ├─ foreach (var id in itemIds)
        │  ├─ …
        │  ├─ IIndexManager.RebuildAsync
        │  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~       │  ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~       │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
        ├─ if (rebuildCounter == 0)
        └─ else (!(rebuildCounter == 0))

  AdminController.Rebuild
  ├─ …
  ├─ if (indexManager is null)
  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
  ├─ IIndexManager.RebuildAsync
  ├─ if (await indexManager.RebuildAsync(indexProfile))
~ │  ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  └─ else (!(await indexManager.RebuildAsync(indexProfile)))

  AdminController.Reset
  ├─ …
  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~ ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Synchronize
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
~ ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  WorkerFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ ShellFeaturesManagerExtensions.IsFeatureEnabledAsync (depth limit)
     ├─ if (!(await featuresManager.IsFeatureEnabledAsync("OrchardCore.Search.Elasticsearch.Worker")))
~    └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ILayerService.GetLayersAsync → LayerService.GetLayersAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ foreach (var factory in _conditionFactories)
  │  ├─ IConditionFactory.Create → ConditionFactory<TCondition>.Create
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  └─ new LayerEditViewModel

  AdminController.Index
  ├─ …
  ├─ IContentDefinitionManager.ListTypeDefinitionsAsync → ContentDefinitionManager.ListTypeDefinitionsAsync (depth limit)
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  └─ foreach (var widget in widgets.OrderBy(x => x.Position))
     ├─ if (contentDefinitions.Any(c => c.Name == widget.ContentItem.ContentType))
~    │  └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
     └─ else (!(contentDefinitions.Any(c => c.Name == widget.ContentItem.ContentType)))

  AdminController.UpdatePosition
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ ContentItemExtensions.Apply (depth limit)
  ├─ ContentExtensions.IsPublished
  ├─ if (contentItem.IsPublished() == false)
~ │  ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  │  └─ if (publishedContentItem != null)
  ├─ new LayerState (depth limit)
  └─ IDocumentManager<TDocument>.UpdateAsync → DocumentManager<TDocument>.UpdateAsync (depth limit)

  LayerRuleController.Create
  ├─ …
  ├─ LayerRuleController.FindConditionGroup (depth limit)
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.ConditionType) is not null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  LayerRuleController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == type) is not null)
  ├─ new LayerRuleCreateViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  LayerRuleController.Edit
  ├─ …
  ├─ ILayerService.LoadLayersAsync → LayerService.LoadLayersAsync (depth limit)
  ├─ LayerRuleController.FindCondition (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ NotifierExtensions.ErrorAsync (depth limit)

  LayerRuleController.Edit
  ├─ …
  ├─ LayerRuleController.FindCondition (depth limit)
  ├─ new LayerRuleEditViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  LayerFilter.OnResultExecutionAsync
  ├─ ResultExecutingContextExtensions.IsViewOrPageResult
  ├─ if (context.IsViewOrPageResult())
  └─ if (context.IsViewOrPageResult() && !AdminAttribute.IsApplied(context.HttpContext))
     ├─ …
     ├─ if (!_memoryCache.TryGetValue<CacheEntry>(WidgetsKey, out var cacheEntry) || cacheEntry.Identifie…
     ├─ ILayerService.GetLayersAsync → LayerService.GetLayersAsync (depth limit)
~    ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
     ├─ ContentDefinitionManagerExtensions.ListWidgetTypeDefinitionsAsync (depth limit)
     └─ foreach (var widget in widgets)
        ├─ if (!layersCache.TryGetValue(layer.Name, out display))
        ├─ if (widgetDefinitions.TryGetValue(widget.ContentItem.ContentType, out var definition))
        └─ if (widgetDefinitions.TryGetValue(widget.ContentItem.ContentType, out var definition) && (!defini…
           ├─ ContentItemExtensions.Clone (depth limit)
~          ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
           ├─ StringExtensions.HtmlClassify (depth limit)
           ├─ new WidgetWrapper (depth limit)
           └─ …

  LiquidRazorHelperExtensions.LiquidToHtmlAsync
~ └─ LiquidRazorHelperExtensions.LiquidToHtmlAsync (changes below depth limit)

  OrderController.UpdateContentItemOrders
  ├─ …
  ├─ foreach (var pagedContentItem in pageOfContentItems)
  ├─ ContentItemExtensions.TryGet (depth limit)
~ └─ IContainerService.UpdateContentItemOrdersAsync → ContainerService.UpdateContentItemOrdersAsync (changes below depth limit)

  RemotePublishingController.Rsd
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ ContentItemExtensions.TryGet (depth limit)

  new ContainedQueryObjectType
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
~    └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)

  new LocalizationSettings
  └─ possible initialization of LocalizationSettings
~    └─ initialization of LocalizationSettings (body changed; visible calls unchanged)

+ new LocalizationJSLocalizer

  AdminController.QueryIndex
  ├─ …
  ├─ new AdminQueryViewModel
  ├─ else (!(string.IsNullOrWhiteSpace(query)))
~ └─ AdminController.Query (changes below depth limit)

  LuceneApiController.Content
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, LuceneSearchPermissions.QueryLuceneApi))
~ └─ LuceneApiController.LuceneQueryApiAsync (changes below depth limit)

  LuceneApiController.ContentPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, LuceneSearchPermissions.QueryLuceneApi))
~ └─ LuceneApiController.LuceneQueryApiAsync (changes below depth limit)

  LuceneApiController.Documents
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, LuceneSearchPermissions.QueryLuceneApi))
~ └─ LuceneApiController.LuceneQueryApiAsync (changes below depth limit)

  LuceneApiController.DocumentsPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ if (!await _authorizationService.AuthorizeAsync(User, LuceneSearchPermissions.QueryLuceneApi))
~ └─ LuceneApiController.LuceneQueryApiAsync (changes below depth limit)

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  IndexingMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ IDbConnectionAccessor.CreateConnection → DbConnectionAccessor.CreateConnection (depth limit)
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     └─ foreach (var indexObject in indexesObject)
        ├─ IIndexNameProvider.GetFullIndexName
~       ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
        ├─ while (await indexProfileManager.FindByNameAsync(indexProfile.Name)is not null)
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ …
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ EntityExtensions.Put (depth limit)
~       ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
        └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Lucene")

  ContentRazorHelperExtensions.MarkdownToHtmlAsync
  ├─ if (renderLiquid)
~ │  └─ LiquidTemplateManagerExtensions.RenderStringAsync (changes below depth limit)
  ├─ IMarkdownService.ToHtml → DefaultMarkdownService.ToHtml
  ├─ IShortcodeService.ProcessAsync → ShortcodeService.ProcessAsync (depth limit)
  └─ …

  new MarkdownBodyQueryObjectType
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
~    └─ MarkdownBodyQueryObjectType.ToHtml (changes below depth limit)

  new MarkdownFieldQueryObjectType
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
~    └─ MarkdownFieldQueryObjectType.ToHtml (changes below depth limit)

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  LegacyImageCacheFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  LegacyImageCacheFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  MediaProfilesController.Index
  ├─ …
  ├─ MediaProfilesManager.GetMediaProfilesDocumentAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new MediaProfileIndexViewModel (depth limit)
  └─ mediaProfiles.Select

  GetLocalizationsEndpoint.HandleAsync
  └─ cache.GetOrCreate
~    └─ JSLocalizerExtensions.GetMergedLocalizations (changes below depth limit)

  ViewMediaFolderAuthorizationHandler.HandleRequirementAsync
  ├─ …
  ├─ ViewMediaFolderAuthorizationHandler.IsAuthorizedFolder
  ├─ if (!(IsAuthorizedFolder(_mediaFieldsFolder, path)))
  ├─ if (IsAuthorizedFolder(_mediaFieldsFolder, path) || IsDescendantOfAuthorizedFolder(_mediaFieldsFo…
~ │  └─ ViewMediaFolderAuthorizationHandler.AuthorizeAttachedMediaFieldsFolderAsync (changes below depth limit)
  ├─ ViewMediaFolderAuthorizationHandler.IsAuthorizedFolder
  ├─ if (!(IsAuthorizedFolder(_usersFolder, path)))
  └─ …

  AdminController.Create
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (menuItemId == null)
  ├─ else (!(menuItemId == null))
~ └─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)

  AdminController.Delete
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ AdminController.FindMenuItem (depth limit)
  ├─ JNode.SelectNode
~ ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Edit
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of Permissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.FindMenuItem (depth limit)
  ├─ JNode.ToObject (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.EditPost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ AdminController.FindMenuItem (depth limit)
  ├─ JNode.ToObject (depth limit)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ ContentItemExtensions.Merge (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ new JsonMergeSettings
  ├─ JObject.Merge (depth limit)
~ └─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)

  Migrations.CreateAsync
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom2Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

+ new MenuJSLocalizer

  MiniProfilerFilter.OnResultExecutionAsync
  ├─ …
  ├─ ResultExecutingContextExtensions.IsViewOrPageResult
  ├─ if (context.IsViewOrPageResult())
  └─ if (context.IsViewOrPageResult() && ((viewMiniProfilerOnFrontEnd && !AdminAttribute.IsApplied(con…
~    ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
     └─ if (footerZone is Shape shape)
~       ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
        └─ IShapeExtensions.AddAsync (depth limit)

  PagerShapes.Pager
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.PagerSlim
  ├─ …
  ├─ PagerShapes.SetCustomUrlParams
  ├─ IShapeExtensions.TryGetProperty (depth limit)
  ├─ if (shape.TryGetProperty("Before", out string before))
  │  ├─ Arguments.From [interceptor in PagerShapes.PagerSlim] (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
  ├─ IShapeExtensions.TryGetProperty (depth limit)
  ├─ if (shape.TryGetProperty("After", out string after))
  │  ├─ Arguments.From [interceptor in PagerShapes.PagerSlim] (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ IShapeExtensions.TryGetProperty (depth limit)
~ ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  └─ PagerShapes.WrapWithPageSizeSelector

  PagerShapes.Pager_CurrentPage
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ IShapeExtensions.GetProperty (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_First
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Gap
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ IShapeExtensions.GetProperty (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Last
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Link
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Links
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
  ├─ if (totalPageCount < 2)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
~ │  ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  │  └─ PagerShapes.WrapWithPageSizeSelector
  ├─ PagerShapes.GetRouteData (depth limit)
  ├─ PagerShapes.SetCustomUrlParams
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ IShapeExtensions.AddAsync (depth limit)
  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ IShapeExtensions.AddAsync (depth limit)
  ├─ if (firstPage > 1 && numberOfPagesToShow > 0)
  │  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
  ├─ if (numberOfPagesToShow > 0 && lastPage > 1)
  │  └─ for (p <= lastPage)
  │     ├─ if (p == currentPage)
  │     │  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ │     │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │     │  └─ IShapeExtensions.AddAsync (depth limit)
  │     └─ else (!(p == currentPage))
  │        ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ │        ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │        └─ IShapeExtensions.AddAsync (depth limit)
  ├─ if (lastPage < totalPageCount && numberOfPagesToShow > 0)
  │  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ IShapeExtensions.AddAsync (depth limit)
  ├─ Arguments.From [interceptor in PagerShapes.Pager_Links] (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ IShapeExtensions.AddAsync (depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
~ ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  └─ PagerShapes.WrapWithPageSizeSelector

  PagerShapes.Pager_Next
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Previous
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  AdminController.List
  ├─ …
  ├─ new Pager (depth limit)
  ├─ INotificationsAdminListQueryService.QueryAsync → DefaultNotificationsAdminListQueryService.QueryAsync (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var notification in queryResult.Notifications)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync [interceptor in AdminController.List] (changes below depth limit)

  AdminController.ListFilterPOST
~ └─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)

  XmlCommentCache.GenerateCacheEntries
  ├─ …
  ├─ new XmlComment ×2
- ├─ new XmlComment
  ├─ new XmlParameterComment ×2
  └─ …

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
~ ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)
     └─ OpenIdValidationConfiguration.GetServerSettingsAsync (depth limit)

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
  └─ if (!string.IsNullOrEmpty(settings.Tenant) && !string.Equals(settings.Tenant, _shellSettings.Name…
~    ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
     └─ ShellScope.UsingAsync (changes below depth limit)
~       ├─ IShellHost.GetOrCreateShellContextAsync → ShellHost.GetOrCreateShellContextAsync (changes below depth limit)
~       └─ ShellContext.AddDependentShellAsync (changes below depth limit)

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
  ├─ possible initialization of OpenIdValidationConfiguration.AttachProblemDetailsResponseBody
~ ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)
     ├─ OpenIdValidationConfiguration.GetServerSettingsAsync (depth limit)
     ├─ IOpenIdServerService.GetSigningKeysAsync → OpenIdServerService.GetSigningKeysAsync (depth limit)
     └─ …

  ApplicationController.Index
  ├─ …
  ├─ foreach (var application in _applicationManager.ListAsync(pager.PageSize, pager.GetStartIndex()))
  ├─ new OpenIdApplicationsIndexViewModel
~ └─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)

  ScopeController.Index
  ├─ …
  ├─ new Pager (depth limit)
  ├─ new OpenIdScopeIndexViewModel
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ Pager.GetStartIndex
  └─ foreach (var scope in _scopeManager.ListAsync(pager.PageSize, pager.GetStartIndex()))

  ServerConfigurationController.Index
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IOpenIdServerService.GetSettingsAsync → OpenIdServerService.GetSettingsAsync (depth limit)
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  ServerConfigurationController.IndexPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IOpenIdServerService.GetSettingsAsync → OpenIdServerService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IOpenIdServerService.ValidateSettingsAsync → OpenIdServerService.ValidateSettingsAsync (depth limit)
  ├─ IOpenIdServerService.UpdateSettingsAsync → OpenIdServerService.UpdateSettingsAsync (depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
~ └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)

  ValidationConfigurationController.Index
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IOpenIdValidationService.GetSettingsAsync → OpenIdValidationService.GetSettingsAsync (depth limit)
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  ValidationConfigurationController.IndexPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IOpenIdValidationService.GetSettingsAsync → OpenIdValidationService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
~ ├─ IOpenIdValidationService.ValidateSettingsAsync → OpenIdValidationService.ValidateSettingsAsync (changes below depth limit)
  ├─ IOpenIdValidationService.UpdateSettingsAsync → OpenIdValidationService.UpdateSettingsAsync (depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
~ └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)

+ new OpenIdJSLocalizer

  AdminController.Index
  ├─ …
  ├─ shapeTypes.Select
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ new ListShapePlacementsViewModel (depth limit)

  ContentQueryOrchardRazorHelperExtensions.ContentQueryAsync
~ └─ ContentQueryOrchardRazorHelperExtensions.ContentQueryAsync (changes below depth limit)

  ContentQueryOrchardRazorHelperExtensions.ContentQueryResultsAsync
~ ├─ QueryOrchardRazorHelperExtensions.QueryResultsAsync (changes below depth limit)
  └─ if (queryResult.Items != null)

  AdminController.Create
  ├─ …
  ├─ IQueryManager.NewAsync → DefaultQueryManager.NewAsync (depth limit)
  ├─ new QueriesCreateViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IQueryManager.NewAsync → DefaultQueryManager.NewAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  AdminController.Edit
  ├─ …
  ├─ IQueryManager.GetQueryAsync → DefaultQueryManager.GetQueryAsync (depth limit)
  ├─ new QueriesEditViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.EditPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IQueryManager.GetQueryAsync → DefaultQueryManager.GetQueryAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  AdminController.Index
  ├─ …
  ├─ IQueryManager.PageQueriesAsync → DefaultQueryManager.PageQueriesAsync (depth limit)
  ├─ new QueriesIndexViewModel (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ foreach (var query in result.Records)
     ├─ new QueryEntry
~    └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)

  QueryApiController.QueryGet
~ └─ QueryApiController.ExecuteQueryAsync (changes below depth limit)

  QueryApiController.QueryPost
~ └─ QueryApiController.ExecuteQueryAsync (changes below depth limit)

  new QueryGlobalMethodProvider
  ├─ new GlobalMethod
  └─ callback ×2
     └─ callback
~       └─ QueryGlobalMethodProvider.ExecuteQueryAsync (changes below depth limit)

  AdminController.Query
  ├─ else (!(string.IsNullOrWhiteSpace(query)))
  ├─ new AdminQueryViewModel
~ └─ AdminController.Query (changes below depth limit)

  QueryOrchardRazorHelperExtensions.QueryAsync
~ └─ QueryOrchardRazorHelperExtensions.QueryAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ IRateLimitPolicyStore.CreateAsync → RateLimitPolicyStore.CreateAsync (depth limit)
  ├─ AdminController.ShouldReloadPolicy
  ├─ if (ShouldReloadPolicy(wasEnabled: false, isEnabled: policy.IsEnabled))
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Delete
  ├─ …
  ├─ AdminController.GetCurrentPolicyAsync (depth limit)
  ├─ IRateLimitPolicyStore.DeleteAsync → RateLimitPolicyStore.DeleteAsync (depth limit)
  ├─ if (policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Disable
  ├─ …
  ├─ AdminController.GetCurrentPolicyAsync (depth limit)
  ├─ if (policy.IsEnabled)
  ├─ if (policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.GetCurrentPolicyAsync (depth limit)
~ └─ AdminController.CreateEditViewModelAsync (changes below depth limit)

  AdminController.EditPost
~ └─ AdminController.SavePolicyAsync (changes below depth limit)

  AdminController.Enable
  ├─ …
  ├─ AdminController.GetCurrentPolicyAsync (depth limit)
  ├─ if (!policy.IsEnabled)
  ├─ if (!policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Index
  ├─ …
  ├─ Pager.GetStartIndex
  ├─ new RateLimitsIndexViewModel
  ├─ pagedPolicies.Select
~ │  └─ AdminController.BuildPolicyEntryAsync (changes below depth limit)
  ├─ AdminController.BuildBuiltInRouteLimits (depth limit)
  ├─ AdminController.BuildBuiltInGroupLimits (depth limit)
  └─ if (totalCount > pager.PageSize)
~    └─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)

  AdminController.IndexPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ AdminController.GetCurrentPoliciesAsync (depth limit)
  ├─ case RateLimitPolicyBulkAction.Enable:
  │  ├─ foreach (var policy in policies.Where(x => !x.IsEnabled))
  │  ├─ if (totalChanged == 0)
~ │  ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  │  ├─ HtmlLocalizerExtensions.Plural (depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  ├─ case RateLimitPolicyBulkAction.Disable:
  │  ├─ foreach (var policy in policies.Where(x => x.IsEnabled))
  │  ├─ if (totalChanged == 0)
~ │  ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  │  ├─ HtmlLocalizerExtensions.Plural (depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  └─ case RateLimitPolicyBulkAction.Remove:
     ├─ foreach (var policy in policies)
     ├─ if (totalDeleted == 0)
     ├─ if (shouldReload)
~    │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
     ├─ HtmlLocalizerExtensions.Plural (depth limit)
     └─ NotifierExtensions.SuccessAsync (depth limit)

  LimiterController.Create
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  LimiterController.CreatePost
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IRateLimitPolicyStore.UpdateAsync → RateLimitPolicyStore.UpdateAsync (depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  LimiterController.Edit
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  LimiterController.EditPost
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IRateLimitPolicyStore.UpdateAsync → RateLimitPolicyStore.UpdateAsync (depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  GlobalRateLimitsMigrations.CreateAsync
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  AdminController.Execute
  ├─ possible initialization of RecipePermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ AdminController.GetRecipesAsync (depth limit)
  ├─ if (recipe == null)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
  ├─ try
~ │  ├─ IRecipeExecutor.ExecuteAsync → RecipeExecutor.ExecuteAsync (changes below depth limit)
~ │  ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  ├─ catch (RecipeExecutionException e)
  └─ catch (Exception e)

  AdminController.Index
  ├─ possible initialization of RecipePermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ AdminController.GetRecipesAsync (depth limit)
  └─ recipes.Select

  ResourceManagementOptionsConfiguration.Configure
~ └─ ResourceManagementOptionsConfiguration.BuildManifest (signature changed)

  AdminController.Clone
  ├─ possible initialization of RolesPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ AdminController.GetCloneRoleViewModelAsync (changes below depth limit)

  AdminController.ClonePost
  ├─ …
  ├─ if (ModelState.IsValid)
  ├─ if (ModelState.IsValid && await ValidateRoleNameAsync(name))
~ └─ AdminController.GetCloneRoleViewModelAsync (changes below depth limit)

  AdminController.Display
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ new DisplayRoleViewModel
~ └─ AdminController.GetRolePermissionsViewModelAsync (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ new EditRoleViewModel
~ └─ AdminController.GetRolePermissionsViewModelAsync (changes below depth limit)

  RolesMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing
  └─ if (!_shellSettings.IsInitializing())
~    └─ RolesMigrations.MigrateSystemRoles (changes below depth limit)

  SearchController.Search
  ├─ …
  ├─ if (string.IsNullOrWhiteSpace(terms))
  ├─ new PagerSlim (depth limit)
  ├─ ISearchService.SearchAsync
  │  ├─ ⇢ AzureAISearchService.SearchAsync (depth limit)
~ │  ├─ ⇢ ElasticsearchService.SearchAsync (changes below depth limit)
  │  └─ ⇢ LuceneSearchService.SearchAsync (depth limit)
  ├─ new SearchContext
  ├─ if (!searchResult.Success || searchResult.ContentItemIds.Count == 0)
  ├─ …
  ├─ new SearchFormViewModel (depth limit)
  ├─ new SearchResultsViewModel (depth limit)
~ └─ ShapeFactoryExtensions.PagerSlimAsync (changes below depth limit)

  Migrations.CreateAsync
  ├─ ContentDefinitionManagerExtensions.AlterPartDefinitionAsync (depth limit)
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

+ new SeoJSLocalizer

  AdminController.Index
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ISiteService.GetSiteSettingsAsync → SiteService.GetSiteSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  ├─ IShapeExtensions.HasItemsInAnyZone (depth limit)
  └─ new AdminIndexViewModel

  AdminController.IndexPost
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IShapeExtensions.HasItemsInAnyZone (depth limit)
  ├─ new AdminIndexViewModel
  └─ …

  SetupController.Index
  ├─ ISetupService.GetSetupRecipesAsync → SetupService.GetSetupRecipesAsync (depth limit)
~ ├─ SetupController.ShouldProceedWithTokenAsync (changes below depth limit)
  ├─ new SetupViewModel
  ├─ IClock.GetSystemTimeZone → Clock.GetSystemTimeZone (depth limit)
  └─ …

  SetupController.IndexPOST
~ ├─ SetupController.ShouldProceedWithTokenAsync (changes below depth limit)
  ├─ ISetupService.GetSetupRecipesAsync → SetupService.GetSetupRecipesAsync (depth limit)
  ├─ if (!string.IsNullOrEmpty(model.Email))
  ├─ …
  ├─ SetupController.GetPresetDatabaseProvider
  ├─ SetupController.HasPresetDatabaseConfiguration (depth limit)
  ├─ try
~ │  └─ ISetupService.SetupAsync → SetupService.SetupAsync (changes below depth limit)
  ├─ catch (Exception ex) when (!ex.IsFatal())
  └─ if (setupContext.Errors.Count > 0)

  AdminController.Index
  ├─ …
  ├─ ShortcodeTemplatesManager.GetShortcodeTemplatesDocumentAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new ShortcodeTemplateIndexViewModel (depth limit)
  └─ shortcodeTemplates.Select

+ new ShortcodesJSLocalizer

  TemplateShortcodeProvider.EvaluateAsync
  ├─ …
  ├─ new ShortcodeViewModel
  ├─ new TemplateShortcodeProvider.Content (depth limit)
~ └─ ILiquidTemplateManager.RenderStringAsync → LiquidTemplateManager.RenderStringAsync (changes below depth limit)

  AdminController.Display
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ISitemapManager.GetSitemapAsync → SitemapManager.GetSitemapAsync (depth limit)
  ├─ foreach (var source in sitemap.SitemapSources)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ foreach (var factory in _sourceFactories)
  │  ├─ ISitemapSourceFactory.Create → SitemapSourceFactory<TSitemapSource>.Create (depth limit)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  └─ new DisplaySitemapViewModel

  AdminController.List
  ├─ …
  ├─ new ListSitemapViewModel (depth limit)
  ├─ results.Select
~ └─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)

  SitemapController.Index
  ├─ …
  ├─ ISitemapCacheProvider.GetCachedSitemapAsync → DefaultSitemapCacheProvider.GetCachedSitemapAsync (depth limit)
  ├─ if (fileResolver != null)
  └─ else (!(fileResolver != null))
     ├─ possible initialization of SitemapController
     └─ s_workers.GetOrAdd
        └─ new Lazy<Task<Stream>>
           └─ try
              ├─ ISiteService.GetSiteSettingsAsync → SiteService.GetSiteSettingsAsync (depth limit)
              ├─ new SitemapBuilderContext
~             ├─ ISitemapBuilder.BuildAsync → DefaultSitemapBuilder.BuildAsync (changes below depth limit)
              ├─ possible initialization of MemoryStreamFactory
              ├─ MemoryStreamFactory.GetStream
              └─ …

  SitemapIndexController.List
  ├─ …
  ├─ ISitemapManager.GetSitemapsAsync → SitemapManager.GetSitemapsAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new ListSitemapIndexViewModel (depth limit)
  └─ results.Select

  SourceController.Create
  ├─ …
  ├─ ISitemapManager.LoadSitemapAsync → SitemapManager.LoadSitemapAsync (depth limit)
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.SitemapSourceType) is not null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)

  SourceController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == sourceType) is not null)
  ├─ new CreateSourceViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  SourceController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ ISitemapManager.LoadSitemapAsync → SitemapManager.LoadSitemapAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ NotifierExtensions.ErrorAsync (depth limit)

  SourceController.Edit
  ├─ …
  ├─ ISitemapManager.GetSitemapAsync → SitemapManager.GetSitemapAsync (depth limit)
  ├─ new EditSourceViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.Create
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (taxonomyItemId == null)
  └─ else (!(taxonomyItemId == null))

  AdminController.Delete
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ AdminController.RemoveTaxonomyItem (depth limit)
  └─ …

  AdminController.Edit
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ possible initialization of Permissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ └─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)

  AdminController.EditPost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
  │  ├─ possible initialization of VersionOptions
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ AdminController.FindTaxonomyItem (depth limit)
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ new JsonMergeSettings
  └─ JObject.Merge (depth limit)

  TagController.CreatePost
  ├─ …
  ├─ possible initialization of VersionOptions
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (changes below depth limit)
  ├─ if (result.Succeeded)
~ │  └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  └─ new CreatedTagViewModel

  new TaxonomyFieldQueryObjectType
  ├─ …
  ├─ Field<ListGraphType<StringGraphType>, IEnumerable<string>>("termContentItemIds").Description(S["term content item ids"]).PagingArguments().Resolve
  ├─ ResolveFieldContextExtensions.PagingArguments
  ├─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit)
  │  ├─ ResolveFieldContextExtensions.Page
~ │  ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  │  └─ foreach (var termContentItemId in ids)
  └─ FieldBuilderResolverExtensions.ResolveLockedAsync (depth limit) ↑ as above

+ new TaxonomiesJSLocalizer

  TaxonomyOrchardHelperExtensions.GetInheritedTermsAsync
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ TaxonomyOrchardHelperExtensions.FindTermHierarchy (depth limit)

  TaxonomyOrchardHelperExtensions.GetTaxonomyTermAsync
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ TaxonomyOrchardHelperExtensions.FindTerm (depth limit)

  PreviewController.Render
  ├─ …
  ├─ else (!(string.IsNullOrEmpty(handle) || handle == _homeUrl))
  ├─ possible initialization of VersionOptions
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
~ └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)

  TemplateController.Admin
~ └─ TemplateController.Index (changes below depth limit)

  AdminController.Create
  ├─ …
  ├─ AdminController.ApplyConfiguredDatabasePatterns (depth limit)
  ├─ if (ModelState.IsValid)
  ├─ if (ModelState.IsValid)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ ShellSettingsExtensions.AsUninitialized
  │  │  ├─ ShellSettingsExtensions.AsDisposable
~ │  │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  │  └─ if (action == CreateAndSetupValue)
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ _recipeHarvesters.Select
  └─ AdminController.GetFeatureProfilesAsync (depth limit)

  AdminController.Disable
  ├─ …
  ├─ if (!shellSettings.IsRunning())
  ├─ ShellSettingsExtensions.AsDisabled
~ └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ AdminController.ApplyConfiguredDatabasePatterns (depth limit)
  ├─ if (ModelState.IsValid)
  ├─ if (ModelState.IsValid)
  │  ├─ try
  │  │  ├─ ShellSettingsExtensions.IsUninitialized
~ │  │  └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ ShellSettingsExtensions.IsUninitialized
  ├─ if (shellSettings.IsUninitialized())
  └─ …

  AdminController.Enable
  ├─ …
  ├─ if (!shellSettings.IsDisabled())
  ├─ ShellSettingsExtensions.AsRunning
~ └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)

  AdminController.Index
  ├─ …
  ├─ ShellSettingsExtensions.IsDefaultShell
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings
  └─ foreach (var tenantName in model.TenantNames ?? [])
     ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings
     ├─ case "Disable":
     │  ├─ ShellSettingsExtensions.IsDefaultShell
     │  ├─ if (shellSettings.IsDefaultShell())
     │  └─ else (!(shellSettings.IsDefaultShell()))
     │     ├─ ShellSettingsExtensions.IsRunning
     │     ├─ if (!shellSettings.IsRunning())
     │     └─ else (!(!shellSettings.IsRunning()))
     │        ├─ ShellSettingsExtensions.AsDisabled
~    │        └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
     └─ case "Enable":
        ├─ ShellSettingsExtensions.IsDisabled
        ├─ if (!shellSettings.IsDisabled())
        └─ else (!(!shellSettings.IsDisabled()))
           ├─ ShellSettingsExtensions.AsRunning
~          └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)

  AdminController.Index
  ├─ …
  ├─ Pager.GetStartIndex
  ├─ sortedSettings.Skip(pager.GetStartIndex()).Take(pager.PageSize).Select
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ new AdminIndexViewModel (depth limit)

  AdminController.Reload
  ├─ …
  ├─ ShellSettingsExtensions.IsDefaultShell
  ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings
~ └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)

  AdminController.Remove
  ├─ …
  ├─ ShellSettingsExtensions.IsRemovable (depth limit)
  ├─ if (!shellSettings.IsRemovable())
~ ├─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)
  ├─ if (!context.Success)
  └─ else (!(!context.Success))

  FeatureProfilesController.Index
  ├─ …
  ├─ FeatureProfilesManager.GetFeatureProfilesDocumentAsync (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new FeatureProfilesIndexViewModel (depth limit)
  └─ featureProfiles.Select

  TenantApiController.Create
  ├─ …
  ├─ try
  ├─ catch (Exception ex) when (!ex.IsFatal())
  └─ if (ModelState.IsValid)
     ├─ if (!model.IsNewTenant)
     ├─ try
     │  ├─ …
     │  ├─ ShellSettingsExtensions.AsUninitialized
     │  ├─ ShellSettingsExtensions.AsDisposable
~    │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
     │  ├─ ShellHostExtensions.GetSettings (depth limit)
     │  ├─ TenantApiController.CreateSetupToken
     │  └─ …
     └─ catch (Exception ex) when (!ex.IsFatal())

  TenantApiController.Disable
  ├─ …
  ├─ ShellSettingsExtensions.IsRunning
  ├─ ShellSettingsExtensions.AsDisabled
~ └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)

  TenantApiController.Edit
  ├─ …
  ├─ if (ModelState.IsValid)
  ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings
  └─ if (ModelState.IsValid)
     ├─ try
     │  ├─ ShellSettingsExtensions.IsUninitialized
~    │  └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
     └─ catch (Exception ex) when (!ex.IsFatal())

  TenantApiController.Enable
  ├─ …
  ├─ ShellSettingsExtensions.IsDisabled
  ├─ ShellSettingsExtensions.AsRunning
~ └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)

  TenantApiController.Remove
  ├─ …
  ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings
  ├─ ShellSettingsExtensions.IsRemovable (depth limit)
~ └─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)

  TenantApiController.Setup
  ├─ …
  ├─ else (!(string.IsNullOrEmpty(recipeName)))
  ├─ new SetupContext
~ ├─ ISetupService.SetupAsync → SetupService.SetupAsync (changes below depth limit)
  └─ if (setupContext.Errors.Count > 0)

  AdminController.Disable
  ├─ possible initialization of Permissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
~ ├─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Enable
  ├─ possible initialization of Permissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
~ ├─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Index
  ├─ …
  ├─ if (currentSiteThemeExtensionInfo != null)
  ├─ IShellFeaturesManager.GetEnabledFeaturesAsync → ShellFeaturesManager.GetEnabledFeaturesAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).Where
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).Where(f => { if (f.IsAlwaysEnabled || f.EnabledByDependencyOnly || !f.IsTheme()) { return false; }  var tags = f.Extension.Manifest.Tags.ToArray(); var isHidden = tags.Any(t => string.Equals(t, "hidden", StringComparison.OrdinalIgnoreCase)); if (isHidden) { return false; }  return true; }).Select
  └─ …

  AdminController.SetCurrentTheme
  ├─ possible initialization of Permissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ else (!(string.IsNullOrEmpty(id)))
~    ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
     ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
     └─ else (!(feature == null))
        ├─ …
        ├─ else (!(isAdmin))
        ├─ IShellFeaturesManager.GetEnabledFeaturesAsync → ShellFeaturesManager.GetEnabledFeaturesAsync (depth limit)
        ├─ if (!isEnabled)
~       │  ├─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)
        │  └─ NotifierExtensions.SuccessAsync (depth limit)
        └─ NotifierExtensions.SuccessAsync (depth limit)

  ThemeService.DisableFeaturesAsync
~ └─ ThemeService.DisableFeaturesAsync (changes below depth limit)

  ThemeService.DisableThemeFeaturesAsync
  ├─ while (themeName != null)
  ├─ ISiteThemeService.GetSiteThemeNameAsync → SiteThemeService.GetSiteThemeNameAsync (depth limit)
  └─ while (themes.Count > 0)
     └─ if (themeId != currentTheme)
~       └─ ThemeService.DisableFeaturesAsync (changes below depth limit)

  ThemeService.EnableFeaturesAsync
~ └─ ThemeService.EnableFeaturesAsync (changes below depth limit)

  ThemeService.EnableThemeFeaturesAsync
  ├─ while (themeName != null)
  └─ while (themes.Count > 0)
~    └─ ThemeService.EnableFeaturesAsync (changes below depth limit)

  AdminController.Create
  ├─ …
  ├─ if (rule == null)
  ├─ new RewriteRuleViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePOST
  ├─ …
  ├─ if (rule == null)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ IShellReleaseManager.SuspendReleaseRequest → DefaultShellReleaseManager.SuspendReleaseRequest

  AdminController.Delete
  ├─ …
  ├─ IRewriteRulesManager.FindByIdAsync → RewriteRulesManager.FindByIdAsync (depth limit)
  ├─ IRewriteRulesManager.DeleteAsync → RewriteRulesManager.DeleteAsync (depth limit)
~ ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Edit
  ├─ …
  ├─ IRewriteRulesManager.FindByIdAsync → RewriteRulesManager.FindByIdAsync (depth limit)
  ├─ new RewriteRuleViewModel
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.EditPOST
  ├─ …
  ├─ RewriteRule.Clone (depth limit)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ IShellReleaseManager.SuspendReleaseRequest → DefaultShellReleaseManager.SuspendReleaseRequest

  AdminController.Index
  ├─ …
  ├─ IRewriteRulesManager.GetAllAsync → RewriteRulesManager.GetAllAsync (depth limit)
  ├─ new ListRewriteRuleViewModel
  └─ foreach (var rule in rules)
     ├─ new RewriteRuleEntry
~    └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)

  AccountController.LogOff
  ├─ IUserService.GetAuthenticatedUserAsync → UserService.GetAuthenticatedUserAsync
  ├─ if (user != null)
  ├─ if (user != null)
  │  └─ InvokeExtensions.InvokeAsync (depth limit)
  │     └─ ILogoutFormEvent.LoggedOutAsync
~ │        ├─ ⇢ LogoutFormEventHandler.LoggedOutAsync (changes below depth limit)
  │        └─ ⇢ LogoutFormEventBase.LoggedOutAsync
  └─ AccountBaseController.RedirectToLocal (depth limit)

  AccountController.Login
  ├─ …
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ new LoginForm (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ AccountBaseController.CopyTempDataErrorsToModelState (depth limit)

  AccountController.LoginPOST
  ├─ …
  ├─ if (loginSettings.DisableLocalLogin)
  ├─ new LoginForm (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
  ├─ if (ModelState.IsValid)
  │  ├─ IUserService.GetUserAsync → UserService.GetUserAsync
  │  ├─ if (user != null)
  │  │  ├─ if (result.Succeeded)
  │  │  │  ├─ foreach (var loginFormEvent in _loginFormEvents)
  │  │  │  └─ if (result.Succeeded)
  │  │  │     ├─ InvokeExtensions.InvokeAsync (depth limit)
~ │  │  │     └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
  │  │  ├─ if (result.RequiresTwoFactor)
  │  │  └─ if (result.IsLockedOut)
  │  └─ else (!(user != null))
  ├─ if (user == null)
  └─ else (!(user == null))

  AdminController.Create
  ├─ …
  ├─ possible initialization of UsersPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.CreatePost
  ├─ …
  ├─ possible initialization of UsersPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IUserService.CreateUserAsync → UserService.CreateUserAsync (depth limit)
  └─ NotifierExtensions.SuccessAsync (depth limit)

  AdminController.Disable
  ├─ possible initialization of UsersPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IUserService.DisableAsync → UserService.DisableAsync (changes below depth limit)
  ├─ if (await _userService.DisableAsync(user))
  └─ else (!(await _userService.DisableAsync(user)))

  AdminController.Display
  ├─ possible initialization of UsersPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)

  AdminController.Edit
  ├─ if (string.IsNullOrEmpty(id))
  ├─ if (!editingOwnUser)
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  AdminController.EditPost
  ├─ if (string.IsNullOrEmpty(id))
  ├─ if (!editingOwnUser)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
  └─ if (!string.IsNullOrEmpty(returnUrl))

  AdminController.Enable
  ├─ possible initialization of UsersPermissions
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
~ ├─ IUserService.EnableAsync → UserService.EnableAsync (changes below depth limit)
  ├─ if (await _userService.EnableAsync(user))
  └─ else (!(await _userService.EnableAsync(user)))

  AdminController.Index
  ├─ …
  ├─ new Pager (depth limit)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var user in results)
  │  ├─ new UserEntry
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ RoleServiceExtensions.GetRoleNamesAsync (depth limit)
  ├─ foreach (var roleName in await _roleService.GetRoleNamesAsync())
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync [interceptor in AdminController.Index] (changes below depth limit)

  AdminController.IndexFilterPOST
~ └─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)

  AdminController.IndexPOST
  ├─ …
  ├─ new User (depth limit)
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  └─ if (itemIds != null && itemIds.Any())
     └─ foreach (var user in checkedUsers)
        ├─ …
        ├─ case UsersBulkAction.ConfirmEmail:
        ├─ case UsersBulkAction.Delete:
        ├─ case UsersBulkAction.Disable:
        │  └─ if (!isSameUser && canEditUser)
~       │     ├─ IUserService.DisableAsync → UserService.DisableAsync (changes below depth limit)
        │     └─ NotifierExtensions.SuccessAsync (depth limit)
        └─ case UsersBulkAction.Enable:
           └─ if (!isSameUser && canEditUser)
~             ├─ IUserService.EnableAsync → UserService.EnableAsync (changes below depth limit)
              └─ NotifierExtensions.SuccessAsync (depth limit)

  EmailConfirmationController.ConfirmEmail
  └─ if (result.Succeeded)
     ├─ new UserConfirmContext (depth limit)
     └─ InvokeExtensions.InvokeAsync (depth limit)
        └─ IUserEventHandler.ConfirmedAsync
           ├─ ⇢ UserEventHandler.ConfirmedAsync (depth limit)
~          ├─ ⇢ UserEventHandler.ConfirmedAsync (changes below depth limit)
           └─ ⇢ UserEventHandlerBase.ConfirmedAsync

  EmailConfirmationController.SendVerificationEmail
  ├─ if (id != currentUserId)
~ ├─ UserEmailService.SendEmailConfirmationAsync (changes below depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
  └─ ControllerTypeExtensions.ControllerName

  ExternalAuthenticationsController.ExternalLoginCallback
  ├─ …
  ├─ ExternalAuthenticationsController.GetRememberMe (depth limit)
  ├─ AccountBaseController.CopyTempDataErrorsToModelState (depth limit)
  ├─ if (iUser != null)
  │  ├─ InvokeExtensions.InvokeAsync (depth limit)
  │  ├─ if (ModelState.IsValid)
  │  │  ├─ foreach (var loginFormEvent in _loginFormEvents)
  │  │  ├─ ExternalAuthenticationsController.ExternalSignInAsync (depth limit)
  │  │  └─ if (signInResult.Succeeded)
~ │  │     └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
  │  └─ ExternalAuthenticationsController.RedirectToLogin (depth limit)
  ├─ ExternalLoginInfoExtensions.GetEmail
  ├─ if (iUser != null)
  ├─ …
  ├─ new RegisterExternalLoginViewModel
  ├─ ExternalAuthenticationsController.GenerateUsernameAsync (depth limit)
  └─ if (noInformationRequired)
     ├─ new RegisterUserForm (depth limit)
~    ├─ IUserService.RegisterAsync → UserService.RegisterAsync (changes below depth limit)
     ├─ if (iUser == null || !ModelState.IsValid)
     ├─ if (identityResult.Succeeded)
     │  ├─ if (iUser is User user)
     │  ├─ ExternalAuthenticationsController.ExternalSignInAsync (depth limit)
     │  ├─ if (signInResult.Succeeded)
~    │  │  └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
     │  └─ ExternalAuthenticationsController.RedirectToLogin (depth limit)
     └─ ExternalAuthenticationsController.AddErrorsToModelState

  ExternalAuthenticationsController.LinkExternalLogin
  ├─ ExternalLoginInfoExtensions.GetEmail
  ├─ if (ModelState.IsValid)
  │  ├─ InvokeExtensions.InvokeAsync (depth limit)
  │  └─ else (!(!signInResult.Succeeded))
  │     ├─ if (identityResult.Succeeded)
  │     │  ├─ …
  │     │  ├─ ExternalAuthenticationsController.GetRememberMe (depth limit)
  │     │  ├─ ExternalAuthenticationsController.ExternalSignInAsync (depth limit)
  │     │  └─ if ((await ExternalSignInAsync(user, info, GetRememberMe(info, loginSettings))).Succeeded)
~ │     │     └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
  │     └─ ExternalAuthenticationsController.AddErrorsToModelState
  ├─ ExternalAuthenticationsController.CopyModelStateErrorsToTempData
  └─ ExternalAuthenticationsController.RedirectToLogin (depth limit)

  ExternalAuthenticationsController.RegisterExternalLogin
  ├─ …
  ├─ ExternalAuthenticationsController.UpdateAndValidateUserNameAsync (depth limit)
  ├─ ExternalAuthenticationsController.UpdateAndValidatePasswordAsync (depth limit)
  └─ if (ModelState.IsValid)
     ├─ new RegisterUserForm (depth limit)
~    ├─ IUserService.RegisterAsync → UserService.RegisterAsync (changes below depth limit)
     └─ if (iUser is not null && ModelState.IsValid)
        ├─ if (identityResult.Succeeded)
        │  ├─ …
        │  ├─ ExternalAuthenticationsController.GetRememberMe (depth limit)
        │  ├─ ExternalAuthenticationsController.ExternalSignInAsync (depth limit)
        │  └─ if (signInResult.Succeeded)
~       │     └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
        └─ ExternalAuthenticationsController.AddErrorsToModelState

  RegistrationController.Register
~ └─ DisplayManagerExtensions.BuildEditorAsync (changes below depth limit)

  RegistrationController.RegisterPOST
  ├─ new RegisterUserForm (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  └─ if (ModelState.IsValid)
~    ├─ IUserService.RegisterAsync → UserService.RegisterAsync (changes below depth limit)
     └─ if (iUser is User user)

  ResetPasswordController.ForgotPassword
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
~ └─ DisplayManagerExtensions.BuildEditorAsync (changes below depth limit)

  ResetPasswordController.ForgotPasswordPOST
  ├─ …
  ├─ ISite.TryGet → SiteSettings.TryGet (depth limit)
  ├─ new ForgotPasswordForm (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
  └─ if (ModelState.IsValid)
     ├─ IUserService.GetForgotPasswordUserAsync → UserService.GetForgotPasswordUserAsync (depth limit)
     └─ else (!(_registrationOptions.CurrentValue.UsersMustValidateEmail && !await _userManager.IsEmailCo…
~       ├─ UserEmailService.SendPasswordResetAsync (changes below depth limit)
        ├─ new PasswordRecoveryContext
        └─ InvokeExtensions.InvokeAsync (depth limit)

  ResetPasswordController.ResetPassword
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ new ResetPasswordForm (depth limit)
~ └─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)

  ResetPasswordController.ResetPasswordPOST
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ new ResetPasswordForm (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
  └─ if (ModelState.IsValid)

  SmsAuthenticatorController.IndexPost
  ├─ …
  ├─ if (canSetNewPhone)
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
~ ├─ SmsAuthenticatorController.GetBodyAsync (changes below depth limit)
  ├─ SmsServiceExtensions.SendAsync (depth limit)
  ├─ if (!result.Succeeded)
  └─ …

  TwoFactorAuthenticationController.Index
  ├─ …
  ├─ TwoFactorAuthenticationBaseController.GetTwoFactorProvidersAsync
  ├─ new TwoFactorAuthenticationViewModel
~ ├─ TwoFactorAuthenticationController.PopulateModelAsync (changes below depth limit)
  └─ if (user is User u)

  TwoFactorAuthenticationController.Index
  ├─ …
  ├─ TwoFactorAuthenticationBaseController.GetTwoFactorProvidersAsync
  ├─ if (ModelState.IsValid)
~ └─ TwoFactorAuthenticationController.PopulateModelAsync (changes below depth limit)

  TwoFactorAuthenticationController.LoginWithRecoveryCode
  └─ if (ModelState.IsValid)
     ├─ if (user == null)
     ├─ if (result.Succeeded)
     │  ├─ InvokeExtensions.InvokeAsync (depth limit)
~    │  └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
     └─ if (result.IsLockedOut)

  TwoFactorAuthenticationController.LoginWithTwoFactorAuthenticationPost
  ├─ …
  ├─ TwoFactorAuthenticationController.GetProvider (depth limit)
  ├─ if (string.IsNullOrEmpty(currentProvider))
  └─ if (ModelState.IsValid)
     ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
     ├─ TwoFactorAuthenticationBaseController.StripToken
     ├─ if (result.Succeeded)
     │  ├─ InvokeExtensions.InvokeAsync (depth limit)
~    │  └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
     ├─ if (result.IsLockedOut)
     └─ InvokeExtensions.InvokeAsync (depth limit)

  ExternalAuthenticationMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ EntityExtensions.Put (depth limit)
     ├─ ISiteService.UpdateSiteSettingsAsync → SiteService.UpdateSiteSettingsAsync (depth limit)
     └─ if (enumValue is not null && enumValue != 1)
~       └─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)

  SendCode.HandleAsync
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
~ ├─ SendCode.GetSubjectAsync (changes below depth limit)
~ ├─ SendCode.GetBodyAsync (changes below depth limit)
  └─ EmailServiceExtensions.SendAsync (depth limit)

  SendCode.HandleAsync
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
~ ├─ SendCode.GetBodyAsync (changes below depth limit)
  └─ SmsServiceExtensions.SendAsync (depth limit)

  AdminController.BuildEditor
  ├─ …
  ├─ new WidgetMetadata (depth limit)
  ├─ ContentItemExtensions.Weld (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  └─ new BuildEditorViewModel

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ActivityController.Create
  ├─ …
  ├─ new ActivityRecord (depth limit)
  ├─ IActivityIdGenerator.GenerateUniqueId → ActivityIdGenerator.GenerateUniqueId (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → ActivityDisplayManager.BuildEditorAsync (changes below depth limit)
  ├─ new ActivityEditViewModel
  └─ if (!activity.HasEditor)
~    └─ ActivityController.Create (changes below depth limit)

  ActivityController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IWorkflowManager.CreateActivityExecutionContextAsync → WorkflowManager.CreateActivityExecutionContextAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → ActivityDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ NotifierExtensions.SuccessAsync (depth limit)
  └─ if (Url.IsLocalUrl(model.ReturnUrl))

  ActivityController.Edit
  ├─ …
  ├─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)
  ├─ IWorkflowManager.CreateActivityExecutionContextAsync → WorkflowManager.CreateActivityExecutionContextAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → ActivityDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ new ActivityEditViewModel

  WorkflowController.Details
  ├─ …
  ├─ IWorkflowStore.GetAsync → WorkflowStore.GetAsync
  ├─ IWorkflowTypeStore.GetAsync → WorkflowTypeStore.GetAsync
~ ├─ IWorkflowManager.CreateWorkflowExecutionContextAsync → WorkflowManager.CreateWorkflowExecutionContextAsync (changes below depth limit)
  ├─ workflowType.Activities.Select
  ├─ foreach (var activityContext in activityContexts)
~ │  └─ WorkflowController.BuildActivityDisplayAsync (changes below depth limit)
  ├─ foreach (var activityContext in activityContexts)
  ├─ new WorkflowViewModel
  └─ …

  WorkflowController.Index
  ├─ …
  ├─ IWorkflowTypeStore.GetAsync → WorkflowTypeStore.GetAsync
  ├─ new Pager (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ Pager.GetStartIndex
  ├─ new WorkflowIndexViewModel (depth limit)
  └─ …

  WorkflowController.Restart
  ├─ …
  ├─ DistributedLockExtensions.TryAcquireWorkflowTypeLockAsync (depth limit)
  ├─ if (!locked)
  └─ else (!(!locked))
     ├─ if (workflowType.IsSingleton)
     ├─ if (workflowType.IsSingleton && await _workflowStore.HasHaltedInstanceAsync(workflowType.Workflow…
     └─ else (!(workflowType.IsSingleton && await _workflowStore.HasHaltedInstanceAsync(workflowType.Work…
~       ├─ WorkflowManagerExtensions.RestartWorkflowAsync (changes below depth limit)
        └─ NotifierExtensions.SuccessAsync (depth limit)

  WorkflowTypeController.Edit
  ├─ …
  ├─ IActivityLibrary.ListActivities → ActivityLibrary.ListActivities
  ├─ IWorkflowManager.NewWorkflow → WorkflowManager.NewWorkflow (depth limit)
~ ├─ IWorkflowManager.CreateWorkflowExecutionContextAsync → WorkflowManager.CreateWorkflowExecutionContextAsync (changes below depth limit)
  ├─ workflowType.Activities.Select
  ├─ foreach (var activity in availableActivities)
~ │  └─ WorkflowTypeController.BuildActivityDisplay (changes below depth limit)
  ├─ foreach (var activityContext in activityContexts)
~ │  └─ WorkflowTypeController.BuildActivityDisplay (changes below depth limit)
  ├─ foreach (var activityContext in activityContexts)
  ├─ new WorkflowTypeViewModel
  └─ …

  WorkflowTypeController.Index
  ├─ …
  ├─ if (options is null)
  ├─ Pager.GetStartIndex
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new WorkflowTypeIndexViewModel
  └─ workflowTypes.Select

  HttpWorkflowController.Invoke
  ├─ …
  ├─ IWorkflowTypeStore.GetAsync → WorkflowTypeStore.GetAsync
  ├─ ActivityLibraryExtensions.InstantiateActivity (depth limit)
  ├─ if (startActivity.IsStart)
  │  ├─ DistributedLockExtensions.TryAcquireWorkflowTypeLockAsync (depth limit)
  │  └─ if (locked)
  │     ├─ if (!(!workflowType.IsSingleton))
  │     └─ if (!workflowType.IsSingleton || !await _workflowStore.HasHaltedInstanceAsync(workflowType.Workfl…
~ │        └─ IWorkflowManager.StartWorkflowAsync → WorkflowManager.StartWorkflowAsync (changes below depth limit)
  ├─ else (!(startActivity.IsStart))
  │  ├─ IWorkflowStore.ListAsync → WorkflowStore.ListAsync
  │  └─ foreach (var workflow in workflows)
  │     └─ if (blockingActivity != null)
  │        ├─ DistributedLockExtensions.TryAcquireWorkflowLockAsync (depth limit)
  │        ├─ if (workflow.IsAtomic)
  │        └─ if (blockingActivity != null)
~ │           └─ IWorkflowManager.ResumeWorkflowAsync → WorkflowManager.ResumeWorkflowAsync (changes below depth limit)
  └─ HttpWorkflowController.GetWorkflowActionResult (depth limit)

  HttpWorkflowController.Trigger
  ├─ ISecurityTokenService.TryDecryptToken → SecurityTokenService.TryDecryptToken (depth limit)
  ├─ if (!string.IsNullOrWhiteSpace(payload.WorkflowId))
  │  ├─ IWorkflowStore.GetAsync → WorkflowStore.GetAsync
  │  ├─ DistributedLockExtensions.TryAcquireWorkflowLockAsync (depth limit)
  │  └─ if (locked)
  │     ├─ if (workflow.IsAtomic)
  │     └─ if (workflow != null)
  │        └─ foreach (var signalActivity in signalActivities)
~ │           └─ IWorkflowManager.ResumeWorkflowAsync → WorkflowManager.ResumeWorkflowAsync (changes below depth limit)
  ├─ else (!(!string.IsNullOrWhiteSpace(payload.WorkflowId)))
~ │  └─ IWorkflowManager.TriggerEventAsync → WorkflowManager.TriggerEventAsync (changes below depth limit)
  └─ HttpWorkflowController.GetWorkflowActionResult (depth limit)

  WorkflowActionFilter.OnActionExecutionAsync
  ├─ IWorkflowRouteEntries.GetWorkflowRouteEntriesAsync → WorkflowRouteEntries<TWorkflowRouteDocument>.GetWorkflowRouteEntriesAsync (depth limit)
  ├─ if (!workflowTypeEntriesTask.IsCompletedSuccessfully)
~ │  └─ WorkflowActionFilter.OnActionExecutionAsync.AwaitedWorkflowTypeEntries (changes below depth limit)
  ├─ IWorkflowRouteEntries.GetWorkflowRouteEntriesAsync → WorkflowRouteEntries<TWorkflowRouteDocument>.GetWorkflowRouteEntriesAsync (depth limit)
  ├─ if (!workflowEntriesTask.IsCompletedSuccessfully)
~ │  └─ WorkflowActionFilter.OnActionExecutionAsync.AwaitedWorkflowEntries (changes below depth limit)
~ └─ WorkflowActionFilter.ProcessWorkflowsAsync (changes below depth limit)

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  HomeController.ServiceEndpoint
~ ├─ HomeController.DispatchAsync (changes below depth limit)
  ├─ possible initialization of MemoryStreamFactory
  ├─ MemoryStreamFactory.GetStream
  └─ …

  new ResourceManagementOptionsConfiguration
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  ResourceManagementOptionsConfiguration.Configure
  └─ possible initialization of ResourceManagementOptionsConfiguration
~    └─ initialization of ResourceManagementOptionsConfiguration (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  ShellsSettingsSourcesExtensions.AddSourcesAsync
  └─ IShellsSettingsSources.AddSourcesAsync
~    ├─ ⇢ DatabaseShellsSettingsSources.AddSourcesAsync (changes below depth limit)
     └─ ⇢ ShellsSettingsSources.AddSourcesAsync (depth limit)

  ShellScope.UsingChildScopeAsync
~ ├─ ShellScope.CreateChildScopeAsync (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)

  ShellScope.UsingChildScopeAsync
~ ├─ ShellScope.CreateChildScopeAsync (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.DisableFeaturesAsync
~ └─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.EnableFeaturesAsync
~ └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.UpdateFeaturesAsync
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
~ └─ IShellFeaturesManager.UpdateFeaturesAsync → ShellFeaturesManager.UpdateFeaturesAsync (changes below depth limit)

  ShellHostExtensions.ReleaseAllShellContextsAsync
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings
  └─ foreach (var settings in shellHost.GetAllSettings())
~    └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)

  ShellHostExtensions.ReloadAllShellContextsAsync
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings
  └─ foreach (var settings in shellHost.GetAllSettings())
~    └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)

  ServiceExtensions.AddOrchardCms
~ └─ ServiceExtensions.AddOrchardCms (changes below depth limit)

  AutoroutePartIndexProvider.Describe
~ └─ AutoroutePartIndexProvider.Describe (changes below depth limit)

  ContentLocalizationOrchardHelperExtensions.GetContentCultureAsync
  ├─ new CultureAspect
~ └─ IContentManager.PopulateAspectAsync → DefaultContentManager.PopulateAspectAsync (changes below depth limit)

  ContentManagerExtensions.GetContentItemMetadataAsync
~ └─ ContentManagerExtensions.PopulateAspectAsync (changes below depth limit)

  ContentManagerExtensions.UpdateValidateAndCreateAsync
~ ├─ IContentManager.UpdateAsync → DefaultContentManager.UpdateAsync (changes below depth limit)
~ ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (changes below depth limit)
  └─ if (result.Succeeded)
~    └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)

  ContentOrchardRazorHelperExtensions.DisplayAsync
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  DefaultContentManager.CreateContentItemVersionAsync
~ └─ DefaultContentManager.CreateContentItemVersionAsync (changes below depth limit)

  DefaultContentManager.UpdateContentItemVersionAsync
~ └─ DefaultContentManager.UpdateContentItemVersionAsync (changes below depth limit)

  OrchardCoreBuilderExtensions.AddLiquidViews
  └─ OrchardCoreBuilder.ConfigureServices (depth limit)
~    └─ LiquidCoreServices.AddLiquidCoreServices (changes below depth limit)

  LiquidPage.ExecuteAsync
~ └─ LiquidViewTemplate.RenderAsync (changes below depth limit)

  new LiquidViewParser
  ├─ RegisterEmptyTag
~ │  └─ RenderBodyTag.WriteToAsync (changes below depth limit)
  ├─ RegisterParserTag
~ │  └─ RenderSectionTag.WriteToAsync (changes below depth limit)
  ├─ RegisterParserTag
  ├─ RegisterParserTag
  ├─ …
  ├─ RegisterParserTag
  ├─ RegisterParserTag
  ├─ RegisterParserTag
~ │  └─ FluidTagHelper.WriteArgumentsTagHelperAsync (changes below depth limit)
  ├─ RegisterParserBlock
~ │  └─ FluidTagHelper.WriteArgumentsBlockHelperAsync (changes below depth limit)
  ├─ RegisterParserTag
~ │  └─ ShapeTag.WriteToAsync (changes below depth limit)
  ├─ RegisterParserBlock
~ │  └─ ZoneTag.WriteToAsync (changes below depth limit)
  ├─ ArgumentsList.AndSkip(TagEnd).And(Parsers.ZeroOrOne(AnyTagsList.AndSkip(CreateTag("enda")))).Then<Statement>
  │  └─ new LiquidViewParser.ParserBlockStatement<T>
~ │     └─ DefaultAnchorTag.WriteToAsync (changes below depth limit)
  ├─ RegisterParserBlock
~ │  └─ FluidTagHelper.WriteToAsync (changes below depth limit)
  ├─ RegisterParserBlock
  ├─ RegisterParserTag
  └─ …

  CultureValue.GetValueAsync
  ├─ case "Dir"
  ├─ case "SupportedCultures"
  │  └─ if (_culture is null)
~ │     └─ CultureValue.GetSupportedCulturesAsync (changes below depth limit)
  └─ case "DefaultCulture"
     └─ if (_culture is null)
~       └─ CultureValue.GetDefaultCultureAsync (changes below depth limit)

  DisplayDriverBase.Copy
  └─ DisplayDriverBase.Factory
     ├─ …
     ├─ ⇢ SiteDisplayDriver<TSettings>.Factory (depth limit)
     ├─ ⇢ DisplayDriverBase.Factory (depth limit)
~    └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  DisplayDriverBase.Dynamic
  └─ DisplayDriverBase.Factory
     ├─ …
     ├─ ⇢ SiteDisplayDriver<TSettings>.Factory (depth limit)
     ├─ ⇢ DisplayDriverBase.Factory (depth limit)
~    └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  DisplayDriverBase.Dynamic
  └─ DisplayDriverBase.Factory ↑ as above

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DefaultShapeFactory.TryInvokeMember
  ├─ Arguments.From (depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  DisplayHelper.TryInvoke
  ├─ Arguments.From (depth limit)
~ └─ DisplayHelper.InvokeAsync (changes below depth limit)

  DisplayHelper.TryInvokeMember
  ├─ Arguments.From (depth limit)
~ └─ DisplayHelper.InvokeAsync (changes below depth limit)

  NotifyFilter.OnResultExecutionAsync
  ├─ if (_shouldDeleteCookie)
  ├─ ResultExecutingContextExtensions.IsViewOrPageResult
~ └─ NotifyFilter.OnResultExecutionAsyncCore (changes below depth limit)

  RazorPage<TModel>.DisplayAsAsync
  ├─ if (clearAlternates.Value)
  ├─ RazorPage<TModel>.EnsureDisplayHelper
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  RazorPage<TModel>.DisplayAsync
  ├─ if (shape is IShape s)
  │  ├─ RazorPage<TModel>.EnsureDisplayHelper
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ if (shape is string str)

  RazorPage<TModel>.RenderBodyAsync
~ └─ RazorPage<TModel>.DisplayAsync (changes below depth limit)

  RazorPage<TModel>.RenderSection
~ └─ RazorPage<TModel>.RenderSection (changes below depth limit)

  RazorPage<TModel>.RenderSectionAsync
~ └─ RazorPage<TModel>.RenderSectionAsync (changes below depth limit)

  RazorViewActionFilter.OnActionExecutionAsync
~ ├─ RazorViewActionFilter.OnActionExecutionAsync (changes below depth limit)
  └─ if (!task.IsCompletedSuccessfully)

  RazorViewActionFilter.OnPageHandlerExecutionAsync
~ ├─ RazorViewActionFilter.OnActionExecutionAsync (changes below depth limit)
  └─ if (!task.IsCompletedSuccessfully)

  Page.DisplayAsync
  ├─ if (shape is IShape s)
  │  ├─ Page.EnsureDisplayHelper
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ if (shape is string str)

  Page.RenderSectionAsync
~ └─ Page.RenderSectionAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ IShapeFactory.CreateAsync → DefaultShapeFactory.CreateAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  CoreShapes.List
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var item in items)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  CoreShapes.NotifyMessages
  ├─ shape.Properties.TryGetValue
  └─ foreach (var entry in messages)
     ├─ Arguments.From (depth limit)
~    ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.Card
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  ├─ AlternatesCollection.Clear (depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ StringExtensions.HtmlClassify (depth limit)

  GroupShapes.CardContainer
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var card in shape.Items.OfType<IShape>())
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.Column
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var column in shape.Items)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.ColumnContainer
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var column in shape.Items)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.LocalNavigation
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.Tab
  ├─ …
  ├─ StringExtensions.HtmlClassify (depth limit)
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.TabContainer
  ├─ new LocalNavigationArguments (depth limit)
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var tab in shape.Items.OfType<IShape>())
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PageTitleShapes.PageTitle
  ├─ …
  ├─ ISiteService.GetSiteSettingsAsync → SiteService.GetSiteSettingsAsync (depth limit)
  ├─ if (string.IsNullOrWhiteSpace(siteSettings.PageTitleFormat))
  └─ else (!(string.IsNullOrWhiteSpace(siteSettings.PageTitleFormat)))
~    └─ LiquidTemplateManagerExtensions.RenderHtmlContentAsync (changes below depth limit)

  ThemeLayout.ExecuteAsync
  ├─ RazorPage<TModel>.RenderLayoutBody
  └─ if (ThemeLayout != null)
     ├─ IShapeExtensions.AddAsync (depth limit)
~    ├─ RazorPage<TModel>.DisplayAsync (changes below depth limit)
     ├─ PositionWrapper.TryWrap (depth limit)
     ├─ foreach (var zone in ThemeLayout.Properties.ToArray())
     │  └─ if (zone.Value is IShape shape)
     │     ├─ IShapeExtensions.IsNullOrEmpty
~    │     ├─ RazorPage<TModel>.DisplayAsync (changes below depth limit)
     │     └─ PositionWrapper.TryWrap (depth limit)
~    └─ RazorPage<TModel>.DisplayAsync (changes below depth limit)

  ZoneShapes.CardGrouping
  ├─ if (groupings.Count > 1)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ possible initialization of FlatPositionComparer
  │  ├─ foreach (var orderedGrouping in orderedGroupings)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ foreach (var item in orderedGrouping)
  │  │  └─ IShapeExtensions.AddAsync (depth limit)
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ else (!(groupings.Count > 1))
~    ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  ZoneShapes.ColumnGrouping
  ├─ if (hasColumnItems)
  │  ├─ if (beforeRow is not null)
  │  │  └─ foreach (var item in beforeRow)
~ │  │     └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ possible initialization of FlatPositionComparer
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ foreach (var columnItem in sortedColumnItems)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ StringExtensions.HtmlClassify (depth limit)
  │  │  ├─ IShapeExtensions.AddAsync (depth limit)
  │  │  └─ …
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  └─ if (afterRow is not null)
  │     └─ foreach (var item in afterRow)
~ │        └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ else (!(hasColumnItems))
     └─ foreach (var item in allItems)
~       └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  ZoneShapes.ContentZone
  ├─ if (!isGrouped)
  │  └─ foreach (var item in shapes)
~ │     └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ if (groupings.Count > 1)
  │  ├─ possible initialization of FlatPositionComparer
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ foreach (var orderedGrouping in orderedGroupings)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ foreach (var item in orderedGrouping)
  │  │  └─ IShapeExtensions.AddAsync (depth limit)
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ else (!(groupings.Count > 1))
     └─ if (groupings.Count == 1)
~       ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~       └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  ZoneShapes.Zone
  └─ foreach (var item in Shape)
~    └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  LiquidTemplateManagerExtensions.RenderHtmlContentAsync
~ └─ ILiquidTemplateManager.RenderHtmlContentAsync → LiquidTemplateManager.RenderHtmlContentAsync (changes below depth limit)

  LiquidTemplateManagerExtensions.RenderStringAsync
~ └─ ILiquidTemplateManager.RenderAsync → LiquidTemplateManager.RenderAsync (changes below depth limit)

  LiquidTemplateManagerExtensions.RenderStringAsync
~ └─ ILiquidTemplateManager.RenderAsync → LiquidTemplateManager.RenderAsync (changes below depth limit)

  LiquidTemplateManagerExtensions.RenderStringAsync
~ └─ ILiquidTemplateManager.RenderAsync → LiquidTemplateManager.RenderAsync (changes below depth limit)

  LocalizationOrchardHelperExtensions.GetJSLocalizations
~ └─ JSLocalizerExtensions.GetMergedLocalizations (changes below depth limit)

  ReCaptchaShape.ReCaptcha
  ├─ ReCaptchaSettings.ConfigurationExists
~ ├─ ReCaptchaShape.GetReCaptchaScriptUrlAsync (changes below depth limit)
  └─ IResourceManager.RegisterFootScript → ResourceManager.RegisterFootScript

  UserStore.CreateAsync
  ├─ if (string.IsNullOrEmpty(newUserId))
  └─ try
     ├─ …
     ├─ new UserCreateContext (depth limit)
     ├─ InvokeExtensions.InvokeAsync (depth limit)
     └─ InvokeExtensions.InvokeAsync (depth limit)
        └─ IUserEventHandler.CreatedAsync
           ├─ ⇢ UserEventHandler.CreatedAsync (depth limit)
~          ├─ ⇢ UserEventHandler.CreatedAsync (changes below depth limit)
           └─ ⇢ UserEventHandlerBase.CreatedAsync

  UserStore.DeleteAsync
  └─ try
     ├─ new UserDeleteContext (depth limit)
     ├─ InvokeExtensions.InvokeAsync (depth limit)
     └─ InvokeExtensions.InvokeAsync (depth limit)
        └─ IUserEventHandler.DeletedAsync
           ├─ ⇢ UserEventHandler.DeletedAsync (depth limit)
           ├─ ⇢ UserEventHandler.DeletedAsync (depth limit)
~          ├─ ⇢ UserEventHandler.DeletedAsync (changes below depth limit)
           └─ ⇢ UserEventHandlerBase.DeletedAsync

  UserStore.UpdateAsync
  └─ try
     ├─ new UserUpdateContext (depth limit)
     ├─ InvokeExtensions.InvokeAsync (depth limit)
     └─ InvokeExtensions.InvokeAsync (depth limit)
        └─ IUserEventHandler.UpdatedAsync
           ├─ ⇢ UserEventHandler.UpdatedAsync (depth limit)
           ├─ ⇢ UserEventHandler.UpdatedAsync (depth limit)
~          ├─ ⇢ UserEventHandler.UpdatedAsync (changes below depth limit)
           └─ ⇢ UserEventHandlerBase.UpdatedAsync

  new DistributedShellHostedService
  ├─ callback
~ │  └─ DistributedShellHostedService.LoadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReleasingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReloadingAsync (changes below depth limit)
  └─ callback
~    └─ DistributedShellHostedService.RemovingAsync (changes below depth limit)

  DistributedShellHostedService.ExecuteAsync
  ├─ possible initialization of DistributedShellHostedService
  ├─ while (!stoppingToken.IsCancellationRequested)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ IShellHost.TryGetShellContext → ShellHost.TryGetShellContext
  │  │  ├─ ShellSettingsExtensions.IsUninitialized
  │  │  ├─ if (defaultTenantSyncingSeconds++ > DefaultTenantSyncingPeriod)
  │  │  │  ├─ IShellSettingsManager.LoadSettingsAsync ↑ as above
  │  │  │  ├─ ShellSettingsExtensions.AsDisposable
  │  │  │  ├─ ShellSettingsExtensions.IsRunning
  │  │  │  └─ if (loadedDefaultSettings.IsRunning())
~ │  │  │     └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  │  │  ├─ ShellSettingsExtensions.IsRunning
~ │  │  ├─ DistributedShellHostedService.GetOrCreateDistributedContextAsync (changes below depth limit)
  │  │  ├─ catch (Exception ex) when (!ex.IsFatal())
  │  │  ├─ catch (Exception ex) when (!ex.IsFatal())
  │  │  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings
  │  │  ├─ if (shellCountChangedId is not null && _shellCountChangedId != shellCountChangedId)
  │  │  │  ├─ IShellSettingsManager.LoadSettingsNamesAsync
~ │  │  │  │  ├─ ⇢ ShellSettingsManager.LoadSettingsNamesAsync (changes below depth limit)
  │  │  │  │  └─ ⇢ SingleShellSettingsManager.LoadSettingsNamesAsync
  │  │  │  └─ foreach (var tenant in tenantsToCreate)
  │  │  │     ├─ IShellSettingsManager.LoadSettingsAsync ↑ as above
  │  │  │     └─ ShellSettingsExtensions.AsDisposable
  │  │  └─ foreach (var settings in loadedSettings)
  │  │     ├─ DistributedShellHostedService.TryWaitAfterBusyTime (depth limit)
  │  │     ├─ try
  │  │     │  ├─ DistributedShellHostedService.ReleaseIdKey
  │  │     │  ├─ if (releaseId is not null && !tenantsToCreate.Contains(settings.Name))
  │  │     │  │  ├─ _identifiers.GetOrAdd
  │  │     │  │  └─ if (identifier.ReleaseId != releaseId)
~ │  │     │  │     └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  │  │     │  ├─ DistributedShellHostedService.ReloadIdKey
  │  │     │  ├─ if (reloadId is not null)
  │  │     │  │  ├─ _identifiers.GetOrAdd
  │  │     │  │  └─ if (identifier.ReloadId != reloadId)
~ │  │     │  │     └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  │  │     │  ├─ ShellSettingsExtensions.IsDefaultShell
  │  │     │  └─ if (!settings.IsDefaultShell() && tenantsToRemove.Contains(settings.Name))
  │  │     │     ├─ ShellSettingsExtensions.IsRemovable (depth limit)
  │  │     │     └─ if (settings.IsRemovable())
~ │  │     │        ├─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)
  │  │     │        └─ else (!(removingContext.FailedOnLockTimeout))
~ │  │     │           └─ IShellHost.RemoveShellContextAsync → ShellHost.RemoveShellContextAsync (changes below depth limit)
  │  │     └─ catch (Exception ex) when (!ex.IsFatal())
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ callback
~ │  └─ DistributedShellHostedService.LoadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReleasingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReloadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.RemovingAsync (changes below depth limit)
  └─ if (_context is not null)

  ModularBackgroundService.ExecuteAsync
  ├─ if (_options.ShellWarmup)
  │  ├─ try
~ │  │  └─ IShellHost.InitializeAsync → ShellHost.InitializeAsync (changes below depth limit)
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ while (GetRunningShells().Length == 0)
  └─ while (!stoppingToken.IsCancellationRequested)
     ├─ try
     │  ├─ ModularBackgroundService.GetRunningShells (depth limit)
~    │  ├─ ModularBackgroundService.UpdateAsync (changes below depth limit)
~    │  └─ ModularBackgroundService.RunAsync (changes below depth limit)
     ├─ catch (Exception ex) when (!ex.IsFatal())
     └─ ModularBackgroundService.WaitAsync

  ModularTenantContainerMiddleware.Invoke
~ ├─ IShellHost.InitializeAsync → ShellHost.InitializeAsync (changes below depth limit)
  ├─ RunningShellTableExtensions.Match (depth limit)
  └─ if (shellSettings is not null)
     ├─ ShellSettingsExtensions.IsInitializing
     ├─ HttpContextExtensions.UseShellScopeServices (depth limit)
~    ├─ IShellHost.GetScopeAsync → ShellHost.GetScopeAsync (changes below depth limit)
     ├─ new ShellContextFeature
~    └─ ShellScope.UsingAsync (changes below depth limit)
        └─ if (feature?.Error is not null)

  ModularTenantRouterMiddleware.Invoke
  ├─ ShellContextExtensions.HasPipeline
  ├─ if (!shellContext.HasPipeline())
~ │  └─ ModularTenantRouterMiddleware.Invoke.Awaited (changes below depth limit)
  └─ IShellPipeline.Invoke → ShellRequestPipeline.Invoke
```
