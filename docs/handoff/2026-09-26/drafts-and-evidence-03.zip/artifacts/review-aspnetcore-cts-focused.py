from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import flatten, schema, jsonschema

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
path = root / 'aspnetcore-stream-cts-disposal-static-candidate-source-focused.json'
data = json.loads(path.read_text(encoding='utf-8'))
jsonschema.validate(data, schema)
nodes = list(flatten(data['trees']))
assert len(nodes) == len({node['id'] for node in nodes}) == 114
assert len(data['trees']) == 1
changes = [node for node in nodes if node['change'] != 'unchanged']
assert len(changes) == 1
added = changes[0]
assert added['label'] == 'streamCts.Dispose' and added['change'] == 'added' and added['before'] is None
assert added['kind'] == 'call' and added['children'] == [] and added['detail'] is None and added['omission'] is None
source_path = 'src/SignalR/server/Core/src/Internal/DefaultHubDispatcher.cs'
assert added['after'] == {
    'symbolId': 'source::System.Threading.CancellationTokenSource.Dispose()',
    'signature': None, 'binding': 'resolved', 'dispatch': 'direct',
    'targetIds': ['source::System.Threading.CancellationTokenSource.Dispose()'],
    'definition': None,
    'callSites': [{'path': source_path, 'startLine': 612, 'startColumn': 17, 'endLine': 612, 'endColumn': 36}],
    'relation': 'call', 'candidates': [], 'origin': 'metadata'
}
parent = next(node for node in nodes if added in node['children'])
assert parent['label'] == 'if (!connection.ActiveRequestCancellationSources.TryAdd(invocationId, streamCts))'
assert parent['children'][-1] == added
assert parent['children'][-2]['label'] == 'DefaultHubDispatcherLog.InvocationIdInUse'
for node in nodes:
    if node == added:
        continue
    assert node['before'] is not None and node['after'] is not None
    expected = copy.deepcopy(node['before'])
    for location in [expected['definition'], *expected['callSites']]:
        if location is None or location['path'] != source_path:
            continue
        for field in ['startLine', 'endLine']:
            if location[field] is not None and location[field] >= 612:
                location[field] += 1
    assert expected == node['after'], (node['id'], node['label'])
existing = [node for node in nodes if node['label'] == 'streamCts.Dispose' and node['change'] == 'unchanged']
assert len(existing) == 1
assert existing[0]['before']['callSites'][0]['startLine'] == 684
assert existing[0]['after']['callSites'][0]['startLine'] == 685
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore'
before, after = data['from']['commit'], data['to']['commit']
sources = [subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + source_path]).decode('utf-8-sig') for revision in [before, after]]
old_lines, new_lines = [source.splitlines() for source in sources]
assert new_lines[611].strip() == 'streamCts.Dispose();'
assert old_lines[611].strip() == new_lines[612].strip() == 'return;'
assert old_lines == new_lines[:611] + new_lines[612:]
blobs = [subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + source_path], text=True).strip() for revision in [before, after]]
callback_path = root / 'aspnetcore-http-response-callback-review.json'
callback = json.loads(callback_path.read_text(encoding='utf-8'))
jsonschema.validate(callback, schema)
paths = []
def visit(node, ancestors):
    current = ancestors + [node]
    if node['label'] == 'disposable.Dispose':
        paths.append(current)
    for child in node['children']:
        visit(child, current)
for node in callback['trees']:
    visit(node, [])
assert len(paths) == 1
dispose_path = paths[0]
assert any(node['label'] == 'callback' and node['after']['relation'] == 'callback' for node in dispose_path)
assert dispose_path[-1]['after']['dispatch'] == 'possible'
assert len(dispose_path[-1]['after']['targetIds']) == 267
proof = {
    'before': before, 'after': after, 'sourcePath': source_path, 'sourceBlobs': dict(zip(['before', 'after'], blobs)),
    'focusedJsonSha256': digest(path), 'nodes': len(nodes), 'onlyChangedCall': added,
    'allOtherSidesEqualExceptExactOneLineSourceShift': True,
    'existingFinallyDisposePreserved': True,
    'callbackTreeSha256': digest(callback_path),
    'httpResponseDisposalHasCallbackAncestor': True,
    'possibleCanonicalDisposeTargets': 267,
    'review': 'The immutable diff adds exactly one Dispose before the duplicate-invocation early return. The existing finally disposal remains unchanged. All other 113 node sides match after the independently known source-line shift. The broad root witness preserves deferred callback ancestry and possible dispatch; it does not prove that any sample root invokes the changed SignalR method at runtime.',
    'semanticFocusedJsonReviewed': True, 'renderReviewPending': True, 'automaticRootReviewPending': True, 'accepted': False
}
text_path = path.with_suffix('.text')
markdown_path = path.with_suffix('.md')
if text_path.exists() and markdown_path.exists() and markdown_path.stat().st_size:
    rendered = text_path.read_text(encoding='utf-8')
    markdown = markdown_path.read_text(encoding='utf-8')
    assert markdown == '```diff\n' + rendered + '```\n'
    assert [line for line in rendered.splitlines() if line.startswith(('+ ', '- ', '~ '))] == ['+ │  │  └─ streamCts.Dispose']
    assert '  │  ├─ if (!connection.ActiveRequestCancellationSources.TryAdd(invocationId, streamCts))\n  │  │  ├─ DefaultHubDispatcherLog.InvocationIdInUse\n+ │  │  └─ streamCts.Dispose\n' in rendered
    for format in ['text', 'md']:
        assert digest(path.with_suffix('.' + format + '.stderr')) == digest(path.with_suffix('.json.stderr'))
    proof.update(renderReviewPending=False, focusedTextSha256=digest(text_path), focusedMarkdownSha256=digest(markdown_path), textAndMarkdownMatch=True, onlyRenderedChangeIsConditionalDispose=True)
(root / 'aspnetcore-cts-focused-json-review.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed one added conditional CTS disposal, preserved all 113 other node sides and existing finally disposal, and verified explicit callback ancestry.')
