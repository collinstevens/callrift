from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
build = root / 'artifacts/dispatch-cardinality-cli-tests/build/bin/Check/debug'
assert (build / 'Check.dll').exists()
worker = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug'
cores = {
    'baseline': worker / 'Callrift.Core.dll',
    'complete': root / 'artifacts/dispatch-cardinality-complete-boundaries/build/bin/Callrift.Core/debug/Callrift.Core.dll'
}
report = {}
for name, core in cores.items():
    target = root / ('artifacts/dispatch-cardinality-cli-tests/' + name + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(worker / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(worker / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    for relative in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']:
        shutil.copy2(core, target / relative)
    report[name] = {relative: hashlib.sha256((target / relative).read_bytes()).hexdigest() for relative in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.MSBuild.dll']}
(root / 'artifacts/dispatch-cardinality-cli-tests-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report))
