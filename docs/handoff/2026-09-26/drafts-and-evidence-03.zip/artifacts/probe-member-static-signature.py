from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parents[1]
repository = Path(tempfile.mkdtemp(prefix='callrift-static-signature-'))
cli = root / 'artifacts/static-coalesce-initialization-cli-tests/candidate-ready/callrift.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def git(*arguments):
    return subprocess.check_output(['git', '-C', str(repository), *arguments], stderr=subprocess.STDOUT).decode('utf-8').strip()
git('init', '-b', 'main')
git('config', 'user.name', 'callrift fixture')
git('config', 'user.email', 'fixture@example.invalid')
git('config', 'core.autocrlf', 'false')
(repository / 'App.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>\n', encoding='utf-8', newline='\n')
source = 'public sealed class Api { public int Read() => 1; }\n'
(repository / 'Api.cs').write_text(source, encoding='utf-8', newline='\n')
git('add', 'App.csproj', 'Api.cs')
git('-c', 'commit.gpgsign=false', 'commit', '-m', 'fixture before')
before = git('rev-parse', 'HEAD')
(repository / 'Api.cs').write_text(source.replace('public int Read', 'public static int Read'), encoding='utf-8', newline='\n')
git('add', 'Api.cs')
git('-c', 'commit.gpgsign=false', 'commit', '-m', 'fixture after')
after = git('rev-parse', 'HEAD')
results = []
for mode, options in [('source', []), ('msbuild', ['--project', 'App.csproj'])]:
    output = root / 'artifacts' / ('member-static-signature-' + mode + '.json')
    error = output.with_suffix('.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), 'diff', before, after, '--entry', 'Api.Read', '--format', 'json', *options]
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=repository, stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    assert code == 0, error.read_text(encoding='utf-8')
    data = json.loads(output.read_text(encoding='utf-8'))
    assert data['diagnostics'] == []
    result = {'mode': mode, 'exitCode': code, 'hasChanges': data['hasChanges'], 'roots': len(data['trees']), 'diagnostics': len(data['diagnostics']), 'expectedHasChanges': True, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'seconds': time.monotonic() - started, 'command': command}
    results.append(result)
    print(json.dumps(result), flush=True)
record = {'repository': str(repository), 'before': before, 'after': after, 'sourceBefore': source, 'sourceAfter': source.replace('public int Read', 'public static int Read'), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'results': results, 'reason': 'Changing a public instance method into a static method changes its receiver requirement and API signature while retaining its body. The selected declaration exists on both sides, so an empty diff loses that declaration change.'}
(root / 'artifacts/member-static-signature-probe.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
