from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path.cwd()
repository = Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore')
cli = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug/callrift.dll'
assert hashlib.sha256((cli.parent / 'Callrift.Core.dll').read_bytes()).hexdigest() == '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'
assert hashlib.sha256((cli.parent / 'msbuild/Callrift.MSBuild.dll').read_bytes()).hexdigest() == '039cf4cdca0851530b0eca7aaedfe75a4235a40101dc63169431d05a630eda7d'
cases = json.loads((root / 'artifacts/orchardcore-expansion-candidates.json').read_text(encoding='utf-8'))
results = []
for case in cases[:2]:
    focus = ['--depth', '3', '--externals'] + [argument for entry in case['entries'] for argument in ['--entry', entry]]
    project = ['--project', case['project'], '--framework', case['framework']]
    views = [('msbuild-roots', ['--depth', '1', *project]), ('source-roots', ['--depth', '1']), ('source-focused', focus), ('msbuild-focused', [*focus, *project])]
    for view, options in views:
        for format in (['json', 'text', 'md'] if view == 'msbuild-roots' else ['text', 'md']):
            name = case['id'] + '-' + view
            output = root / 'artifacts' / (name + '.' + format)
            error = root / 'artifacts' / (name + '.' + format + '.err')
            assert not output.exists()
            start = time.monotonic()
            with output.open('w', encoding='utf-8', newline='\n') as stdout, error.open('w', encoding='utf-8', newline='\n') as stderr:
                process = subprocess.Popen(['dotnet', str(cli), 'diff', case['before'], case['after'], '--format', format, '--color', 'never', *options], cwd=repository, env=dict(os.environ, NO_COLOR='1'), stdout=stdout, stderr=stderr)
                try:
                    code = process.wait(timeout=900)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
                    process.wait()
                    code = 124
            record = {'id': case['id'], 'view': view, 'format': format, 'exit': code, 'seconds': round(time.monotonic() - start, 2), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'accepted': False}
            if format == 'json' and code == 0:
                document = json.loads(output.read_text(encoding='utf-8-sig'))
                record.update(roots=len(document['trees']), diagnostics=len(document['diagnostics']), truncated=document['truncated'])
            results.append(record)
            (root / 'artifacts/orchardcore-expansion-formats.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
            print(json.dumps(record), flush=True)
            assert code == 0, name + '/' + format
