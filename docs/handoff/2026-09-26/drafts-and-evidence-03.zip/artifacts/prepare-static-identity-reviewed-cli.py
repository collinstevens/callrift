from pathlib import Path
import shutil

root = Path('artifacts')
source = root / 'static-initialization-scope-cli'
target = root / 'static-initialization-identity-reviewed-cli'
assert not target.exists()
target.mkdir()
for path in source.iterdir():
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, target / path.name)
path = target / 'StaticInitializationIdentityTests.cs'
text = path.read_text(encoding='utf-8-sig').replace('Left/Shared.csproj', 'Left/Left.csproj').replace('Right/Shared.csproj', 'Right/Right.csproj')
text = text.replace('Assert.StartsWith("exit: 0\\n", output);', 'Assert.True(output.StartsWith("exit: 0\\n", StringComparison.Ordinal), output);')
path.write_text(text, encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-scope-cli.py').read_text(encoding='utf-8')
freeze = freeze.replace("directory = r / 'static-initialization-scope-cli'", "directory = r / 'static-initialization-identity-reviewed-cli'")
freeze = freeze.replace("'static-initialization-scope-cli-build.log'", "'static-initialization-identity-reviewed-cli-build.log'")
freeze = freeze.replace("'static-initialization-scope-cli-inputs.json'", "'static-initialization-identity-reviewed-cli-inputs.json'")
(root / 'freeze-static-identity-reviewed-cli.py').write_text(freeze, encoding='utf-8', newline='\n')
print(target)
