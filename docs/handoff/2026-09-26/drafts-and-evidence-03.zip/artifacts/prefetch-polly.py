import pathlib
import subprocess

root = pathlib.Path(__file__).resolve().parent
ids = (root / 'polly-prefetch-object-ids.txt').read_text().splitlines()
assert all(len(value) == 40 and all(c in '0123456789abcdef' for c in value) for value in ids)
with (root / 'polly-prefetch.log').open('wb') as output:
    result = subprocess.run(['git', '-C', 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/polly', '-c', 'fetch.negotiationAlgorithm=noop', 'fetch', 'origin', '--no-tags', '--no-write-fetch-head', '--recurse-submodules=no', '--filter=blob:none', '--stdin'], input=('\n'.join(ids) + '\n').encode(), stdout=output, stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
