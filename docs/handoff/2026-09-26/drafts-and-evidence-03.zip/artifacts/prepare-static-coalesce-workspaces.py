from pathlib import Path
import shutil

root = Path('artifacts')
target = root / 'static-coalesce-complete-workspaces'
assert not target.exists()
target.mkdir()
for path in Path('tests/Callrift.Workspaces').glob('*.cs'):
    shutil.copy2(path, target / path.name)
shutil.copy2(root / 'static-interceptor-identity-workspaces-v2/InterceptorTests.cs', target / 'InterceptorTests.cs')
shutil.copy2(root / 'static-initialization-callback-workspaces/Check.csproj', target / 'Check.csproj')
program = (root / 'static-interceptor-identity-probe/Program.cs').read_text(encoding='utf-8')
fixture_start = program.index('foreach (var fixture in new[]\n{') + len('foreach (var fixture in new[]\n{')
fixture_end = program.index('\n})\n{', fixture_start)
fixtures = program[fixture_start:fixture_end]
body_start = program.index('    var before = Graph(', fixture_end)
body_end = program.index('    var passed = ', body_start)
body = program[body_start:body_end]
graph_start = program.index('    CallGraph Graph(', body_end)
graph_end = program.index('\n}\nFile.WriteAllText(', graph_start)
graph = program[graph_start:graph_end]
graph = graph.replace('        var attributes = invocations.Select', '#pragma warning disable RSEXPERIMENTAL002\n        var attributes = invocations.Select')
graph = graph.replace('        var initializer = ', '#pragma warning restore RSEXPERIMENTAL002\n        var initializer = ')
source = '''using System.Text.Json;
using Callrift.Core;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Xunit;

namespace Callrift.Workspaces;

public sealed class GeneratedInitializerIdentityTests
{
    private static readonly (string Name, bool Explicit, bool Shared, string Change)[] Fixtures =
    [''' + fixtures + '''
    ];

    public static IEnumerable<object[]> Cases => Fixtures.SelectMany(fixture => new[] { new object[] { fixture.Name, false }, new object[] { fixture.Name, true } });

    [Theory]
    [MemberData(nameof(Cases))]
    public void GeneratedInitializersKeepStableIdentityAndExposeRealChanges(string name, bool serialized)
    {
        var fixture = Fixtures.Single(fixture => fixture.Name == name);
        var options = new DiffOptions { MaxDepth = 10, IncludeExternals = true };
''' + '\n'.join('    ' + line if line else '' for line in body.rstrip().splitlines()) + '''
        Assert.True(stableKeys);
        Assert.True(noRandomNames);
        Assert.Equal(expectedRoots, actualRoots);
        Assert.True(changedCalls);
        Assert.Empty(diff.Diagnostics);

''' + '\n'.join(line if line.startswith('#pragma') else '    ' + line if line else '' for line in graph.splitlines()) + '''
    }

    private static IEnumerable<DiffNode> Flatten(IEnumerable<DiffNode> nodes) => nodes.SelectMany(node => new[] { node }.Concat(Flatten(node.Children)));
}
'''
(target / 'GeneratedInitializerIdentityTests.cs').write_text(source, encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-interceptor-workspaces.py').read_text(encoding='utf-8')
freeze = freeze.replace("'static-interceptor-identity-workspaces'", "'static-coalesce-complete-workspaces'")
old = "[('baseline', root / 'static-callback-initialization-cli/candidate-ready'), ('candidate', root / 'static-interceptor-identity-cli/candidate-ready')]"
assert old in freeze
freeze = freeze.replace(old, "[('candidate', root / 'static-coalesce-initialization-cli-tests/candidate-ready')]")
freeze = freeze.replace('Frozen baseline and candidate workspace checks', 'Frozen complete workspace checks')
(root / 'freeze-static-coalesce-workspaces.py').write_text(freeze, encoding='utf-8', newline='\n')
print('Prepared all26 CLI workspace checks plus16 generated initializer API regressions as test source.')
