from pathlib import Path

root = Path('artifacts')
source = (root / 'static-trigger-final/Program.cs').read_text(encoding='utf-8-sig')
start = source.index('    ("explicit-method-repeated"')
end = source.index('\n};', start)
state = 'static class State { public static int Value; static State() { Sink.Before(); } public static int Read() => Value; } static class Hold { public static void Accept(System.Func<int> first, System.Func<int> second) { Sink.Add(\\\"accept\\\"); _ = second(); } }'
cases = []
for name, first, second in [
    ('field', '() => { _ = State.Value; return State.Value; }', '() => State.Value'),
    ('method', '() => { _ = State.Read(); return State.Read(); }', '() => State.Read()'),
    ('method-group', 'State.Read', 'State.Read')
]:
    invocation = 'Hold.Accept(' + first + ', ' + second + '); Sink.Add(\\\"done\\\"); _ = State.Value;'
    cases.append('    ("' + name + '", "' + state + '", "' + invocation + '", "accept,before,done", true)')
source = source[:start] + ',\n'.join(cases) + source[end:]
source = source.replace('    Console.WriteLine(JsonSerializer.Serialize(new { fixture.Name,', '''    IEnumerable<DiffNode> Flatten(IEnumerable<DiffNode> nodes) => nodes.SelectMany(node => new[] { node }.Concat(Flatten(node.Children)));
    var nodes = Flatten(tree.Trees).ToArray();
    var initializerCount = nodes.Count(node => node.Label == "initialization of State");
    var callbackBranchCount = nodes.Count(node => node.Label == "possible initialization of State" && node.After?.Relation == "callback");
    Console.WriteLine(JsonSerializer.Serialize(new { initializerCount, callbackBranchCount, fixture.Name,''')
for name, core in [('static-callback-runtime-baseline', 'static-initialization-complete-cli/candidate-ready'), ('static-callback-runtime-candidate', 'static-callback-initialization-cli/candidate-ready')]:
    target = root / name
    assert not target.exists()
    target.mkdir()
    (target / 'Program.cs').write_text(source, encoding='utf-8', newline='\n')
    project = (root / 'static-trigger-final/Check.csproj').read_text(encoding='utf-8-sig').replace('static-initialization-complete-cli/candidate-ready', core)
    (target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared compiler/runtime checks for independently supplied callback arguments.')
