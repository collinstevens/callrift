from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/dispatch-cardinality-complete-corpus'
target = root / 'artifacts/dispatch-cycle-corpus'
assert not target.exists()
target.mkdir()
for name in ['Check.csproj', 'RealWorldCaseTests.cs']:
    shutil.copy2(source / name, target / name)
shutil.copytree(source / 'real-world-cases', target / 'real-world-cases')
(target / 'Snapshots').mkdir()
for file in (source / 'Snapshots').glob('*.verified.txt'):
    shutil.copy2(file, target / 'Snapshots' / file.name)
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(root / 'artifacts/dispatch-cycle-corpus-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared independent 89-view corpus with the accepted expectations.')
