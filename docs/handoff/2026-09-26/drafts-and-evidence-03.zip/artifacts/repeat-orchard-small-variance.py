import json,subprocess,time
from pathlib import Path
root=Path('artifacts').resolve()
entries=json.loads((root/'orchard-manifest-draft.json').read_text(encoding='utf-8'))
cli=Path('artifacts/variance-ocelot-cli/callrift.dll').resolve()
for e in entries:
 if e['after'][:7] not in ['ee892e7','0e50949']:continue
 for view in e['views']:
  key=e['after'][:7]
  stem=root/f"orchard-{key}-{view['id']}-variance-repeat"
  command=['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe',str(cli),'diff',e['before'],e['after'],*view['options'],'--format','json','--color','never']
  started=time.monotonic()
  with stem.with_suffix('.json').open('wb') as stdout,stem.with_suffix('.err').open('wb') as stderr:
   process=subprocess.Popen(command,cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore',stdout=stdout,stderr=stderr)
   try:code=process.wait(timeout=600)
   except subprocess.TimeoutExpired:
    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
    process.wait()
    raise
  assert code==0,stem
  old=json.loads((root/f"orchard-{key}-{view['id']}-final.json").read_text(encoding='utf-8'))
  new=json.loads(stem.with_suffix('.json').read_text(encoding='utf-8'))
  if 'virtual-nonabstract-dispatch' in old['analysis']['limitations']:old['analysis']['limitations'].remove('virtual-nonabstract-dispatch')
  assert old==new,stem
  print(key,view['id'],'all fields identical except obsolete coverage entry',round(time.monotonic()-started,1),flush=True)
