from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-compatibility-scenarios'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs_path = root / 'static-initialization-compatibility-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['versions']['candidate'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
trx = next((root / (directory.name + '-results')).glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '617' and counters['failed'] == '0'
proof = {'core': inputs['versions']['candidate']['Callrift.Core.dll'], 'worker': inputs['versions']['candidate']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': [result.attrib for result in tree.findall('.//{*}UnitTestResult')]}
(root / 'static-initialization-first-scenarios-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 617 passing scenarios on unchanged frozen f581/934 inputs. This is not the latest candidate.')
