from pathlib import Path
import json

root = Path.cwd()
artifacts = root / 'artifacts'
target = artifacts / 'constructor-depth-leaf-source-review'
target.mkdir(exist_ok=True)
configurations = target / 'configs'
assert not configurations.exists()
configurations.mkdir()
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
catalog = json.loads((artifacts / 'constructor-depth-delta-catalog.json').read_text(encoding='utf-8'))
jobs = {}
for entry in catalog:
    case = next(case for case in sorted(manifest, key=lambda item: -len(item['id'])) if entry['view'].startswith(case['id']))
    path = artifacts / 'constructor-depth-corpus/Snapshots' / (entry['view'] + '-json.received.txt')
    text = path.read_text(encoding='utf-8-sig')
    document = json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
    for delta in entry['deltas']:
        if not delta['path'].endswith('/omission') or delta['after'] is not None or delta['before'].get('reason') != 'depth-limit':
            continue
        node = document
        for part in delta['path'].split('/')[1:-1]:
            node = node[int(part)] if isinstance(node, list) else node[part]
        for side in ['before', 'after']:
            value = node.get(side)
            if not value:
                continue
            assert value['definition'] is not None
            jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'leaves': []})['leaves'].append({
                'view': entry['view'], 'revision': case[side], 'side': side, 'nodeId': node['id'], 'label': node['label'], 'symbolId': value['symbolId'], 'definition': value['definition']})
for name, configuration in jobs.items():
    (configurations / (name + '.json')).write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
(target / 'jobs.json').write_text(json.dumps(list(jobs), indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'cases': len(jobs), 'leafSideOccurrences': sum(len(configuration['leaves']) for configuration in jobs.values())}))
