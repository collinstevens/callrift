from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import document, flatten, rendered, manifest, schema, jsonschema

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus/Snapshots'
name = 'ocelot-custom-json-merge-source-focused'
case = manifest['ocelot-custom-json-merge']
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/ocelot'
source_path = 'src/DependencyInjection/ConfigurationBuilderExtensions.cs'
sources = {}
blobs = {}
for side in ['before', 'after']:
    spec = case[side] + ':' + source_path
    sources[side] = subprocess.check_output(['git', '-C', repository, 'show', spec]).decode('utf-8-sig').splitlines()
    blobs[side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', spec], text=True).strip()

expected = {
    'if (environmentFile is null)': (111, 131, 'environmentFile ??= Path.Join(folder, string.Format(EnvironmentConfigFile, envName))', ['? string.Format', 'Path.Join']),
    'if (fileConfiguration is null)': (121, 141, 'fileConfiguration ??= new FileConfiguration()', ['new FileConfiguration']),
    'if (configuration.GlobalConfiguration is null)': (None, 176, 'configuration.GlobalConfiguration ??= new()', ['new FileGlobalConfiguration']),
    'if (primaryFile is null)': (122, 145, 'primaryFile ??= Path.Join(folder, PrimaryConfigFile)', ['Path.Join']),
    'if (globalFile is null)': (123, 146, 'globalFile ??= Path.Join(folder, GlobalConfigFile)', ['Path.Join'])
}
before_path = directory / (name + '-json.verified.txt')
after_path = directory / (name + '-json.received.txt')
before, after = document(before_path), document(after_path)
jsonschema.validate(after, schema)
branches = [node for node in flatten(after['trees']) if node['label'] in expected]
assert len(branches) == len(expected)
for node in branches:
    before_line, after_line, expression, children = expected[node['label']]
    assert node['kind'] == 'branch' and node['detail'] is None and node['omission'] is None
    assert node['change'] == ('added' if before_line is None else 'unchanged')
    assert [child['label'] for child in node['children']] == children
    for side, line in [('before', before_line), ('after', after_line)]:
        value = node[side]
        if line is None:
            assert value is None
            continue
        assert sources[side][line - 1].strip() == expression + ';'
        location = {'path': source_path, 'startLine': line, 'startColumn': 9, 'endLine': line, 'endColumn': 9 + len(expression)}
        assert value == {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}

def normalized(value, unwrap=False):
    if isinstance(value, list):
        return [item for node in value for item in (normalized(node['children'], True) if unwrap and isinstance(node, dict) and node.get('label') in expected else [normalized(node, unwrap)])]
    if isinstance(value, dict):
        return {key: normalized(item, unwrap) for key, item in value.items() if key != 'id'}
    return value

expected_before = copy.deepcopy(before)
depth_nodes = [node for node in flatten(expected_before['trees'][1]['children']) if node['label'] == 'new FileGlobalConfiguration']
assert len(depth_nodes) == 2
for node in depth_nodes:
    assert node['detail'] is None and node['omission'] is None
    assert [child['label'] for child in node['children']] == ['new Object', 'new FileGlobalAuthenticationOptions', 'new Dictionary<string, string>', 'new FileGlobalHttpHandlerOptions', 'new FileMetadataOptions', 'new FileSecurityOptions', 'new FileServiceDiscoveryProvider', 'new Dictionary<string, string>']
    node.update(detail='depth limit', omission={'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}, children=[])
assert normalized(expected_before) == normalized(after, True)

before_text_path = directory / (name + '.verified.txt')
after_text_path = directory / (name + '.received.txt')
old_text, old_error = rendered(before_text_path)
new_text, new_error = rendered(after_text_path)
assert old_error == new_error
old_guard = '+ │  └─ new FileGlobalConfiguration\n+ │     ├─ new Object\n+ │     ├─ new FileGlobalAuthenticationOptions (depth limit)\n+ │     ├─ new Dictionary<string, string>\n+ │     ├─ new FileGlobalHttpHandlerOptions (depth limit)\n+ │     ├─ new FileMetadataOptions (depth limit)\n+ │     ├─ new FileSecurityOptions (depth limit)\n+ │     ├─ new FileServiceDiscoveryProvider (depth limit)\n+ │     └─ new Dictionary<string, string>\n'
new_guard = '+ │  └─ if (configuration.GlobalConfiguration is null)\n+ │     └─ new FileGlobalConfiguration (depth limit)\n'
expected_text = old_text
for old, new in [('  ├─ new FileConfiguration\n', '  ├─ if (fileConfiguration is null)\n'), (old_guard, new_guard), ('  ├─ Path.Join ×2\n', '  ├─ if (primaryFile is null)\n  ├─ if (globalFile is null)\n')]:
    assert expected_text.count(old) == 1
    expected_text = expected_text.replace(old, new)
assert expected_text == new_text

digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
proof = {
    'view': name,
    'snapshotDirectory': directory.as_posix(),
    'sourceRevisions': {side: case[side] for side in sources},
    'sourcePath': source_path,
    'sourceBlobs': blobs,
    'conditionalBranches': list(expected),
    'depthChanges': 2,
    'schemaV1': True,
    'allOtherPriorJsonPreservedExceptTraversalIds': True,
    'textAndMarkdownExactExpectedEdits': True,
    'review': 'Each null-coalescing assignment runs its RHS only if the existing value is null. Five new branches match the exact immutable source expressions and spans. Existing constructor and metadata calls retain their order and evidence. The added structural level places two FileGlobalConfiguration calls at the existing depth bound. Both now expose explicit depth omissions instead of their constructor children. Root selection, changes, diagnostics, target identities, existing locations and all other JSON fields remain identical. Text context now shows null guards in place of unconditional calls; hidden descendants remain in JSON except for the two declared depth omissions.',
    'files': {path.name: digest(path) for path in [after_path, after_text_path]},
    'baselineFiles': {path.name: digest(path) for path in [before_path, before_text_path]},
    'repeatStatus': 'pending'
}
(root / 'static-coalesce-ocelot-source-focused-review.json').write_text(json.dumps({'views': [proof]}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed five conditional branches and two depth omissions; all other prior JSON and exact rendered edits verified.')
