from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
for name in ['scenarios', 'workspaces']:
    source = artifacts / ('dispatch-cardinality-final-' + name)
    target = artifacts / ('dispatch-cycle-' + name)
    assert not target.exists()
    target.mkdir()
    for file in source.glob('*.cs'):
        shutil.copy2(file, target / file.name)
    shutil.copy2(source / 'Check.csproj', target / 'Check.csproj')
    (target / 'Snapshots').mkdir()
    for file in (source / 'Snapshots').glob('*.verified.txt'):
        shutil.copy2(file, target / 'Snapshots' / file.name)
    if name == 'scenarios':
        shutil.copy2(artifacts / 'DispatchCycleIdentityTests.cs', target / 'DispatchCycleIdentityTests.cs')
    inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    (artifacts / f'dispatch-cycle-{name}-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared 403 scenarios and 22 workspace checks with reviewed expectations.')
