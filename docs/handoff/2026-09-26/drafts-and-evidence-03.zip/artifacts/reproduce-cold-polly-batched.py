import json
import os
from pathlib import Path
import subprocess
import time

out = Path('artifacts').resolve()
baseline = json.loads((out / 'cold-polly-baseline.json').read_text(encoding='utf-8'))
repo = Path(baseline['cache']).parent / 'polly-batched'

def run(args, **kwargs):
    result = subprocess.run(args, capture_output=True, timeout=120, **kwargs)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace'))
    return result.stdout

run(['git', 'clone', '--filter=blob:none', '--no-checkout', '--single-branch', baseline['repository'], str(repo)])
ids = ('\n'.join(oid for oid, path in baseline['selected']) + '\n').encode('ascii')
missing = run(['git', '--no-lazy-fetch', '-C', str(repo), 'cat-file', '--batch-check'], input=ids).decode('utf-8').splitlines()
assert len(missing) == 20 and all(line.endswith(' missing') for line in missing)
trace = out / 'cold-polly-batched-trace.jsonl'
env = dict(os.environ, GIT_TRACE2_EVENT=str(trace))
started = time.monotonic()
run(['git', '-C', str(repo), '-c', 'fetch.negotiationAlgorithm=noop', 'fetch', 'origin', '--no-tags', '--no-write-fetch-head', '--recurse-submodules=no', '--filter=blob:none', '--stdin'], input=ids, env=env)
content = run(['git', '-C', str(repo), 'cat-file', '--batch'], input=ids, env=env)
elapsed = time.monotonic() - started
assert content == (out / 'cold-polly-baseline-bytes.bin').read_bytes()
events = [json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines()]
lazy_fetches = [event['argv'] for event in events if event.get('event') == 'child_start' and 'fetch' in event.get('argv', [])]
report = {'repository': baseline['repository'], 'revision': baseline['revision'], 'cache': str(repo), 'initiallyMissing': len(missing), 'explicitFetches': 1, 'lazyFetches': len(lazy_fetches), 'combinedFetchReadSeconds': elapsed, 'bytes': len(content), 'bytesEqualToBaseline': True, 'conditions': 'separate fresh blob-filtered clone; same 20 source blobs; concurrent validation; operational reproduction only, not a benchmark'}
(out / 'cold-polly-batched.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report), flush=True)
