from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/declaration-signatures-cli-v2-ready/callrift.dll'
name = 'orchardcore-esmodule-signature-restored-roots-trial'
output = root / 'artifacts' / (name + '.json')
error = root / 'artifacts' / (name + '.stderr')
assert not output.exists()
command = ['dotnet', str(cli), 'diff', 'b304fcd78a70b792c6f63916c0ce6e6957bb1aa0', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', '--project', 'src/OrchardCore.Cms.Web/OrchardCore.Cms.Web.csproj', '--framework', 'net10.0', '--depth', '1', '--format', 'json']
started = time.monotonic()
with output.open('wb') as stdout, error.open('wb') as stderr:
    process = subprocess.Popen(['mise', 'exec', '-c', subprocess.list2cmdline(command)], cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', stdout=stdout, stderr=stderr)
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
        process.wait()
        raise
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record = {'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'stderr': error.read_text(encoding='utf-8'), 'accepted': False}
(root / 'artifacts' / (name + '-record.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record), flush=True)
