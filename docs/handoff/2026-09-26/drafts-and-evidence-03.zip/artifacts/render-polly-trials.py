import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/polly')
dotnet = 'C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe'
cli = root.parent / 'src/Callrift.Cli/bin/Debug/net11.0/callrift.dll'
output = root / 'polly-rendered-trials'
output.mkdir(exist_ok=True)
for entry in json.loads((root / 'polly-manifest-draft.json').read_text()):
    for view in entry['views']:
        name = entry['id'] + '-' + view['id']
        chunks = []
        trees = []
        for format in ['text', 'md']:
            result = subprocess.run([dotnet, str(cli), 'diff', entry['before'], entry['after'], *view['options'], '--format', format, '--color', 'never'], cwd=repo, capture_output=True, encoding='utf-8')
            if result.returncode:
                raise RuntimeError(name + ': ' + result.stderr)
            chunks.append(f'format: {format}\nexit: 0\nstdout:\n{result.stdout}stderr:\n{result.stderr}')
            tree = result.stdout.strip()
            if format == 'md' and tree.startswith('```diff\n') and tree.endswith('\n```'):
                tree = tree[len('```diff\n'):-len('\n```')].strip()
            trees.append(tree)
        assert trees[0] == trees[1], name
        (output / (name + '.txt')).write_text('\n'.join(chunks), encoding='utf-8', newline='\n')
        print(name, 'text/Markdown agree', flush=True)
