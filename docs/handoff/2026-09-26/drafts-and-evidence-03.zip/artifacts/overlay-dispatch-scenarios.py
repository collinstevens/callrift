from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/dispatch-cardinality-cli/candidate'
target = root / 'artifacts/dispatch-cardinality-scenarios/build/bin/Check/debug'
shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(source / name, target / name)
report = {}
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']:
    report[name] = hashlib.sha256((target / name).read_bytes()).hexdigest()
assert report['Callrift.Core.dll'] == report['msbuild/Callrift.Core.dll']
assert report['Callrift.MSBuild.dll'] == report['msbuild/Callrift.MSBuild.dll']
(root / 'artifacts/dispatch-cardinality-scenarios-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report))
