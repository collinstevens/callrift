from pathlib import Path

r = Path('artifacts')
directory = r / 'static-initialization-cli'
assert not directory.exists()
directory.mkdir()
matrix = (r / 'static-trigger-matrix/Program.cs').read_text(encoding='utf-8')
fixtures = matrix.split('[]\n{', 1)[1].split('\n};', 1)[0]
source = '''using System.Text.Json;
using Xunit;

namespace Callrift.Scenarios;

public sealed class StaticInitializationTests
{
    private static readonly (string Name, string Source, string Invoke, string Runtime, bool ReachesInitializer)[] Fixtures =
    {
FIXTURES
    };
    private const string Sink = " public static class Sink { public static readonly System.Collections.Generic.List<string> Events = new(); public static int Before() { Events.Add(\\"before\\"); return 1; } public static int After() { Events.Add(\\"after\\"); return 2; } public static int Argument() { Events.Add(\\"argument\\"); return 3; } public static void Add(string value) { Events.Add(value); } }";
    public static IEnumerable<object[]> Cases => Fixtures.SelectMany(fixture => new[] { new object[] { fixture.Name, false }, new object[] { fixture.Name, true } });

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task FollowsConditionalInitialization(string name, bool workspace)
    {
        var example = Fixtures.Single(fixture => fixture.Name == name);
        var source = example.Source + " public static class Entry { public static void Run() { " + example.Invoke + " } }" + Sink;
        var before = new Dictionary<string, string>
        {
            ["Flow.cs"] = source,
            ["App.csproj"] = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>"
        };
        var after = new Dictionary<string, string>(before) { ["Flow.cs"] = source.Replace("Sink.Before()", "Sink.After()", StringComparison.Ordinal) };
        await using var fixture = await GitFixture.CreateAsync(new Scenario("static-" + name, "Conditional type initialization follows original declarations and closed generic contexts.", before, after, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        using var tree = Parse(await fixture.RunAsync(["tree", fixture.Before, "--entry", "Entry.Run", "--format", "json", "--depth", "30", "--externals", .. mode]));
        var calls = Flatten(tree.RootElement.GetProperty("trees")).ToArray();
        var labels = calls.Select(node => node.GetProperty("label").GetString()).ToArray();
        Assert.Equal(example.ReachesInitializer, labels.Contains("Sink.Before"));
        Assert.DoesNotContain(calls, node => node.TryGetProperty("omission", out var omission) && omission.ValueKind == JsonValueKind.Object && omission.GetProperty("reason").GetString() == "cycle");
        if (name is "explicit-method-repeated" or "explicit-instance" or "self-reference" or "mutual-reference") Assert.Single(labels.Where(label => label == "Sink.Before"));
        if (name == "closed-generic-types") Assert.Equal(2, labels.Count(label => label == "Sink.Before"));
        if (name is "explicit-method-repeated" or "self-reference") Assert.Equal(2, labels.Count(label => label == "State.Touch"));
        if (name is "explicit-field-write-order" or "explicit-method-argument-order") Assert.True(Array.IndexOf(labels, "Sink.Argument") < Array.IndexOf(labels, "Sink.Before"));
        if (name == "fields-before-constructor") Assert.True(Array.IndexOf(labels, "Sink.Before") < Array.IndexOf(labels, "Sink.Argument"));
        foreach (var initializer in calls.Where(node => node.GetProperty("label").GetString()!.StartsWith("initialization of ", StringComparison.Ordinal)))
        {
            var side = initializer.GetProperty("after");
            Assert.Contains("..cctor()", side.GetProperty("symbolId").GetString());
            Assert.NotEqual(JsonValueKind.Null, side.GetProperty("definition").ValueKind);
        }
        using var diff = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", "Entry.Run", "--format", "json", "--depth", "30", "--externals", .. mode]));
        Assert.Equal(example.ReachesInitializer, diff.RootElement.GetProperty("hasChanges").GetBoolean());
        using var reach = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", "Entry.Run", "--to", "Sink.Before", "--format", "json", "--depth", "30", "--externals", .. mode]));
        Assert.Equal(example.ReachesInitializer, reach.RootElement.GetProperty("paths").GetArrayLength() != 0);
        foreach (var format in new[] { "text", "md" })
        {
            var output = await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", "Entry.Run", "--format", format, "--depth", "30", "--externals", .. mode]);
            Assert.StartsWith("exit: 0\\n", output);
            Assert.Equal(example.ReachesInitializer, output.Contains("Sink.Before", StringComparison.Ordinal));
            Assert.Equal(example.ReachesInitializer, output.Contains("Sink.After", StringComparison.Ordinal));
        }
    }

    [Theory]
    [InlineData("method", false)]
    [InlineData("method", true)]
    [InlineData("field", false)]
    [InlineData("field", true)]
    [InlineData("generic-field", false)]
    [InlineData("generic-field", true)]
    [InlineData("inherited-method", false)]
    [InlineData("inherited-method", true)]
    public async Task LinksInitializersAcrossProjects(string kind, bool workspace)
    {
        var library = kind switch
        {
            "method" => "public static class State { static State() { Sink.Before(); } public static void Touch() {} }",
            "field" => "public static class State { public static int Value = Sink.Before(); }",
            "generic-field" => "public static class State<T> { public static int Value = Sink.Before(); }",
            _ => "public class Base { static Base() { Sink.Before(); } public static void Touch() {} }"
        };
        var invoke = kind switch
        {
            "field" => "_ = State.Value;",
            "generic-field" => "_ = State<int>.Value; _ = State<string>.Value; _ = State<int>.Value;",
            _ => "State.Touch();"
        };
        var source = (kind == "inherited-method" ? "public class State : Base {} " : "") + "public static class Entry { public static void Run() { " + invoke + " } }";
        var before = new Dictionary<string, string>
        {
            ["Lib/Flow.cs"] = library + Sink,
            ["Flow.cs"] = source,
            ["App.csproj"] = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup><ItemGroup><Compile Remove=\\"Lib/**/*.cs\\"/><ProjectReference Include=\\"Lib/Lib.csproj\\"/></ItemGroup></Project>",
            ["Lib/Lib.csproj"] = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>"
        };
        var after = new Dictionary<string, string>(before) { ["Lib/Flow.cs"] = before["Lib/Flow.cs"].Replace("Sink.Before()", "Sink.After()", StringComparison.Ordinal) };
        await using var fixture = await GitFixture.CreateAsync(new Scenario("static-project-" + kind, "Initialization uses the declaring project even when metadata imports hide its private constructor.", before, after, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        using var tree = Parse(await fixture.RunAsync(["tree", fixture.Before, "--entry", "Entry.Run", "--format", "json", "--depth", "30", .. mode]));
        var nodes = Flatten(tree.RootElement.GetProperty("trees")).ToArray();
        Assert.Equal(kind == "generic-field" ? 2 : 1, nodes.Count(node => node.GetProperty("label").GetString() == "Sink.Before"));
        foreach (var initializer in nodes.Where(node => node.GetProperty("label").GetString()!.StartsWith("initialization of ", StringComparison.Ordinal)))
        {
            var side = initializer.GetProperty("after");
            Assert.Equal("Lib/Flow.cs", side.GetProperty("definition").GetProperty("path").GetString());
            if (workspace) Assert.StartsWith("project:Lib/Lib.csproj@net11.0::", side.GetProperty("symbolId").GetString());
        }
        using var diff = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", "Entry.Run", "--format", "json", "--depth", "30", .. mode]));
        Assert.True(diff.RootElement.GetProperty("hasChanges").GetBoolean());
        using var reach = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", "Entry.Run", "--to", "Sink.Before", "--format", "json", "--depth", "30", .. mode]));
        Assert.NotEmpty(reach.RootElement.GetProperty("paths").EnumerateArray());
    }

    private static JsonDocument Parse(string output)
    {
        Assert.StartsWith("exit: 0\\n", output);
        var result = JsonDocument.Parse(output.Split("stdout:\\n", StringSplitOptions.None)[1].Split("stderr:\\n", StringSplitOptions.None)[0]);
        Assert.Empty(result.RootElement.GetProperty("diagnostics").EnumerateArray());
        return result;
    }

    private static IEnumerable<JsonElement> Flatten(JsonElement nodes) => nodes.EnumerateArray().SelectMany(node => new[] { node }.Concat(Flatten(node.GetProperty("children"))));
}
'''.replace('FIXTURES', fixtures)
(directory / 'StaticInitializationTests.cs').write_text(source, encoding='utf-8', newline='\n')
(directory / 'Check.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><IsTestProject>true</IsTestProject><IsPackable>false</IsPackable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup>
  <ItemGroup>
    <Compile Include="../top-level-constructor-cli-tests/AssemblySettings.cs" />
    <Compile Include="StaticInitializationTests.cs" />
    <Compile Include="../../tests/Callrift.Scenarios/GitFixture.cs" />
    <Compile Include="../../tests/Callrift.Scenarios/ScenarioCatalog.cs" />
    <ProjectReference Include="../../src/Callrift.Cli/Callrift.Cli.csproj" />
    <PackageReference Include="Microsoft.NET.Test.Sdk" /><PackageReference Include="xunit" /><PackageReference Include="xunit.runner.visualstudio" PrivateAssets="all" />
  </ItemGroup>
</Project>
''', encoding='utf-8', newline='\n')
print('Prepared 54 real CLI static-initialization checks across source and restored modes.')
