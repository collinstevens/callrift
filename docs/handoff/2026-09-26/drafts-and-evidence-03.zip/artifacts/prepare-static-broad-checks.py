from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['workspaces', 'corpus']:
    source = root / ('record-copy-compatibility-' + ('corpus-repeat' if suffix == 'corpus' else suffix))
    target = root / ('static-initialization-compatibility-' + suffix)
    assert not target.exists()
    target.mkdir()
    for path in source.iterdir():
        if path.suffix in ['.cs', '.csproj']:
            text = path.read_text(encoding='utf-8-sig').replace('record-copy-compatibility-corpus-repeat', 'static-initialization-compatibility-corpus')
            (target / path.name).write_text(text, encoding='utf-8', newline='\n')
    shutil.copytree(source / 'Snapshots', target / 'Snapshots')
    if suffix == 'corpus':
        shutil.copytree('real-world-cases', target / 'real-world-cases')
    print(target)
