from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

artifacts = Path.cwd() / 'artifacts'
files = list((artifacts / 'constructor-reviewed-scenario-results').glob('*.trx'))
assert len(files) == 1
counters = ET.parse(files[0]).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
assert counters['total'] == '41' and counters['passed'] == '40' and counters['failed'] == '1'
directory = artifacts / 'constructor-reviewed-scenarios'
snapshot = directory / 'Snapshots/dispatch-added-json.received.txt'
verified = snapshot.with_name('dispatch-added-json.verified.txt')

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    index = content.index('{')
    value, length = json.JSONDecoder().raw_decode(content[index:])
    return value, content[:index], content[index + length:]

before, prefix, suffix = read(verified)
after, new_prefix, new_suffix = read(snapshot)
assert prefix == new_prefix and suffix == new_suffix
source = 'interface IWorker { void Save(); } class First : IWorker { public void Save() {} } class Second : IWorker { public void Save() {} } class Flow(IWorker worker) { public void Run() => worker.Save(); }'
declaration = 'class Second : IWorker { public void Save() {} }'
start = source.index(declaration) + 1
assert start == 84 and start + len(declaration) == 132
expected_root = {'id': 'n4', 'kind': 'member', 'change': 'added', 'label': 'new Second', 'detail': None, 'before': None,
    'after': {'symbolId': 'source::Second..ctor()', 'signature': 'Second.Second() -> void', 'binding': 'resolved', 'dispatch': 'direct',
              'targetIds': ['source::Second..ctor()'], 'definition': {'path': 'Program.cs', 'startLine': 1, 'startColumn': 84, 'endLine': 1, 'endColumn': 132},
              'callSites': [], 'relation': 'definition', 'candidates': None, 'origin': 'source'}, 'children': [], 'omission': None}
before['trees'].append(expected_root)
assert before == after
shutil.copy2(snapshot, verified)
review = json.loads((artifacts / 'constructor-scenario-delta-review.json').read_text(encoding='utf-8'))
review['dispatchJsonStillNeedsReview'] = False
review['dispatchAddedJson'] = {'addedRoot': expected_root, 'allOtherFieldsExact': True, 'sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest()}
(artifacts / 'constructor-scenario-delta-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
inputs_path = artifacts / 'constructor-reviewed-scenario-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
inputs['sourcesAndSnapshots']['Snapshots/dispatch-added-json.verified.txt'] = hashlib.sha256(verified.read_bytes()).hexdigest()
inputs_path.write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed the added default-constructor JSON root against source and updated only the private expectation after the 41-case replay ended.')
