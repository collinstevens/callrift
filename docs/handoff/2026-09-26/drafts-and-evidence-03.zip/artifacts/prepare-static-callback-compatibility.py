from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['scenarios', 'corpus']:
    source = root / ('static-initialization-compatibility-' + suffix)
    target = root / ('static-initialization-callback-' + suffix)
    assert not target.exists()
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
    if suffix == 'scenarios':
        for path in (root / 'static-initialization-callback-complete-cli').glob('*.cs'):
            shutil.copy2(path, target / path.name)
    else:
        import json
        review = json.loads((root / 'static-six-view-review.json').read_text(encoding='utf-8'))
        for record in review['views']:
            for name in record['files']:
                verified = name.replace('.received.', '.verified.')
                shutil.copy2(root / 'static-initialization-six-view-repeat/Snapshots' / verified, target / 'Snapshots' / verified)
    print(target.as_posix())
