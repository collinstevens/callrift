from pathlib import Path
import json
import subprocess

root = Path('artifacts/static-diagnostic-source-batch-review')
for name in json.loads((root / 'jobs.json').read_text(encoding='utf-8')):
    with (root / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        run = subprocess.run(['dotnet', str(root / 'build/bin/Check/debug/Check.dll'), str(root / (name + '.json')), str(root / (name + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=660)
    report_path = root / (name + '-report.json')
    if report_path.exists():
        report = json.loads(report_path.read_text(encoding='utf-8'))
        print(json.dumps({'case': name, 'exitCode': run.returncode, 'count': report['count'], 'proven': report['proven'], 'unmatched': report['unmatched']}), flush=True)
    else:
        print(json.dumps({'case': name, 'exitCode': run.returncode, 'reportMissing': True}), flush=True)
