from pathlib import Path
import copy
import hashlib
import json
import shutil

root = Path.cwd()
snapshots = root / 'artifacts/dispatch-cardinality-final-scenarios/Snapshots'
baseline = root / 'tests/Callrift.Scenarios/Snapshots/dispatch-added-json.verified.txt'
received = snapshots / 'dispatch-added-json.received.txt'
def parse(file):
    text = file.read_text(encoding='utf-8-sig')
    assert text.startswith('exit: 0\nstdout:\n') and text.endswith('\nstderr:\n')
    return json.loads(text.split('stdout:\n', 1)[1].rsplit('\nstderr:', 1)[0])
before = parse(baseline)
actual = parse(received)
expected = copy.deepcopy(before)
parent = expected['trees'][0]
old_call, new_call = parent['children']
new_call['id'] = 'n1'
new_call['change'] = 'unchanged'
new_call['before'] = old_call['before']
first, second = new_call['children']
first['id'] = 'n2'
first['change'] = 'unchanged'
first['before'] = copy.deepcopy(first['after'])
second['id'] = 'n3'
parent['children'] = [new_call]
assert actual == expected
source_before = 'interface IWorker { void Save(); } class First : IWorker { public void Save() {} } class Flow(IWorker worker) { public void Run() => worker.Save(); }'
source_after = source_before.replace('class Flow', 'class Second : IWorker { public void Save() {} } class Flow')
def validate_location(location, source, text):
    assert location['path'] == 'Program.cs'
    assert location['startLine'] == location['endLine'] == 1
    assert source[location['startColumn'] - 1:location['endColumn'] - 1] == text
for side, source in [('before', source_before), ('after', source_after)]:
    validate_location(parent[side]['definition'], source, 'public void Run() => worker.Save();')
    validate_location(new_call[side]['definition'], source, 'void Save();')
    validate_location(new_call[side]['callSites'][0], source, 'worker.Save()')
    validate_location(first[side]['definition'], source, 'public void Save() {}')
validate_location(second['after']['definition'], source_after, 'public void Save() {}')
assert first['before']['symbolId'] == first['after']['symbolId'] == 'source::First.Save()'
assert new_call['before']['targetIds'] == ['source::First.Save()']
assert new_call['after']['targetIds'] == ['source::First.Save()', 'source::Second.Save()']
assert not actual['diagnostics'] and not actual['truncated']
assert received.read_bytes().startswith(b'\xef\xbb\xbf') and b'\r\n' not in received.read_bytes()
shutil.copy2(received, snapshots / 'dispatch-added-json.verified.txt')
record = {'sourceBefore': source_before, 'sourceAfter': source_after, 'reviewedEffect': 'Only Second.Save is added; Flow, IWorker.Save, and First.Save are preserved.', 'unchangedOtherFields': True, 'locationsChecked': 9, 'baselineSha256': hashlib.sha256(baseline.read_bytes()).hexdigest(), 'reviewedSha256': hashlib.sha256(received.read_bytes()).hexdigest(), 'productionPromoted': False}
(root / 'artifacts/dispatch-cardinality-scenario-review.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed exact JSON delta and all nine definition/call-site locations; private expectation updated.')
