from pathlib import Path
import collections
import copy
import hashlib
import json
import subprocess

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'constructor-exact-corpus/Snapshots'
case = next(case for case in json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8')) if case['id'] == 'orchardcore-role-submission')
source_path = 'src/OrchardCore/OrchardCore.Roles.Abstractions/Role.cs'
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
blobs = {}
for side in ['before', 'after']:
    revision = case[side]
    source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + source_path]).decode('utf-8-sig')
    assert 'public class Role : IRole\n' in source
    assert 'Role(' not in source
    assert 'public List<RoleClaim> RoleClaims { get; set; } = [];' in source
    blobs[revision] = subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + source_path], text=True).strip()
assert len(set(blobs.values())) == 1
configuration = json.loads((artifacts / 'constructor-diagnostic-source-review/orchard-role.json').read_text(encoding='utf-8'))
proof = json.loads((artifacts / 'constructor-diagnostic-source-review/orchard-role-report.json').read_text(encoding='utf-8'))
assert proof['diagnosticCount'] == proof['provenMissingBaseCount'] == 404 and not proof['unmatched']

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    index = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[index:])
    return document, content[:index], content[index + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def counter(items):
    return collections.Counter(json.dumps(item, sort_keys=True) for item in items)

def stderr(diagnostics):
    lines = []
    for item in diagnostics[:8]:
        location = item.get('location')
        prefix = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(prefix + item['code'] + ': ' + item['message'])
    if len(diagnostics) > 8:
        lines.append(str(len(diagnostics) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

reviews = []
for mode in ['source', 'msbuild']:
    name = case['id'] + '-' + mode + '-roots'
    original, prefix, suffix = read(directory / (name + '-json.verified.txt'))
    actual, new_prefix, new_suffix = read(directory / (name + '-json.received.txt'))
    assert prefix == new_prefix
    expected = copy.deepcopy(original)
    count = 0
    for node in nodes(expected['trees']):
        for side in ['before', 'after']:
            value = node.get(side)
            if value and (value['symbolId'] or '').endswith('::OrchardCore.Security.Role..ctor()'):
                assert value['signature'] == 'OrchardCore.Security.Role.Role()' and value['definition']['path'] == source_path
                value['signature'] += ' -> void'
                count += 1
    assert count == 2
    if mode == 'source':
        assert counter(actual['diagnostics']) - counter(original['diagnostics']) == counter(configuration['diagnostics'])
        assert not counter(original['diagnostics']) - counter(actual['diagnostics'])
        expected['diagnostics'] = actual['diagnostics']
    assert expected == actual
    assert suffix.split('stderr:\n', 1)[1].strip() == stderr(original['diagnostics'])
    assert new_suffix.split('stderr:\n', 1)[1].strip() == stderr(actual['diagnostics'])
    old_text = (directory / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    new_path = directory / (name + '.received.txt')
    new_text = new_path.read_text(encoding='utf-8-sig') if new_path.exists() else old_text
    for format in ['text', 'md']:
        def split(content):
            section = content.split('format: ' + format + '\nexit: 0\nstdout:\n', 1)[1]
            output, errors = section.split('stderr:\n', 1)
            return output, errors.split('\nformat: ', 1)[0]
        old_output, old_errors = split(old_text)
        new_output, new_errors = split(new_text)
        assert old_output == new_output
        assert old_errors.strip() == stderr(original['diagnostics'])
        assert new_errors.strip() == stderr(actual['diagnostics'])
    reviews.append({'view': name, 'signatureChanges': count, 'addedDiagnostics': 404 if mode == 'source' else 0,
                    'allOtherJsonExact': True, 'renderedStdoutExact': True, 'stderrMatchesReviewedDiagnostics': True,
                    'sha256': hashlib.sha256((directory / (name + '-json.received.txt')).read_bytes()).hexdigest()})
(artifacts / 'constructor-role-signature-review.json').write_text(json.dumps({'productionPromoted': False, 'sourcePath': source_path, 'immutableBlobs': blobs, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed both Orchard role automatic-root views: four signature fields and 404 source-only base-binding diagnostics; all other output is exact.')
