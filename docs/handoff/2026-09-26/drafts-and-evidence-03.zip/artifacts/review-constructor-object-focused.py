from pathlib import Path
import copy
import hashlib
import json

root = Path.cwd()
artifacts = root / 'artifacts'
old_directory = artifacts / 'constructor-depth-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
jobs = {}
reports = []

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    index = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[index:])
    return document, content[:index], content[index + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

for name in ['ocelot-custom-json-merge', 'ocelot-timeout-status', 'polly-executor-continuations']:
    case = next(case for case in manifest if case['id'] == name)
    view = name + '-msbuild-focused'
    settings = next(view for view in case['views'] if view['id'] == 'msbuild-focused')['options']
    assert '--externals' in settings and settings[settings.index('--depth') + 1] == '3'
    original, prefix, suffix = read(old_directory / (view + '-json.verified.txt'))
    actual, new_prefix, new_suffix = read(old_directory / (view + '-json.received.txt'))
    assert prefix == new_prefix and suffix == new_suffix
    expected = copy.deepcopy(actual)
    checks = []
    removed = []
    def strip(items, parent=None, depth=0):
        result = []
        for index, node in enumerate(items):
            if node['label'] == 'new Object' and parent and parent['label'] in ['new FileConfiguration', 'new FileGlobalConfiguration', 'new Error', 'new ScheduledTaskExecutor.Entry']:
                assert index == 0 and node['change'] == parent['change']
                assert node['kind'] == 'call' and not node['children'] and node['detail'] is None and node['omission'] is None
                for side in ['before', 'after']:
                    value = node.get(side)
                    assert (value is None) == (parent.get(side) is None)
                    if not value:
                        continue
                    location = parent[side]['definition']
                    assert value == {'symbolId': 'metadata:System.Runtime::object..ctor()', 'signature': None, 'binding': 'resolved', 'dispatch': 'direct',
                        'targetIds': ['metadata:System.Runtime::object..ctor()'], 'definition': None, 'callSites': [location], 'relation': 'call', 'candidates': [], 'origin': 'metadata'}
                    checks.append({'kind': 'object-base', 'revision': case[side], 'view': view, 'location': location})
                removed.append(node)
                continue
            node['children'] = strip(node['children'], node, depth + 1)
            if node['label'] == 'new FileServiceDiscoveryProvider':
                assert depth == 3 and node['detail'] == 'depth limit' and node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
                assert not node['children']
                node['detail'] = None
                node['omission'] = None
                for side in ['before', 'after']:
                    value = node.get(side)
                    if value:
                        assert value['signature'] == 'Ocelot.Configuration.File.FileServiceDiscoveryProvider.FileServiceDiscoveryProvider() -> void'
                        assert value['definition'] == {'path': 'src/Configuration/File/FileServiceDiscoveryProvider.cs', 'startLine': 3, 'startColumn': 1, 'endLine': 13, 'endColumn': 2}
                        checks.append({'kind': 'implicit-definition', 'revision': case[side], 'view': view, 'location': value['definition'], 'type': 'Ocelot.Configuration.File.FileServiceDiscoveryProvider', 'parameterTypes': []})
                        value['signature'] = None
                        value['definition'] = None
            if node['label'] in ['new RequestTimedOutError', 'new ScheduledTaskExecutor.Entry']:
                for side in ['before', 'after']:
                    value = node.get(side)
                    if value and value['signature'].endswith(' -> void') and (node['label'] == 'new ScheduledTaskExecutor.Entry' or side == 'after'):
                        type_name = 'Ocelot.Errors.RequestTimedOutError' if node['label'] == 'new RequestTimedOutError' else 'Polly.CircuitBreaker.ScheduledTaskExecutor.Entry'
                        parameter_types = ['System.Exception'] if node['label'] == 'new RequestTimedOutError' else ['System.Func<System.Threading.Tasks.Task>', 'System.Threading.Tasks.TaskCompletionSource<object>']
                        checks.append({'kind': 'primary-definition', 'revision': case[side], 'view': view, 'location': value['definition'], 'type': type_name, 'parameterTypes': parameter_types})
                        value['signature'] = value['signature'].removesuffix(' -> void')
            result.append(node)
        return result
    expected['trees'] = strip(expected['trees'])
    old_nodes = list(nodes(original['trees']))
    new_nodes = list(nodes(expected['trees']))
    assert len(old_nodes) == len(new_nodes)
    mapping = {new['id']: old['id'] for old, new in zip(old_nodes, new_nodes)}
    for node in new_nodes:
        node['id'] = mapping[node['id']]
        if node['omission'] and node['omission']['referenceId']:
            node['omission']['referenceId'] = mapping[node['omission']['referenceId']]
    assert expected == original, view
    assert len(removed) == {'ocelot-custom-json-merge': 3, 'ocelot-timeout-status': 1, 'polly-executor-continuations': 1}[name]
    old_text = (old_directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = old_directory / (view + '.received.txt')
    if name == 'ocelot-custom-json-merge':
        new_text = text_path.read_text(encoding='utf-8-sig')
        added_line = '+ │     ├─ new Object\n'
        assert new_text.count(added_line) == 2
        expected_text = new_text.replace(added_line, '').replace('new FileServiceDiscoveryProvider (depth limit)', 'new FileServiceDiscoveryProvider')
        assert expected_text == old_text
    else:
        assert not text_path.exists()
    jobs[name] = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': checks}
    reports.append({'view': view, 'objectBaseCalls': len(removed), 'sourceChecks': len(checks), 'jsonAndTextDifferencesBounded': True, 'sourceProofPending': True,
                    'sha256': hashlib.sha256((old_directory / (view + '-json.received.txt')).read_bytes()).hexdigest()})
for name, config in jobs.items():
    (artifacts / 'constructor-object-source-review' / (name + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
(artifacts / 'constructor-object-focused-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reports}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reports))
