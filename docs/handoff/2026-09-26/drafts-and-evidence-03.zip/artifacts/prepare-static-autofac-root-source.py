import json
import sys
from static_review_support import root, snapshots, document, manifest, flatten

case_id = sys.argv[1] if len(sys.argv) > 1 else 'autofac-pipeline-callbacks'
config_name = sys.argv[2] if len(sys.argv) > 2 else 'autofac'
case = manifest[case_id]
checks = {}
for mode in ['source', 'msbuild']:
    name = case['id'] + '-' + mode + '-roots'
    before = document(snapshots / (name + '-json.verified.txt'))
    after = document(snapshots / (name + '-json.received.txt'))
    old_keys = {(node['after'] or node['before'])['symbolId'] for node in before['trees']}
    nodes = [node for node in after['trees'] if (node['after'] or node['before'])['symbolId'] not in old_keys]
    for node in flatten(nodes):
        for side in ['before', 'after']:
            value = node[side]
            if value is None or value['origin'] != 'source' or value['definition'] is None or value['symbolId'].endswith('..cctor()'):
                continue
            check = {'revision': case[side], 'definition': value['definition'], 'signature': value['signature'], 'callSites': value['callSites']}
            checks[json.dumps(check, sort_keys=True)] = check
directory = root / 'static-root-source-review'
(directory / (config_name + '.json')).write_text(json.dumps({'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac', 'checks': list(checks.values())}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared ' + str(len(checks)) + ' unique new-root declaration/callsite checks.')
