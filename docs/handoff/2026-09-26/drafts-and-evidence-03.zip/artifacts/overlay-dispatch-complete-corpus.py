from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
target = root / 'artifacts/dispatch-cardinality-complete-corpus/build/bin/Check/debug'
assert (target / 'Callrift.RealWorldCases.Tests.dll').exists()
source = root / 'artifacts/dispatch-cardinality-cli-tests/complete-ready'
shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(source / name, target / name)
record = {name: hashlib.sha256((target / name).read_bytes()).hexdigest() for name in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.MSBuild.dll']}
record['sources'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in (root / 'artifacts/dispatch-cardinality-complete-core').rglob('*.cs') if not any(part in ['bin', 'obj'] for part in file.parts)}
(root / 'artifacts/dispatch-cardinality-complete-corpus-inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen complete Core and matching worker; recorded source and binary hashes.')
