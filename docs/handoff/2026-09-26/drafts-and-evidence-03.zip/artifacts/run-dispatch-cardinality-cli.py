from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path.cwd()
base = root / 'artifacts/dispatch-cardinality-cli'
assert not base.exists()
base.mkdir()
fixture = base / 'fixture'
fixture.mkdir()
original_cli = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug'
candidate_cli = base / 'candidate'
shutil.copytree(original_cli, candidate_cli)
candidate_core = root / 'artifacts/dispatch-cardinality-check/candidate-build/bin/Callrift.Core/debug/Callrift.Core.dll'
for destination in [candidate_cli / 'Callrift.Core.dll', candidate_cli / 'msbuild/Callrift.Core.dll']:
    shutil.copy2(candidate_core, destination)
def git(*arguments):
    return subprocess.run(['git', *arguments], cwd=fixture, check=True, capture_output=True, text=True, encoding='utf-8').stdout.strip()
git('init', '--initial-branch=main')
(fixture / 'App.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>', encoding='utf-8')
source = 'interface IWorker { void Run(System.Action action); } sealed class First : IWorker { public void Run(System.Action action) => action(); } static class Sink { public static void Keep() {} } static class Entry { public static void Run(IWorker worker) => worker.Run(() => Sink.Keep()); }'
(fixture / 'Flow.cs').write_text(source, encoding='utf-8')
git('add', '.')
git('commit', '--no-gpg-sign', '-m', 'test: create dispatch before fixture')
before = git('rev-parse', 'HEAD')
(fixture / 'Flow.cs').write_text(source + ' sealed class Second : IWorker { public void Run(System.Action action) => action(); }', encoding='utf-8')
git('add', '.')
git('commit', '--no-gpg-sign', '-m', 'test: add possible implementation')
after = git('rev-parse', 'HEAD')
environment = dict(os.environ, NO_COLOR='1', CALLRIFT_WORKSPACE_CACHE=str(base / 'workspace-cache'))
def nodes(items):
    for item in items:
        yield item
        yield from nodes(item['children'])
report = []
for version, cli in [('baseline', original_cli), ('candidate', candidate_cli)]:
    for workspace in [False, True]:
        for reverse in [False, True]:
            arguments = ['dotnet', str(cli / 'callrift.dll'), 'diff', after if reverse else before, before if reverse else after, '--entry', 'Entry.Run', '--depth', '10', '--externals', '--format', 'json']
            if workspace:
                arguments += ['--project', 'App.csproj']
            result = subprocess.run(arguments, cwd=fixture, env=environment, capture_output=True, text=True, encoding='utf-8', timeout=180)
            name = f'{version}-{workspace}-{reverse}'
            (base / (name + '.json')).write_text(result.stdout, encoding='utf-8', newline='\n')
            (base / (name + '.err')).write_text(result.stderr, encoding='utf-8', newline='\n')
            assert result.returncode == 0, (name, result.returncode, result.stderr)
            data = json.loads(result.stdout)
            assert not data['diagnostics'], (name, data['diagnostics'])
            items = list(nodes(data['trees']))
            preserved = [node for node in items if 'First.Run' in node['label']]
            passed = len(preserved) == 1 and all(node['change'] == 'unchanged' and node['before'] and node['after'] for node in preserved)
            assert passed == (version == 'candidate'), (name, preserved)
            if passed:
                callbacks = [node for node in items if node['label'] == 'Sink.Keep']
                assert len(callbacks) == 1 and callbacks[0]['change'] == 'unchanged', (name, callbacks)
            item = {'version': version, 'workspace': workspace, 'reverse': reverse, 'preservedImplementation': passed, 'diagnostics': len(data['diagnostics'])}
            report.append(item)
            print(json.dumps(item), flush=True)
(base / 'report.json').write_text(json.dumps({'before': before, 'after': after, 'coreSha256': hashlib.sha256(candidate_core.read_bytes()).hexdigest(), 'checks': report}, indent=2) + '\n', encoding='utf-8', newline='\n')
