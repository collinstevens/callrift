import collections
import json
import re
import subprocess
from static_review_support import root, snapshots, manifest, document, flatten, clean, rendered, digest, schema, initializer_evidence, jsonschema

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
identity = lambda node: (node['after'] or node['before'])['symbolId']
depth_omission = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
lifetime_names = ['InstancePerDependency', 'SingleInstance', 'InstancePerLifetimeScope']
changed_targets = ['MetaRegistrationSource.ResolveInstance', 'Container.ResolveComponent', 'LifetimeScope.ResolveComponent', 'DefaultResolveRequestContext.ResolveComponent', 'DecoratorContext.ResolveComponent']
source_key = lambda value: json.dumps({name: value[name] for name in ['revision', 'definition', 'signature', 'callSites']}, sort_keys=True)

def node(label, children=None, detail=None, relation='call', change='unchanged'):
    return [label, change, detail, relation, children or []]

def shape(value):
    return node(value['label'], [shape(child) for child in value['children']], value['detail'], (value['after'] or value['before'])['relation'], value['change'])

benchmark_initialization = node('possible initialization of BenchmarkSet', [node('initialization of BenchmarkSet', detail='body changed; visible calls unchanged', change='modified')], relation='branch')
profiling_shape = node('Program.Main', [
    benchmark_initialization,
    node('if (args.Length == 0)', [node('Program.PrintBenchmarks')], relation='branch'),
    node('if (selectedBenchmark is null)', [node('Program.PrintBenchmarks')], relation='branch'),
    node('? BenchmarkConverter.TypeToBenchmarks'),
    node('else (!(benchRunInfo.BenchmarksCases.Length == 0))', [
        node('else (!(benchRunInfo.BenchmarksCases.Length == 1))', [
            node('if (args.Length > 1)', [node('if (uint.TryParse(args[1], out var selection))', [
                node('else (!(selection < benchRunInfo.BenchmarksCases.Length))', [node('? PrintCases')], relation='branch')], relation='branch')], relation='branch'),
            node('else (!(args.Length > 1))', [node('? PrintCases')], relation='branch')], relation='branch')], relation='branch'),
    node('? Activator.CreateInstance'), node('? BenchmarkActionFactory.CreateGlobalSetup'), node('? BenchmarkActionFactory.CreateGlobalCleanup'),
    node('? setupAction.InvokeSingle'), node('Program.Main.WorkloadAction', detail='depth limit'),
    node('new ThreadStart', [node('Program.Main.WorkloadAction', detail='depth limit', relation='callback')]), node('? cleanupAction.InvokeSingle')], relation='definition')
benchmark_shape = node('Program.Main', [
    node('Program.ExtractBaselineVersion', detail='depth limit'), node('new BenchmarkConfig', detail='depth limit'),
    node('? Job.Default.WithId'), node('? config.AddJob'),
    node('if (!string.IsNullOrWhiteSpace(baselineVersion))', [
        node('? Job.Default.WithId'), node('? Job.Default.WithId($"Package-{baselineVersion}").AsBaseline'),
        node('? Job.Default.WithId($"Package-{baselineVersion}").AsBaseline().WithMsBuildArguments'), node('? config.AddJob')], relation='branch'),
    benchmark_initialization, node('? new BenchmarkSwitcher'), node('? new BenchmarkSwitcher(BenchmarkSet.All).Run')], relation='definition')
program_shapes = {'source::Autofac.BenchmarkProfiling.Program.Main(string[])': profiling_shape, 'source::Autofac.Benchmarks.Program.Main(string[])': benchmark_shape}
program_rendering = {
    'source::Autofac.BenchmarkProfiling.Program.Main(string[])': '  Program.Main\n  ├─ possible initialization of BenchmarkSet\n~ │  └─ initialization of BenchmarkSet (body changed; visible calls unchanged)\n  ├─ if (args.Length == 0)\n  ├─ if (selectedBenchmark is null)\n  └─ …',
    'source::Autofac.Benchmarks.Program.Main(string[])': '  Program.Main\n  ├─ …\n  ├─ ? config.AddJob\n  ├─ if (!string.IsNullOrWhiteSpace(baselineVersion))\n  ├─ possible initialization of BenchmarkSet\n~ │  └─ initialization of BenchmarkSet (body changed; visible calls unchanged)\n  ├─ ? new BenchmarkSwitcher\n  └─ ? new BenchmarkSwitcher(BenchmarkSet.All).Run'}

def has_changes(value):
    return value['change'] != 'unchanged' or any(has_changes(child) for child in value['children'])

def blocks(text, value):
    parts = text.strip('\n').split('\n\n')
    nodes = [item for item in value['trees'] if has_changes(item)]
    assert len(parts) == len(nodes)
    return {identity(item): part for item, part in zip(nodes, parts)}

def normalize(block):
    return [(line[0], re.sub(r'^[ │├└─]*', '', line[2:])) for line in block.splitlines() if 'possible initialization of ' not in line and 'initialization of ReflectionCacheSet' not in line]

restored_name = 'autofac-pipeline-callbacks-msbuild-roots'
restored = document(snapshots / (restored_name + '-json.received.txt'))
restored_blocks = blocks(rendered(snapshots / (restored_name + '.received.txt'))[0], restored)
restored_proof = root / 'static-autofac-pipeline-restored-roots-review.json'
restored_review = json.loads(restored_proof.read_text(encoding='utf-8'))
for name, expected in restored_review['files'].items():
    assert digest(snapshots / name) == expected
pipeline_shapes = {value['label']: shape(value) for value in restored['trees'] if value['label'] in ['ServicePipelines.IsDefaultMiddleware', 'StronglyTypedMetaRegistrationSource.CreateMetaRegistration']}
pipeline_rendering = {value['label']: restored_blocks[identity(value)] for value in restored['trees'] if value['label'] in pipeline_shapes}
records = []
for case_id, report_name in [('autofac-pipeline-callbacks', 'autofac'), ('autofac-service-key-inheritance', 'autofac-key')]:
    case = manifest[case_id]
    name = case_id + '-source-roots'
    paths = [snapshots / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
    before, after = map(document, paths)
    jsonschema.validate(after, schema)
    assert before['diagnostics'] == after['diagnostics'] and len(after['diagnostics']) == 180
    assert {key: value for key, value in before.items() if key != 'trees'} == {key: value for key, value in after.items() if key != 'trees'}
    old = {identity(value): value for value in before['trees']}
    new = {identity(value): value for value in after['trees']}
    assert not old.keys() - new.keys()
    added = {key: new[key] for key in new.keys() - old.keys()}
    pipeline = case_id == 'autofac-pipeline-callbacks'
    assert len(added) == (4 if pipeline else 2)
    assert set(program_shapes) <= added.keys()
    counts = collections.Counter()
    for key in old:
        left, right = clean(old[key]), clean(new[key])
        for item in flatten(right['children']):
            lifetime = next((method for method in lifetime_names if item['label'].endswith('RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.' + method)), None)
            if lifetime is not None:
                assert item['detail'] == 'depth limit' and item['omission'] == depth_omission and item['change'] == 'unchanged'
                item['detail'], item['omission'] = None, None
                counts[lifetime] += 1
            if pipeline and item['label'] in ['⇢ ' + target for target in changed_targets] and item['change'] == 'modified' and item['detail'] == 'changes below depth limit':
                item['change'], item['detail'] = 'unchanged', 'depth limit'
                counts[item['label']] += 1
        assert left == right, key
    assert {key: counts[key] for key in lifetime_names} == {'InstancePerDependency': 1, 'SingleInstance': 6, 'InstancePerLifetimeScope': 10}
    assert {key: value for key, value in counts.items() if key.startswith('⇢ ')} == ({'⇢ ' + target: 1 for target in changed_targets} if pipeline else {})
    source_path = root / 'static-root-source-review' / (report_name + '-report.json')
    source_report = json.loads(source_path.read_text(encoding='utf-8'))
    assert source_report['failed'] == 0 and source_report['checks'] == (44 if pipeline else 16)
    source_proven = {source_key(record['check']) for record in source_report['records'] if record['passed']}
    for key, item in added.items():
        assert shape(item) == (program_shapes[key] if key in program_shapes else pipeline_shapes[item['label']])
        for child in flatten([item]):
            if child['label'] == 'initialization of BenchmarkSet':
                assert {key: value for key, value in child['before'].items() if key != 'definition'} == {key: value for key, value in child['after'].items() if key != 'definition'}
            else:
                assert child['before'] == child['after']
            assert child['omission'] == (depth_omission if child['detail'] in ['depth limit', 'changes below depth limit'] else None)
            for side in ['before', 'after']:
                value = child[side]
                if value['origin'] == 'source' and value['definition'] is not None and not value['symbolId'].endswith('..cctor()'):
                    assert source_key({'revision': case[side], 'definition': value['definition'], 'signature': value['signature'], 'callSites': value['callSites']}) in source_proven
                if value['binding'] == 'unresolved':
                    assert value['symbolId'] is None and value['targetIds'] == [] and value['origin'] == 'unknown'
                    assert any(diagnostic['location'] == site for diagnostic in after['diagnostics'] for site in value['callSites'])
    branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
    expected_counts = {'BenchmarkSet': 2, 'KeyedService': 1, 'ReflectionCacheSet': 1 if pipeline else 2, 'DefaultPropertySelector': 6, 'ResolveRequest': 8, 'ResolutionValueExtensions': 1}
    if pipeline:
        expected_counts['ServicePipelines'] = 1
    assert collections.Counter(item['label'].removeprefix('possible initialization of ') for item in branches) == expected_counts
    initializer_key, initializer_proven = initializer_evidence(case_id)
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        child = branch['children'][0]
        assert child['children'] == []
        assert child['omission'] == (depth_omission if child['label'] in ['initialization of DefaultPropertySelector', 'initialization of ServicePipelines'] else None)
        for side in ['before', 'after']:
            value, structural = child[side], branch[side]
            if value is None:
                assert structural is None and not pipeline and branch['change'] == child['change'] == 'added'
                continue
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
            assert initializer_key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}) in initializer_proven
    blobs = {}
    source_expectations = {
        'bench/Autofac.BenchmarkProfiling/Program.cs': ['var availableBenchmarks = Benchmarks.BenchmarkSet.All;', 'WorkloadAction(100);', 'WorkloadAction(10000);'],
        'bench/Autofac.Benchmarks/Program.cs': ['BenchmarkSet.All.Length', 'new BenchmarkSwitcher(BenchmarkSet.All).Run(filteredArgs, config);'],
        'src/Autofac/Builder/RegistrationBuilder{TLimit,TActivatorData,TRegistrationStyle}.cs': ['RegistrationData.Lifetime = CurrentScopeLifetime.Instance;', 'RegistrationData.Lifetime = RootScopeLifetime.Instance;'],
        'src/Autofac/Core/Lifetime/CurrentScopeLifetime.cs': ['Instance { get; } = new CurrentScopeLifetime();'],
        'src/Autofac/Core/Lifetime/RootScopeLifetime.cs': ['Instance { get; } = new RootScopeLifetime();'],
        'src/Autofac/Core/KeyedService.cs': ['AnyKey { get; } = new object();']}
    for path, snippets in source_expectations.items():
        blobs[path] = {}
        for side in ['before', 'after']:
            source = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            assert all(snippet in source for snippet in snippets)
            blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
    type_list_path = 'bench/Autofac.Benchmarks/BenchmarkSet.cs'
    diff = subprocess.check_output(['git', '-C', repository, 'diff', case['before'], case['after'], '--', type_list_path], text=True)
    additions = [line for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
    assert additions == (['+        typeof(ResolvePipelineAllocationBenchmark),'] if pipeline else ['+        typeof(ContainerBuildBenchmark),', '+        typeof(ContainerBuildInheritedMembersBenchmark),'])
    text_paths = [snapshots / (name + '.' + suffix + '.txt') for suffix in ['verified', 'received']]
    old_stdout, old_stderr = rendered(text_paths[0])
    new_stdout, new_stderr = rendered(text_paths[1])
    assert old_stderr == new_stderr
    old_blocks, new_blocks = blocks(old_stdout, before), blocks(new_stdout, after)
    factory_shifts = 0
    for key in old_blocks:
        left, right = normalize(old_blocks[key]), normalize(new_blocks[key])
        right = [(mark, label.removesuffix(' (depth limit)') if any(label.endswith('RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.' + method + ' (depth limit)') for method in lifetime_names) else label) for mark, label in right]
        if pipeline and 'LazyWithMetadataRegistrationSource.CreateLazyRegistration' in key:
            for line in [(' ', 'IComponentContext.ResolveComponent')] + [('~', '⇢ ' + target + ' (changes below depth limit)') for target in changed_targets[1:]]:
                assert right.count(line) == 1
                right.remove(line)
        right = [(' ', '⇢ MetaRegistrationSource.ResolveInstance (depth limit)') if line == ('~', '⇢ MetaRegistrationSource.ResolveInstance (changes below depth limit)') else line for line in right]
        if left != right:
            assert len(left) == len(right)
            assert [(a, b) for a, b in zip(left, right) if a != b] == [((' ', 'Enforce.ArgumentTypeIsFunction (depth limit)'), (' ', '…'))]
            factory_shifts += 1
    assert factory_shifts == 1
    for key, item in added.items():
        assert new_blocks[key] == (program_rendering[key] if key in program_rendering else pipeline_rendering[item['label']])
    records.append({'view': name, 'newRoots': sorted(added), 'initializerBranches': len(branches), 'reviewedExistingNodeChanges': dict(counts), 'sourceRootReportSha256': digest(source_path), 'sourceRootReviewerSha256': digest(root / 'static-root-source-review/Program.cs'), 'sourceBlobs': blobs, 'restoredPipelineReviewSha256': digest(restored_proof), 'schemaV1': True, 'textMarkdownParity': True, 'diagnosticsUnchanged': 180, 'files': {path.name: digest(path) for path in [paths[1], text_paths[1]]}, 'repeatStatus': 'pending', 'review': 'The benchmark entry points read the changed static type list. Typeof additions modify its body without adding visible calls. Seventeen existing lifetime configuration calls now expose hidden singleton initializer work at the depth boundary. New source definitions and call sites match independent compiler records; unresolved package-dependent calls retain matching diagnostics. All prior fields and rendered content are preserved outside the explicitly reviewed additions and depth/context effects.'})
(root / 'static-autofac-source-roots-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed two Autofac source automatic views, four benchmark entry-point additions, two pipeline roots, and forty initializer branches.')
