from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
source = artifacts / 'dispatch-cardinality-cli-tests/complete-ready'
expected = 'bd0250ef13f4b4fc2b3a217529f7a4edf8c1a3a12162e302337a3c02d67b00ef'
assert hashlib.sha256((source / 'Callrift.Core.dll').read_bytes()).hexdigest() == expected
for name in ['scenarios', 'workspaces']:
    log = (artifacts / f'dispatch-cardinality-final-{name}-build.log').read_text(encoding='utf-8-sig')
    assert 'Build succeeded.' in log and '0 Error(s)' in log
    target = artifacts / f'dispatch-cardinality-final-{name}/build/bin/Check/debug'
    assert (target / 'Check.dll').exists()
    shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    for file in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
        shutil.copy2(source / file, target / file)
    hashes = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    (artifacts / f'dispatch-cardinality-final-{name}-binary-inputs.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
expected_text = '''A new implementation changes an unchanged interface call's candidate set.

exit: 0
stdout:
  Flow.Run
  └─ IWorker.Save
     ├─ ⇢ First.Save
+    └─ ⇢ Second.Save
stderr:

markdown:
exit: 0
stdout:
```diff
  Flow.Run
  └─ IWorker.Save
     ├─ ⇢ First.Save
+    └─ ⇢ Second.Save
```
stderr:
'''
received = artifacts / 'dispatch-cardinality-scenarios/Snapshots/dispatch-added.received.txt'
assert received.read_text(encoding='utf-8-sig') == expected_text
(artifacts / 'dispatch-cardinality-final-scenarios/Snapshots/dispatch-added.verified.txt').write_text(expected_text, encoding='utf-8-sig', newline='\n')
print('Frozen matching Core and worker; reviewed text expectation in private harness only.')
