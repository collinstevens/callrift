from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('artifacts/schema-review-python').resolve()))
import jsonschema
schema_path=Path('schemas/output-v1.schema.json');schema=json.loads(schema_path.read_text(encoding='utf-8'))
jsonschema.validators.validator_for(schema).check_schema(schema)
validator=jsonschema.validators.validator_for(schema)(schema)
root=Path('artifacts/record-copy-compatibility-corpus-repeat/Snapshots');paths=sorted(root.glob('*-json.verified.txt'))+[root/'serilog-msbuild.verified.txt'];records=[]
for path in paths:
 s=path.read_text(encoding='utf-8-sig')
 if path.name=='serilog-msbuild.verified.txt':s=s[s.index('format: json'):]
 document,_=json.JSONDecoder().raw_decode(s[s.index('{'):]);validator.validate(document)
 records.append({'snapshot':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert len(records)==89
Path('artifacts/record-copy-corpus-schema-validation.json').write_text(json.dumps({'validator':'jsonschema 4.25.1','schemaSha256':hashlib.sha256(schema_path.read_bytes()).hexdigest(),'validated':len(records),'snapshots':records},indent=2)+'\n',encoding='utf-8',newline='\n')
print('All 89 reviewed corpus JSON envelopes validate against published schema v1.')
