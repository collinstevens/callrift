from pathlib import Path
import json
import shutil
import sys

root = Path.cwd()
identifier = sys.argv[1]
case = next(case for case in json.loads((root / 'artifacts/orchardcore-expansion-candidates.json').read_text(encoding='utf-8')) if case['id'] == identifier)
base = root / 'artifacts' / (identifier + '-reviewed-corpus')
assert not base.exists()
base.mkdir()
source = root / 'artifacts/receiver-context-delegate-corpus'
for name in ['Check.csproj', 'RealWorldCaseTests.cs']:
    shutil.copy2(source / name, base / name)
(base / 'real-world-cases/reviews').mkdir(parents=True)
(base / 'Snapshots').mkdir()
entry = {key: case[key] for key in ['id', 'repository', 'before', 'after', 'license', 'licenseFile', 'beforeLicenseBlob', 'afterLicenseBlob']}
entry.update(cacheName='orchardcore', reason='Extract logout sign-out and redirect handling and preserve end-session settings in recipes and deployment', tags=['branch-guard', 'async', 'helper-extraction', 'method-move', 'cross-project', 'automatic-roots'], options=[], knownIssue='issues/orchardcore-coverage.md', review='reviews/' + identifier + '.md', routine=False)
focus = ['--depth', '3', '--externals'] + [argument for selector in case['entries'] for argument in ['--entry', selector]]
project = ['--project', case['project'], '--framework', case['framework']]
entry['views'] = [{'id': name, 'routine': False, 'options': options} for name, options in [('source-roots', ['--depth', '1']), ('source-focused', focus), ('msbuild-roots', ['--depth', '1', *project]), ('msbuild-focused', [*focus, *project])]]
(base / 'real-world-cases/manifest.json').write_text(json.dumps([entry], indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copy2(root / ('artifacts/' + identifier + '-review.md'), base / 'real-world-cases' / entry['review'])
for view in entry['views']:
    stem = identifier + '-' + view['id']
    formats = []
    for format in ['text', 'md']:
        stdout = (root / ('artifacts/' + stem + '.' + format)).read_text(encoding='utf-8-sig')
        stderr = (root / ('artifacts/' + stem + '.' + format + '.err')).read_text(encoding='utf-8-sig')
        formats.append(f'format: {format}\nexit: 0\nstdout:\n{stdout}stderr:\n{stderr}')
    (base / 'Snapshots' / (stem + '.verified.txt')).write_bytes(b'\xef\xbb\xbf' + '\n'.join(formats).encode('utf-8'))
    stdout = (root / ('artifacts/' + stem + '.json')).read_text(encoding='utf-8-sig')
    error = root / ('artifacts/' + stem + ('.json.err' if view['id'] == 'msbuild-roots' else '.err'))
    stderr = error.read_text(encoding='utf-8-sig')
    (base / 'Snapshots' / (stem + '-json.verified.txt')).write_bytes(b'\xef\xbb\xbf' + f'exit: 0\nstdout:\n{stdout}stderr:\n{stderr}'.encode('utf-8'))
(root / ('artifacts/' + identifier + '-manifest-draft.json')).write_text(json.dumps(entry, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared ' + identifier + ' independent harness.')
