from pathlib import Path
import copy
import hashlib
import json

artifacts = Path.cwd() / 'artifacts'
catalog = json.loads((artifacts / 'constructor-depth-leaf-batch3/catalog.json').read_text(encoding='utf-8'))
source_directory = artifacts / 'constructor-depth-leaf-batch3'
summary = json.loads((source_directory / 'compiler-summary.json').read_text(encoding='utf-8'))
assert sum(item['total'] for item in summary) == 198
supplemental = {}
for name in ['ocelot-poller-reentrancy', 'orchardcore-elasticsearch-authorization']:
    report = json.loads((artifacts / 'constructor-depth-package-leaf-review' / (name + '-report.json')).read_text(encoding='utf-8'))
    assert report['total'] == report['proven'] == 2
    supplemental.update({(record['leaf']['view'], record['leaf']['nodeId'], record['leaf']['side']): record for record in report['records']})
proofs = {}
for item in summary:
    report = json.loads((source_directory / (item['case'] + '-compiler-report.json')).read_text(encoding='utf-8'))
    for record in report['records']:
        leaf = record['leaf']
        if not record['provenNoVisibleCalls']:
            resolved = supplemental[(leaf['view'], leaf['nodeId'], leaf['side'])]
            assert resolved['leaf'] == leaf and resolved['sourceBlob'] == record['sourceBlob']
            record = resolved
        assert record['provenNoVisibleCalls']
        proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = record
older_reviewed = set()
for name in ['constructor-diagnostic-only-view-review.json', 'constructor-autofac-signature-review.json', 'constructor-role-signature-review.json']:
    older_reviewed.update(item['view'] for item in json.loads((artifacts / name).read_text(encoding='utf-8'))['reviews'])

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    index = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[index:])
    return document, content[:index], content[index + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

reviews = []
for entry in catalog:
    if not entry['deltas']:
        continue
    assert set(entry['fieldChanges']) == {'detail', 'omission'}, entry['view']
    old_directory = artifacts / 'constructor-exact-corpus/Snapshots'
    new_directory = artifacts / 'constructor-depth-corpus/Snapshots'
    original, prefix, suffix = read(old_directory / entry['baseline'])
    path = new_directory / (entry['view'] + '-json.received.txt')
    actual, new_prefix, new_suffix = read(path)
    assert prefix == new_prefix and suffix == new_suffix
    expected = copy.deepcopy(original)
    actual_nodes = {node['id']: node for node in nodes(actual['trees'])}
    changed_nodes = []
    for node in nodes(expected['trees']):
        actual_node = actual_nodes[node['id']]
        if node['omission'] == actual_node['omission']:
            continue
        assert node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
        assert node['detail'] in ['depth limit', 'changes below depth limit'] and actual_node['omission'] is None and actual_node['detail'] is None
        if node['detail'] == 'changes below depth limit':
            assert node['change'] in ['added', 'removed', 'modified']
        for side in ['before', 'after']:
            if node.get(side):
                proof = proofs[(entry['view'], node['id'], side)]
                assert proof['leaf']['definition'] == node[side]['definition']
                assert proof['leaf']['symbolId'] == node[side]['symbolId']
        node['omission'] = None
        node['detail'] = None
        changed_nodes.append(node)
    assert expected == actual
    old_text_path = old_directory / (entry['view'] + '.received.txt')
    if not old_text_path.exists():
        old_text_path = old_text_path.with_name(old_text_path.name.replace('.received.', '.verified.'))
    new_text_path = new_directory / (entry['view'] + '.received.txt')
    if not new_text_path.exists():
        new_text_path = new_text_path.with_name(new_text_path.name.replace('.received.', '.verified.'))
    old_lines = old_text_path.read_text(encoding='utf-8-sig').splitlines()
    new_lines = new_text_path.read_text(encoding='utf-8-sig').splitlines()
    assert len(old_lines) == len(new_lines), entry['view']
    removed_text_markers = 0
    for old, new in zip(old_lines, new_lines):
        if old == new:
            continue
        markers = [' (depth limit)', ' (changes below depth limit)']
        assert sum(old.count(marker) for marker in markers) == 1 and old.replace(markers[0], '').replace(markers[1], '') == new, (entry['view'], old, new)
        assert any(node['label'] in old for node in changed_nodes), (entry['view'], old)
        removed_text_markers += 1
    full_view = entry['baseline'].endswith('.verified.txt') or entry['view'] in older_reviewed
    reviews.append({'view': entry['view'], 'removedDepthMarkers': len(changed_nodes), 'removedTextMarkdownMarkers': removed_text_markers,
        'sourceProven': True, 'allOtherJsonAndRenderedLinesExact': True, 'fullConstructorAndDepthViewReviewed': full_view,
        'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(new_text_path.read_bytes()).hexdigest()})
    print(json.dumps(reviews[-1]))
(artifacts / 'constructor-depth-leaf-batch3-output-review.json').write_text(json.dumps({'productionPromoted': False, 'reviewedSourceSideOccurrences': 198, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
