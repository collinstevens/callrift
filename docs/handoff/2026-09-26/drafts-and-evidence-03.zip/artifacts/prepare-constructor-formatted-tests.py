from pathlib import Path
import hashlib
import json

root = Path.cwd()
artifacts = root / 'artifacts'
target = artifacts / 'constructor-integration-tests'
assert not target.exists()
target.mkdir()
records = {}
for name, source in [('ConstructorInitializationTests.cs', artifacts / 'ConstructorInitializationTests.cs'), ('ConstructorEquivalenceTests.cs', artifacts / 'constructor-equivalence-final/ConstructorEquivalenceTests.cs')]:
    original = source.read_text(encoding='utf-8')
    lines = original.splitlines()
    if name == 'ConstructorEquivalenceTests.cs':
        start = lines.index('        foreach (var reverse in new[] { false, true })')
        end = lines.index('        }', start)
        lines[start:end + 1] = ['    ' + line for line in lines[start:end + 1]]
    formatted = '\n'.join(lines) + '\n'
    assert [line.lstrip() for line in original.splitlines()] == [line.lstrip() for line in formatted.splitlines()]
    destination = target / name
    destination.write_text(formatted, encoding='utf-8', newline='\n')
    records[name] = {'originalSha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'formattedSha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'onlyLeadingWhitespaceChanged': True}
project = (artifacts / 'constructor-initialization-reviewed-cli-tests/Check.csproj').read_text(encoding='utf-8')
project = project.replace('../ConstructorInitializationTests.cs', 'ConstructorInitializationTests.cs').replace('../constructor-equivalence-final/ConstructorEquivalenceTests.cs', 'ConstructorEquivalenceTests.cs')
(target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
(artifacts / 'constructor-formatted-test-inputs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared formatted test files and proved that only leading whitespace changed.')
