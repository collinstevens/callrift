import json
import sys
sys.stdout.reconfigure(encoding="utf-8")
from pathlib import Path
import subprocess
from collections import Counter
repo='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/ocelot'
pins=['d1f22d930430410bfd0233f5e9e4f92980cf7df0','8646f482fc8c4aead02b6769762b6eeef73e9e6d','7b38a95066e75c4ec2fb434ca91c3584282319c1','f156fd4017ca25025fffdad8ec56c1d657dfb402','c20325bcb6a4d080ed1172d5303811031e532b03','fe672ec02c2b7c4dc5c5b8167bf5f39d24363d47']
def git(*args):return subprocess.check_output(['git','-C',repo,*args]).decode('utf-8')
entries=[]
for after in pins:
 before=git('rev-parse',after+'^').strip()
 licenses=[git('rev-parse',rev+':LICENSE.md').strip() for rev in [before,after]]
 changed=git('diff','--name-only',before,after).splitlines()
 paths=git('ls-tree','-r','--name-only',after).splitlines()
 sdks=[json.loads(git('show',rev+':global.json')) if git('ls-tree','--name-only',rev,'global.json').strip() else None for rev in [before,after]]
 entry={'before':before,'after':after,'subject':git('show','-s','--format=%s',after).strip(),'beforeLicenseBlob':licenses[0],'afterLicenseBlob':licenses[1],'changed':changed,'counts':dict(Counter(Path(path).suffix for path in paths)),'globalJsonInputs':sdks}
 entries.append(entry)
 print(after[:7],entry['subject'],'cs',entry['counts'].get('.cs'),'projects',entry['counts'].get('.csproj'),'license',licenses,'sdk',sdks,flush=True)
 print('\n'.join(path for path in changed if path.startswith('src/')),flush=True)
Path('artifacts/ocelot-candidates.json').write_text(json.dumps(entries,indent=2)+'\n',encoding='utf-8',newline='\n')
print(git('show',pins[0]+':LICENSE.md'),flush=True)
