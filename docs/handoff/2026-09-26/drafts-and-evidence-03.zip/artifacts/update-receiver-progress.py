from pathlib import Path
import hashlib
import json

root = Path.cwd()
core = root / 'artifacts/receiver-context-reviewed-build/bin/Callrift.Core/debug/Callrift.Core.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = {
    'productionHead': '7cfb72b3a1f11a28fda028f9e5d32e16a4a97d07',
    'coreSha256': digest(core),
    'files': {str(p.relative_to(root)).replace('\\', '/'): digest(p) for p in sorted((root / 'artifacts/receiver-context-core').rglob('*.cs')) if 'obj' not in p.parts},
    'cliCoreSha256': digest(root / 'artifacts/receiver-context-reviewed-cli-build/bin/Check/debug/Callrift.Core.dll'),
    'workerCoreSha256': digest(root / 'artifacts/receiver-context-reviewed-cli-build/bin/Check/debug/msbuild/Callrift.Core.dll'),
}
assert report['coreSha256'] == report['cliCoreSha256'] == report['workerCoreSha256']
(root / 'artifacts/receiver-context-reviewed-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
progress = '''# Receiver-context progress

The production checkpoint 7cfb72b is pushed. Its 313 scenarios passed in 35m29s. All 81 updated generic-context corpus views are verified: 80 in the broad repeat and the previously reviewed Autofac view in a separate exact-Core repeat. Evidence is generic-context-reviewed-corpus-completion.json. Sweep CI 36141027845 succeeded; ASP.NET CI 36144222033 failed with unknown cause; generic-context CI 36153634040 is running. Previously blocked job-detail inspection has not been retried.

Receiver changes remain isolated under artifacts/receiver-context-core. No production receiver changes or received snapshots have been accepted. The latest source and binary hashes are receiver-context-reviewed-inputs.json.

The prototype retains the containing instance through inherited helpers, constructors, callbacks, local functions, and reference casts. Separate object parameters, fields, static intermediaries, and user conversions retain their own receiver boundaries. Closed type-parameter receivers constrain dispatch; open ones remain conservative. Exact object creation excludes derived runtime classes. Receiver contexts share the existing explicit state and type bounds.

An earlier 313-scenario trial uses obsolete Core b25cb00a. Four failures exposed duplicate inherited calls and a false base-method-group edit. The corrected prototype tracks receiver identity only for methods whose containing-instance calls depend on dispatch. All four failing checks now pass in 35 seconds. The old trial remains useful only for finding additional defects. A separate generic recursion fixture exposed double normalization of canonical owner parameters; its corrected cycle refers to the first invocation.

Latest focused evidence: 21 source fixtures pass, the independent generic cycle fixture passes, four existing compatibility cases pass, and the receiver-only state-budget fixture passes. The budget fixture reports only Child511.Added as affected and explicitly marks the unchanged selected Child500.Entry as truncated. Formatting passes. The final 44 source/MSBuild CLI checks are running from frozen binaries. Earlier 42 CLI checks and 22 workspace checks passed a prior prototype and do not validate the latest corrections.

The initial receiver corpus trial was stopped because its driver launched outside mise. Child workers selected the system .NET installation without runtime 11. No result from that trial is accepted. The first latest CLI launch also had a wrong worker destination and was stopped; receiver-context-reviewed-cli-mixed-worker.log preserves the evidence. The restarted run has matching Core hashes in the parent and msbuild worker.

Next: complete the 44 CLI checks, rerun workspace and broad compatibility checks with the final frozen Core, then run all 81 corpus views through mise. Review each difference against immutable source before any promotion. Final package and integrated checks remain required.
'''
(root / 'artifacts/receiver-context-progress.md').write_text(progress, encoding='utf-8', newline='\n')
goal = root / 'GOAL.md'
text = goal.read_text(encoding='utf-8')
text = text.replace('broad current repeat and push remain in progress.', 'all 81 updated corpus views are verified and its 313-scenario push hook passed in 35m29s.')
text = text.replace('Full updated repeat is running.', 'All 81 updated views are verified; exact evidence is artifacts/generic-context-reviewed-corpus-completion.json.')
text = text.replace('Latest successful CI is reachability 36130808564.', 'Latest successful CI is sweep 36141027845 at 0766045.')
text = text.replace('Sweep CI 36141027845 and ASP.NET Core CI 36144222033 are running.', 'ASP.NET Core CI 36144222033 failed with unknown cause. Generic-context CI 36153634040 is running.')
text = text.replace('Its push runs 313 scenarios in artifacts/push-generic-context.log. Latest pushed checkpoint remains bfd1572.', 'Its 313-scenario push hook passed in 35m29s. origin/master is 7cfb72b.')
text += '\n2026-09-25 08:30 PDT: Generic checkpoint 7cfb72b is pushed after all 313 scenarios passed in 35m29s. All 81 reviewed generic-context corpus views are verified (80 in the broad repeat plus the expected Autofac view in an exact-Core repeat). Latest successful CI is sweep 36141027845; ASP.NET CI 36144222033 failed with unknown cause and generic CI 36153634040 is running. The receiver prototype remains artifacts-only, with 21 passing source fixtures, an independent cycle check, four corrected compatibility checks, and a passing receiver-only state-budget check. Its final 44 CLI cases are running. Full source hashes, version distinctions, harness launch errors, and remaining work are in artifacts/receiver-context-progress.md. No receiver snapshot is accepted.\n'
goal.write_text(text, encoding='utf-8', newline='\n')
print(json.dumps({'coreSha256': report['coreSha256'], 'matchingWorker': True}))
