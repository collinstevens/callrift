from pathlib import Path
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
target = artifacts / 'constructor-depth-corpus'
assert not target.exists()
target.mkdir()
for name in ['Check.csproj', 'RealWorldCaseTests.cs', 'packages.lock.json']:
    shutil.copy2(artifacts / 'constructor-exact-corpus' / name, target / name)
shutil.copytree(root / 'real-world-cases', target / 'real-world-cases')
shutil.copytree(root / 'tests/Callrift.RealWorldCases/Snapshots', target / 'Snapshots', ignore=shutil.ignore_patterns('*.received.txt'))
print('Prepared immutable corpus inputs using current production expectations, including the reviewed dispatch-cycle correction.')
