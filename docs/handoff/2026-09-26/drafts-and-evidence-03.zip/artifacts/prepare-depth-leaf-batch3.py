from pathlib import Path
import json

root = Path.cwd()
artifacts = root / 'artifacts'
target = artifacts / 'constructor-depth-leaf-batch3'
assert not (target / 'jobs.json').exists()
target.mkdir(exist_ok=True)
(target / 'configs').mkdir(exist_ok=True)
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
old_views = {item['view'] for item in json.loads((artifacts / 'constructor-depth-delta-catalog-batch2.json').read_text(encoding='utf-8'))}
catalog = [entry for entry in json.loads((artifacts / 'constructor-depth-delta-catalog-batch3.json').read_text(encoding='utf-8')) if entry['view'] not in old_views]
jobs = {}
for entry in catalog:
    case = next(case for case in sorted(manifest, key=lambda item: -len(item['id'])) if entry['view'].startswith(case['id']))
    view_id = entry['view'].removeprefix(case['id'] + '-')
    view = next(view for view in case['views'] if view['id'] == view_id)
    include_externals = '--externals' in case['options'] + view['options']
    path = artifacts / 'constructor-depth-corpus/Snapshots' / (entry['view'] + '-json.received.txt')
    text = path.read_text(encoding='utf-8-sig')
    document = json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
    for delta in entry['deltas']:
        if not delta['path'].endswith('/omission') or delta['after'] is not None or delta['before'].get('reason') != 'depth-limit':
            continue
        node = document
        for part in delta['path'].split('/')[1:-1]:
            node = node[int(part)] if isinstance(node, list) else node[part]
        for side in ['before', 'after']:
            value = node.get(side)
            if not value:
                continue
            if value['definition'] is None:
                assert len(value['targetIds']) == 1 and not value['targetIds'][0].startswith('metadata:'), (entry['view'], node['label'], value)
            config = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'leaves': []})
            if case['cacheName'] == 'polly':
                config['projectUsingFile'] = 'Directory.Build.targets'
            config['leaves'].append({'view': entry['view'], 'revision': case[side], 'side': side, 'nodeId': node['id'], 'label': node['label'],
                                    'symbolId': value['symbolId'], 'bodySymbolId': value['targetIds'][0] if value['definition'] is None else value['symbolId'],
                                    'definition': value['definition'], 'includeExternals': include_externals})
for name, configuration in jobs.items():
    (target / 'configs' / (name + '.json')).write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
(target / 'jobs.json').write_text(json.dumps(list(jobs), indent=2) + '\n', encoding='utf-8', newline='\n')
(target / 'catalog.json').write_text(json.dumps(catalog, indent=2) + '\n', encoding='utf-8', newline='\n')
runner = (artifacts / 'run-depth-leaf-refined-review.py').read_text(encoding='utf-8')
runner = runner.replace("directory = Path('artifacts/constructor-depth-leaf-source-review')", "directory = Path('artifacts/constructor-depth-leaf-batch3')")
(artifacts / 'run-depth-leaf-batch3.py').write_text(runner, encoding='utf-8', newline='\n')
print(json.dumps({'newViews': len(catalog), 'cases': len(jobs), 'sourceSideOccurrences': sum(len(config['leaves']) for config in jobs.values())}))
