from pathlib import Path
import difflib, hashlib, json, subprocess

root = Path(__file__).resolve().parents[1]
inputs = json.loads((root / 'artifacts/reachability-inputs.json').read_text())
source = Path('src/Callrift.Core/Diffing/TreeExpander.cs')
benchmark = Path('benchmarks/Callrift.Benchmarks/ReachabilityBenchmarks.cs')
assert hashlib.sha256((root / source).read_bytes()).hexdigest() == inputs['finalTreeExpanderSha256']
assert hashlib.sha256((root / benchmark).read_bytes()).hexdigest() == inputs['sharedBenchmarkSha256']
assert 'All eight benchmark output hashes match' in (root / 'artifacts/reachability-final-measurement-driver.log').read_text()
runs = json.loads((root / 'artifacts/reachability-controlled-runs.json').read_text())['runs']
runs += json.loads((root / 'artifacts/reachability-memo-controlled-runs.json').read_text())['runs']
runs += json.loads((root / 'artifacts/reachability-final-controlled-runs.json').read_text())['runs']
assert [run['version'] for run in runs] == ['baseline', 'candidate', 'memo', 'final']
assert all(run['workloads'] == runs[0]['workloads'] for run in runs)
labels = {'baseline': 'original', 'candidate': 'reverse-index', 'memo': 'unsynchronized-cache', 'final': 'cache'}
destination = root / 'benchmarks/baselines'
reports = {}
exports = []
for run in runs:
    original = Path(run['export'])
    data = json.loads(original.read_text(encoding='utf-8-sig'))
    assert len(data['Benchmarks']) == 8
    assert all(item['Statistics']['N'] >= 10 for item in data['Benchmarks'])
    name = 'reachability-windows-' + labels[run['version']] + '.json'
    output = destination / name
    output.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
    reports[run['version']] = data
    exports.append({**run, 'export': name, 'originalExportSha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                    'committedExportSha256': hashlib.sha256(output.read_bytes()).hexdigest()})
host = reports['baseline']['HostEnvironmentInfo']
for report in reports.values():
    for field in ['BenchmarkDotNetVersion', 'OsVersion', 'ProcessorName', 'RuntimeVersion', 'DotNetCliVersion', 'Configuration', 'LogicalCoreCount']:
        assert host[field] == report['HostEnvironmentInfo'][field], field
baseline_source = (Path(inputs['baselineDirectory']) / source).read_text(encoding='utf-8').splitlines(keepends=True)
patches = {}
for version in ['candidate', 'memo']:
    variant_source = (Path(inputs[version + 'Directory']) / source).read_text(encoding='utf-8').splitlines(keepends=True)
    name = 'reachability-' + labels[version] + '.patch'
    patch = 'diff --git a/' + source.as_posix() + ' b/' + source.as_posix() + '\n'
    patch += ''.join(difflib.unified_diff(baseline_source, variant_source, fromfile='a/' + source.as_posix(), tofile='b/' + source.as_posix()))
    (destination / name).write_text(patch, encoding='utf-8', newline='\n')
    patches[version] = name
source_inputs = json.loads((root / 'artifacts/reachability-source-input-audit.json').read_text())
manifest = {entry['id']: entry for entry in json.loads((root / 'real-world-cases/manifest.json').read_text())}
catalog = {key: manifest[key] for key in ['serilog-alignment-guard', 'polly-secondary-action']}
catalog['serilog-alignment-guard'].update(beforeLicenseBlob='37ec93a14fdcd0d6e525d97c0cfa6b314eaa98d8', afterLicenseBlob='37ec93a14fdcd0d6e525d97c0cfa6b314eaa98d8')
for key, repository, license_name, license_file, blob in [
    ('orchardcore-breadcrumbs', 'https://github.com/OrchardCMS/OrchardCore.git', 'BSD-3-Clause', 'LICENSE', '183936c000fa2cc5969ba724afc1bdc5bfae5080'),
    ('aspnetcore-header-recovery', 'https://github.com/dotnet/aspnetcore.git', 'MIT', 'LICENSE.txt', '984713a49622a96da110443c15477613bc12656b')
]:
    catalog[key] = {'repository': repository, 'license': license_name, 'licenseFile': license_file, 'beforeLicenseBlob': blob, 'afterLicenseBlob': blob}
workloads = []
for key, workload in runs[0]['workloads'].items():
    workloads.append({**workload, 'repository': catalog[key]['repository'], 'license': catalog[key]['license'],
                      'licenseFile': catalog[key]['licenseFile'], 'beforeLicenseBlob': catalog[key]['beforeLicenseBlob'],
                      'afterLicenseBlob': catalog[key]['afterLicenseBlob'], 'sourceInputs': [item for item in source_inputs if item['Id'] == key]})
metadata = {
    'description': 'Controlled source-mode expansion measurements with identical graph inputs and sampled output hashes across four implementations.',
    'implementations': {**inputs, 'status': 'Final synchronized cache measured and validated', 'discardedVariantPatches': patches},
    'gitVersion': subprocess.check_output(['git', '--version'], cwd=root, text=True).strip(),
    'scope': {
        'operation': 'Fresh TreeExpander per invocation, shared across up to the first ten sorted automatic after-side root definitions, depth one.',
        'emptyChangeSet': 'ExpandUnchanged uses the same roots and graph with an empty change set.',
        'setup': 'Git reads, parsing, binding, change detection, root selection, and output-hash computation occur before measurement.',
        'memory': 'Managed benchmark-process allocations include expander and cache construction. No MSBuild worker participates in this source-stage measurement.',
        'cacheConditions': 'Pinned inputs already fetched; filesystem and package caches warm. Each workload uses a fresh benchmark process.',
        'controls': 'Same machine, SDK, dependency versions, benchmark source, pinned inputs and root identities. No concurrent agent builds, tests or CLI trials during measurement.',
        'iterations': 'Three warmups, fifteen requested measurements, one launch; full exports retain raw measurements and outlier decisions.',
        'remaining': 'Complete diff/tree/reach commands, graph construction stages, cold inputs, workspace stages and worker allocations remain separate requirements.'
    },
    'workloads': workloads,
    'runs': exports,
    'validation': {
        'sampledOutputs': 'All eight complete sampled-tree hashes match every implementation and repeat setup.',
        'semanticAlgorithm': 'All 51 existing real-world checks and 22 workspace checks passed the selective cache before synchronization was added.',
        'finalTargetedScenarios': 58,
        'finalExhaustiveGraphChecks': 12288,
        'finalConcurrentExpansions': 30720,
        'concurrencyControl': 'Original implementation passed; unsynchronized memoization failed immediately with dictionary corruption; synchronized implementation passed.',
        'fullHeaderOutput': json.loads((root / 'artifacts/reachability-final-header-comparison.json').read_text()),
        'packageAndFormatting': 'Final package smoke and formatting passed.',
        'largeCorpusCases': 'The two larger benchmark pairs remain unaccepted corpus candidates.'
    }
}
(destination / 'reachability-windows-metadata.json').write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
def indexed(report):
    return {(item['Method'], item['FullName'].split('Case: "')[1].split('"')[0]): item for item in report['Benchmarks']}
before = indexed(reports['baseline'])
after = indexed(reports['final'])
rows = []
for case in ['serilog-alignment-guard', 'polly-secondary-action', 'orchardcore-breadcrumbs', 'aspnetcore-header-recovery']:
    for method in ['ExpandChanged', 'ExpandUnchanged']:
        old = before[method, case]
        new = after[method, case]
        row = {'case': case, 'method': method, 'originalMeanMs': old['Statistics']['Mean'] / 1e6,
               'originalStdDevMs': old['Statistics']['StandardDeviation'] / 1e6, 'finalMeanMs': new['Statistics']['Mean'] / 1e6,
               'finalStdDevMs': new['Statistics']['StandardDeviation'] / 1e6, 'timeRatio': old['Statistics']['Mean'] / new['Statistics']['Mean'],
               'originalBytes': old['Memory']['BytesAllocatedPerOperation'], 'finalBytes': new['Memory']['BytesAllocatedPerOperation']}
        rows.append(row)
        print(json.dumps(row), flush=True)
(root / 'artifacts/reachability-summary.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
