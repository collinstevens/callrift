from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path.cwd()
directory = root / 'artifacts/receiver-context-all-autofac-traces'
directory.mkdir(exist_ok=True)
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
revisions = sorted({case[side] for case in manifest if case['cacheName'] == 'autofac' for side in ['before', 'after']})
binary = root / 'artifacts/receiver-context-autofac-trace/build/bin/Check/debug/Check.dll'
assert hashlib.sha256(binary.with_name('Callrift.Core.dll').read_bytes()).hexdigest() == '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'
reports = []
for mode in ['source', 'msbuild']:
    for revision in revisions:
        path = directory / (mode + '-' + revision + '.jsonl')
        start = time.monotonic()
        with path.open('w', encoding='utf-8', newline='\n') as output:
            result = subprocess.run(['dotnet', str(binary), revision, mode], stdout=output, stderr=subprocess.STDOUT, timeout=360)
        assert result.returncode == 0, str(path)
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        assert len(rows[0]['Targets']) == 2
        assert sorted(row['Result'] for row in rows[1:]) == ['DefaultRegisteredServicesTracker.AddRegistration', 'ScopeRestrictedRegisteredServicesTracker.AddRegistration']
        if mode == 'msbuild':
            assert rows[0]['Diagnostics'] == 0
        report = {'mode': mode, 'revision': revision, 'diagnostics': rows[0]['Diagnostics'], 'contexts': 2, 'distinctOverrides': True, 'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'seconds': round(time.monotonic() - start, 2)}
        reports.append(report)
        print(json.dumps(report), flush=True)
(directory / 'report.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8', newline='\n')
