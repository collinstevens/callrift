from pathlib import Path
import json
import subprocess
import time

root = Path.cwd()
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
cli = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug/callrift.dll'
entries = ['AliasPartRazorHelperExtensions.GetContentItemByAliasAsync', 'FluidShapeRenderBenchmark.ShapeRenderStatic', 'HttpBackgroundJob.ExecuteAfterEndOfRequestAsync']
document = json.loads((root / 'artifacts/orchardcore-openid-logout-source-roots.json').read_text(encoding='utf-8-sig'))
entries = [next(node['after']['symbolId'] for node in document['trees'] if node['label'] == entry) for entry in entries]
for index, entry in enumerate(entries):
    output = root / ('artifacts/orchardcore-openid-root-path-exact-' + str(index) + '.json')
    error = output.with_suffix('.err')
    start = time.monotonic()
    with output.open('w', encoding='utf-8', newline='\n') as stdout, error.open('w', encoding='utf-8', newline='\n') as stderr:
        result = subprocess.run(['dotnet', str(cli), 'reach', '9866770c0e90e1e2b60681922e247fda7ec4ec01', '--entry', entry, '--to', 'OrchardCore.OpenId.OpenIdExtensions.GetUserIdentifier(global::System.Security.Claims.ClaimsPrincipal)', '--depth', '40', '--max-paths', '1', '--format', 'json'], cwd=repository, stdout=stdout, stderr=stderr, timeout=300)
    print(json.dumps({'entry': entry, 'exit': result.returncode, 'seconds': round(time.monotonic() - start, 2)}), flush=True)
    assert result.returncode == 0
