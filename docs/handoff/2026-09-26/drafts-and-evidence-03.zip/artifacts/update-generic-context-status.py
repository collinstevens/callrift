from pathlib import Path

root = Path.cwd()
goal = root / 'GOAL.md'
text = goal.read_text(encoding='utf-8')
text = text.replace('Constraint CI 36138178724 and sweep CI 36141027845 are running.', 'Constraint CI 36138178724 also failed; its cause remains unknown. Sweep CI 36141027845 and ASP.NET Core CI 36144222033 are running.')
lines = text.splitlines()
for index, line in enumerate(lines):
    if line.startswith('| Signed checkpoints and working tree |'):
        lines[index] = '| Signed checkpoints and working tree | Latest pushed checkpoint is bfd1572878a0fb813ed51317caf7dca535759f2c, the reviewed ASP.NET Core pair, after 272 scenarios passed in 29m27s. CI 36144222033 is running. Generic-context implementation is now uncommitted in fifteen Core files, three scenario files, and four documentation files. No generic-context snapshots have been accepted. GOAL.md stays locally excluded. |'
text = '\n'.join(lines) + '\n'
update = '''
2026-09-25 07:25 PDT: Approved seven-pair checkpoint efd9d42 remains committed and pushed. Latest signed ASP.NET checkpoint bfd1572 pushed after 272 hook scenarios passed in 29m27s. Constraint CI 36138178724 failed; no blocked job-detail action was retried. Sweep and ASP.NET CI remain running at the last permitted list check.

The generic-context implementation was integrated after matching all original/draft hashes. Fifteen Core files, three scenario files, and four docs are uncommitted. Final frozen Core SHA256 is 4c87e9d67cd27cfee65fc2e99f7f302e687c8b0cfd0bdcb925d286c9d5eaa320. Its 39 new regressions pass in 4m56s and all 22 workspaces in 4m31s. The integrated production build passes the same 39 in 5m7s plus package/tool/consumer smoke, formatting, and workflows. Final ASP.NET trace has 32,953 declarations, 41,910 projected members, no limits, twenty reachable states from the independently selected path, ModelMetadata dictionary arguments, and no forbidden comparer path. These are correctness checks, not benchmarks.

Final frozen 272-scenario session 89373 and 81-case session 30187 remain running. Snapshot review found sixteen views whose exact JSON trees and rendered bodies remain unchanged; new explicit limits are the only differences. Audit verifies 288 diagnostic occurrences against 192 immutable source inputs. Two semantic differences require investigation before acceptance: ASP.NET GetTaskResult mislabels an added implementation as a generic-argument edit; OrchardCore restored workflow output retains more instantiations of inherited display-driver methods. No received output has been promoted. Full source provenance, prior failures, trace evidence, and statuses remain under artifacts/generic-context-*.
'''
goal.write_text(text + update, encoding='utf-8', newline='\n')
progress = root / 'artifacts/generic-context-progress.md'
with progress.open('a', encoding='utf-8', newline='\n') as output:
    output.write('\n## 2026-09-25 07:25 PDT integrated status\n' + update)
