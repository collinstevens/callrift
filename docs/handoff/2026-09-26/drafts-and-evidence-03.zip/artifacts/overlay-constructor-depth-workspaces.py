from pathlib import Path
import hashlib
import json
import shutil

artifacts = Path.cwd() / 'artifacts'
directory = artifacts / 'constructor-depth-workspaces'
log = (artifacts / 'constructor-depth-workspaces-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
ready = directory / 'candidate-ready'
assert not ready.exists()
shutil.copytree(directory / 'build/bin/Check/debug', ready)
frozen = artifacts / 'constructor-depth-cli/candidate-ready'
shutil.copytree(frozen / 'msbuild', ready / 'msbuild', dirs_exist_ok=True)
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(frozen / name, ready / name)
hashes = {file.relative_to(ready).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in ready.rglob('*') if file.is_file()}
assert hashes['Callrift.Core.dll'] == hashes['msbuild/Callrift.Core.dll'] == '528c86f4dd75eda4adf3a3c1b7ea0676ffb95acbc82b132d28d081e77fee431b'
inputs = {file.relative_to(directory).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for pattern in ['*.cs', 'Snapshots/*.verified.txt'] for file in directory.glob(pattern)}
(artifacts / 'constructor-depth-workspace-inputs.json').write_text(json.dumps({'binaries': hashes, 'sourcesAndSnapshots': inputs}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen latest constructor/depth Core and matching packaged worker for 22 workspace checks.')
