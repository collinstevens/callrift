from pathlib import Path
import copy
import hashlib
import json
import subprocess

root = Path.cwd()
before = json.loads((root / 'artifacts/orchardcore-esmodule-localization-source-focused.json').read_text(encoding='utf-8'))
after = json.loads((root / 'artifacts/dispatch-cycle-orchard-focused.json').read_text(encoding='utf-8'))
def nodes(items):
    for item in items:
        yield item
        yield from nodes(item['children'])
def without_ids(value):
    result = copy.deepcopy(value)
    for node in nodes(result):
        node.pop('id')
    return result
assert before['diagnostics'] == after['diagnostics']
assert before['analysis'] == after['analysis']
assert before['from'] == after['from'] and before['to'] == after['to']
assert without_ids(before['trees'][1:]) == without_ids(after['trees'][1:])
previous = list(nodes(before['trees'][:1]))
current = list(nodes(after['trees'][:1]))
old_call = next(node for node in previous if node['label'] == 'IJSLocalizer.GetLocalizations → MediaJSLocalizer.GetLocalizations')
new_call = next(node for node in previous if node['label'] == 'IJSLocalizer.GetLocalizations')
call = next(node for node in current if node['label'] == 'IJSLocalizer.GetLocalizations')
assert call['change'] == 'unchanged'
assert call['before'] == old_call['before']
assert call['after'] == new_call['after']
media = next(node for node in call['children'] if node['label'] == '⇢ MediaJSLocalizer.GetLocalizations')
assert media['change'] == 'unchanged' and media['before'] and media['after']
assert sum(node['change'] == 'added' for node in call['children']) == 10
assert len(call['children']) == 11
repo = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
path = media['after']['definition']['path']
blobs = [subprocess.check_output(['git', 'rev-parse', data['commit'] + ':' + path], cwd=repo, text=True).strip() for data in [after['from'], after['to']]]
assert blobs[0] == blobs[1]
record = {'preservedImplementation': media['label'], 'preservedSourcePath': path, 'preservedBlob': blobs[0], 'addedImplementations': [node['label'] for node in call['children'] if node['change'] == 'added'], 'resourceManifestTreeUnchanged': True, 'diagnosticsUnchanged': True, 'reviewComplete': False}
(root / 'artifacts/dispatch-cycle-orchard-review.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record))
