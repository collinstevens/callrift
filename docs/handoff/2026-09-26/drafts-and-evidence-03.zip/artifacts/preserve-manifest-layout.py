import json
import os
import pathlib
import subprocess

root = pathlib.Path(__file__).resolve().parent.parent
manifest = root / 'real-world-cases/manifest.json'
base = subprocess.check_output(['git', 'show', 'HEAD:real-world-cases/manifest.json'], cwd=root).decode('utf-8')
original = json.loads(base)
current = json.loads(manifest.read_text(encoding='utf-8'))
assert current[:len(original)] == original
additions = current[len(original):]
assert len(additions) == 5 and all(entry['id'].startswith('polly-') for entry in additions)
body = '\n'.join(json.dumps(additions, indent=2, ensure_ascii=False).splitlines()[1:-1])
text = base.rstrip()[:-1].rstrip() + ',\n' + body + '\n]\n'
temporary = manifest.with_name('manifest.json.layout.tmp')
temporary.write_text(text, encoding='utf-8', newline='\n')
os.replace(temporary, manifest)
