from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-callback-corpus'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
trx_files = list((root / (directory.name + '-results')).glob('*.trx'))
assert len(trx_files) == 1
trx = trx_files[0]
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == '89' and counters['passed'] == '33' and counters['failed'] == '56'
results = tree.findall('.//{*}UnitTestResult')
failures = [result for result in results if result.attrib['outcome'] == 'Failed']
assert all('VerifyException' in result.find('.//{*}Message').text for result in failures)
failed_views = []
for result in failures:
    match = re.search(r'ReviewedView\(id: "([^"]+)", viewId: "([^"]+)"\)', result.attrib['testName'])
    if match:
        failed_views.append('-'.join(match.groups()))
    else:
        match = re.search(r'PinnedHistory\(id: "([^"]+)"\)', result.attrib['testName'])
        assert match, result.attrib['testName']
        failed_views.append(match.group(1))
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'allFailuresAreVerifyDifferences': True, 'unacceptedDifferences': sorted(failed_views), 'results': [result.attrib for result in results]}
(root / 'static-initialization-callback-corpus-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified terminal latest corpus: 33 passes, 56 snapshot differences, no other failures, unchanged frozen c01/973 inputs.')
