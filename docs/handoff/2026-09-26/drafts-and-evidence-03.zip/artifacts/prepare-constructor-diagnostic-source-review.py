from pathlib import Path
import collections
import json

root = Path.cwd()
directory = root / 'artifacts/constructor-exact-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
name = 'orchardcore-role-submission'
view = name + '-source-roots'
before = collections.Counter(json.dumps(item, sort_keys=True) for item in read(directory / (view + '-json.verified.txt'))['diagnostics'])
after = collections.Counter(json.dumps(item, sort_keys=True) for item in read(directory / (view + '-json.received.txt'))['diagnostics'])
assert not (before - after)
diagnostics = [json.loads(item) for item in (after - before).elements()]
assert len(diagnostics) == 404
assert all(item['code'] == 'unresolved-call' and item['message'].startswith('Cannot bind implicit base constructor for ') for item in diagnostics)
case = next(case for case in manifest if case['id'] == name)
config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'revisions': [case['before'], case['after']], 'diagnostics': diagnostics}
(root / 'artifacts/constructor-diagnostic-source-review/orchard-role.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
