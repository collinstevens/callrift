from pathlib import Path
import json
import subprocess

directory = Path('artifacts/constructor-depth-leaf-source-review')
reports = []
for name in json.loads((directory / 'jobs.json').read_text(encoding='utf-8')):
    with (directory / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(directory / 'bin/Release/net11.0/Check.dll'), str(directory / 'configs' / (name + '.json')), str(directory / (name + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, name
    report = json.loads((directory / (name + '-report.json')).read_text(encoding='utf-8'))
    summary = {'case': name, 'total': report['total'], 'proven': report['proven']}
    reports.append(summary)
    print(json.dumps(summary), flush=True)
(directory / 'summary.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8', newline='\n')
