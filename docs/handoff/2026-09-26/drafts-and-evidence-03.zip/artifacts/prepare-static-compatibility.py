from pathlib import Path
import shutil

root = Path('artifacts')
target = root / 'static-initialization-compatibility-scenarios'
assert not target.exists()
target.mkdir()
for path in Path('tests/Callrift.Scenarios').iterdir():
    if path.suffix == '.cs':
        shutil.copy2(path, target / path.name)
shutil.copytree('tests/Callrift.Scenarios/Snapshots', target / 'Snapshots')
shutil.copy2(root / 'record-copy-compatibility-scenarios/Check.csproj', target / 'Check.csproj')
for path in (root / 'static-initialization-identity-reviewed-cli').glob('Static*.cs'):
    shutil.copy2(path, target / path.name)
for suffix in ['core', 'worker']:
    source = root / ('static-initialization-scope-' + suffix)
    destination = root / ('static-initialization-callback-' + suffix)
    assert not destination.exists()
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns('bin', 'obj', 'build'))
path = root / 'static-initialization-callback-worker/Callrift.MSBuild.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-initialization-scope-core', 'static-initialization-callback-core'), encoding='utf-8', newline='\n')
path = root / 'static-initialization-callback-core/Analysis/CallCollector.cs'
text = path.read_text(encoding='utf-8-sig')
start = text.index('            case ExpressionSyntax expression when expression is IdentifierNameSyntax')
end = text.index('                return;', start) + len('                return;\n')
callback = text[start:end]
text = text[:start] + text[end:]
insert = text.index('            case AssignmentExpressionSyntax assignment when StaticMember')
text = text[:insert] + callback + text[insert:]
path.write_text(text, encoding='utf-8', newline='\n')
print('Prepared 541 existing scenarios plus 76 static-initialization checks and a callback correction.')
