using Callrift.Core;
using Callrift.MSBuild;
using Xunit;

namespace Callrift.Workspaces;

public sealed class WorkspaceLockTests
{
    [Fact]
    public async Task LongRunningAnalysisReleasesWorkspaceForWaitingRequest()
    {
        using var fixture = new CacheFixture();
        await fixture.InitializeAsync();
        using var holder = fixture.Hold();
        var waiting = fixture.AnalyzeAsync();
        await Task.Delay(TimeSpan.FromSeconds(90));
        Assert.False(waiting.IsCompleted, waiting.Exception?.ToString());
        holder.Dispose();
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => waiting.WaitAsync(TimeSpan.FromSeconds(10)));
        Assert.StartsWith("No restored workspace cache exists", exception.Message);
    }

    [Fact]
    public async Task WaitingRequestCanBeCancelledWithoutReleasingOtherAnalysis()
    {
        using var fixture = new CacheFixture();
        await fixture.InitializeAsync();
        using var holder = fixture.Hold();
        using var cancellation = new CancellationTokenSource();
        var waiting = fixture.AnalyzeAsync(cancellation.Token);
        Assert.False(waiting.IsCompleted);
        cancellation.Cancel();
        var exception = await Assert.ThrowsAnyAsync<OperationCanceledException>(() => waiting.WaitAsync(TimeSpan.FromSeconds(10)));
        Assert.Equal(cancellation.Token, exception.CancellationToken);
        Assert.Throws<IOException>(() => fixture.Hold());
    }

    [Fact]
    public async Task InvalidLockPathFailsPromptly()
    {
        using var fixture = new CacheFixture();
        await fixture.InitializeAsync();
        File.Delete(fixture.LockPath);
        Directory.CreateDirectory(fixture.LockPath);
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => fixture.AnalyzeAsync().WaitAsync(TimeSpan.FromSeconds(10)));
    }

    private sealed class CacheFixture : IDisposable
    {
        private readonly string? previousCache = Environment.GetEnvironmentVariable("CALLRIFT_WORKSPACE_CACHE");
        private readonly DirectoryInfo directory = Directory.CreateTempSubdirectory("callrift-lock-");
        private readonly MSBuildAnalysisProvider provider = new(new MSBuildOptions("App.csproj", NoRestore: true));
        private readonly SourceSnapshot snapshot = new("lock", [new SourceFile("App.csproj", "<Project />", "lock-fixture")]);
        public string LockPath { get; private set; } = "";

        public async Task InitializeAsync()
        {
            Environment.SetEnvironmentVariable("CALLRIFT_WORKSPACE_CACHE", directory.FullName);
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => AnalyzeAsync());
            Assert.StartsWith("No restored workspace cache exists", exception.Message);
            LockPath = Assert.Single(Directory.GetFiles(directory.FullName, "analysis.lock", SearchOption.AllDirectories));
        }

        public FileStream Hold() => new(LockPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);

        public Task<CallGraph> AnalyzeAsync(CancellationToken cancellationToken = default) =>
            provider.AnalyzeAsync(snapshot, new AnalysisOptions(), cancellationToken);

        public void Dispose()
        {
            Environment.SetEnvironmentVariable("CALLRIFT_WORKSPACE_CACHE", previousCache);
            directory.Delete(true);
        }
    }
}
