import collections
import difflib
import hashlib
import json
import subprocess
from static_review_support import root, manifest, document, snapshots, flatten, digest, clean, initializer_evidence, prior_fields_and_diagnostics

name = 'orchardcore-openid-logout-source-roots'
case = manifest['orchardcore-openid-logout']
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
received = document(snapshots / (name + '-json.received.txt'))
initializers = [node for node in flatten(received['trees']) if node['label'].startswith('initialization of ')]
assert len(initializers) == 227
initializer_paths = {node['after']['definition']['path'] for node in initializers}
assert len(initializer_paths) == 42
module = 'src/OrchardCore.Modules/'
preview_path = module + 'OrchardCore.ContentPreview/Controllers/PreviewController.cs'
download_path = module + 'OrchardCore.Contents/Deployment/Download/DownloadController.cs'
alias_path = module + 'OrchardCore.Alias/Razor/AliasPartRazorHelperExtensions.cs'
autoroute_path = module + 'OrchardCore.Autoroute/Razor/AutoroutePartRazorHelperExtensions.cs'
extra_paths = {preview_path, download_path, alias_path, autoroute_path,
    'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JNode.cs',
    'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JObject.cs',
    'src/OrchardCore/OrchardCore.Abstractions/IdGenerator.cs',
    module + 'OrchardCore.Media/SecureMediaPermissions.cs'}
sources = {}
blobs = {}
for path in sorted(initializer_paths | extra_paths):
    ids = []
    for side in ['before', 'after']:
        revision = case[side]
        ids.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
        sources[side, path] = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
    assert ids[0] == ids[1], path
    blobs[path] = ids[0]
assert 'jsonNode.Deserialize<T>(options ?? JOptions.Default)' in sources['after', 'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JNode.cs']
assert 'JsonSerializer.SerializeToElement(obj, options ?? JOptions.Default)' in sources['after', 'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JObject.cs']
assert 'private static readonly char[] s_encode32Chars = "0123456789abcdefghjkmnpqrstvwxyz".ToCharArray();' in sources['after', 'src/OrchardCore/OrchardCore.Abstractions/IdGenerator.cs']
assert 'var encode32Chars = s_encode32Chars;' in sources['after', 'src/OrchardCore/OrchardCore.Abstractions/IdGenerator.cs']
assert 'ConvertToDynamicPermission(Permission permission) => s_permissionTemplates.TryGetValue' in sources['after', module + 'OrchardCore.Media/SecureMediaPermissions.cs']
assert 'private static readonly Permission s_viewMediaTemplate = new(' in sources['after', module + 'OrchardCore.Media/SecureMediaPermissions.cs']
depth = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
depth_targets = [
    ('OrchardCore.Menu.Controllers.AdminController.Edit(string,string)', [6], 'JNode.ToObject'),
    ('OrchardCore.RateLimits.Controllers.LimiterController.Create(string,string)', [8], 'IdGenerator.GenerateId'),
    ('OrchardCore.RateLimits.Controllers.AdminController.CreatePost(global::OrchardCore.RateLimits.ViewModels.RateLimitPolicyEditViewModel)', [6], 'IdGenerator.GenerateId'),
    ('OrchardCore.Taxonomies.Controllers.AdminController.Edit(string,string)', [9], 'JNode.ToObject'),
    ('OrchardCore.RateLimits.Controllers.LimiterController.CreatePost(string,string)', [8], 'IdGenerator.GenerateId'),
    ('OrchardCore.Search.AzureAI.Migrations.AzureAISearchIndexSettingsMigrations.UpdateFrom1()', [1, 16, 7, 0, 0], 'JNode.ToObject'),
    ('OrchardCore.Taxonomies.Controllers.AdminController.EditPost(string,string)', [12], 'JNode.ToObject'),
    ('OrchardCore.Taxonomies.Controllers.AdminController.Delete(string,string)', [11], 'JNode.ToObject'),
    ('OrchardCore.Menu.Controllers.AdminController.EditPost(string,string)', [9], 'JNode.ToObject'),
    ('OrchardCore.Media.Services.ViewMediaFolderAuthorizationHandler.HandleRequirementAsync(AuthorizationHandlerContext,global::OrchardCore.Security.PermissionRequirement)', [11], 'SecureMediaPermissions.ConvertToDynamicPermission'),
    ('OrchardCore.Taxonomies.Controllers.AdminController.CreatePost(string,string,string)', [16, 4], 'JObject.FromObject'),
    ('OrchardCore.Menu.Controllers.AdminController.CreatePost(string,string,string)', [11, 2], 'JObject.FromObject'),
    ('OrchardCore.Contents.Deployment.Download.DownloadController.Display(string,bool)', [7], 'JObject.FromObject'),
    ('OrchardCore.Contents.Deployment.Download.DownloadController.Download(string,bool)', [6], 'JObject.FromObject')]
guards = []
def guard(label, path, line, column, end_line, end_column, expression):
    lines = sources['after', path].splitlines()
    selected = lines[line - 1:end_line]
    selected[-1] = selected[-1][:end_column - 1]
    selected[0] = selected[0][column - 1:]
    assert '\n'.join(selected) == expression, (path, line)
    side = {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None,
        'callSites': [{'path': path, 'startLine': line, 'startColumn': column, 'endLine': end_line, 'endColumn': end_column}],
        'relation': 'branch', 'candidates': None, 'origin': 'structural'}
    guards.append({'label': label, 'location': side['callSites'][0], 'sourceExpression': expression})
    return {'id': None, 'kind': 'branch', 'change': 'unchanged', 'label': label, 'detail': None, 'before': side, 'after': side, 'children': [], 'omission': None}
def prior(value):
    roots = {(node['after'] or node['before'])['symbolId']: node for node in value['trees']}
    for identity, indexes, label in depth_targets:
        node = roots['source::' + identity]
        for index in indexes:
            node = node['children'][index]
        assert node['label'] == label and node['detail'] is None and node['omission'] is None
        node['detail'] = 'depth limit'
        node['omission'] = depth
    preview = roots['source::OrchardCore.ContentPreview.Controllers.PreviewController.Display(string)']
    assert preview['children'][4]['label'] == 'catch'
    preview['children'].insert(4, guard('try', preview_path, 150, 9, 152, 10, '{\n            draft = JsonSerializer.Deserialize<PreviewDraft>(cached, JOptions.Default);\n        }'))
    for identity, path, line in [
        ('AliasPartRazorHelperExtensions.GetContentItemByAliasAsync(global::OrchardCore.IOrchardHelper,string,bool)', alias_path, 51),
        ('AutoroutePartRazorHelperExtensions.GetContentItemBySlugAsync(global::OrchardCore.IOrchardHelper,string,bool)', autoroute_path, 61)]:
        node = roots['source::' + identity]
        assert node['children'][2]['label'] == 'IContentManager.GetAsync → DefaultContentManager.GetAsync'
        assert 'latest ? VersionOptions.Latest : VersionOptions.Published' in sources['after', path].splitlines()[line - 1]
        node['children'][2:2] = [guard('if (latest)', path, line, 70, line, 91, 'VersionOptions.Latest'), guard('else (!(latest))', path, line, 94, line, 118, 'VersionOptions.Published')]
    for method, line in [('Display', 36), ('Download', 67)]:
        node = roots['source::OrchardCore.Contents.Deployment.Download.DownloadController.' + method + '(string,bool)']
        assert node['children'][2]['label'] == 'IContentManager.GetAsync → DefaultContentManager.GetAsync'
        assert 'latest == false ? VersionOptions.Published : VersionOptions.Latest' in sources['after', download_path].splitlines()[line - 1]
        node['children'][2:2] = [guard('if (latest == false)', download_path, line, 91, line, 115, 'VersionOptions.Published'), guard('else (!(latest == false))', download_path, line, 118, line, 139, 'VersionOptions.Latest')]
    def differences(left, right, path=''):
        if left == right:
            return
        if isinstance(left, dict) and isinstance(right, dict) and left.keys() == right.keys():
            for field in left:
                yield from differences(left[field], right[field], path + '/' + field)
        elif isinstance(left, list) and isinstance(right, list) and len(left) == len(right):
            for index, (old, new) in enumerate(zip(left, right)):
                yield from differences(old, new, path + '/' + str(index))
        else:
            yield {'path': path, 'expected': left, 'actual': right}
    remaining = list(differences(clean(value), clean(received)))
    (root / 'static-openid-source-review-unexplained.json').write_text(json.dumps(remaining, indent=2) + '\n', encoding='utf-8', newline='\n')
    if remaining:
        print(json.dumps({'unexplained': len(remaining), 'first': remaining[:3]}))
    return value
render_diff_path = root / 'static-openid-source-render-diff.txt'
reviewed_render_digest = 'eb245d7e7d36fa57b56bf34476e3b883e0be2deaf95f561ee0dd96d399399a0f'
assert digest(render_diff_path) == reviewed_render_digest
def stdout(old, new):
    difference = ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), n=2))
    assert difference == render_diff_path.read_text(encoding='utf-8')
    assert hashlib.sha256(difference.encode('utf-8')).hexdigest() == reviewed_render_digest
    assert len(difference.splitlines()) == 443
before, after, review = prior_fields_and_diagnostics(name, prior_json_transform=prior, stdout_check=stdout)
assert len(guards) == 9
key, proven = initializer_evidence('orchardcore-openid-logout')
branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
assert len(branches) == 227
locations = []
counts = collections.Counter()
for branch in branches:
    assert branch['kind'] == 'branch' and branch['change'] == 'unchanged' and branch['detail'] is None and branch['omission'] is None and len(branch['children']) == 1
    initializer = branch['children'][0]
    assert initializer['kind'] == 'call' and initializer['change'] == 'unchanged' and initializer['label'] == branch['label'].removeprefix('possible ')
    assert initializer['children'] == []
    hidden_metadata_only = initializer['label'] == 'initialization of DistributedShellHostedService'
    assert initializer['omission'] == (None if hidden_metadata_only else depth)
    assert initializer['detail'] == (None if hidden_metadata_only else 'depth limit')
    assert initializer['before'] == initializer['after'] and branch['before'] == branch['after']
    counts[initializer['after']['symbolId']] += 1
    for side in ['before', 'after']:
        value = initializer[side]
        structural = branch[side]
        assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['symbolId'] is None and structural['callSites'] == value['callSites']
        assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
        evidence = proven[key({'revision': case[side], **value})]
        record = evidence['record']
        assert record['passed'] and record['verifiedDeclaration']
        assert record['sourceBlob'] == blobs[value['definition']['path']]
        assert value['symbolId'] == 'source::' + record['type'] + '..cctor()'
        assert record['type'].endswith('.' + initializer['label'].removeprefix('initialization of '))
        assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in record['constructors']]
        assert digest(root.parent / evidence['path']) == evidence['sha256']
        locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
assert len(counts) == 42
review.update(initializerBranches=227, distinctInitializerTypes=42, depthOmittedInitializers=226, metadataOnlyInitializer='DistributedShellHostedService', immutableSourceBlobs=blobs, sourceLocations=locations,
    addedStructuralBranches=guards, reviewedDepthMarkers=[{'root': identity, 'children': indexes, 'label': label} for identity, indexes, label in depth_targets],
    reviewedRenderDiff={'path': render_diff_path.as_posix(), 'sha256': reviewed_render_digest, 'lines': 443, 'review': 'Every rendered change was inspected. Existing modified-call markers remain unchanged. Added initialization branches and conditional VersionOptions branches shift the existing two-sibling unchanged context and ellipses. The sole visible new depth suffix is JNode.ToObject; other depth changes lie in elided unchanged context. Text and Markdown agree.'},
    initializerCounts=dict(counts), review='All227 initializer possibilities are unchanged at both pins and bind to42 distinct immutable type declarations. Permission constructors, source singletons, conditional JSON defaults, generated handler descriptor construction and benchmark source calls justify226 initializer depth omissions. DistributedShellHostedService contains only hidden TimeSpan metadata calls, so its initializer is an empty complete node. The nine new structural branches expose initializer work inside existing try/conditional syntax. Fourteen existing method calls gain precise depth omissions from newly represented initializer paths, including IdGenerator callback field access and four JObject.FromObject calls. All other prior JSON fields, root identities, calls, locations, diagnostics and modified markers are preserved except independently proven added diagnostics.')
(root / 'static-openid-source-roots-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed OpenID source automatic:227 initializer branches/42 types,9 structural branches,14 depth markers,443 inspected rendered diff lines. Repeat pending.')
