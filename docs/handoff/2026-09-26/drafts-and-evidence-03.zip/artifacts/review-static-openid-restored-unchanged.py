import json
from pathlib import Path
from static_review_support import root, digest, document, rendered, jsonschema, schema

name = 'orchardcore-openid-logout-msbuild-roots'
directory = root / 'static-interceptor-orchard-roots-review/Snapshots'
production = Path('tests/Callrift.RealWorldCases/Snapshots')
terminal_path = root / 'static-interceptor-orchard-roots-review-terminal.json'
terminal = json.loads(terminal_path.read_text(encoding='utf-8'))
result = next(result for result in terminal['results'] if result['view'] == name)
assert result['outcome'] == 'Passed'
files = [name + suffix for suffix in ['-json.verified.txt', '.verified.txt']]
for filename in files:
    assert digest(directory / filename) == digest(production / filename)
    assert not (directory / filename.replace('.verified.', '.received.')).exists()
value = document(directory / files[0])
jsonschema.validate(value, schema)
assert [node['label'] for node in value['trees']] == ['AccessController.Authorize', 'AccessController.AuthorizeAccept', 'AccessController.Logout', 'AccessController.LogoutAccept', 'AccessController.Token', 'UserInfoController.Me', 'DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync', 'NamedRecipeStepHandler.ExecuteAsync']
assert value['diagnostics'] == [] and value['truncated'] is True
plain, stderr = rendered(directory / files[1])
assert stderr == ''
review = {'view': name, 'snapshotDirectory': directory.as_posix(), 'files': {filename: digest(directory / filename) for filename in files}, 'noSnapshotChange': True, 'core': terminal['core'], 'worker': terminal['worker'], 'repeatStatus': 'passed', 'terminalEvidence': terminal_path.as_posix(), 'terminalEvidenceSha256': digest(terminal_path), 'schemaV1': True, 'rootCount': 8, 'addedDiagnostics': 0, 'review': 'All three formats match the existing accepted production snapshots byte for byte. The eight original controller/adapter roots and their depth omissions are preserved. No generated definition or initializer occurs in this view. Stable interceptor initializer identities remove the five false pager/controller roots from the earlier candidate. The original immutable-source review remains applicable.'}
(root / 'static-openid-restored-unchanged-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified OpenID restored automatic view is unchanged from accepted production snapshots; its exact candidate replay passed.')
