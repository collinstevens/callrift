from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
name = 'aspnetcore-stream-cts-disposal'
directory = root / (name + '-reviewed-corpus')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
terminal_path = root / (directory.name + '-terminal.json')
terminal = json.loads(terminal_path.read_text(encoding='utf-8'))
assert terminal['counters']['total'] == terminal['counters']['passed'] == '2'
assert digest(Path(terminal['trx'])) == terminal['trxSha256']
inputs_path = root / (directory.name + '-inputs.json')
assert digest(inputs_path) == terminal['inputsSha256']
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for filename, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / filename) == expected
for filename, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / filename) == expected
for filename, expected in inputs['reviews'].items():
    assert digest(root / filename) == expected
assert not list((directory / 'Snapshots').glob('*.received.*'))
manifest_path = Path('real-world-cases/manifest.json')
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
assert len(manifest) == 30 and all(entry['id'] != name for entry in manifest)
draft_path = root / (name + '-manifest-draft.json')
entry = json.loads(draft_path.read_text(encoding='utf-8'))
assert json.loads((directory / 'real-world-cases/manifest.json').read_text(encoding='utf-8')) == [entry]
review_source = root / (name + '-review.md')
review_target = Path('real-world-cases') / entry['review']
assert not review_target.exists()
review = review_source.read_text(encoding='utf-8')
status = 'Status: source and output review complete; independent repeat pending.'
assert review.count(status) == 1
review = review.replace(status, 'Status: accepted after independent source/output review and a matching two-view repeat.')
review += '\nThe isolated repeat passes both views in 7m01s with all four snapshots byte-identical to the reviewed expectations. Frozen parent and worker binaries, sources, review records, and snapshot hashes remain unchanged. A main-harness repeat and cross-platform CI remain pending.\n'
records = []
for filename, expected in inputs['snapshots'].items():
    source = directory / 'Snapshots' / filename
    destination = Path('tests/Callrift.RealWorldCases/Snapshots') / filename
    assert not destination.exists() and digest(source) == expected
    data = source.read_bytes()
    assert data.startswith(b'\xef\xbb\xbf') and b'\r' not in data
    records.append({'source': source.as_posix(), 'target': destination.as_posix(), 'sha256': expected})
assert len(records) == 4
prior_manifest_hash = digest(manifest_path)
manifest.append(entry)
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
review_target.write_text(review, encoding='utf-8', newline='\n')
for record in records:
    shutil.copy2(record['source'], record['target'])
    assert digest(Path(record['target'])) == record['sha256']
proof = {'terminalSha256': digest(terminal_path), 'inputsSha256': digest(inputs_path), 'priorManifestSha256': prior_manifest_hash, 'manifestSha256': digest(manifest_path), 'reviewSourceSha256': digest(review_source), 'reviewTargetSha256': digest(review_target), 'snapshots': records, 'pairs': len(manifest), 'routineChanged': False}
(root / 'aspnetcore-cts-production-promotion.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Added reviewed pair 31 and four byte-identical snapshots after its two-view repeat passed.')
