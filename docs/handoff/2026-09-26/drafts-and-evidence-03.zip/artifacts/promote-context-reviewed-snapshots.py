from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
review = json.loads((root / 'artifacts/generic-context-reviewed-repeat-inputs.json').read_text(encoding='utf-8'))
autofac = json.loads((root / 'artifacts/generic-context-autofac-root-review.json').read_text(encoding='utf-8'))
files = review['files'] + autofac['files']
assert len(files) == 51
for file in files:
    received, target = root / file['received'], root / file['target']
    assert hashlib.sha256(received.read_bytes()).hexdigest() == file['sha256']
    original = root / 'artifacts/generic-context-final-corpus/Snapshots' / target.name
    assert target.read_bytes() == original.read_bytes(), 'Tracked baseline changed since review: ' + file['target']
    assert received.read_bytes().startswith(b'\xef\xbb\xbf')
    assert b'\r\n' not in received.read_bytes()
    file['beforeSha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
for file in files:
    shutil.copyfile(root / file['received'], root / file['target'])
report = {'files': files, 'mainSnapshotsPromoted': True, 'aspnetcoreSnapshotsUnchanged': True, 'fullRepeatPending': True}
(root / 'artifacts/generic-context-snapshot-promotion.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'promotedFiles': len(files), 'fullRepeatPending': True}))
