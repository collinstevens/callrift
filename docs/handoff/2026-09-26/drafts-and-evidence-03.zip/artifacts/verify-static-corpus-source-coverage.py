from pathlib import Path
import hashlib
import json

root = Path('artifacts')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inventory_path = root / 'static-initialization-corpus-review-inventory.json'
inventory = json.loads(inventory_path.read_text(encoding='utf-8'))
assert inventory['runStatus'] == 'terminal' and inventory['terminal']['allFailuresAreVerifyDifferences']
manifest = {case['id']: case for case in json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))}
key = lambda value: json.dumps({name: value[name] for name in ['revision', 'symbolId', 'definition', 'callSites']}, sort_keys=True)
initializers = {}
for folder in ['static-initializer-source-review', 'static-initializer-source-batch2-review', 'static-initializer-source-batch3-review', 'static-generated-initializer-review']:
    for path in (root / folder).glob('*-report.json'):
        report = json.loads(path.read_text(encoding='utf-8'))
        for record in report['records']:
            if record.get('passed') or folder == 'static-generated-initializer-review' and record.get('verified'):
                initializers[key(record['check'])] = {'report': path.as_posix(), 'sha256': digest(path)}
diagnostics = {}
for folder in ['static-diagnostic-source-refined-review', 'static-diagnostic-source-batch-review', 'static-diagnostic-source-batch2-review', 'static-diagnostic-source-batch3-review']:
    for path in (root / folder).glob('*.json'):
        config = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(config, dict) or 'diagnostics' not in config or 'revisions' not in config:
            continue
        report_path = path.with_name(path.stem + '-report.json')
        report = json.loads(report_path.read_text(encoding='utf-8'))
        assert report['count'] == report['proven'] and report['unmatched'] == []
        for diagnostic in config['diagnostics']:
            identity = (config['repository'], tuple(config['revisions']), json.dumps(diagnostic, sort_keys=True))
            diagnostics[identity] = {'config': path.as_posix(), 'configSha256': digest(path), 'report': report_path.as_posix(), 'reportSha256': digest(report_path)}
records = []
for view in inventory['views']:
    case = manifest[view['caseId']]
    initializer_records = []
    diagnostic_records = []
    missing = []
    for occurrence in view['initializerOccurrences']:
        for side in ['before', 'after']:
            value = occurrence[side]
            if value is None:
                continue
            check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
            if key(check) in initializers:
                initializer_records.append({'node': occurrence['node'], 'side': side, **initializers[key(check)]})
            else:
                missing.append({'kind': 'initializer', 'check': check})
    for diagnostic in view['addedDiagnostics']:
        identity = ('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], (case['before'], case['after']), json.dumps(diagnostic, sort_keys=True))
        if identity in diagnostics:
            diagnostic_records.append({'diagnostic': diagnostic, **diagnostics[identity]})
        else:
            missing.append({'kind': 'diagnostic', 'diagnostic': diagnostic})
    records.append({'view': view['view'], 'initializerSides': initializer_records, 'diagnostics': diagnostic_records, 'missing': missing})
proof = {'inventorySha256': digest(inventory_path), 'views': records, 'coveredInitializerSides': sum(len(record['initializerSides']) for record in records), 'coveredAddedDiagnostics': sum(len(record['diagnostics']) for record in records), 'missing': sum(len(record['missing']) for record in records), 'doesNotEstablishCompleteSnapshotCorrectness': True}
(root / 'static-corpus-source-coverage.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: value for key, value in proof.items() if key != 'views'}))
for record in records:
    if record['missing']:
        print(json.dumps({'view': record['view'], 'missing': record['missing']}))
