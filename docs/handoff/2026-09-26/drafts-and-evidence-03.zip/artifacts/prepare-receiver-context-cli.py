from pathlib import Path

root = Path.cwd()
target = root / 'artifacts/receiver-context-cli-tests'
target.mkdir(exist_ok=True)
(target / 'Check.csproj').write_text((root / 'artifacts/generic-context-cli-tests/Check.csproj').read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
source = (root / 'artifacts/receiver-context-fixtures/Program.cs').read_text(encoding='utf-8')
fixtures = source[source.index('const string sinks'):source.index('IEnumerable<DiffNode> Flatten')]
body = '''using System.Text.Json;
using Xunit;

namespace Callrift.Scenarios;

public sealed class ReceiverContextTests
{
    public static IEnumerable<object[]> Cases()
    {
FIXTURES
        foreach (var fixture in fixtures)
            foreach (var workspace in new[] { false, true })
                yield return [fixture.Name, fixture.Source + sinks, fixture.Entry, fixture.Expected, workspace];
    }

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task InheritedCallsRetainReceiver(string name, string source, string entry, string[] expected, bool workspace)
    {
        const string project = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>";
        var after = source.Replace("public static void Right() {}", "public static void Right() { throw new System.InvalidOperationException(); }", StringComparison.Ordinal);
        await using var fixture = await GitFixture.CreateAsync(new Scenario("receiver-context-" + name, "Inherited calls preserve the containing receiver and respect separate objects.",
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = source },
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = after }, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        using var tree = Parse(await fixture.RunAsync(["tree", fixture.Before, "--entry", entry, "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(tree.RootElement.GetProperty("diagnostics").EnumerateArray());
        var actual = Flatten(tree.RootElement.GetProperty("trees")).Select(node => node.GetProperty("label").GetString()!)
            .Where(label => label.StartsWith("Sink.", StringComparison.Ordinal)).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray();
        Assert.Equal(expected, actual);
        using var reach = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", entry, "--to", "Sink.Right", "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(reach.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.Equal(expected.Contains("Sink.Right", StringComparer.Ordinal), reach.RootElement.GetProperty("paths").GetArrayLength() > 0);
        using var diff = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", entry, "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(diff.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.Equal(expected.Contains("Sink.Right", StringComparer.Ordinal), diff.RootElement.GetProperty("hasChanges").GetBoolean());
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task GenericReceiverCycleReferencesFirstInvocation(bool workspace)
    {
        const string project = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>";
        const string source = "class Box<T> { public void Run() => Run(); } class Entry<U> { public static void Start(Box<U> value) => value.Run(); }";
        var files = new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = source };
        var after = new Dictionary<string, string>(files) { ["marker.txt"] = "after" };
        await using var fixture = await GitFixture.CreateAsync(new Scenario("receiver-context-cycle", "An unchanged generic receiver reuses its first active invocation.", files, after, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        using var tree = Parse(await fixture.RunAsync(["tree", fixture.Before, "--entry", "Entry<U>.Start", "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(tree.RootElement.GetProperty("diagnostics").EnumerateArray());
        var first = tree.RootElement.GetProperty("trees")[0].GetProperty("children")[0];
        var repeated = first.GetProperty("children")[0];
        Assert.Equal("cycle", repeated.GetProperty("omission").GetProperty("reason").GetString());
        Assert.Equal(first.GetProperty("id").GetString(), repeated.GetProperty("omission").GetProperty("referenceId").GetString());
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task SiblingOverridePreservesUnchangedSealedReceiver(bool workspace)
    {
        const string project = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>";
        const string source = "class Base { protected void Shared() => Hook(); protected virtual void Hook() => Sink.Left(); } sealed class Left : Base { public void Entry() => Shared(); } sealed class Right : Base {} static class Sink { public static void Left() {} public static void Right() {} }";
        var after = source.Replace("sealed class Right : Base {}", "sealed class Right : Base { protected override void Hook() => Sink.Right(); }", StringComparison.Ordinal);
        await using var fixture = await GitFixture.CreateAsync(new Scenario("receiver-context-sibling-override", "Adding a sibling override preserves the sealed receiver's unchanged call path.",
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = source },
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = after }, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        using var unaffected = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", "Left.Entry", "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(unaffected.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.False(unaffected.RootElement.GetProperty("hasChanges").GetBoolean());
        using var affected = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--entry", "Base.Shared", "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(affected.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.True(affected.RootElement.GetProperty("hasChanges").GetBoolean());
    }

    private static IEnumerable<JsonElement> Flatten(JsonElement nodes)
    {
        foreach (var node in nodes.EnumerateArray())
        {
            yield return node;
            foreach (var child in Flatten(node.GetProperty("children"))) yield return child;
        }
    }

    private static JsonDocument Parse(string output)
    {
        Assert.True(output.StartsWith("exit: 0\\n", StringComparison.Ordinal), output);
        return JsonDocument.Parse(output.Split("stdout:\\n", StringSplitOptions.None)[1].Split("stderr:\\n", StringSplitOptions.None)[0]);
    }
}
'''.replace('FIXTURES', '\n'.join('        ' + line for line in fixtures.splitlines()))
(target / 'ReceiverContextTests.cs').write_text(body, encoding='utf-8', newline='\n')
print('Prepared source/MSBuild CLI cases from the independent receiver fixtures.')
