from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
names = ['static-coalesce-complete-workspaces-v2', 'static-coalesce-workspace-generator']
records = []
for name in names:
    directory = root / name
    inputs_path = root / (name + '-inputs.json')
    inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
    for path, expected in inputs['versions']['candidate'].items():
        assert digest(directory / 'candidate-ready' / path) == expected
    for path, expected in inputs['sources'].items():
        assert digest(Path(path)) == expected
    assert inputs['priorWorkspaceInputsSha256'] == digest(root / 'static-initialization-callback-workspaces-inputs.json')
    assert inputs['priorWorkspaceTerminalSha256'] == digest(root / 'static-initialization-callback-workspaces-terminal.json')
    reports = list((root / (name + '-results')).glob('*.trx'))
    assert len(reports) == 1
    tree = ET.parse(reports[0])
    counters = tree.find('.//{*}Counters').attrib
    results = tree.findall('.//{*}UnitTestResult')
    records.append({'directory': name, 'inputsSha256': digest(inputs_path), 'trx': reports[0].as_posix(), 'trxSha256': digest(reports[0]), 'counters': counters, 'results': [result.attrib for result in results]})
    if name == names[0]:
        assert counters['total'] == counters['executed'] == '42' and counters['passed'] == '41' and counters['failed'] == '1'
        failures = [result for result in results if result.attrib['outcome'] != 'Passed']
        assert len(failures) == 1 and failures[0].attrib['testName'] == 'Callrift.Workspaces.WorkspaceTests.Generator'
        assert 'VerifyException' in ''.join(failures[0].itertext())
    else:
        assert counters['total'] == counters['executed'] == counters['passed'] == '1' and counters['failed'] == '0'
        assert len(results) == 1 and results[0].attrib['testName'] == 'Callrift.Workspaces.WorkspaceTests.Generator'

first, second = [root / name for name in names]
old = 'SDK regex generator bodies participate in change detection; static fields and property accessors do not link the runner back to Flow.Match.'
new = 'SDK regex generator bodies participate in change detection; static initialization links Flow.Match to the regex constructor, while metadata dispatch leaves the generated runner as a separate root.'
for source in first.glob('*.cs'):
    expected = source.read_bytes()
    if source.name == 'WorkspaceTests.cs':
        assert expected.count(old.encode()) == 1
        expected = expected.replace(old.encode(), new.encode())
    assert expected == (second / source.name).read_bytes()
for source in (first / 'Snapshots').glob('*.verified.txt'):
    assert source.read_bytes() == (second / 'Snapshots' / source.name).read_bytes()
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']:
    assert digest(first / 'candidate-ready' / name) == digest(second / 'candidate-ready' / name)
received = list((first / 'Snapshots').glob('*.received.txt'))
assert len(received) == 1 and received[0].name == 'generator.received.txt'
assert received[0].read_bytes().replace(old.encode(), new.encode(), 1) == (first / 'Snapshots/generator.verified.txt').read_bytes()
assert not list((second / 'Snapshots').glob('*.received.*'))
passed = [result for record in records for result in record['results'] if result['outcome'] == 'Passed']
assert len(passed) == len({result['testName'] for result in passed}) == 42
proof = {'core': digest(first / 'candidate-ready/Callrift.Core.dll'), 'worker': digest(first / 'candidate-ready/msbuild/Callrift.MSBuild.dll'), 'distinctPassingChecks': 42, 'descriptionOnlyFailureVerified': True, 'runs': records}
(root / 'static-coalesce-workspaces-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 42 distinct passing workspace checks across the full run and corrected generator repeat; only fixture prose differed.')
