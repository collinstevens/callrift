from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
core = root / 'artifacts/receiver-context-reviewed-build/bin/Callrift.Core/debug/Callrift.Core.dll'
inputs = json.loads((root / 'artifacts/receiver-context-reviewed-inputs.json').read_text(encoding='utf-8'))
assert hashlib.sha256(core.read_bytes()).hexdigest() == inputs['coreSha256']
for project in ['Scenarios', 'Workspaces']:
    source = root / 'tests' / ('Callrift.' + project) / 'bin/Debug/net11.0'
    target = root / 'artifacts' / ('receiver-context-reviewed-' + project.lower())
    shutil.copytree(source, target, dirs_exist_ok=True)
    for relative in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']:
        assert (target / relative).exists(), str(target / relative)
        shutil.copyfile(core, target / relative)
        assert hashlib.sha256((target / relative).read_bytes()).hexdigest() == inputs['coreSha256']
corpus = root / 'artifacts/receiver-context-reviewed-corpus'
corpus.mkdir(exist_ok=True)
for source in (root / 'artifacts/receiver-context-corpus').glob('*.cs'):
    shutil.copyfile(source, corpus / source.name)
shutil.copyfile(root / 'artifacts/receiver-context-corpus/Check.csproj', corpus / 'Check.csproj')
shutil.copytree(root / 'real-world-cases', corpus / 'real-world-cases', dirs_exist_ok=True)
(corpus / 'Snapshots').mkdir(exist_ok=True)
for source in (root / 'tests/Callrift.RealWorldCases/Snapshots').glob('*.verified.txt'):
    shutil.copyfile(source, corpus / 'Snapshots' / source.name)
print('Prepared isolated scenario, workspace, and reviewed corpus harnesses.')
