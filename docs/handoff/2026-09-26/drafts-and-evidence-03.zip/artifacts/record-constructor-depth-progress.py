from pathlib import Path
from datetime import datetime
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path.cwd()
artifacts = root / 'artifacts'
stamp = datetime.now().astimezone().isoformat(timespec='seconds')

def counts(directory):
    paths = list((artifacts / directory).glob('*.trx'))
    assert len(paths) == 1
    return ET.parse(paths[0]).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib

assert counts('constructor-depth-cli-candidate-results')['passed'] == '20'
assert counts('constructor-depth-cli-baseline-results')['failed'] == '14'
assert counts('constructor-depth-reach-candidate-results')['passed'] == '4'
assert counts('constructor-depth-reach-baseline-results')['failed'] == '2'
assert not subprocess.check_output(['git', 'status', '--short'], text=True).strip()
source_review = json.loads((artifacts / 'constructor-base-source-review/serilog-report.json').read_text(encoding='utf-8'))
assert source_review['verifiedCalls'] == 58
serilog_path = artifacts / 'constructor-serilog-subtree-review.json'
serilog = json.loads(serilog_path.read_text(encoding='utf-8'))
serilog['originalSymbolReviewPending'] = False
serilog['originalSymbolReview'] = 'artifacts/constructor-base-source-review/serilog-report.json'
serilog['note'] = 'Thirty added constructor nodes are source-proven. Two leaf-depth markers in the older extra-arguments output are incorrect; use the depth-corrected candidate before promotion. No production expectations are accepted here.'
serilog_path.write_text(json.dumps(serilog, indent=2) + '\n', encoding='utf-8', newline='\n')
binary_inputs = json.loads((artifacts / 'constructor-depth-cli-inputs.json').read_text(encoding='utf-8'))
core_hash = binary_inputs['candidate']['Callrift.Core.dll']
worker_hash = binary_inputs['candidate']['Callrift.MSBuild.dll']
assert core_hash == binary_inputs['candidate']['msbuild/Callrift.Core.dll']
message = f'''\n\n{stamp}: This continuation made concrete progress through a depth-reporting defect reproduction, isolated correction, passing CLI regressions, and further immutable-source review. The previous turn was progress, not a blocked wait. Tracked master remains clean at pushed 9ccabc3. CI 36184288525 and 36177017184 are still running; failed receiver CI details remain unapproved and no rejected read was retried.

Constructor review found false depth-limit omissions for known leaf bodies. Struct default constructors, empty methods, and bodies containing only hidden external calls reported truncated=true despite having no omitted visible calls. Eight independent fixtures across both external-visibility settings reproduce seven false results on e94. An isolated TreeExpander correction checks whether any visible call would be omitted before marking the depth boundary. It retains markers for source calls, unresolved calls, visible external calls, dispatch children, and callbacks. Changed leaf bodies remain modified without claiming changes below a depth limit.

Latest constructor/depth Core: {core_hash}. Matching worker: {worker_hash}. Parent and worker Core hashes agree. Preferred constructor implementation is now artifacts/constructor-depth-core: ConstructorBindings.cs, SourceOnlyAnalysisProvider.cs, CallCollector.cs, and TreeExpander.cs. This includes the partial Program correction and excludes record-copy changes. Do not copy entire prototype directories into production.

All 16 API probes pass (constructor-depth-candidate.log). All 20 tree/diff CLI regressions pass in 4m31s across source/MSBuild modes; baseline fails 14 with six controls passing. Four separate reach CLI checks pass in 12s, while baseline fails the two empty-leaf cases and passes the two real truncation controls. These establish complete versus truncated absent-path results. Core and both test files pass formatting. Exact frozen inputs: constructor-depth-cli-inputs.json and constructor-depth-reach-cli-inputs.json. No production code, tests, or expectations were changed.

Active immutable validation gates:
- Prior constructor e94: 471 scenarios, session 77988, constructor-reviewed-full.log, constructor-reviewed-full-results. This run remains useful compatibility evidence but does not include the depth correction.
- Latest depth candidate: 491 scenarios, session 12554, constructor-depth-scenarios.log, constructor-depth-scenario-results. It includes the 64 constructor tests and 20 depth tree/diff tests, but excludes the four subsequently added reach cases. Keep its source, snapshots, and binaries untouched. Source/binary hashes: constructor-depth-scenario-inputs.json.
- Latest depth candidate: 89 corpus views, session 96743, constructor-depth-corpus.log, constructor-depth-corpus-results. Frozen expectations come from current production 9ccabc3, including the accepted Serilog cycle correction. Received differences remain unaccepted. Source/binary hashes: constructor-depth-corpus-inputs.json.
- Latest depth candidate: 22 workspaces, session 62164, constructor-depth-workspaces.log, constructor-depth-workspace-results. Three prior constructor/generator expectation changes were independently reviewed and hash-checked before copying this harness. Source/binary hashes: constructor-depth-workspace-inputs.json.

Additional source/output review: both Orchard role automatic-root views have exactly four signature field changes plus 404 source-only base-binding diagnostics; all other JSON, text/Markdown stdout, and diagnostic formatting are exact. Immutable Role.cs has no explicit constructor and the same RoleClaims initializer at both pins. Evidence: constructor-role-signature-review.json. This adds two older-candidate reviewed views to the preceding 18; newer depth output still requires comparison.

Four Serilog views have exactly 30 newly exposed base-constructor nodes: 12 alignment source, four allocation source, two extra-arguments source, and 12 alignment restored. The first assertion correctly caught an omitted review category: PropertyToken also inherits MessageTemplateToken. Its immutable constructor was then read alongside TextToken and ScalarValue. Original Roslyn operations independently prove all 58 before/after call occurrences and exact source spans. MessageTemplateToken and LogEventPropertyValue have no instance initializers and only object as a base. Strict comparison removes only these proven added nodes, renumbers sequential JSON IDs, and requires every other JSON field to match. Text and Markdown add only the base constructor beneath the newly added guard; allocation/extra-arguments rendered output is unchanged. Two extra-arguments leaf-depth markers are known wrong in the older output and await the new candidate. Evidence: constructor-serilog-subtree-review.json and constructor-base-source-review/serilog-report.json. No snapshots were promoted.

Required follow-up remains full constructor/depth corpus review and repeat, latest full scenario/workspace results, integrated package checks, reviewed promotion and signed checkpoint, and subsequent record-copy integration with this depth correction. Record-copy c8f2e67c remains a separate e94-based prototype with 22 passing CLI checks; it does not yet contain the depth fix. Full goal thresholds, remaining semantics, performance matrix, final packages, and final three-OS CI remain incomplete. Counts stay 30 pairs across seven repositories and 20 both-mode pairs across five repositories.
'''
(artifacts / 'constructor-depth-progress.md').write_text('# Constructor depth review\n' + message, encoding='utf-8', newline='\n')
for path in [root / 'GOAL.md', artifacts / 'initialization-audit-progress.md']:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(message)
print('Recorded source-proven reviews, exact depth candidate, passing 24 CLI checks, and four active broad gates.')
