from pathlib import Path
import hashlib
import json
import shutil

r = Path('artifacts')
p = r / 'record-copy-compatibility-corpus/Snapshots'
proof_path = r / 'record-copy-corpus-source-review/report.json'
proof = json.loads(proof_path.read_text(encoding='utf-8'))
assert len(proof) == 8 and all(item['declarationCount'] == 2 and item['compilerErrors'] for item in proof)
encoded = lambda value: json.dumps(value, sort_keys=True)
proven = {encoded(item['expectedDiagnostic']) for item in proof}
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for name in ['aspnetcore-js-task-handling-source-focused', 'aspnetcore-js-task-handling-source-roots', 'cleanarchitecture-endpoint-groups']:
    def read(suffix):
        text = (p / (name + '-json.' + suffix + '.txt')).read_text(encoding='utf-8-sig')
        start = text.index('{')
        value, end = json.JSONDecoder().raw_decode(text[start:])
        return value, text[:start], text[start + end:]
    old, old_prefix, old_suffix = read('verified')
    new, new_prefix, new_suffix = read('received')
    assert old_prefix == new_prefix == 'exit: 0\nstdout:\n'
    old_diagnostics = {encoded(item) for item in old['diagnostics']}
    added = [item for item in new['diagnostics'] if encoded(item) not in old_diagnostics]
    assert len(added) == 2 and all(encoded(item) in proven for item in added)
    assert [item for item in new['diagnostics'] if encoded(item) not in {encoded(value) for value in added}] == old['diagnostics']
    expected = dict(old)
    expected['diagnostics'] = new['diagnostics']
    assert expected == new
    original_text = (p / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    received_text = (p / (name + '.received.txt')).read_text(encoding='utf-8-sig')
    prior_line = str(len(old['diagnostics']) - 8) + ' additional diagnostics; use --diagnostics full.'
    next_line = str(len(new['diagnostics']) - 8) + ' additional diagnostics; use --diagnostics full.'
    assert original_text.count(prior_line) == 2
    assert original_text.replace(prior_line, next_line) == received_text
    assert old_suffix.count(prior_line) == 1 and old_suffix.replace(prior_line, next_line) == new_suffix
    records.append({'view': name, 'addedDiagnostics': added, 'allOtherJsonAndRenderedContentUnchanged': True,
        'files': {file.name: digest(file) for file in [p / (name + suffix + '.received.txt') for suffix in ['', '-json']]}})
review = {'sourceProofSha256': digest(proof_path), 'views': records}
(r / 'record-copy-corpus-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
for old_name, new_name in [('record-copy-compatibility-corpus', 'record-copy-compatibility-corpus-repeat'), ('constructor-depth-workspaces', 'record-copy-compatibility-workspaces')]:
    destination = r / new_name
    assert not destination.exists()
    shutil.copytree(r / old_name, destination, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*'))
    if old_name == 'record-copy-compatibility-corpus':
        for record in records:
            for name, expected_hash in record['files'].items():
                assert digest(p / name) == expected_hash
                shutil.copy2(p / name, destination / 'Snapshots' / name.replace('.received.', '.verified.'))
print('Reviewed all three views against eight compiler checks; copied six reviewed snapshot files into an isolated repeat harness.')
