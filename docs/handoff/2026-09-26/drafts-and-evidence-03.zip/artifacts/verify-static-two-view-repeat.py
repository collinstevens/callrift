from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-two-view-repeat'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
for name, expected in inputs['reviews'].items():
    assert digest(root / name) == expected, name
trx = next((root / (directory.name + '-results')).glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '2'
assert counters['failed'] == '0'
assert not list((directory / 'Snapshots').glob('*.received.*'))
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': [result.attrib for result in tree.findall('.//{*}UnitTestResult')]}
(root / 'static-initialization-two-view-repeat-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified both reviewed views passed with unchanged frozen inputs and no received snapshots.')
