import collections
import json
import re
import subprocess
from static_review_support import root, manifest, flatten, prior_fields_and_diagnostics, initializer_evidence

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/ocelot'
views = ['ocelot-custom-json-merge-source-roots'] + ['ocelot-poller-reentrancy-' + mode + '-' + view for mode in ['source', 'msbuild'] for view in ['focused', 'roots']]
records = []
for name in views:
    merge = name.startswith('ocelot-custom')
    case_id = 'ocelot-custom-json-merge' if merge else 'ocelot-poller-reentrancy'
    case = manifest[case_id]
    automatic = name.endswith('-roots')
    def expected_before(document):
        if automatic and not merge:
            targets = [item for item in flatten(document['trees']) if item['label'] == '⇢ InMemoryFileConfigurationPollerOptions.DelayAsync']
            assert len(targets) == 1
            item = targets[0]
            assert item['detail'] is None and item['omission'] is None
            item['detail'] = 'depth limit'
            item['omission'] = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
        return document
    def rendering(before, after):
        if merge:
            def normalized(text):
                return [(line[0], re.sub(r'^[ │├└─]*', '', line[2:])) for line in text.splitlines() if line and 'initialization of ' not in line]
            assert normalized(before) == normalized(after)
        else:
            assert before == after
    before, after, proof = prior_fields_and_diagnostics(name, stdout_check=rendering, prior_json_transform=expected_before)
    branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
    expected_counts = {'possible initialization of ConfigurationBuilderExtensions': 2, 'possible initialization of DiscoverySteps': 1} if merge else {} if automatic else {'possible initialization of InMemoryFileConfigurationPollerOptions': 1}
    assert collections.Counter(item['label'] for item in branches) == expected_counts
    key, proven = initializer_evidence(case_id)
    locations = []
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['children'] == []
        change = 'added' if initializer['label'] == 'initialization of ConfigurationBuilderExtensions' else 'unchanged'
        assert branch['change'] == initializer['change'] == change
        assert initializer['omission'] == ({'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if initializer['label'] == 'initialization of DiscoverySteps' else None)
        for side in ['before', 'after']:
            value, structural = initializer[side], branch[side]
            if value is None:
                assert structural is None and side == 'before' and change == 'added'
                continue
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']]
            evidence = proven[key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']})]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            locations.append({'side': side, 'node': initializer['id'], 'report': evidence['path'], 'sha256': evidence['sha256']})
    expectations = {
        'src/DependencyInjection/ConfigurationBuilderExtensions.cs': (['after'], ['MergedConfigJsonKey = typeof(ConfigurationBuilderExtensions).FullName + ".JSON";', 'MergedConfigJObjectKey = typeof(ConfigurationBuilderExtensions).FullName + ".JObject";', '=> builder.Properties[MergedConfigJsonKey] as string;', 'globalConfiguration ??= MergedConfigJObject.OcelotJSection(']),
        'testing/Steps/DiscoverySteps.cs': (['before', 'after'], ['DynamicRoutingDiscoveryFinder = (services, config, route)', '=> new DynamicRoutingDiscoveryProvider(services, config, route);', '.AddSingleton(DynamicRoutingDiscoveryFinder)'])
    } if merge else {'src/Ocelot/Configuration/Repository/InMemoryFileConfigurationPollerOptions.cs': (['before', 'after'], ['public const int DefaultDelayMilliseconds = 1000;', 'public static int DelayMilliseconds { get; set; } = DefaultDelayMilliseconds;', '=> Task.FromResult(DelayMilliseconds);'])}
    blobs = {}
    for path, (sides, snippets) in expectations.items():
        blobs[path] = {}
        for side in sides:
            source = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            assert all(snippet in source for snippet in snippets)
            blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
    proof.update({'initializerBranches': len(branches), 'sourceLocations': locations, 'sourceBlobs': blobs, 'review': 'Merged configuration keys use runtime typeof/name expressions without source calls, and the discovery finder retains possible deferred constructor work beneath its depth boundary. The poller reads a static auto-property initialized from a constant. Its initializer has no visible calls; automatic views correctly expose the additional initialization step at the existing depth boundary. Root identities, possible dispatch targets, source locations and rendered poller trees remain unchanged. Source poller views add only three independently verified package-dependent initializer diagnostics.'})
    records.append(proof)
(root / 'static-ocelot-remaining-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed five remaining Ocelot views with five initializer branches and two explained automatic depth markers.')
