from pathlib import Path
import json
import subprocess
import sys
import time

root = Path('artifacts/receiver-context-review-trace')
for name in json.loads((root / (sys.argv[1] if len(sys.argv) > 1 else 'jobs.json')).read_text(encoding='utf-8')):
    start = time.monotonic()
    with (root / (name + '.jsonl')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(root / 'build/bin/Check/debug/Check.dll'), str(root / (name + '.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    print(json.dumps({'name': name, 'exitCode': result.returncode, 'seconds': round(time.monotonic() - start, 2)}), flush=True)
    assert result.returncode == 0, name
