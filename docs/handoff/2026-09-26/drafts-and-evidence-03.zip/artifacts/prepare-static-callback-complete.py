from pathlib import Path
import shutil

root = Path('artifacts')
source = root / 'static-initialization-complete-cli'
target = root / 'static-initialization-callback-complete-cli'
assert not target.exists()
target.mkdir()
for path in source.iterdir():
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, target / path.name)
shutil.copy2(root / 'static-callback-initialization-cli/StaticCallbackInitializationTests.cs', target / 'StaticCallbackInitializationTests.cs')
path = target / 'Check.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('    <Compile Include="StaticEventOrderTests.cs" />', '    <Compile Include="StaticEventOrderTests.cs" />\n    <Compile Include="StaticCallbackInitializationTests.cs" />'), encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-complete-cli.py').read_text(encoding='utf-8')
freeze = freeze.replace('static-initialization-complete-cli', 'static-initialization-callback-complete-cli')
freeze = freeze.replace('static-initialization-event-worker', 'static-initialization-callback-state-worker').replace('static-initialization-event-core', 'static-initialization-callback-state-core')
(root / 'freeze-static-callback-complete-cli.py').write_text(freeze, encoding='utf-8', newline='\n')
source = root / 'static-initialization-compatibility-corpus'
target = root / 'static-initialization-six-view-corpus'
assert not target.exists()
target.mkdir()
for path in source.iterdir():
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, target / path.name)
shutil.copytree(source / 'Snapshots', target / 'Snapshots', ignore=shutil.ignore_patterns('*.received.*'))
shutil.copytree(source / 'real-world-cases', target / 'real-world-cases')
path = target / 'RealWorldCaseTests.cs'
text = path.read_text(encoding='utf-8-sig')
old = 'e.Views ?? []'
replacement = '''(e.Views ?? []).Where(v => new[]
        {
            "ocelot-custom-json-merge-msbuild-focused", "ocelot-custom-json-merge-source-focused", "ocelot-custom-json-merge-msbuild-roots",
            "ocelot-route-claims-keys-source-roots", "polly-caller-cancellation-msbuild-roots", "polly-executor-continuations-msbuild-roots"
        }.Contains(e.Id + "-" + v.Id))'''
assert text.count(old) == 1
path.write_text(text.replace(old, replacement), encoding='utf-8', newline='\n')
print('Prepared 110 static/depth checks and six independently selected corpus views.')
