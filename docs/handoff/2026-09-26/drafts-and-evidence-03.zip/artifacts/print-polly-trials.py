import json
import pathlib
import sys

sys.stdout.reconfigure(encoding='utf-8')

root = pathlib.Path(__file__).resolve().parent

def show(nodes, level=0):
    for node in nodes:
        print('  ' * level + node['change'] + ' ' + node['label'] + (' [' + node['detail'] + ']' if node.get('detail') else ''))
        show(node['children'], level + 1)

for file in sorted(root.glob('polly-*-focused-trial.json')):
    try:
        data = json.loads(file.read_text(encoding='utf-8-sig'))
    except json.JSONDecodeError:
        continue
    print(file.name)
    show(data['trees'])
