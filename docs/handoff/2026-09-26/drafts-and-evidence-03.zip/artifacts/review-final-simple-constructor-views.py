from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path('artifacts')
snapshots = root / 'constructor-depth-corpus/Snapshots'
proofs = {}
for folder in ['constructor-depth-leaf-batch4', 'constructor-depth-leaf-batch5']:
    for path in (root / folder).glob('*-compiler-report.json'):
        for record in json.loads(path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = record

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    start = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[start:])
    return document, content[:start], content[start + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def diagnostics(items):
    lines = []
    for item in items[:8]:
        location = item.get('location')
        prefix = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(prefix + item['code'] + ': ' + item['message'])
    if len(items) > 8:
        lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

reviews = []
for view in ['serilog-exception-format', 'serilog-null-key', 'cleanarchitecture-logging-di', 'cleanarchitecture-validation-lambda', 'cleanarchitecture-handler-rename']:
    original, prefix, suffix = read(snapshots / (view + '-json.verified.txt'))
    path = snapshots / (view + '-json.received.txt')
    actual, new_prefix, new_suffix = read(path)
    assert prefix == new_prefix
    expected = copy.deepcopy(original)
    removed_markers = 0
    if view.startswith('serilog-'):
        assert suffix == new_suffix
        actual_nodes = {node['id']: node for node in nodes(actual['trees'])}
        for node in nodes(expected['trees']):
            changed = actual_nodes[node['id']]
            if node['omission'] == changed['omission']:
                continue
            assert node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
            assert node['detail'] == 'depth limit' and changed['omission'] is None and changed['detail'] is None
            for side in ['before', 'after']:
                if node.get(side):
                    proof = proofs[(view, node['id'], side)]
                    assert proof['leaf']['definition'] == node[side]['definition'] and proof['leaf']['symbolId'] == node[side]['symbolId']
            node['detail'] = None
            node['omission'] = None
            removed_markers += 1
    else:
        evidence = root / 'constructor-remaining-diagnostic-review'
        configuration = json.loads((evidence / (view + '.json')).read_text(encoding='utf-8'))
        proof = json.loads((evidence / (view + '-report.json')).read_text(encoding='utf-8'))
        program_review = json.loads((root / 'constructor-cleanarchitecture-program-trial/review.json').read_text(encoding='utf-8'))
        removed = next(item['removedDiagnostic'] for item in program_review['reviews'] if item['case'] == view)
        rejected_index = configuration['diagnostics'].index(removed)
        assert proof['unmatched'] == [rejected_index]
        retained = [item for index, item in enumerate(configuration['diagnostics']) if index != rejected_index]
        assert proof['provenUnboundCount'] == len(retained)
        assert all(record['provenMissingBase'] or record['provenNoCandidate'] for record in proof['records'] if record['index'] != rejected_index)
        counter = lambda items: collections.Counter(json.dumps(item, sort_keys=True) for item in items)
        assert counter(original['diagnostics'] + retained) == counter(actual['diagnostics'])
        added_keys = set(counter(retained))
        assert [item for item in actual['diagnostics'] if json.dumps(item, sort_keys=True) not in added_keys] == original['diagnostics']
        prior, _, _ = read(root / 'constructor-exact-corpus/Snapshots' / (view + '-json.received.txt'))
        assert prior['diagnostics'].count(removed) == 1
        prior['diagnostics'].remove(removed)
        expected['diagnostics'] = prior['diagnostics']
        assert suffix.strip() == 'stderr:\n' + diagnostics(original['diagnostics'])
        assert new_suffix.strip() == 'stderr:\n' + diagnostics(expected['diagnostics'])
    comparable_actual = copy.deepcopy(actual)
    unresolved_base_calls = 0
    if view == 'cleanarchitecture-handler-rename':
        known_types = ['TodoItemCompletedEventHandler', 'TodoItemCreatedEventHandler', 'LogTodoItemCompleted', 'LogTodoItemCreated']
        for node in comparable_actual['trees']:
            if not node['label'].startswith('new '):
                assert not node['children']
                continue
            type_name = node['label'].removeprefix('new ')
            assert type_name in known_types and len(node['children']) == 1
            child = node['children'][0]
            assert child['kind'] == 'call' and child['label'] == '? base()' and child['change'] == node['change']
            assert child['detail'] is None and child['omission'] is None and not child['children']
            for side in ['before', 'after']:
                assert (child[side] is None) == (node[side] is None)
                if node[side] is None:
                    continue
                location = node[side]['definition']
                assert child[side] == {'symbolId': None, 'signature': None, 'binding': 'unresolved', 'dispatch': 'direct',
                                       'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'call', 'candidates': [], 'origin': 'unknown'}
                matching = [index for index, item in enumerate(configuration['diagnostics']) if item['location'] == location
                            and item['message'] == 'Cannot bind implicit base constructor for new ' + type_name + '.']
                assert len(matching) == 1
                revision = configuration['revisions'][0 if side == 'before' else 1]
                records = [record for record in proof['records'] if record['index'] == matching[0] and record['revision'] == revision]
                assert len(records) == 1 and records[0]['provenMissingBase'] and records[0]['type'].endswith('.' + type_name)
            node['children'] = []
            unresolved_base_calls += 1
        assert unresolved_base_calls == 4
        for original_node, actual_node in zip(expected['trees'], comparable_actual['trees']):
            actual_node['id'] = original_node['id']
    assert expected == comparable_actual, view
    old_text = (snapshots / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = snapshots / (view + '.received.txt')
    if not text_path.exists():
        text_path = snapshots / (view + '.verified.txt')
    new_text = text_path.read_text(encoding='utf-8-sig')
    if view.startswith('serilog-'):
        old_lines = old_text.splitlines()
        new_lines = new_text.splitlines()
        assert len(old_lines) == len(new_lines)
        for old, new in zip(old_lines, new_lines):
            if old != new:
                assert old.count(' (depth limit)') == 1 and old.replace(' (depth limit)', '') == new
    else:
        old_errors = diagnostics(original['diagnostics'])
        new_errors = diagnostics(actual['diagnostics'])
        assert old_text.count(old_errors) == new_text.count(new_errors) == 2
        comparable_text = new_text
        if view == 'cleanarchitecture-handler-rename':
            for line in ['- └─ ? base()\n', '+ └─ ? base()\n']:
                assert comparable_text.count(line) == 4
                comparable_text = comparable_text.replace(line, '')
        assert old_text.replace(old_errors, new_errors) == comparable_text
    reviews.append({'view': view, 'fullConstructorAndDepthViewReviewed': True, 'removedDepthMarkers': removed_markers,
                    'addedDiagnostics': len(actual['diagnostics']) - len(original['diagnostics']), 'unresolvedBaseCalls': unresolved_base_calls, 'allOtherJsonAndRenderedOutputExact': True,
                    'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(text_path.read_bytes()).hexdigest()})

(root / 'constructor-final-simple-view-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reviews))
