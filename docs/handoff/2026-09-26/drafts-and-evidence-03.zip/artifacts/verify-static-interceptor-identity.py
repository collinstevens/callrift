from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
cli_inputs_path = root / 'static-interceptor-identity-cli-inputs.json'
cli_inputs = json.loads(cli_inputs_path.read_text(encoding='utf-8'))
for name, expected in cli_inputs['binaries'].items():
    assert digest(root / 'static-interceptor-identity-cli/candidate-ready' / name) == expected
for name, expected in cli_inputs['sources'].items():
    assert digest(Path(name)) == expected
api = {}
for version in ['baseline', 'candidate']:
    folder = root / ('static-interceptor-identity-' + version)
    report = json.loads((folder / 'report.json').read_text(encoding='utf-8'))
    assert len(report) == 16
    assert all(record['passed'] == (version == 'candidate') for record in report)
    if version == 'baseline':
        assert all(not record['stableKeys'] and not record['noRandomNames'] for record in report)
    for path in folder.glob('*-*.json'):
        jsonschema.validate(json.loads(path.read_text(encoding='utf-8')), schema)
    api[version] = {path.as_posix(): digest(path) for path in folder.glob('*.json')}
directory = root / 'static-interceptor-identity-workspaces-v2'
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected
workspace = {}
for version, expected_total, expected_passed in [('baseline', 4, 0), ('candidate', 6, 6)]:
    for name, expected in inputs['versions'][version].items():
        assert digest(directory / (version + '-ready') / name) == expected
    reports = list((root / ('static-interceptor-workspaces-v2-' + version + '-results')).glob('*.trx'))
    assert len(reports) == 1
    tree = ET.parse(reports[0])
    counters = tree.find('.//{*}Counters').attrib
    assert int(counters['total']) == int(counters['executed']) == expected_total
    assert int(counters['passed']) == expected_passed and int(counters['failed']) == expected_total - expected_passed
    results = tree.findall('.//{*}UnitTestResult')
    assert len(results) == expected_total
    for result in results:
        assert result.attrib['outcome'] == ('Passed' if version == 'candidate' else 'Failed')
        if version == 'baseline':
            message = result.find('.//{*}Message').text
            assert 'Assert.Empty() Failure' in message or 'Assert.Single() Failure' in message
            assert 'Interceptor_' in message
    workspace[version] = {'trx': reports[0].as_posix(), 'sha256': digest(reports[0]), 'counters': counters}
pager_path = root / 'static-interceptor-orchard-pager-depth6.json'
pager = json.loads(pager_path.read_text(encoding='utf-8'))
jsonschema.validate(pager, schema)
assert pager['hasChanges'] is False and pager['trees'] == [] and pager['diagnostics'] == [] and pager['truncated'] is False
run_path = root / 'static-interceptor-orchard-pager-depth6-run.json'
run = json.loads(run_path.read_text(encoding='utf-8'))
assert run['exitCode'] == 0 and run['outputSha256'] == digest(pager_path) and run['core'] == cli_inputs['binaries']['Callrift.Core.dll']
program_before = root / 'static-interceptor-identity-probe/Program.cs'
program_after = root / 'static-interceptor-identity-candidate-probe/Program.cs'
assert digest(program_before) == digest(program_after)
probe_binaries = {}
for version, folder in [('baseline', 'static-interceptor-identity-probe'), ('candidate', 'static-interceptor-identity-candidate-probe')]:
    binary_folder = root / folder / 'bin/Debug/net11.0'
    assert digest(binary_folder / 'Callrift.Core.dll') == inputs['versions'][version]['Callrift.Core.dll']
    probe_binaries[version] = {path.as_posix(): digest(path) for path in binary_folder.iterdir() if path.is_file()}
proof = {'core': cli_inputs['binaries']['Callrift.Core.dll'], 'worker': cli_inputs['binaries']['Callrift.MSBuild.dll'], 'cliInputsSha256': digest(cli_inputs_path), 'workspaceInputsSha256': digest(inputs_path), 'apiProgramSha256': digest(program_before), 'apiBinaries': probe_binaries, 'api': api, 'workspaces': workspace, 'orchardPagerRun': run, 'orchardPagerRunSha256': digest(run_path)}
(root / 'static-interceptor-identity-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 16 API regressions fail before/pass after, four CLI regressions fail before/pass after, two existing CLI checks pass, and unchanged OrchardCore pager has no diff. All frozen hashes match.')
