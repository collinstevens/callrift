from pathlib import Path
import hashlib
import json

root = Path.cwd()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
worker = root / 'artifacts/receiver-context-final-worker-build/bin/Callrift.MSBuild/debug'
report = {
    'productionHead': '7cfb72b3a1f11a28fda028f9e5d32e16a4a97d07',
    'coreSha256': digest(worker / 'Callrift.Core.dll'),
    'workerSha256': digest(worker / 'Callrift.MSBuild.dll'),
    'files': {},
    'harnesses': {},
}
for directory in ['receiver-context-core', 'receiver-context-worker', 'receiver-context-cli-tests']:
    for path in sorted((root / 'artifacts' / directory).rglob('*.cs')):
        if 'obj' not in path.parts and 'bin' not in path.parts:
            report['files'][str(path.relative_to(root)).replace('\\', '/')] = digest(path)
for directory in ['receiver-context-final-workspaces', 'receiver-context-final-corpus/build/bin/Check/debug']:
    hashes = {name: digest(root / 'artifacts' / directory / name) for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']}
    assert hashes['Callrift.Core.dll'] == hashes['msbuild/Callrift.Core.dll'] == report['coreSha256']
    assert hashes['Callrift.MSBuild.dll'] == hashes['msbuild/Callrift.MSBuild.dll'] == report['workerSha256']
    report['harnesses'][directory] = hashes
report['earlierFixtureRun'] = {
    'coreSha256': digest(root / 'artifacts/receiver-context-filelocal-cli-build/bin/Check/debug/Callrift.Core.dll'),
    'workerSha256': digest(root / 'artifacts/receiver-context-filelocal-cli-build/bin/Check/debug/Callrift.MSBuild.dll'),
    'difference': 'Before dotnet format and renaming the worker Scope local parameter from method to symbol.',
}
(root / 'artifacts/receiver-context-final-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
progress = root / 'artifacts/receiver-context-progress.md'
text = progress.read_text(encoding='utf-8')
text += '''
## File-local correction implemented in isolation

The failing physical-path reproduction now passes. DispatchTypeDefinition carries an optional logical ContextIdentity. InvocationContext uses it when constructing cross-revision keys while retaining compiler type names for matching. The type catalog covers empty file-local classes/interfaces, nested types, and generic arguments. SymbolNames resolves logical declaring paths. A new additive BuildDispatchMap overload supplies a type-based declaring-path callback; existing public signatures remain. The isolated MSBuild worker resolves type scope and passes the callback when rebuilding the merged dispatch map.

The new file-local test class adds 17 independently specified checks: five direct physical-root comparisons, ten source/MSBuild revision comparisons, and two same-basename file isolation checks. Against the earlier 3863094b Core, 11 fail and six controls pass in 44 seconds. The unchanged logical-source API reproduction now passes with the correction. All 64 new draft cases are running in session 8881 against Core fef77b3e and worker de2cc35a. No cycle fixture setup failure is expected in this run.

Formatting and worker build pass. The final formatted Core is 88a701636880adc34ff53d923167cb4c2bdce175b43ddaf424156b9bc369c019; worker is 7a00fd4a92be4582991225c042f45e6f1af5645fac293f29a13704e211e195c8. Matching worker/Core and source hashes are receiver-context-final-inputs.json. Final workspace session 44045 runs 22 tests; final corpus session 85567 runs 81 views. The earlier 3863094b 313-scenario session 34153 and corpus session 53285 remain immutable and active.

Strict review of two completed earlier OrchardCore views confirms exact JSON trees and text/Markdown stdout; each removes 41 generic-context-limit diagnostics. receiver-context-diagnostic-only-review.json records the exact hashes and removed locations. No output is promoted. Autofac review is ongoing: DefaultRegisteredServicesTracker.TryGetRegistration now has two receiver contexts. Immutable source at 30842446 confirms default and ScopeRestrictedRegisteredServicesTracker runtime types, inherited TryGetRegistration, the GetInitializedServiceInfo -> PopulateServiceInfo path, and the latter's virtual AddRegistration call. The scoped class overrides AddRegistration. Exact projected context identities and the remaining source-view changes still need review before acceptance.
'''
progress.write_text(text, encoding='utf-8', newline='\n')
goal = root / 'GOAL.md'
text = goal.read_text(encoding='utf-8')
text += '\n2026-09-25 08:50 PDT: The previous goal turn made concrete progress through receiver regressions and validation. The file-local physical-path defect now has an isolated fix with logical type identities for invocation comparison and an updated worker. Seventeen new checks produce 11 failures and six controls on the prior Core; all 64 draft cases are running against the correction. Formatting and worker build pass. Final Core 88a70163 and worker 7a00fd4a are frozen with matching hashes in artifacts/receiver-context-final-inputs.json. Final 22-workspace and 81-corpus runs are active; earlier full 313/corpus runs remain immutable. Two Orchard views have exact trees/stdout and only 41 removed limit diagnostics each. Autofac context review remains incomplete. No receiver production source or snapshot has been promoted; tracked master remains clean at 7cfb72b.\n'
goal.write_text(text, encoding='utf-8', newline='\n')
print(json.dumps({key: report[key] for key in ['coreSha256', 'workerSha256']}))
