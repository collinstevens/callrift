from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
source = root / 'static-initialization-callback-corpus'
target = root / 'static-interceptor-identity-corpus'
assert not target.exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
index_path = root / 'static-reviewed-views-index.json'
index = json.loads(index_path.read_text(encoding='utf-8'))
assert index['reviewedCount'] == index['repeatPassedCount'] == 49
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
for view in index['views']:
    assert digest(Path(view['review'])) == view['reviewSha256']
    assert digest(root / view['repeat']['terminalEvidence']) == view['repeat']['terminalEvidenceSha256']
    for name, expected in view['reviewedFiles'].items():
        candidates = [source / 'Snapshots' / name, source / 'Snapshots' / name.replace('.received.', '.verified.'), root / 'static-initialization-compatibility-corpus/Snapshots' / name, root / 'static-initialization-six-view-repeat/Snapshots' / name.replace('.received.', '.verified.')]
        matches = [path for path in candidates if path.exists() and digest(path) == expected]
        assert matches, name
        shutil.copy2(matches[0], target / 'Snapshots' / name.replace('.received.', '.verified.'))
(root / (target.name + '-reviews.json')).write_text(json.dumps({'index': index_path.as_posix(), 'indexSha256': digest(index_path), 'views': index['views']}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared all89 corpus checks with exactly49 reviewed view updates;13 changed OrchardCore views remain unaccepted.')
