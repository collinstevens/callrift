from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import document, flatten, rendered, manifest, schema, jsonschema

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus/Snapshots'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
specifications = {
    'autofac-multi-service-registration-msbuild-focused': {
        'case': 'autofac-multi-service-registration',
        'branches': {
            'if (_resolvePipeline is null)': ('src/Autofac/Core/Registration/ServiceRegistrationInfo.cs', 276, 276, '_resolvePipeline ??= BuildPipeline()', ['ServiceRegistrationInfo.BuildPipeline'])
        },
        'renderEdits': []
    },
    'ocelot-custom-json-merge-msbuild-roots': {
        'case': 'ocelot-custom-json-merge',
        'branches': {
            'if (globalConfiguration is null)': ('src/DependencyInjection/ConfigurationBuilderExtensions.cs', None, 513, 'globalConfiguration ??= MergedConfigJObject.OcelotJSection(nameof(FileConfiguration.GlobalConfiguration)) as JObject', ['possible initialization of ConfigurationBuilderExtensions', 'ConfigurationBuilderExtensions.OcelotJSection']),
            'if (current is null)': ('src/DependencyInjection/ConfigurationExtensions.cs', None, 148, 'current ??= OcelotRoutes(configuration)', ['ConfigurationExtensions.OcelotRoutes']),
            'if (configuration is null)': ('src/DependencyInjection/ServiceCollectionExtensions.cs', 71, 71, 'configuration ??= services.FindConfiguration(null)', ['ServiceCollectionExtensions.FindConfiguration'])
        },
        'renderEdits': [
            ('+ ConfigurationBuilderExtensions.OcelotJProperty\n+ ├─ possible initialization of ConfigurationBuilderExtensions\n+ │  └─ initialization of ConfigurationBuilderExtensions\n+ └─ ConfigurationBuilderExtensions.OcelotJSection\n', '+ ConfigurationBuilderExtensions.OcelotJProperty\n+ └─ if (globalConfiguration is null)\n+    ├─ possible initialization of ConfigurationBuilderExtensions\n+    │  └─ initialization of ConfigurationBuilderExtensions\n+    └─ ConfigurationBuilderExtensions.OcelotJSection\n'),
            ('+ ConfigurationExtensions.OcelotProperty\n+ ├─ ConfigurationExtensions.OcelotRoutes\n', '+ ConfigurationExtensions.OcelotProperty\n+ ├─ if (current is null)\n+ │  └─ ConfigurationExtensions.OcelotRoutes\n'),
            ('  ServiceCollectionExtensions.AddOcelotUsingBuilder\n~ ├─ ServiceCollectionExtensions.FindConfiguration (changes below depth limit)\n', '  ServiceCollectionExtensions.AddOcelotUsingBuilder\n  ├─ if (configuration is null)\n~ │  └─ ServiceCollectionExtensions.FindConfiguration (changes below depth limit)\n')
        ]
    }
}
records = []
for name, spec in specifications.items():
    case = manifest[spec['case']]
    repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName']
    before_path, after_path = [directory / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
    before, after = document(before_path), document(after_path)
    jsonschema.validate(after, schema)
    branches = [node for node in flatten(after['trees']) if node['label'] in spec['branches']]
    assert len(branches) == len(spec['branches'])
    blobs = {}
    for node in branches:
        path, before_line, after_line, expression, children = spec['branches'][node['label']]
        assert node['kind'] == 'branch' and node['detail'] is None and node['omission'] is None
        assert node['change'] == ('added' if before_line is None else 'unchanged')
        assert [child['label'] for child in node['children']] == children
        for side, line in [('before', before_line), ('after', after_line)]:
            if line is None:
                assert node[side] is None
                continue
            git_spec = case[side] + ':' + path
            source = subprocess.check_output(['git', '-C', repository, 'show', git_spec]).decode('utf-8-sig')
            assert source.splitlines()[line - 1].strip() == expression + ';'
            blobs[git_spec] = subprocess.check_output(['git', '-C', repository, 'rev-parse', git_spec], text=True).strip()
            location = {'path': path, 'startLine': line, 'startColumn': 9, 'endLine': line, 'endColumn': 9 + len(expression)}
            assert node[side] == {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}

    def normalized(value, unwrap=False):
        if isinstance(value, list):
            return [item for node in value for item in (normalized(node['children'], True) if unwrap and isinstance(node, dict) and node.get('label') in spec['branches'] else [normalized(node, unwrap)])]
        if isinstance(value, dict):
            return {key: normalized(item, unwrap) for key, item in value.items() if key != 'id'}
        return value

    assert normalized(before) == normalized(after, True), name
    before_text_path = directory / (name + '.verified.txt')
    after_text_path = directory / (name + '.received.txt')
    if not after_text_path.exists():
        after_text_path = before_text_path
    old_text, old_error = rendered(before_text_path)
    new_text, new_error = rendered(after_text_path)
    assert old_error == new_error
    expected_text = old_text
    for old, new in spec['renderEdits']:
        assert expected_text.count(old) == (2 if old.startswith('  ServiceCollectionExtensions.AddOcelotUsingBuilder') else 1)
        expected_text = expected_text.replace(old, new, 1)
    assert expected_text == new_text
    records.append({
        'view': name,
        'snapshotDirectory': directory.as_posix(),
        'sourceBlobs': blobs,
        'conditionalBranches': list(spec['branches']),
        'schemaV1': True,
        'allOtherPriorJsonPreservedExceptTraversalIds': True,
        'textAndMarkdownExactExpectedEdits': True,
        'review': 'Lazy pipeline construction and configuration defaults run only when their current value is null. Each added guard matches the exact immutable coalescing expression and source span. Unwrapping only the enumerated branches preserves every prior JSON field except traversal IDs, including initializer subtrees, source calls, dispatch targets, roots, diagnostics and depth omissions. Rendering is unchanged for the focused pipeline view; the three Ocelot edits place the original children under their guards and preserve existing change markers.',
        'files': {path.name: digest(path) for path in [after_path, after_text_path]},
        'baselineFiles': {path.name: digest(path) for path in [before_path, before_text_path]},
        'repeatStatus': 'pending'
    })
(root / 'static-coalesce-two-views-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed four conditional branches across two views; all other prior JSON and exact rendering preserved.')
