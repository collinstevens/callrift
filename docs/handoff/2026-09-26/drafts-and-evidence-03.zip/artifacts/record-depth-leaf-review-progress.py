from pathlib import Path
from datetime import datetime
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path.cwd()
artifacts = root / 'artifacts'
stamp = datetime.now().astimezone().isoformat(timespec='seconds')
reports = json.loads((artifacts / 'constructor-depth-leaf-output-review.json').read_text(encoding='utf-8'))
assert len(reports['reviews']) == 10
assert sum(item['removedDepthMarkers'] for item in reports['reviews']) == 145
assert sum(item['fullConstructorAndDepthViewReviewed'] for item in reports['reviews']) == 7
paths = list((artifacts / 'constructor-depth-workspace-results').glob('*.trx'))
assert len(paths) == 1
counters = ET.parse(paths[0]).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
assert counters['passed'] == counters['total'] == '22' and counters['failed'] == '0'
assert not subprocess.check_output(['git', 'status', '--short'], text=True).strip()
proof_directory = artifacts / 'constructor-depth-leaf-source-review'
proof_files = [proof_directory / 'Program.cs', proof_directory / 'Check.csproj', proof_directory / 'bin/Release/net11.0/Check.dll',
               proof_directory / 'bin/Release/net11.0/Callrift.Core.dll', artifacts / 'constructor-depth-delta-catalog.json', artifacts / 'review-depth-leaf-output-deltas.py']
proof_files += list((proof_directory / 'configs').glob('*.json')) + list(proof_directory.glob('*-compiler-report.json'))
hashes = {file.relative_to(root).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in proof_files}
(artifacts / 'constructor-depth-leaf-proof-inputs.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
message = f'''\n\n{stamp}: This continuation made review and validation progress. All 22 workspace checks passed on constructor/depth Core 528c86f4 in five minutes; session 62164 is terminal and collected. The prior 471-scenario run (77988/PID 36756), latest 491-scenario run (12554/PID 29108), and latest 89-view corpus run (96743/PID 57524) remain live, confirmed by process inspection. Their frozen inputs remain unchanged. Tracked master is clean at pushed 9ccabc3.

Independent leaf-body review covers 283 before/after occurrences across eight cases. Original syntax and compiler symbols, instance initializers, base types, and configured external visibility prove no omitted visible calls at those member boundaries. The reviewer does not invoke callrift analysis or TreeExpander. Its first conservative pass left compile-time nameof expressions, generated-resource argument binding, and Polly's generated namespace import unproven. Follow-up excludes compiler-bound INameOfOperation, proves restored object creations target metadata types, and reads Polly's unconditional namespace imports from the pinned Directory.Build.targets. The source blob for those imports is recorded. Source-only compilation keeps its original imports. Unmodeled accessors/operators/static initialization remain part of the separate unfinished semantic audit; this proof concerns the currently declared call-graph visibility.

Strict output comparison verifies 145 removed depth markers across ten views. Every other JSON field and rendered line is unchanged relative to the preceding constructor candidate. Two added Autofac benchmark members retain their added status while losing misleading 'changes below depth limit' details. Twenty Program.Check/CheckThrows nodes retain their call-site callback children exactly; the omitted member body and preserved callback subtrees are distinct. Seven views now have complete constructor-plus-depth review by combining the new proof with earlier reviewed constructor deltas or unchanged production expectations. Three still require their constructor changes to be reviewed: Autofac service-key source roots, Ocelot timeout source roots, and Orchard Elasticsearch restored focused. Evidence: constructor-depth-leaf-output-review.json, constructor-depth-leaf-source-review/*-compiler-report.json, and constructor-depth-leaf-proof-inputs.json. Nothing was promoted.

Preserve constructor-depth-delta-catalog.json because this proof refers to that captured batch. The catalog script now refuses to overwrite an existing output; pass a fresh output filename when inspecting subsequent received views. The current full corpus run is still producing results. The prior conservative reports remain available separately from the final compiler reports.

Exploratory source review also read Ocelot FileConfiguration/FileGlobalConfiguration/Error constructors and Polly ScheduledTaskExecutor.Entry at immutable pins. Their restored focused outputs add object-base calls. Complete JSON/text/location review of those three views remains pending, including FileServiceDiscoveryProvider's newly indexed implicit constructor and primary-constructor signatures. constructor-small-focused-tree-changes.jsonl is a catalogue, not acceptance evidence.

No implementation checkpoint is ready until the constructor/depth corpus changes and broad validation are complete. Next steps remain full review, latest scenario results, corpus repeat, integrated package checks, signed promotion, then record-copy work based on the depth-corrected implementation. The full goal remains active: 30/60 pairs, remaining semantic requirements, the performance matrix, and final package/three-OS CI evidence are incomplete. Previously rejected receiver CI job-detail reads remain unapproved and were not retried.
'''
for file in [root / 'GOAL.md', artifacts / 'constructor-depth-progress.md', artifacts / 'initialization-audit-progress.md']:
    with file.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(message)
print('Recorded 22 passing workspaces, 283 source-proven occurrences, 145 reviewed marker removals, and remaining gates.')
