from pathlib import Path
import json

artifacts = Path.cwd() / 'artifacts'
source = (artifacts / 'receiver-context-review-trace/Program.cs').read_text(encoding='utf-8')
source = source.replace('using Callrift.MSBuild;\n', '')
start = source.index('IAnalysisProvider provider =')
end = source.index('var repository =', start)
source = source[:start] + 'IAnalysisProvider provider = new SourceOnlyAnalysisProvider();\n' + source[end:]
(artifacts / 'dispatch-serilog-trace/Program.cs').write_text(source, encoding='utf-8', newline='\n')
for name, revision in [('before', '60935b4d7abad71cf6157b45a10f5c3c65ead527'), ('after', '6c3fbcf636b0671bbd6f5032b61a2254937d8408')]:
    config = {'revision': revision, 'cache': 'serilog', 'labels': ['LogEventPropertyValueVisitor<TState, TResult>.Visit', 'JsonValueFormatter.VisitDictionaryValue', 'JsonValueFormatter.VisitSequenceValue', 'JsonValueFormatter.VisitStructureValue']}
    (artifacts / f'dispatch-serilog-trace/{name}.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
