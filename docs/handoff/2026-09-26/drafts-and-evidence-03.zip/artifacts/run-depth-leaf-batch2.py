from pathlib import Path
import json
import subprocess

directory = Path('artifacts/constructor-depth-leaf-batch2')
reports = []
for name in json.loads((directory / 'jobs.json').read_text(encoding='utf-8')):
    with (directory / (name + '-compiler.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(directory / 'bin/Release/net11.0/Check.dll'), str(directory / 'configs' / (name + '.json')), str(directory / (name + '-compiler-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, name
    report = json.loads((directory / (name + '-compiler-report.json')).read_text(encoding='utf-8'))
    summary = {'case': name, 'total': report['total'], 'proven': report['proven']}
    reports.append(summary)
    print(json.dumps(summary), flush=True)
(directory / 'compiler-summary.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8', newline='\n')
