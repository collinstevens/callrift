from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path.cwd()
artifacts = root / 'artifacts'
snapshots = artifacts / 'constructor-exact-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))

def decode(path):
    content = path.read_text(encoding='utf-8-sig')
    payload = content.split('stdout:\n', 1)[1]
    value, length = json.JSONDecoder().raw_decode(payload)
    return value, payload[length:].removeprefix('\n').split('stderr:\n', 1)[1]

def counter(items):
    return collections.Counter(json.dumps(item, sort_keys=True) for item in items)

def diagnostic_output(items):
    lines = []
    for item in items[:8]:
        location = item.get('location')
        prefix = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(prefix + item['code'] + ': ' + item['message'])
    if len(items) > 8:
        lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

reviews = []
for received in sorted(snapshots.glob('*-json.received.txt')):
    name = received.name.removesuffix('-json.received.txt')
    case = next((case for case in sorted(manifest, key=lambda item: -len(item['id'])) if name.startswith(case['id'])), None)
    if case is None:
        continue
    original, original_error = decode(received.with_name(received.name.replace('.received.', '.verified.')))
    actual, actual_error = decode(received)
    expected = copy.deepcopy(original)
    expected['diagnostics'] = actual['diagnostics']
    if expected != actual or original['diagnostics'] == actual['diagnostics']:
        continue
    selected = None
    for directory in [artifacts / 'constructor-diagnostic-source-review', artifacts / 'constructor-remaining-diagnostic-review']:
        stem = 'orchard-role' if case['id'] == 'orchardcore-role-submission' else case['id']
        path = directory / (stem + '-report.json')
        if path.exists():
            selected = (path, path.with_name(stem + '.json'))
            break
    if selected is None:
        continue
    report = json.loads(selected[0].read_text(encoding='utf-8'))
    if report['unmatched']:
        continue
    configuration = json.loads(selected[1].read_text(encoding='utf-8'))
    added = counter(actual['diagnostics']) - counter(original['diagnostics'])
    assert not counter(original['diagnostics']) - counter(actual['diagnostics'])
    assert added == counter(configuration['diagnostics']), name
    assert original_error.strip() == diagnostic_output(original['diagnostics'])
    assert actual_error.strip() == diagnostic_output(actual['diagnostics'])
    old_text = (snapshots / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    new_text = (snapshots / (name + '.received.txt')).read_text(encoding='utf-8-sig')
    for format in ['text', 'md']:
        def section(text):
            part = text.split('format: ' + format + '\nexit: 0\nstdout:\n', 1)[1]
            output, errors = part.split('stderr:\n', 1)
            return output, errors.split('\nformat: ', 1)[0]
        old_output, old_errors = section(old_text)
        new_output, new_errors = section(new_text)
        assert old_output == new_output, (name, format)
        assert old_errors.strip() == diagnostic_output(original['diagnostics']), (name, format, 'old stderr')
        assert new_errors.strip() == diagnostic_output(actual['diagnostics']), (name, format, 'new stderr')
    reviews.append({'view': name, 'addedDiagnostics': sum(added.values()), 'sourceEvidence': str(selected[0].relative_to(root)),
                    'allOtherJsonExact': True, 'renderedStdoutExact': True, 'stderrMatchesDiagnostics': True,
                    'jsonSha256': hashlib.sha256(received.read_bytes()).hexdigest(),
                    'textSha256': hashlib.sha256((snapshots / (name + '.received.txt')).read_bytes()).hexdigest()})
    print(json.dumps(reviews[-1]))
(artifacts / 'constructor-diagnostic-only-view-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
