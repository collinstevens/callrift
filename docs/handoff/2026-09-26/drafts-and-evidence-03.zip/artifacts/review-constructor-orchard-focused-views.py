from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path('artifacts')
directory = root / 'constructor-depth-corpus/Snapshots'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
proofs = {}
for folder in ['constructor-depth-leaf-source-review', 'constructor-depth-leaf-batch2', 'constructor-depth-leaf-batch3', 'constructor-depth-leaf-batch4', 'constructor-depth-leaf-batch5']:
    for path in (root / folder).glob('*-compiler-report.json'):
        for record in json.loads(path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf

for folder in ['constructor-depth-package-leaf-review', 'constructor-depth-leaf-batch4-supplement']:
    for path in (root / folder).glob('*-report.json'):
        for record in json.loads(path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    start = text.index('{')
    document, length = json.JSONDecoder().raw_decode(text[start:])
    return document, text[:start], text[start + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def diagnostic_output(items):
    lines = []
    for item in items[:8]:
        location = item.get('location')
        start = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(start + item['code'] + ': ' + item['message'])
    if len(items) > 8:
        lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

jobs = {}
reviews = []
for view in [case + '-' + mode + '-focused' for case in ['orchardcore-elasticsearch-authorization', 'orchardcore-openid-logout', 'orchardcore-role-submission', 'orchardcore-workflow-startup'] for mode in ['source', 'msbuild']]:
    case = next(case for case in manifest if view.startswith(case['id'] + '-'))
    original, prefix, suffix = read(directory / (view + '-json.verified.txt'))
    path = directory / (view + '-json.received.txt')
    actual, new_prefix, new_suffix = read(path)
    expected = copy.deepcopy(original)
    assert prefix == new_prefix
    if '-source-' in view:
        diagnostic_directory = root / 'constructor-diagnostic-source-review'
        if not (diagnostic_directory / (case['id'] + '.json')).exists():
            diagnostic_directory = root / 'constructor-remaining-diagnostic-review'
        diagnostic_name = 'orchard-role' if case['id'] == 'orchardcore-role-submission' else case['id']
        if diagnostic_name == 'orchard-role':
            diagnostic_directory = root / 'constructor-diagnostic-source-review'
        configuration = json.loads((diagnostic_directory / (diagnostic_name + '.json')).read_text(encoding='utf-8'))
        proof = json.loads((diagnostic_directory / (diagnostic_name + '-report.json')).read_text(encoding='utf-8'))
        assert not proof['unmatched'] and proof['provenMissingBaseCount'] == proof['diagnosticCount']
        counter = lambda items: collections.Counter(json.dumps(item, sort_keys=True) for item in items)
        added = counter(configuration['diagnostics'])
        assert counter(actual['diagnostics']) == counter(original['diagnostics']) + added
        assert [item for item in actual['diagnostics'] if json.dumps(item, sort_keys=True) not in added] == original['diagnostics']
        expected['diagnostics'] = actual['diagnostics']
    else:
        assert actual['diagnostics'] == original['diagnostics']
    old_errors = diagnostic_output(original['diagnostics'])
    new_errors = diagnostic_output(actual['diagnostics'])
    assert suffix.strip() == ('stderr:\n' + old_errors).strip() and new_suffix.strip() == ('stderr:\n' + new_errors).strip()
    mode = 'source' if '-source-' in view else 'msbuild'
    settings = next(item['options'] for item in case['views'] if item['id'] == mode + '-focused')
    assert '--externals' in settings
    depth_limit = int(settings[settings.index('--depth') + 1])
    reduced = copy.deepcopy(actual)
    job = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': []})
    allowed_parents = ['new IndexInfoViewModel', 'new AdminQueryViewModel', 'new ErrorViewModel', 'new Role', 'new NotifyContext', 'new Entity', 'new ActivityEditViewModel', 'new Transition']
    initializer_inventory = {'new AdminQueryViewModel': ['TimeSpan.Zero', '[]', '[]'], 'new Role': ['[]'], 'new Entity': ['[]']}
    removed_nodes = []
    depths = {}
    def base_check(parent, side, expected_base, base_definition=None):
        value = parent[side]
        check = {'view': view, 'nodeId': parent['id'], 'side': side, 'revision': case[side], 'symbolId': value['symbolId'],
                 'signature': value['signature'], 'definition': value['definition'], 'requireSourceBase': expected_base != 'object',
                 'expectedBase': expected_base, 'expectedInitializers': initializer_inventory.get(parent['label'], [])}
        if base_definition is not None:
            check['baseDefinition'] = base_definition
        job['checks'].append(check)
    def strip(items, parent=None, depth=0):
        result = []
        for index, node in enumerate(items):
            depths[node['id']] = depth
            if node['label'] == 'new Object' and parent and parent['label'] in allowed_parents:
                assert index == 0 and depth <= depth_limit
                assert node['kind'] == 'call' and node['change'] == parent['change'] and node['detail'] is None and node['omission'] is None and not node['children']
                for side in ['before', 'after']:
                    value = node[side]
                    assert (value is None) == (parent[side] is None)
                    if not value: continue
                    identity = 'source::object..ctor()' if mode == 'source' else 'metadata:System.Runtime::object..ctor()'
                    assert value == {'symbolId': identity, 'signature': None, 'binding': 'resolved', 'dispatch': 'direct', 'targetIds': [identity], 'definition': None, 'callSites': [parent[side]['definition']], 'relation': 'call', 'candidates': [], 'origin': 'metadata'}
                    base_check(parent, side, 'object')
                removed_nodes.append(node)
                continue
            if node['label'] == 'new Entity' and parent and parent['label'] == 'new ActivityRecord':
                assert index == 0 and depth < depth_limit and len(node['children']) == 1 and node['children'][0]['label'] == 'new Object'
                assert node['kind'] == 'call' and node['change'] == parent['change'] and node['detail'] is None and node['omission'] is None
                for side in ['before', 'after']:
                    value = node[side]
                    assert (value is None) == (parent[side] is None)
                    if not value: continue
                    identity = ('source::' if mode == 'source' else 'project:src/OrchardCore/OrchardCore.Infrastructure.Abstractions/OrchardCore.Infrastructure.Abstractions.csproj@net10.0::') + 'OrchardCore.Entities.Entity..ctor()'
                    definition = {'path': 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Entities/Entity.cs', 'startLine': 5, 'startColumn': 1, 'endLine': 8, 'endColumn': 2}
                    assert value == {'symbolId': identity, 'signature': 'OrchardCore.Entities.Entity.Entity() -> void', 'binding': 'resolved', 'dispatch': 'direct', 'targetIds': [identity], 'definition': definition, 'callSites': [parent[side]['definition']], 'relation': 'call', 'candidates': [], 'origin': 'source'}
                    base_check(parent, side, 'OrchardCore.Entities.Entity', definition)
                node['children'] = strip(node['children'], node, depth + 1)
                assert not node['children']
                removed_nodes.append(node)
                continue
            node['children'] = strip(node['children'], node, depth + 1)
            result.append(node)
        return result
    reduced['trees'] = strip(reduced['trees'])
    expected_added_count = {'orchardcore-elasticsearch-authorization': 2, 'orchardcore-openid-logout': 2,
        'orchardcore-role-submission': 1 if mode == 'source' else 2, 'orchardcore-workflow-startup': 4 if mode == 'source' else 5}[case['id']]
    assert len(removed_nodes) == expected_added_count
    old_nodes = list(nodes(expected['trees']))
    new_nodes = list(nodes(reduced['trees']))
    assert len(old_nodes) == len(new_nodes)
    added_markers = 0
    removed_markers = 0
    metadata_checks = 0
    changed_labels = set()
    for old, new in zip(old_nodes, new_nodes):
        assert old['kind'] == new['kind'] and old['label'] == new['label']
        new_boundary = old['omission'] is None and new['omission'] is not None
        checked_sides = []
        for side in ['before', 'after']:
            assert (old[side] is None) == (new[side] is None)
            if old[side] is None:
                continue
            if old[side]['signature'] != new[side]['signature'] or old[side]['definition'] != new[side]['definition']:
                assert old[side]['signature'] is None or new[side]['signature'] == old[side]['signature'] + ' -> void'
                assert old[side]['definition'] is None or old[side]['definition'] == new[side]['definition']
                assert new[side]['symbolId'].endswith('..ctor()') and new[side]['definition'] is not None
                check = {'view': view, 'nodeId': new['id'], 'side': side, 'revision': case[side], 'symbolId': new[side]['symbolId'],
                         'signature': new[side]['signature'], 'definition': new[side]['definition'], 'requireSourceBase': new_boundary and new['label'] == 'new ActivityRecord'}
                job = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': []})
                job['checks'].append(check)
                old[side]['signature'] = new[side]['signature']
                old[side]['definition'] = new[side]['definition']
                metadata_checks += 1
                checked_sides.append(side)
        if old['omission'] != new['omission']:
            changed_labels.add(new['label'])
            if new_boundary:
                assert new['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and new['detail'] == 'depth limit'
                assert old['detail'] is None and not new['children']
                assert all(side in checked_sides for side in ['before', 'after'] if new[side])
                assert depths[new['id']] == depth_limit
                for side in ['before', 'after']:
                    if new[side]:
                        base_check(new, side, 'OrchardCore.Entities.Entity' if new['label'] == 'new ActivityRecord' else 'object')
                added_markers += 1
            else:
                assert old['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and old['detail'] in ['depth limit', 'changes below depth limit']
                assert new['omission'] is None and new['detail'] is None
                for side in ['before', 'after']:
                    if new[side]:
                        proof = proofs[(view, new['id'], side)]
                        assert proof['definition'] == new[side]['definition'] and proof['symbolId'] == new[side]['symbolId']
                removed_markers += 1
            old['omission'] = new['omission']
            old['detail'] = new['detail']
    mapping = {new['id']: old['id'] for old, new in zip(old_nodes, new_nodes)}
    for node in new_nodes:
        node['id'] = mapping[node['id']]
        if node['omission'] and node['omission']['referenceId']:
            node['omission']['referenceId'] = mapping[node['omission']['referenceId']]
    assert expected == reduced, view
    old_text = (directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = directory / (view + '.received.txt')
    if not text_path.exists():
        text_path = directory / (view + '.verified.txt')
    new_text = text_path.read_text(encoding='utf-8-sig')
    if old_errors != new_errors:
        assert old_text.count(old_errors) == new_text.count(new_errors) == 2
        old_text = old_text.replace(old_errors, new_errors)
    old_lines = old_text.splitlines()
    new_lines = new_text.splitlines()
    assert len(old_lines) == len(new_lines)
    for old, new in zip(old_lines, new_lines):
        if old == new:
            continue
        assert any(label in old and label in new for label in changed_labels)
        assert old.replace(' (depth limit)', '').replace(' (changes below depth limit)', '') == new.replace(' (depth limit)', '')
    reviews.append({'view': view, 'sourceProofPending': True, 'metadataChecks': metadata_checks, 'addedNodes': len(removed_nodes), 'addedDepthMarkers': added_markers,
                    'removedDepthMarkers': removed_markers, 'allOtherJsonAndRenderedOutputExact': True,
                    'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(text_path.read_bytes()).hexdigest()})
for name, configuration in jobs.items():
    (root / 'constructor-orchard-focused-source-review' / (name + '.json')).write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / 'constructor-orchard-focused-view-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reviews))
