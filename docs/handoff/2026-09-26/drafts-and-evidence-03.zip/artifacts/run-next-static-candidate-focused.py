from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/static-coalesce-initialization-cli-tests/candidate-ready/callrift.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
jobs = [
    ('aspnetcore-stream-cts-disposal-static-candidate-witness', 'aspnetcore', ['reach', '3563a8e77e0e09055a7f0f18ef9ab026dcd59ad2', '--entry', 'source::ApplicationModelWebSite.ApplicationModelController.GetActionSpecificDescription()', '--to', 'DefaultHubDispatcher<THub>.StreamAsync', '--max-paths', '1', '--depth', '18']),
    ('orchardcore-esmodule-localization-static-candidate-source-focused', 'orchardcore', ['diff', 'b304fcd78a70b792c6f63916c0ce6e6957bb1aa0', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', '--depth', '4', '--externals', '--entry', 'source::OrchardCore.Localization.DefaultLocalizationService.GetDefaultCultureAsync()', '--entry', 'source::OrchardCore.Localization.Services.LocalizationService.GetSupportedCulturesAsync()', '--entry', 'source::OrchardCore.Localization.Models.LocalizationSettings..ctor()', '--entry', 'source::OrchardCore.ContentFields.Services.ContentFieldsJSLocalizer.GetLocalizations(string)', '--entry', 'source::OrchardCore.Resources.ResourceManagementOptionsConfiguration.BuildManifest()'])
]
records = []
for name, cache, arguments in jobs:
    output = root / 'artifacts' / (name + '.json')
    error = output.with_suffix('.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), *arguments, '--format', 'json', '--color', 'never']
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / cache, stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    record = {'name': name, 'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'accepted': False}
    if code == 0:
        data = json.loads(output.read_text(encoding='utf-8'))
        record.update(roots=len(data.get('trees', [])), paths=len(data.get('paths', [])), diagnostics=len(data['diagnostics']), truncated=data['truncated'])
    records.append(record)
    (root / 'artifacts/next-static-candidate-focused-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(record), flush=True)
    if code != 0:
        print(error.read_text(encoding='utf-8'), flush=True)
