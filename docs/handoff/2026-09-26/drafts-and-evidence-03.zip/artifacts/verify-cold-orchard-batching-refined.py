from pathlib import Path
import json,os,subprocess,time,uuid
root=Path.cwd()
entry=json.loads((root/'artifacts/orchard-candidates.json').read_text(encoding='utf-8'))[0]
client=Path(os.environ['LOCALAPPDATA'])/'Callrift/inspection'/('cold-orchard-batching-refined-'+uuid.uuid4().hex)
client.mkdir(parents=True)
server=Path(os.environ['LOCALAPPDATA'])/'Callrift/real-world-cases/orchardcore'
def git(*args):return subprocess.run(['git','-C',str(client),*args],capture_output=True,check=True).stdout
for args in [('init','--initial-branch=inspection'),('remote','add','archive',server.as_uri()),('config','remote.archive.promisor','true'),('config','remote.archive.partialCloneFilter','blob:none'),('config','remote.archive.uploadpack','git -c uploadpack.allowFilter=true upload-pack'),('fetch','--depth=1','--filter=blob:none','--no-tags','archive',entry['before'],entry['after'])]:git(*args)
listing=git('ls-tree','-r','-z',entry['after'])
asset=next(item.split(b'\t',1) for item in listing.split(b'\0') if item.endswith(b'.png'))
asset_id=asset[0].split()[2].decode('ascii')
assert subprocess.run(['git','-C',str(client),'--no-lazy-fetch','cat-file','-e',asset_id],capture_output=True).returncode!=0
trace=root/'artifacts/cold-orchard-batching-refined-trace.jsonl'
env=os.environ.copy()
env['GIT_TRACE2_EVENT']=str(trace)
command=['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe',str(root/'src/Callrift.Cli/bin/Debug/net11.0/callrift.dll'),'diff',entry['before'],entry['after'],'--depth','1','--format','json']
with (root/'artifacts/cold-orchard-batching-refined.json').open('wb') as stdout,(root/'artifacts/cold-orchard-batching-refined.err').open('wb') as stderr:
 process=subprocess.Popen(command,cwd=client,env=env,stdout=stdout,stderr=stderr)
 try:code=process.wait(timeout=600)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
  process.wait()
  raise
assert code==0,code
actual=json.loads((root/'artifacts/cold-orchard-batching-refined.json').read_text(encoding='utf-8'))
expected=json.loads((root/'artifacts/orchard-4910d17-source-roots-final.json').read_text(encoding='utf-8'))
assert actual==expected
assert subprocess.run(['git','-C',str(client),'--no-lazy-fetch','cat-file','-e',asset_id],capture_output=True).returncode!=0
fetches=sum(1 for line in trace.read_text(encoding='utf-8').splitlines() if (event:=json.loads(line)).get('event')=='cmd_name' and event.get('name')=='fetch')
assert 1<=fetches<=2,fetches
report={'before':entry['before'],'after':entry['after'],'client':str(client),'sourceFileCount':entry['counts']['.cs'],'fetches':fetches,'roots':len(actual['trees']),'diagnostics':len(actual['diagnostics']),'allJsonFieldsIdentical':True,'unrelatedAssetStillMissing':asset[1].decode('utf-8'),'performanceClaim':False}
(root/'artifacts/cold-orchard-batching-refined-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report),flush=True)
