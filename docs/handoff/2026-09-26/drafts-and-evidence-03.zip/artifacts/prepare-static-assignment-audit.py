from pathlib import Path

root = Path('artifacts')
directory = root / 'static-assignment-order-audit'
assert not directory.exists()
directory.mkdir()
project = (root / 'static-trigger-scope/Check.csproj').read_text(encoding='utf-8-sig').replace('static-initialization-scope-cli/candidate-ready', 'static-initialization-compatibility-scenarios/candidate-ready')
(directory / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
source = (root / 'static-trigger-scope/Program.cs').read_text(encoding='utf-8-sig')
begin = source.index('    ("explicit-method-repeated"')
end = source.index('\n};', begin)
cases = r'''    ("event-add-factory", "static class State { static State() { Sink.Before(); } public static event System.Action Changed { add { Sink.Add(\"add\"); } remove {} } } static class Factory { public static System.Action Create() { Sink.Argument(); return () => {}; } }", "State.Changed += Factory.Create();", "argument,before,add", true),
    ("event-remove-factory", "static class State { static State() { Sink.Before(); } public static event System.Action Changed { add {} remove { Sink.Add(\"remove\"); } } } static class Factory { public static System.Action Create() { Sink.Argument(); return () => {}; } }", "State.Changed -= Factory.Create();", "argument,before,remove", true),
    ("field-compound-assignment", "static class State { public static int Value; static State() { Sink.Before(); } }", "State.Value += Sink.Argument();", "before,argument", true),
    ("property-compound-assignment", "static class State { static State() { Sink.Before(); } public static int Value { get { Sink.Add(\"get\"); return 1; } set { Sink.Add(\"set\"); } } }", "State.Value += Sink.Argument();", "before,get,argument,set", true)'''
source = source[:begin] + cases + source[end:]
(directory / 'Program.cs').write_text(source, encoding='utf-8', newline='\n')
print(directory)
