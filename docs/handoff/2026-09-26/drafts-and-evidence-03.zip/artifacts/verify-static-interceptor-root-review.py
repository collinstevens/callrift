from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-interceptor-orchard-roots-review'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
reviews_path = root / (directory.name + '-reviews.json')
assert digest(reviews_path) == inputs['reviewsSha256']
selected = json.loads(reviews_path.read_text(encoding='utf-8'))['selectedViews']
reports = list((root / (directory.name + '-results')).glob('*.trx'))
assert len(reports) == 1
tree = ET.parse(reports[0])
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == '4' and counters['passed'] == '1' and counters['failed'] == '3'
results = []
for result in tree.findall('.//{*}UnitTestResult'):
    name = result.attrib['testName']
    view = next(view for view in selected if 'id: "' + view.removesuffix('-msbuild-roots') + '"' in name)
    assert 'viewId: "msbuild-roots"' in name
    assert result.attrib['outcome'] == ('Passed' if view == 'orchardcore-openid-logout-msbuild-roots' else 'Failed')
    if result.attrib['outcome'] == 'Failed':
        assert 'VerifyException' in result.find('.//{*}Message').text
    results.append({'view': view, **result.attrib})
assert len({result['view'] for result in results}) == 4
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': reports[0].as_posix(), 'trxSha256': digest(reports[0]), 'counters': counters, 'results': results, 'received': {path.name: digest(path) for path in (directory / 'Snapshots').glob('*.received.*')}}
(root / (directory.name + '-terminal.json')).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified four restored views: unchanged OpenID passed; three differences are Verify-only. All frozen inputs remain unchanged.')
