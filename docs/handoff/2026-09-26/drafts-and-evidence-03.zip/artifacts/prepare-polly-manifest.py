import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
candidates = json.loads((root / 'polly-candidates.json').read_text())
choices = [
    ('polly-reload-monitor', 'f2a07e687b3020f6cbaaf9192f14e1f8845682e3', 'Polly.Extensions', 'AddResiliencePipelineContext<TKey>.EnableReloads', 4, 'Extract monitor-based reload setup with a null guard', ['helper-extraction', 'callback', 'project-reference']),
    ('polly-caller-cancellation', 'e984839b8324a163270f0bc686929a1066de69e0', 'Polly.Core', 'OutcomeUtilities.WithCallerCancellationToken', 4, 'Preserve the caller token through timeout and hedging cancellation', ['exception-path', 'branch-guard', 'async']),
    ('polly-telemetry-source', 'b87f20347af528b6f7c6ff1f9e6c1bc02f97856c', 'Polly.Extensions', 'new TelemetrySource', 4, 'Share versioned telemetry resources and refactor pipeline construction across projects', ['multi-project', 'primary-constructor', 'static-initialization']),
    ('polly-executor-continuations', '016dd909db880b9d8d07954ff5f4ea3cc1e11c67', 'Polly.Core', 'ScheduledTaskExecutor.ScheduleTask', 3, 'Select asynchronous continuations through a completion-source constructor overload', ['overload-change', 'async', 'method-group']),
    ('polly-secondary-action', '1a80392b1f093f40e59c515f4aeb989bea5db857', 'Polly.Extensions', 'TaskExecution<T>.InitializeAsync', 4, 'Extract secondary action setup, chain telemetry constructors, and extend build coverage tasks', ['multi-project', 'helper-extraction', 'constructor-chain', 'exception-path', 'top-level'])
]
entries = []
for identifier, after, project, entry, depth, reason, tags in choices:
    pair = next(candidate for candidate in candidates if candidate['after'] == after)
    views = []
    for mode in ['source', 'msbuild']:
        prefix = [] if mode == 'source' else ['--project', f'src/{project}/{project}.csproj', '--framework', 'net8.0']
        for view in ['roots', 'focused']:
            options = ['--depth', '1'] if view == 'roots' else ['--entry', entry, '--depth', str(depth), '--externals']
            views.append({'id': mode + '-' + view, 'routine': identifier == 'polly-reload-monitor' and view == 'focused', 'options': prefix + options})
    entries.append({'id': identifier, 'repository': 'https://github.com/App-vNext/Polly.git', 'cacheName': 'polly', 'license': 'BSD-3-Clause', 'licenseFile': 'LICENSE', 'before': pair['before'], 'after': after, 'beforeLicenseBlob': '620c5f1faddf428efafc8049e3e3aee5dbaadcea', 'afterLicenseBlob': '620c5f1faddf428efafc8049e3e3aee5dbaadcea', 'reason': reason, 'tags': tags, 'options': [], 'knownIssue': 'issues/source-only-coverage.md', 'review': 'reviews/' + identifier + '.md', 'views': views})
(root / 'polly-manifest-draft.json').write_text(json.dumps(entries, indent=2) + '\n', encoding='utf-8')
print('Wrote five provisional entries with twenty views; the real manifest is unchanged.')
