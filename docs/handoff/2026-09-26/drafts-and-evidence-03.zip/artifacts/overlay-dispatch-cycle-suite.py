from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path.cwd()
name = sys.argv[1]
assert name in ['corpus', 'scenarios', 'workspaces']
artifacts = root / 'artifacts'
log = (artifacts / f'dispatch-cycle-{name}-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
target = artifacts / f'dispatch-cycle-{name}/build/bin/Check/debug'
assert (target / ('Callrift.RealWorldCases.Tests.dll' if name == 'corpus' else 'Check.dll')).exists()
source = artifacts / 'dispatch-cycle-cli-tests/corrected-ready'
assert hashlib.sha256((source / 'Callrift.Core.dll').read_bytes()).hexdigest() == '505bc5fec6c5d90b49fdab9f358b92c1a509126cda9c064a6c4d4272bda89c8e'
shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
for file in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(source / file, target / file)
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(artifacts / f'dispatch-cycle-{name}-binary-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen ' + name + ' with corrected Core and matching worker.')
