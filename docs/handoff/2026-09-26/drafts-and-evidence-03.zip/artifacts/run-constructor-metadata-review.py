from pathlib import Path
import json
import subprocess
root = Path('artifacts/constructor-metadata-source-review')
for name in ['polly-caller-cancellation', 'polly-executor-continuations', 'polly-telemetry-source', 'autofac-held-pipeline']:
    with (root / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(root / 'bin/Release/net11.0/Check.dll'), str(root / (name + '.json')), str(root / (name + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, name
    report = json.loads((root / (name + '-report.json')).read_text(encoding='utf-8'))
    print(json.dumps({'case': name, 'verified': report['verified']}), flush=True)
