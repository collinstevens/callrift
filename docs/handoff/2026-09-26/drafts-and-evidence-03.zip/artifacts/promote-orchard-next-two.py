from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
manifest_file = root / 'real-world-cases/manifest.json'
original = manifest_file.read_bytes()
manifest = json.loads(original)
assert len(manifest) == 28
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
cases = [
    ('orchardcore-elasticsearch-authorization', 'orchardcore-elasticsearch-manifest-draft.json', 'orchardcore-elasticsearch-reviewed-corpus', 'orchardcore-elasticsearch-reviewed-results', '8m23s'),
    ('orchardcore-openid-logout', 'orchardcore-openid-logout-manifest-draft.json', 'orchardcore-openid-logout-reviewed-corpus', 'orchardcore-openid-reviewed-results', '7m30s')
]
report = []
for identifier, draft, harness_name, result_name, duration in cases:
    entry = json.loads((root / 'artifacts' / draft).read_text(encoding='utf-8'))
    assert entry['id'] == identifier and not any(item['id'] == identifier for item in manifest)
    harness = root / 'artifacts' / harness_name
    assert json.loads((harness / 'real-world-cases/manifest.json').read_text(encoding='utf-8')) == [entry]
    assert len(entry['views']) == 4 and not list((harness / 'Snapshots').glob('*.received.txt'))
    result_files = list((root / 'artifacts' / result_name).glob('*.trx'))
    assert len(result_files) == 1
    counters = ET.parse(result_files[0]).find('.//t:Counters', namespace).attrib
    assert counters['total'] == '4' and counters['passed'] == '4' and counters['failed'] == '0'
    for name, expected in [('Callrift.Core.dll', '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'), ('Callrift.MSBuild.dll', '039cf4cdca0851530b0eca7aaedfe75a4235a40101dc63169431d05a630eda7d')]:
        for prefix in ['', 'msbuild/']:
            assert hashlib.sha256((harness / 'build/bin/Check/debug' / (prefix + name)).read_bytes()).hexdigest() == expected
    snapshots = list((harness / 'Snapshots').glob(identifier + '-*.verified.txt'))
    assert len(snapshots) == 8
    for file in snapshots:
        target = root / 'tests/Callrift.RealWorldCases/Snapshots' / file.name
        assert not target.exists()
    review_file = root / 'real-world-cases' / entry['review']
    assert not review_file.exists()
    review = (root / 'artifacts' / (identifier + '-review.md')).read_text(encoding='utf-8')
    lines = review.splitlines()
    assert lines[2].startswith('Status:')
    lines[2] = f'Status: reviewed and accepted. All four source/restored automatic/focused views passed an independent replay in {duration}.'
    report.append({'id': identifier, 'entry': entry, 'reviewTarget': review_file.relative_to(root).as_posix(), 'reviewText': '\n'.join(lines) + '\n', 'resultsFile': result_files[0].relative_to(root).as_posix(), 'snapshots': [{'source': file.relative_to(root).as_posix(), 'target': 'tests/Callrift.RealWorldCases/Snapshots/' + file.name, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()} for file in snapshots]})
    manifest.append(entry)
assert len(manifest) == 30 and len({entry['id'] for entry in manifest}) == 30
for item in report:
    (root / item['reviewTarget']).write_text(item.pop('reviewText'), encoding='utf-8', newline='\n')
    for snapshot in item['snapshots']:
        content = (root / snapshot['source']).read_bytes()
        assert content.startswith(b'\xef\xbb\xbf') and b'\r' not in content
        (root / snapshot['target']).write_bytes(content)
manifest_file.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / 'artifacts/orchard-next-two-promotion.json').write_text(json.dumps({'beforeManifestSha256': hashlib.sha256(original).hexdigest(), 'afterManifestSha256': hashlib.sha256(manifest_file.read_bytes()).hexdigest(), 'cases': report}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Promoted two reviewed pairs, two reviews, and sixteen byte-identical snapshots. Manifest now contains 30 pairs.')
