import json
import os
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
root = pathlib.Path(__file__).resolve().parent.parent
cache = pathlib.Path(os.environ['LOCALAPPDATA']) / 'Callrift/real-world-cases'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text())
choices = [('autofac-any-key-cache-msbuild-roots', ['context.Resolve', 'if ((TService']), ('autofac-multi-service-registration-msbuild-focused', ['registrationAccessor(resultTypeService)', 'possibleSubstitutions .Select']), ('cleanarchitecture-validation-lambda', ['? validationResults .Where']), ('serilog-extra-arguments', ['if (definition =='])]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

for stem, prefixes in choices:
    case = next(case for case in manifest if stem.startswith(case['id']))
    file = root / 'tests/Callrift.RealWorldCases/Snapshots' / (stem + '-json.verified.txt')
    data = json.loads(file.read_text(encoding='utf-8-sig').split('stdout:\n', 1)[1].split('stderr:\n', 1)[0])
    for prefix in prefixes:
        node = next(node for node in nodes(data['trees']) if node['label'].startswith(prefix))
        detail = node['after'] or node['before']
        location = next(iter(detail['callSites']), None) or detail['definition']
        revision = case['after'] if node['after'] else case['before']
        source = subprocess.check_output(['git', '-C', str(cache / case['cacheName']), 'show', revision + ':' + location['path']]).decode('utf-8-sig').splitlines()
        start = location['startLine'] - 1
        print(case['id'], revision, location['path'], 'line', start + 1)
        print('\n'.join(source[max(0, start - 1):min(len(source), start + 9)]))
