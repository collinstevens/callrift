from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/static-coalesce-initialization-cli-tests/candidate-ready/callrift.dll'
name = 'aspnetcore-cts-restored-trial'
output = root / 'artifacts' / (name + '.json')
error = root / 'artifacts' / (name + '.stderr')
assert not output.exists()
command = ['dotnet', str(cli), 'diff', '4cab91a40393e7d0341cf43cb88930588a0b4876', '3563a8e77e0e09055a7f0f18ef9ab026dcd59ad2', '--project', 'src/SignalR/server/Core/src/Microsoft.AspNetCore.SignalR.Core.csproj', '--framework', 'net11.0', '--depth', '1', '--format', 'json']
started = time.monotonic()
with output.open('wb') as stdout, error.open('wb') as stderr:
    process = subprocess.Popen(command, cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore', stdout=stdout, stderr=stderr)
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
        process.wait()
        raise
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record = {'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'stderr': error.read_text(encoding='utf-8'), 'accepted': False}
(root / 'artifacts' / (name + '-record.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record), flush=True)
