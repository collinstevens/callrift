from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path.cwd()
target = root / 'artifacts/constructor-top-level-aspnetcore-trial'
assert not target.exists()
target.mkdir()
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
case = next(case for case in manifest if case['id'] == 'aspnetcore-js-task-handling')
cli = root / 'artifacts/top-level-constructor-cli-tests/candidate-ready/callrift.dll'
core = cli.with_name('Callrift.Core.dll')
assert hashlib.sha256(core.read_bytes()).hexdigest() == 'e94daf21a34d0ff093c0ebbec85da5c450b540ade524c8f66d2ce662a3053116'
records = []
for view in case['views']:
    assert view['id'].startswith('source-')
    for format in ['text', 'md', 'json']:
        start = time.monotonic()
        result = subprocess.run(['dotnet', str(cli), 'diff', case['before'], case['after'], '--format', format, '--color', 'never', *case['options'], *view['options']],
            cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / case['cacheName'], capture_output=True, text=True, encoding='utf-8', timeout=600)
        (target / (view['id'] + '-' + format + '.stdout')).write_text(result.stdout, encoding='utf-8', newline='\n')
        (target / (view['id'] + '-' + format + '.stderr')).write_text(result.stderr, encoding='utf-8', newline='\n')
        record = {'view': view['id'], 'format': format, 'exitCode': result.returncode, 'seconds': round(time.monotonic() - start, 2), 'stdoutSha256': hashlib.sha256(result.stdout.encode()).hexdigest()}
        records.append(record)
        print(json.dumps(record), flush=True)
        assert result.returncode == 0
(target / 'run.json').write_text(json.dumps({'coreSha256': hashlib.sha256(core.read_bytes()).hexdigest(), 'before': case['before'], 'after': case['after'], 'reviewed': False, 'runs': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
