from pathlib import Path
from datetime import datetime
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = json.loads((root / 'static-event-order-cli-inputs.json').read_text(encoding='utf-8'))
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
for version, files in inputs['versions'].items():
    for name, expected in files.items():
        assert digest(root / 'static-event-order-cli' / (version + '-ready') / name) == expected, name
proof = {}
for name, passed in [('baseline', 0), ('candidate', 4)]:
    path = next((root / ('static-event-order-' + name + '-results')).glob('*.trx'))
    tree = ET.parse(path)
    counters = tree.find('.//{*}Counters').attrib
    assert counters['total'] == counters['executed'] == '4' and int(counters['passed']) == passed
    failures = [result.find('.//{*}Message').text for result in tree.findall('.//{*}UnitTestResult') if result.attrib['outcome'] == 'Failed']
    assert all('Factory.Create' in message and 'possible initialization of State' in message for message in failures)
    proof[name] = {'path': path.as_posix(), 'sha256': digest(path), 'counters': counters}
def flatten(nodes):
    for node in nodes:
        yield node
        yield from flatten(node['children'])
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
validator = jsonschema.validators.validator_for(schema)(schema)
proof['envelopes'] = {}
for version, directory in [('baseline', 'static-assignment-order-audit'), ('candidate', 'static-assignment-order-corrected')]:
    records = [json.loads(line) for line in (root / (directory + '.log')).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(records) == 4 and all(row['runtimePassed'] and row['semanticPassed'] for row in records)
    for path in (root / directory / 'output').glob('*.json'):
        document = json.loads(path.read_text(encoding='utf-8-sig'))
        validator.validate(document)
        proof['envelopes'][path.as_posix()] = digest(path)
        if path.name.endswith('-tree.json'):
            labels = [node['label'] for node in flatten(document['trees']) if node['label'].startswith('Sink.')]
            expected = ['Sink.Argument', 'Sink.Before'] if version == 'candidate' and path.name.startswith('event-') else ['Sink.Before', 'Sink.Argument']
            assert labels == expected, (path.name, labels, expected)
    proof[version]['runtimeAudit'] = records
assert len(proof['envelopes']) == 24
proof['accessorBodyCoverageComplete'] = False
proof['core'] = inputs['versions']['candidate']['Callrift.Core.dll']
proof['worker'] = inputs['versions']['candidate']['Callrift.MSBuild.dll']
for name in ['static-initialization-event-core-format.log', 'static-initialization-event-worker-format.log', 'static-event-order-cli-format.log']:
    assert not (root / name).read_text(encoding='utf-8-sig').strip(), name
    proof[name] = digest(root / name)
(root / 'static-event-order-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
message = f'''

{datetime.now().astimezone().isoformat(timespec='seconds')}

Additional static ordering audit found event +=/-= evaluated the handler factory after type initialization in f581. Independent compiler/runtime fixtures prove argument-before-initializer for both event operations; ordinary field compound assignment remains initializer-before-argument. The prototype now handles event assignments as accessor invocations for initialization timing. Four source/restored CLI checks fail for ordering on f581 and pass on latest Core 02e29b8cfc30b8474ef9ba8305863c92ac62c9f90ec2c186952ecae4f8cc25fd plus worker 4e25f01fe8424498f73a58ce2b5dc8147d6f3c8eca34adfb868bcb1e766a4017. Frozen at static-event-order-cli/candidate-ready; inputs static-event-order-cli-inputs.json. Sources static-initialization-event-core and static-initialization-event-worker. Event candidate session 99848 and baseline 28617 are terminal per TRX/logs. Four compiled runtime/API cases preserve correct order; 24 before/after audit JSON envelopes validate against schema v1. Independently verified proof static-event-order-evidence.json. All three isolated format checks pass. Event/accessor body collection remains missing; these checks prove initialization timing only.

Broader 617/22/89 runs still use frozen f581, not 02e29. Latest event candidate needs the full static CLI checks and broad review before integration. Workspace generator and initial Ocelot/OrchardCore corpus views now have received deltas; none accepted. Initial rendered inspection shows generated regex and permission initializer reachability, but source/JSON/identity/depth/order review is still required. Do not treat received snapshots or runtime reachability booleans alone as complete correctness evidence.
'''
for name in ['GOAL.md', 'artifacts/static-initialization-progress.md', 'artifacts/initialization-audit-progress.md']:
    with Path(name).open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(message)
print('Verified four baseline failures, four candidate passes, independent event/compound runtime order, unchanged frozen inputs, and 24 schema-v1 envelopes.')
