from pathlib import Path
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
artifacts = root / 'artifacts'
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def counters(directory):
    files = list((artifacts / directory).glob('*.trx'))
    assert len(files) == 1, files
    result = ET.parse(files[0]).find('.//t:Counters', namespace)
    return {key: int(result.attrib[key]) for key in ['total', 'passed', 'failed']}
assert counters('dispatch-cycle-cli-corrected-results') == {'total': 24, 'passed': 24, 'failed': 0}
assert counters('dispatch-cycle-cli-baseline-results') == {'total': 4, 'passed': 0, 'failed': 4}
assert counters('dispatch-cardinality-final-workspaces-results') == {'total': 22, 'passed': 22, 'failed': 0}
assert counters('dispatch-cardinality-scenarios-results') == {'total': 379, 'passed': 378, 'failed': 1}
simple = json.loads((artifacts / 'dispatch-cycle-check.log').read_text(encoding='utf-8-sig'))
matrix = [json.loads(line) for line in (artifacts / 'dispatch-cycle-matrix.log').read_text(encoding='utf-8-sig').splitlines()]
boundaries = [json.loads(line) for line in (artifacts / 'dispatch-cycle-boundaries.log').read_text(encoding='utf-8-sig').splitlines()]
assert len(simple) == 6 and all(not row['failed'] and row['diagnostics'] == 0 for row in simple)
assert len(matrix) == 24 and all(not row['failed'] and row['diagnostics'] == 0 for row in matrix)
assert len(boundaries) == 8 and all(row['passed'] and row['diagnostics'] == 0 for row in boundaries)
queries = json.loads((artifacts / 'dispatch-cycle-query-compatibility/report.json').read_text(encoding='utf-8'))
assert len(queries['queries']) == 24 and all(row['identical'] for row in queries['queries']) and queries['diffFormatsReviewed']
trial = json.loads((artifacts / 'dispatch-cycle-orchard-trial.json').read_text(encoding='utf-8'))
assert len(trial) == 3 and all(row['exit'] == 0 for row in trial)
text = '''
2026-09-25 11:17 PDT: The preceding status turn was a verified wait: Git and test processes were confirmed live, with receiver and Orchard pushes pending. This continuation made concrete progress through an additional cycle defect reproduction, corrected isolated implementation, strict snapshot review, and new validation evidence.

Receiver 1abdee9 is now pushed after all 379 scenarios passed in 42m7s. Its CI 36171714134 is in progress; latest successful CI remains 36153634040 at 7cfb72b. The queued a32cfc4 Orchard push has built its clean checkpoint and is running its 379-scenario hook in session 55162. Do not rebuild normal Debug outputs while that hook uses them. The tracked tree remains clean at a32cfc4, with origin/master at 1abdee9.

Dispatch validation found and fixed a further self-cycle defect. The bd0250ef prototype linked cycles to a dispatch contract and falsely modified a preserved recursive virtual implementation. Four independent CLI regressions fail on that prototype in both modes. The latest isolated Core505bc5fe preserves single-self dispatch contracts, original call identity, normalized declaration signatures, and contextual cycle ancestors. All 24 final CLI cases pass in 1m55s; 38 API checks and four self-cycle probes pass. All 42 JSON envelopes validate against schema version 1. Core/test formatting passes. Twenty-four tree/reach comparisons remain byte-identical to receiver output across both modes, both pins, and all three formats. The latest Orchard focused JSON/text/Markdown and stderr are byte-identical to the reviewed preceding trial; the full localization candidate remains unaccepted.

The original a627d673 full379 repeat finished with 378 passes and one independently reviewed dispatch-added snapshot mismatch. Text/Markdown, JSON fields, and all nine source locations support preserving First.Save and adding only Second.Save. Two corrected expectations exist only in private harnesses. The bd0250ef workspace repeat passed all22 in4m47s; its 89-view corpus86037 and 399-scenario34311 runs remain active. Latest Core505 full89 corpus29049, full403 scenarios3585, and22 workspaces44730 are running from separately frozen sources/binaries. No dispatch production source or snapshot has been promoted. Exact source/version provenance, logs, fixture failures, and next actions are artifacts/dispatch-cardinality-progress.md and dispatch-cycle-cli-inputs.json.

Constructor/static initialization remains incomplete. Eight constructor probes check zero compiler errors and reproduce omitted implicit/base calls plus a false equivalent-constructor change. Ten operation probes establish that written constructor bodies expose implicit base invocations, but synthesized constructors and some primary constructors have no operation body. Optional/params overload binding, records, structs, generic/project identity, and static initialization need complete treatment. artifacts/initialization-audit-progress.md records the evidence and required boundaries. Corpus counts remain30pairs/sevenrepositories and20both-modepairs; another30pairs, performance matrix, remaining semantic work, packaging on the final implementation, and final three-OS CI remain mandatory.
'''
goal = root / 'GOAL.md'
current = goal.read_text(encoding='utf-8')
assert '2026-09-25 11:17 PDT:' not in current
goal.write_text(current.rstrip() + '\n' + text, encoding='utf-8', newline='\n')
progress = artifacts / 'dispatch-cardinality-progress.md'
progress.write_text(progress.read_text(encoding='utf-8') + '\n11:17 follow-up: query session75470 completed all24 byte-identical comparisons and diff-format checks. Orchard session23297 completed all three formats; strict source/output review passes, and JSON/text/Markdown/stderr are byte-identical to the preceding reviewed trial. The newest22 workspace and full403/89 runs remain pending.\n', encoding='utf-8', newline='\n')
print('Recorded exact passing results, active sessions, pushed receiver checkpoint, and remaining full-goal requirements.')
