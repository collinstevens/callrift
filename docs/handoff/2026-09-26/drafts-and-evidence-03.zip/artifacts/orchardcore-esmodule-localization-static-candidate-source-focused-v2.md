```diff
+ ContentFieldsJSLocalizer.GetLocalizations
+ ├─ string.Equals
+ ├─ if (string.Equals(group, "content-fields-options-editor", StringComparison.OrdinalIgnoreCase))
+ │  └─ new Dictionary<string, string>
+ ├─ string.Equals
+ ├─ if (string.Equals(group, "content-fields-multiselect-picker", StringComparison.OrdinalIgnoreCase))
+ │  └─ new Dictionary<string, string>
+ ├─ string.Equals
+ └─ if (string.Equals(group, "content-fields-multitextfield-picker", StringComparison.OrdinalIgnoreCa…
+    └─ new Dictionary<string, string>

  DefaultLocalizationService.GetDefaultCultureAsync
  └─ possible initialization of DefaultLocalizationService
     └─ initialization of DefaultLocalizationService
+       ├─ string.IsNullOrEmpty
        └─ Task.FromResult ×2

  JSLocalizerExtensions.GetMergedLocalizations
  ├─ …
  ├─ ArgumentNullException.ThrowIfNull
  ├─ new Dictionary<string, string>
  └─ foreach (var group in groups)
     └─ foreach (var jsLocalizer in jsLocalizers)
        └─ IJSLocalizer.GetLocalizations
+          ├─ ⇢ AdminMenuJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ ContentFieldsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ CorsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ FormsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ LocalizationJSLocalizer.GetLocalizations (changes below depth limit)
           ├─ ⇢ MediaJSLocalizer.GetLocalizations (depth limit)
+          ├─ ⇢ MenuJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ OpenIdJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ SeoJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ ShortcodesJSLocalizer.GetLocalizations (changes below depth limit)
+          └─ ⇢ TaxonomiesJSLocalizer.GetLocalizations (changes below depth limit)

  new LocalizationSettings
  ├─ new Object
  └─ possible initialization of LocalizationSettings
     └─ initialization of LocalizationSettings
+       └─ string.IsNullOrEmpty

  LocalizationService.GetSupportedCulturesAsync
  ├─ LocalizationService.InitializeLocalizationSettingsAsync
  └─ if (_localizationSettings.SupportedCultures == null || _localizationSettings.SupportedCultures.Le…
     └─ possible initialization of LocalizationService
        └─ initialization of LocalizationService
+          ├─ string.IsNullOrEmpty
           └─ CultureInfo.GetCultureInfo ×2

  ResourceManagementOptionsConfiguration.BuildManifest
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetDependencies
- │  └─ Dependencies.AddRange
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetUrl
- │  └─ ArgumentException.ThrowIfNullOrEmpty
- ├─ ResourceDefinition.SetCdn
- │  └─ ResourceDefinition.SetCdn
- │     └─ ArgumentException.ThrowIfNullOrEmpty
- ├─ ResourceDefinition.SetCdnIntegrity
- │  └─ ArgumentException.ThrowIfNullOrEmpty
- ├─ ResourceDefinition.SetVersion
- │  ├─ System.Version.TryParse
- │  └─ if (!System.Version.TryParse(version, out _))
- │     └─ new FormatException
- ├─ ResourceManifest.DefineScript
- │  └─ ResourceManifest.DefineResource
- │     ├─ new ResourceDefinition
- │     │  └─ new Object
- │     ├─ ResourceManifest.GetResources
- │     │  ├─ _resources.TryGetValue
- │     │  └─ if (!_resources.TryGetValue(resourceType, out var resources))
- │     │     └─ new Dictionary<string, IList<ResourceDefinition>>
- │     ├─ resources.TryGetValue → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.TryGetValue
- │     │  ├─ Arguments.NamedEnumerable<T>.Named.EnsureNameToIndex (depth limit)
- │     │  └─ _nameToIndex.TryGetValue
- │     ├─ if (!resources.TryGetValue(resourceName, out var value))
- │     │  └─ new List<ResourceDefinition>
- │     └─ value.Add
  ├─ ResourceDefinition.SetDependencies
- ├─ ResourceDefinition.SetUrl
- │  └─ ResourceDefinition.SetUrl ↑ as above
- ├─ ResourceDefinition.SetCdn
- │  └─ ResourceDefinition.SetCdn ↑ as above
- ├─ ResourceDefinition.SetCdnIntegrity
- │  └─ ResourceDefinition.SetCdnIntegrity ↑ as above
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetDependencies ↑ as above
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ResourceDefinition.SetDependencies ↑ as above
- ├─ ResourceDefinition.SetUrl ↑ as above
  ├─ ResourceDefinition.SetCdn
  ├─ ResourceDefinition.SetCdnIntegrity
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineStyle
- ├─ ResourceDefinition.SetUrl ↑ as above
- ├─ ResourceDefinition.SetCdn ↑ as above
- ├─ ResourceDefinition.SetCdnIntegrity ↑ as above
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineStyle
- │  └─ ResourceManifest.DefineResource ↑ as above
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetDependencies ↑ as above
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceManifest.DefineScript
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetCdn ↑ as above
- ├─ ResourceDefinition.SetCdnIntegrity ↑ as above
  ├─ ResourceDefinition.SetVersion
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ResourceDefinition.SetUrl ↑ as above
- ├─ ResourceDefinition.SetPosition
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ? manifest.DefineScript("monaco").SetAttribute
+ ├─ ResourceManifest.DefineStyle
+ │  └─ ResourceManifest.DefineResource
+ │     ├─ new ResourceDefinition
+ │     │  └─ new Object
+ │     ├─ ResourceManifest.GetResources
+ │     │  ├─ _resources.TryGetValue
+ │     │  └─ if (!_resources.TryGetValue(resourceType, out var resources))
+ │     │     └─ new Dictionary<string, IList<ResourceDefinition>>
+ │     ├─ resources.TryGetValue → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.TryGetValue
+ │     │  ├─ Arguments.NamedEnumerable<T>.Named.EnsureNameToIndex (depth limit)
+ │     │  └─ _nameToIndex.TryGetValue
+ │     ├─ if (!resources.TryGetValue(resourceName, out var value))
+ │     │  └─ new List<ResourceDefinition>
+ │     └─ value.Add
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetDependencies ↑ as above
  └─ ResourceDefinition.SetVersion
```
