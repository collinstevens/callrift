from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path.cwd()
artifacts = root / 'artifacts'
name = sys.argv[1] if len(sys.argv) > 1 else 'dispatch-integrated-check'
assert name in ['dispatch-integrated-check', 'dispatch-integrated-serial']
target = artifacts / name / 'build/bin/Check/release'
source = root / 'src/Callrift.Cli/bin/Release/net11.0'
assert 'Build succeeded.' in (artifacts / (name + '-build.log')).read_text(encoding='utf-8-sig')
shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(source / name, target / name)
assert (target / 'Callrift.Core.dll').read_bytes() == (target / 'msbuild/Callrift.Core.dll').read_bytes()
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(artifacts / (name + '-inputs.json')).write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Overlaid packaged integrated Release Core and matching worker for 38 targeted checks.')
