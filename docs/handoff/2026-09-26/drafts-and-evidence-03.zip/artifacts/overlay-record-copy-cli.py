from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
log = (artifacts / 'record-copy-cli-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
build = artifacts / 'record-copy-cli/build/bin/Check/debug'
baseline = artifacts / 'top-level-constructor-cli-tests/candidate-ready'
core = artifacts / 'record-copy-core/bin/Release/net11.0/Callrift.Core.dll'
record = {}
assert not (artifacts / 'record-copy-cli-inputs.json').exists()
for version in ['baseline', 'candidate']:
    target = artifacts / 'record-copy-cli' / (version + '-ready')
    if target.exists():
        assert version == 'baseline'
        assert (target / 'Check.dll').read_bytes() == (build / 'Check.dll').read_bytes()
    shutil.copytree(build, target, dirs_exist_ok=True)
    shutil.copytree(baseline / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(baseline / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    selected = baseline / 'Callrift.Core.dll' if version == 'baseline' else core
    for name in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']:
        shutil.copy2(selected, target / name)
    record[version] = {file.relative_to(target).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    assert record[version]['Callrift.Core.dll'] == record[version]['msbuild/Callrift.Core.dll']
record['sources'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in (artifacts / 'record-copy-core').rglob('*.cs') if not any(part in ['bin', 'obj'] for part in file.parts)}
record['newTestsSha256'] = hashlib.sha256((artifacts / 'RecordCopyTests.cs').read_bytes()).hexdigest()
(artifacts / 'record-copy-cli-inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({version: record[version]['Callrift.Core.dll'] for version in ['baseline', 'candidate']}))
