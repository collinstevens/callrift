from pathlib import Path
import collections
import json
import subprocess
import time

root = Path.cwd()
artifacts = root / 'artifacts'
snapshots = artifacts / 'constructor-exact-corpus/Snapshots'
existing = artifacts / 'constructor-diagnostic-source-review'
target = artifacts / 'constructor-remaining-diagnostic-review'
assert not target.exists()
target.mkdir()
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(content[content.index('{'):])[0]

cases = {}
for received in sorted(snapshots.glob('*-json.received.txt')):
    case = next((case for case in sorted(manifest, key=lambda item: -len(item['id'])) if received.name.startswith(case['id'])), None)
    if case is None or case['id'] == 'orchardcore-role-submission' or (existing / (case['id'] + '-report.json')).exists():
        continue
    original = read(received.with_name(received.name.replace('.received.', '.verified.')))
    actual = read(received)
    if original['analysis']['mode'] != 'source':
        continue
    old = collections.Counter(json.dumps(item, sort_keys=True) for item in original['diagnostics'])
    new = collections.Counter(json.dumps(item, sort_keys=True) for item in actual['diagnostics'])
    added = new - old
    assert not old - new
    if not added:
        continue
    assert all(json.loads(item)['message'].startswith('Cannot bind implicit base constructor for ') for item in added)
    if case['id'] in cases:
        assert cases[case['id']]['added'] == added
        cases[case['id']]['views'].append(received.name)
    else:
        cases[case['id']] = {'case': case, 'added': added, 'views': [received.name]}

summaries = []
for name, entry in cases.items():
    case = entry['case']
    config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'],
              'revisions': [case['before'], case['after']], 'diagnostics': [json.loads(item) for item in entry['added'].elements()], 'views': entry['views']}
    config_path = target / (name + '.json')
    output_path = target / (name + '-report.json')
    config_path.write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
    start = time.monotonic()
    with (target / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(existing / 'bin/Debug/net11.0/Check.dll'), str(config_path), str(output_path)], stdout=output, stderr=subprocess.STDOUT, timeout=540)
    assert result.returncode == 0, name
    report = json.loads(output_path.read_text(encoding='utf-8'))
    summary = {'case': name, 'seconds': round(time.monotonic() - start, 2), 'diagnosticCount': report['diagnosticCount'],
               'provenUnboundCount': report['provenUnboundCount'], 'unmatched': report['unmatched']}
    summaries.append(summary)
    print(json.dumps(summary), flush=True)
(target / 'summary.json').write_text(json.dumps(summaries, indent=2) + '\n', encoding='utf-8', newline='\n')
