from pathlib import Path
from datetime import datetime
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path.cwd()
artifacts = root / 'artifacts'
stamp = datetime.now().astimezone().isoformat(timespec='seconds')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == subprocess.check_output(['git', 'rev-parse', 'origin/master'], text=True).strip() == '9ccabc3c7bfe834cfa699b0ca7e6922f94115055'
assert not subprocess.check_output(['git', 'status', '--short'], text=True).strip()
assert 'Passed:   407' in (artifacts / 'push-dispatch-cardinality.log').read_text(encoding='utf-8-sig')

def counters(name):
    paths = list((artifacts / name).glob('*.trx'))
    assert len(paths) == 1
    return ET.parse(paths[0]).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib

assert counters('record-copy-cli-candidate-results')['passed'] == '22'
assert counters('record-copy-cli-baseline-results')['failed'] == '12'
assert counters('record-copy-cli-baseline-results')['passed'] == '8'
assert len(json.loads((artifacts / 'constructor-diagnostic-only-view-review.json').read_text(encoding='utf-8'))['reviews']) == 13
assert len(json.loads((artifacts / 'constructor-autofac-signature-review.json').read_text(encoding='utf-8'))['reviews']) == 5
supplemental = json.loads((artifacts / 'constructor-remaining-diagnostic-review/summary.json').read_text(encoding='utf-8'))
message = f'''\n\n{stamp}: Dispatch/Git checkpoint 9ccabc3 reached origin/master after all 407 scenarios passed in 47m21s. The old push session92694 is terminal and collected; normal Debug outputs are no longer occupied. HEAD and origin/master match and the tracked tree is clean. Latest CI36184288525 is running at9ccabc3; Orchard CI36177017184 is also running. The earlier failed receiver job detail read remains unapproved and was not retried.

Frozen constructor23d1 broad validation is terminal: 465 scenarios yielded440 passes and25 failures in about1hour, and89corpus views yielded17passes/72snapshot differences in58m55s. Both handles98858/50842 are collected. Scenario failures consist of16 old global root-count assertions and9 reviewed snapshots. Source fixture review permits canonical constructor signatures, implicit declaration spans, and the additional new Second default-constructor root. A private latest-e94 replay produced40passes/1JSONdifference across41scenario/query checks; the final dispatch JSON difference was independently reviewed as exactly the added constructor root, including source span84–132. Ten reviewed expectation files exist only in artifacts/constructor-reviewed-scenarios. No production snapshot was changed.

Latest full471 scenario validation is active in session77988, logconstructor-reviewed-full.log/resultsconstructor-reviewed-full-results. It uses Coree94daf21 plus matching worker039cf4cd, all64 new constructor tests, and the20 revised dispatch assertions. Inputs and frozen binary hashes areconstructor-reviewed-scenario-inputs.json; reviews areconstructor-scenario-delta-review.json. Do not edit this private source, snapshots, or binaries while the run is active.

Supplemental source analysis inspected {len(supplemental)} previously uncovered cases and {sum(item['diagnosticCount'] for item in supplemental)} added diagnostic occurrences. It proved {sum(item['provenUnboundCount'] for item in supplemental)} and isolated3falseProgramwarnings in CleanArchitecture. Nine real CLI runs on e94 remove exactly those three warnings across text, Markdown, andJSON; all other fields/stdout are exact. These are the same partialProgram defect already covered by failing-before/passing-after fixtures. Evidence: constructor-remaining-diagnostic-review andconstructor-cleanarchitecture-program-trial/review.json.

Strict full-output review now covers13diagnostic-only corpus views (constructor-diagnostic-only-view-review.json), backed by original compiler symbols and immutable source blobs; trees, all non-diagnosticJSON, and text/Markdownstdout remain exact, and stderr matches the reviewed diagnostics. Five Autofac restored automatic-root views have exactly10signaturefieldchanges and no other differences (constructor-autofac-signature-review.json). The initial extension of that check rejected an overly broad source-byte-equality assumption: older held-pipeline source lacks a null-forgiving operator in Execute. Direct immutable diff proves this is the sole cross-history difference; each pair's source and every constructor declaration agree. The report now records that distinction. These18 reviewed views are not a full72difference review. Other constructor trees, depth markers, newly discovered roots, generated members, and locations remain pending, as does a final full-corpus repeat.

Record-copy candidatec8f2e67c passes22realCLI cases in5m6s. Constructor-onlye94 baseline fails12of20valid-source cases with8controls passing in2m47s. Candidate includes20source/MSBuild cases for automatic/focused diff, tree, reach, text, Markdown, andJSON, plus2source-only duplicate-copy diagnostics cases. All9compiler-valid runtime/API fixtures also pass; both previously crashing duplicate-copy probes now return explicitunresolved-record-copydiagnostics. Core and test formatting pass. Versions and hashes are record-copy-cli-inputs.json. No record-copy source/test has been integrated; invalid-copy-access and duplicate-record compilation diagnostics, clone presentation, comprehensive locations, broad compatibility, and performance still need work.

Counts remain30reviewedpairs/sevenrepositories,20both-modepairs/fiverepositories,89fullviews. Goal remains active and incomplete:30additionalpairs, remaining semantics includingstaticinitialization/accessors/operators/events/conversions/conventions, fullperformanceevidence, finalpackages, and finalthree-OSCI remain mandatory. No complete or blocked status is claimed.
'''
for path in [root / 'GOAL.md', artifacts / 'initialization-audit-progress.md', artifacts / 'record-copy-progress.md']:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(message)
with (artifacts / 'dispatch-cardinality-progress.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write(f'\n\n{stamp}: Signed9ccabc3 is pushed after407/407scenarios passed in47m21s. HEAD/originmaster match and the tracked tree is clean. CI36184288525 is running. The required hook is complete; earlier independent403/workspace22/package38 evidence remains valid. Constructor and record-copy prototypes stay isolated; see initialization-audit-progress.md for their newer review/results.\n')
print('Recorded pushed checkpoint, terminal broad results, reviewed differences, passing record-copy checks, and active 471-case gate.')
