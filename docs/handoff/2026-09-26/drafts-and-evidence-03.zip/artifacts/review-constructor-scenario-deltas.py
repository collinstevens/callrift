from pathlib import Path
import copy
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
source = artifacts / 'constructor-exact-scenarios'
target = artifacts / 'constructor-reviewed-scenarios'
assert not target.exists()
catalog = (source / 'ScenarioCatalog.cs').read_text(encoding='utf-8')
assert 'record Order(string Sku);' in catalog
assert 'record Order(OrderRequest Request, decimal Price);' in catalog
assert 'class Flow { readonly int value = Create();' in catalog
assert 'class App {}' in catalog
assert 'class Handler { public void Handle() { Before(); } void Before() {} void After() {} }' in catalog
assert 'class Flow { public void Run() { Before(); } void Before() {} void After() {} }' in catalog
assert 'class Second : IWorker { public void Save() {} } class Flow' in catalog

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    index = text.index('{')
    value, count = json.JSONDecoder().raw_decode(text[index:])
    return value, text[:index], text[index + count:]

signatures = {
    'constructor-initializer-json': ('source::Flow..ctor()', 'Flow.Flow()', 2),
    'orders-json': ('source::Order..ctor(global::OrderRequest,decimal)', 'Order.Order(OrderRequest, decimal)', 2),
    'records-partials-json': ('source::Order..ctor(string)', 'Order.Order(string)', 2),
    'query-diff-locs': ('source::Order..ctor(global::OrderRequest,decimal)', 'Order.Order(OrderRequest, decimal)', 2),
    'query-tree': ('source::Order..ctor(global::OrderRequest,decimal)', 'Order.Order(OrderRequest, decimal)', 1)
}
definitions = {
    'source::App..ctor()': ('App.App() -> void', 'Program.cs', 3, 13, 13),
    'source::Handler..ctor()': ('Handler.Handler() -> void', 'Program.cs', 4, 86, 85),
    'source::Flow..ctor()': ('Flow.Flow() -> void', 'src/Latest/Flow.cs', 1, 80, 79)
}
reports = []
for file in sorted((source / 'Snapshots').glob('*.received.txt')):
    name = file.name.removesuffix('.received.txt')
    verified = file.with_name(name + '.verified.txt')
    if name == 'dispatch-added':
        before = verified.read_text(encoding='utf-8-sig')
        after = file.read_text(encoding='utf-8-sig')
        needle = '+    └─ ⇢ Second.Save\n'
        assert before.count(needle) == 2
        assert before.replace(needle, needle + '\n+ new Second\n') == after
        changes = 2
    else:
        original, prefix, suffix = read(verified)
        received, new_prefix, new_suffix = read(file)
        assert prefix == new_prefix and suffix == new_suffix
        expected = copy.deepcopy(original)
        changes = 0
        for node in nodes(expected['trees']):
            for side in ['before', 'after']:
                value = node.get(side)
                if not value:
                    continue
                if name in signatures:
                    symbol, signature, count = signatures[name]
                    if value['symbolId'] == symbol:
                        assert value['signature'] == signature
                        value['signature'] += ' -> void'
                        changes += 1
                else:
                    assert name in ['top-level-json', 'query-strict', 'tests-included-json']
                    symbol = value['symbolId']
                    allowed = ['source::Flow..ctor()'] if name == 'tests-included-json' else ['source::App..ctor()', 'source::Handler..ctor()']
                    if symbol in allowed:
                        assert value['signature'] is None and value['definition'] is None
                        signature, path, line, before_end, after_end = definitions[symbol]
                        value['signature'] = signature
                        value['definition'] = {'path': path, 'startLine': line, 'startColumn': 1, 'endLine': line, 'endColumn': before_end if side == 'before' else after_end}
                        changes += 1
        assert changes == (signatures[name][2] if name in signatures else 2 if name == 'tests-included-json' else 4)
        assert expected == received, name
    reports.append({'file': file.name, 'reviewedChanges': changes, 'allOtherFieldsAndFormatsExact': True, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
assert len(reports) == 9
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.txt'))
for report in reports:
    name = report['file']
    shutil.copy2(source / 'Snapshots' / name, target / 'Snapshots' / name.replace('.received.', '.verified.'))
for name in ['TopLevelConstructorTests.cs', 'ConstructorDiscoveryTests.cs']:
    shutil.copy2(artifacts / name, target / name)
shutil.copy2(artifacts / 'constructor-aware-dispatch-tests/DispatchCardinalityTests.cs', target / 'DispatchCardinalityTests.cs')
report = {'productionPromoted': False, 'sourceCatalogSha256': hashlib.sha256((source / 'ScenarioCatalog.cs').read_bytes()).hexdigest(),
          'reviews': reports, 'dispatchJsonStillNeedsReview': True, 'target': str(target.relative_to(root))}
(artifacts / 'constructor-scenario-delta-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed nine scenario snapshot differences and prepared the private 471-case harness. Dispatch JSON remains pending.')
