from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
review = json.loads((root / 'artifacts/generic-context-diagnostic-update-review.json').read_text(encoding='utf-8'))
files = [file for view in review['reviewedDiagnosticOnlyViews'] for file in view['files']]
for mode in ['source', 'msbuild']:
    report = json.loads((root / ('artifacts/generic-context-orchard-' + mode + '-instantiation-review.json')).read_text(encoding='utf-8'))
    files.append({key: report[key] for key in ['received', 'target', 'sha256']})
    if mode == 'source':
        received = report['received'].replace('-json.received.txt', '.received.txt')
        files.append({'received': received, 'target': report['target'].replace('-json.verified.txt', '.verified.txt'), 'sha256': hashlib.sha256((root / received).read_bytes()).hexdigest()})
assert len(files) == 49
for file in files:
    received = root / file['received']
    assert hashlib.sha256(received.read_bytes()).hexdigest() == file['sha256']
    target = root / 'artifacts/generic-context-reviewed-corpus/Snapshots' / Path(file['target']).name
    shutil.copyfile(received, target)
report = {'coreSha256': hashlib.sha256((root / 'artifacts/generic-context-reviewed-corpus/build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(), 'files': files, 'mainSnapshotsPromoted': False, 'pending': ['autofac-any-key-cache-source-roots']}
(root / 'artifacts/generic-context-reviewed-repeat-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'privateReviewedSnapshots': len(files), 'mainSnapshotsPromoted': False, 'coreSha256': report['coreSha256']}))
