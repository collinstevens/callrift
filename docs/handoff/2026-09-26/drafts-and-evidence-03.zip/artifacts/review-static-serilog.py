import collections
import json
import subprocess
from static_review_support import root, snapshots, manifest, document, flatten, clean, rendered, digest, schema, initializer_evidence, jsonschema

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/serilog'
report_path = root / 'static-initializer-body-source-review/serilog-report.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
assert report['checks'] == 6 and report['failed'] == 0
source_key = lambda value: json.dumps(value, sort_keys=True)
source_proven = {source_key(record['check']) for record in report['records'] if record['passed']}
depth_omission = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
expected_rendered = {
    'serilog-allocation': "  MessageTemplateParser.ParseTextToken\n+ ├─ possible initialization of MessageTemplateParser\n+ │  └─ initialization of MessageTemplateParser\n+ │     └─ new TextToken\n+ │        ├─ new MessageTemplateToken\n+ │        └─ Guard.AgainstNull\n  ├─ if (i == -1)\n  ├─ if (ch == '{')\n  │  └─ else (!(i < messageTemplate.Length && messageTemplate[i] == '{'))\n- │     ├─ if (next == startAt)\n- │     │  └─ possible initialization of MessageTemplateParser\n- │     │     └─ initialization of MessageTemplateParser\n- │     │        └─ new TextToken (depth limit)\n  │     └─ else (!(next == startAt))\n  ├─ while (i < messageTemplate.Length)\n  └─ new TextToken\n",
    'serilog-extra-arguments': '  PropertyBinder.ConstructNamedProperties\n  ├─ if (namedProperties == null)\n+ │  ├─ if (messageTemplateParameters.Length > 0)\n+ │  │  └─ SelfLog.WriteLine\n+ │  │     └─ possible initialization of SelfLog\n+ │  │        └─ initialization of SelfLog\n+ │  │           └─ new SelfLog.SelfLogFailureListener\n  │  └─ possible initialization of PropertyBinder\n  ├─ if (namedProperties.Length != messageTemplateParameters.Length)\n  ├─ for (i < matchedRun)\n  └─ …\n'}
expectations = {
    'serilog-allocation': {'src/Serilog/Parsing/MessageTemplateParser.cs': ['static readonly TextToken EmptyTextToken = new("");', 'return next == startAt ? EmptyTextToken : new(messageTemplate.Substring(startAt, i - 1 - startAt));']},
    'serilog-exception-format': {'src/Serilog/Formatting/Display/LevelOutputFormat.cs': ['static readonly string[][] _titleCaseLevelMap =', 'static readonly string[][] _lowerCaseLevelMap =', 'static readonly string[][] _upperCaseLevelMap ='], 'src/Serilog/Rendering/Padding.cs': ["static readonly char[] PaddingChars = Enumerable.Repeat(' ', 80).ToArray();", 'if (pad <= PaddingChars.Length)']},
    'serilog-extra-arguments': {'src/Serilog/Debugging/SelfLog.cs': ['public static ILoggingFailureListener FailureListener { get; } = new SelfLogFailureListener();', 'class SelfLogFailureListener : ILoggingFailureListener'], 'src/Serilog/Capturing/PropertyBinder.cs': ['static readonly EventProperty[] NoProperties = Array.Empty<EventProperty>();'], 'src/Serilog/Events/ScalarValue.cs': ['public static ScalarValue Null { get; } = new(null);'], 'src/Serilog/Events/SequenceValue.cs': ['public static SequenceValue Empty { get; } = new(Array.Empty<LogEventPropertyValue>());'], 'src/Serilog/Capturing/TrimConfiguration.cs': ['!AppContext.TryGetSwitch("Serilog.Capturing.IsStructureValueSupported", out var isEnabled) || isEnabled;']}}
records = []
for name in ['serilog-allocation', 'serilog-exception-format', 'serilog-extra-arguments']:
    case = manifest[name]
    paths = [snapshots / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
    before, after = map(document, paths)
    jsonschema.validate(after, schema)
    assert before['diagnostics'] == after['diagnostics']
    normalized = clean(after)
    if name == 'serilog-allocation':
        assert before['truncated'] is False and after['truncated'] is True
        normalized['truncated'] = False
    counts = collections.Counter()
    changed_branches = []
    for item in flatten(normalized['trees']):
        if name == 'serilog-allocation' and item['label'] == 'MessageTemplateParser.ParseTextToken':
            assert item['change'] == 'unchanged' and item['detail'] is None
            item['change'], item['detail'] = 'modified', 'body changed; visible calls unchanged'
            counts['root body marker'] += 1
        if name == 'serilog-exception-format' and item['label'] == 'Padding.Apply' and item['detail'] == 'depth limit':
            assert item['omission'] == depth_omission
            item['detail'], item['omission'] = None, None
            counts['padding depth'] += 1
        if name == 'serilog-extra-arguments' and item['label'] == 'if (namedProperties == null)':
            assert item['change'] == 'unchanged' and item['before'] is not None
            changed_branches.append((item['label'], item['before'], 'if (namedProperties == null)\n            return NoProperties;'))
            item['change'], item['before'] = 'added', None
            counts['named-properties guard'] += 1
        removable = [child for child in item['children'] if child['label'] in (['if (next == startAt)'] if name == 'serilog-allocation' else ['if (value == null)', 'if (list.Count == 0)'] if name == 'serilog-extra-arguments' else [])]
        for child in removable:
            assert child['children'] == []
            assert child['change'] == ('removed' if name == 'serilog-allocation' else 'unchanged')
            counts[child['label']] += 1
            expected = {'if (next == startAt)': 'EmptyTextToken', 'if (value == null)': 'if (value == null)\n            return ScalarValue.Null;', 'if (list.Count == 0)': 'if (list.Count == 0)'}[child['label']]
            for side in ['before', 'after']:
                value = child[side]
                if value is not None:
                    changed_branches.append((side, value, expected))
        item['children'] = [child for child in item['children'] if child not in removable]
    assert clean(before) == normalized, name
    assert counts == {'serilog-allocation': {'root body marker': 1, 'if (next == startAt)': 1}, 'serilog-exception-format': {'padding depth': 3}, 'serilog-extra-arguments': {'named-properties guard': 1, 'if (value == null)': 2, 'if (list.Count == 0)': 1}}[name]
    source_blobs = {}
    source_text = {}
    def read(side, path):
        if (side, path) not in source_text:
            source_text[(side, path)] = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            source_blobs.setdefault(path, {})[side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
        return source_text[(side, path)]
    for path, snippets in expectations[name].items():
        for side in ['before', 'after']:
            assert all(snippet in read(side, path) for snippet in snippets)
    if name == 'serilog-allocation':
        path = 'src/Serilog/Parsing/MessageTemplateParser.cs'
        assert "messageTemplate.IndexOfAny(['{', '}'], startAt)" in read('before', path)
        assert "static readonly char[] CurlyBraceChars = ['{', '}'];" in read('after', path)
        assert 'messageTemplate.IndexOfAny(CurlyBraceChars, startAt)' in read('after', path)
    for side, value, expected in changed_branches:
        side = 'before' if side == 'if (namedProperties == null)' else side
        assert value['binding'] == 'structural' and value['relation'] == 'branch' and value['origin'] == 'structural' and len(value['callSites']) == 1
        site = value['callSites'][0]
        lines = read(side, site['path']).splitlines()[site['startLine'] - 1:site['endLine']]
        lines[-1] = lines[-1][:site['endColumn'] - 1]
        lines[0] = lines[0][site['startColumn'] - 1:]
        actual = '\n'.join(lines)
        assert actual.startswith(expected), (name, expected, actual)
        if expected == 'if (list.Count == 0)':
            assert 'result = SequenceValue.Empty;' in actual
    key, proven = initializer_evidence(name)
    branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
    expected_counts = {'serilog-allocation': {'MessageTemplateParser': 2}, 'serilog-exception-format': {'LevelOutputFormat': 5, 'Padding': 3}, 'serilog-extra-arguments': {'SelfLog': 3, 'PropertyBinder': 1, 'ScalarValue': 2, 'SequenceValue': 1, 'TrimConfiguration': 1}}
    assert collections.Counter(item['label'].removeprefix('possible initialization of ') for item in branches) == expected_counts[name]
    expected_profiles = {
        'serilog-allocation': {('MessageTemplateParser', 'added', None, 1): 1, ('MessageTemplateParser', 'removed', None, 1): 1},
        'serilog-exception-format': {('LevelOutputFormat', 'unchanged', None, 0): 5, ('Padding', 'unchanged', None, 0): 3},
        'serilog-extra-arguments': {('SelfLog', 'added', None, 1): 1, ('SelfLog', 'unchanged', None, 1): 1, ('SelfLog', 'unchanged', 'depth limit', 0): 1, ('PropertyBinder', 'unchanged', None, 0): 1, ('ScalarValue', 'unchanged', 'depth limit', 0): 2, ('SequenceValue', 'unchanged', 'depth limit', 0): 1, ('TrimConfiguration', 'unchanged', None, 0): 1}}
    assert collections.Counter((item['label'].removeprefix('possible initialization of '), item['change'], item['children'][0]['detail'], len(item['children'][0]['children'])) for item in branches) == collections.Counter(expected_profiles[name])
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == branch['change']
        assert initializer['omission'] == (depth_omission if initializer['detail'] == 'depth limit' else None)
        if name == 'serilog-allocation':
            token = initializer['children'][0]
            assert token['label'] == 'new TextToken'
            assert token['omission'] == (depth_omission if initializer['change'] == 'removed' else None)
            assert [child['label'] for child in token['children']] == ([] if initializer['change'] == 'removed' else ['new MessageTemplateToken', 'Guard.AgainstNull'])
        elif initializer['children']:
            assert len(initializer['children']) == 1 and initializer['children'][0]['label'] == 'new SelfLog.SelfLogFailureListener' and initializer['children'][0]['children'] == [] and initializer['children'][0]['omission'] is None
        for side in ['before', 'after']:
            value, structural = initializer[side], branch[side]
            if value is None:
                assert structural is None and initializer['change'] in ['added', 'removed']
                continue
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
            assert key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}) in proven
        for child in flatten(initializer['children']):
            assert child['change'] == initializer['change']
            for side in ['before', 'after']:
                value = child[side]
                if value is not None:
                    assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
                    assert source_key({'revision': case[side], 'definition': value['definition'], 'signature': value['signature'], 'callSites': value['callSites']}) in source_proven
    text_paths = [snapshots / (name + '.' + suffix + '.txt') for suffix in ['verified', 'received']]
    if not text_paths[1].exists():
        text_paths[1] = text_paths[0]
    old_stdout, old_stderr = rendered(text_paths[0])
    new_stdout, new_stderr = rendered(text_paths[1])
    assert old_stderr == new_stderr
    assert new_stdout == (old_stdout if name == 'serilog-exception-format' else expected_rendered[name])
    records.append({'view': name, 'initializerBranches': len(branches), 'explainedFieldChanges': dict(counts), 'sourceBlobs': source_blobs, 'constructorHelperReportSha256': digest(report_path), 'constructorHelperReviewerSha256': digest(root / 'static-initializer-body-source-review/Program.cs'), 'schemaV1': True, 'textMarkdownParity': True, 'diagnosticsUnchanged': True, 'files': {path.name: digest(path) for path in [paths[1], text_paths[1]]}, 'repeatStatus': 'pending', 'review': 'Parser brace-array access moves possible initialization ahead of the parser branches, including its EmptyTextToken source constructor chain. Initialization previously possible only in the empty-token conditional is represented at that former position as removed. PropertyBinder now preserves the existing null guard across revisions because returning NoProperties has initializer work; new logging remains inside its added inner guard. ScalarValue.Null and SequenceValue.Empty expose existing unchanged guard branches. Formatting maps are literal arrays; padding uses hidden metadata calls. Remaining JSON fields, guards, source locations and rendered output are preserved or checked against explicit expected trees.'})
    records[-1]['truncationReview'] = 'The allocation document newly reports truncation because its removed initializer path reaches the TextToken constructor at the depth limit. Other document truncation flags are unchanged.'
(root / 'static-serilog-views-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed three Serilog views with eighteen initializer branches, source constructors, guard alignment and unchanged diagnostics.')
