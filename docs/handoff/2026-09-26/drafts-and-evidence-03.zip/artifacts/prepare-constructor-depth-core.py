from pathlib import Path
import hashlib
import json
import shutil

artifacts = Path.cwd() / 'artifacts'
source = artifacts / 'constructor-top-level-core'
target = artifacts / 'constructor-depth-core'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
inputs = {file.relative_to(target).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(artifacts / 'constructor-depth-original-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
path = target / 'Diffing/TreeExpander.cs'
content = path.read_text(encoding='utf-8')
old = 'if (depth >= options.MaxDepth)'
assert content.count(old) == 1
content = content.replace(old, 'if (depth >= options.MaxDepth && HasVisibleCalls(member.Calls))')
anchor = '    private bool ReachesChange(string key)'
assert content.count(anchor) == 1
method = '''    private bool HasVisibleCalls(IEnumerable<CallStep> calls)
    {
        foreach (var call in calls)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (call.Kind != "branch" && (call.IsSource || call.Kind == "unresolved" || options.IncludeExternals
                || resolvedGraph.Members.ContainsKey(call.Key) || resolvedGraph.Targets(call, cancellationToken).Count > 0))
                return true;
            if (HasVisibleCalls(call.Children)) return true;
        }
        return false;
    }

'''
path.write_text(content.replace(anchor, method + anchor), encoding='utf-8', newline='\n')
candidate = artifacts / 'constructor-depth-candidate'
candidate.mkdir()
(candidate / 'Check.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup>
  <ItemGroup><Compile Include="../constructor-depth-audit/Program.cs" /><ProjectReference Include="../constructor-depth-core/Callrift.Core.csproj" /></ItemGroup>
</Project>
''', encoding='utf-8', newline='\n')
print('Prepared isolated visible-call depth correction without changing the active 471-case harness.')
