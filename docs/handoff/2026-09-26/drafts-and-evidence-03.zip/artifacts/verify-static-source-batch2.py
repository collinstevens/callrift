from pathlib import Path
import hashlib
import json
import sys

root = Path('artifacts')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
proof = {}
batch = int(sys.argv[1]) if len(sys.argv) > 1 else 2
for kind in ['initializer', 'diagnostic']:
    directory = root / ('static-' + kind + '-source-batch' + str(batch) + '-review')
    inputs_path = root / (directory.name + '-inputs.json')
    inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
    for name, expected in inputs['files'].items():
        assert digest(directory / name) == expected, name
    records = []
    for name in json.loads((directory / 'jobs.json').read_text(encoding='utf-8')):
        report_path = directory / (name + '-report.json')
        report = json.loads(report_path.read_text(encoding='utf-8'))
        if kind == 'initializer':
            assert report['pending'] == 0 and all(record['passed'] for record in report['records'])
            count = report['passed']
        else:
            assert report['proven'] == report['count'] and report['unmatched'] == []
            count = report['count']
        records.append({'case': name, 'count': count, 'path': report_path.as_posix(), 'sha256': digest(report_path)})
    proof[kind] = {'inputManifestSha256': digest(inputs_path), 'cases': records, 'total': sum(record['count'] for record in records)}
(root / ('static-source-batch' + str(batch) + '-evidence.json')).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({kind: {'cases': len(value['cases']), 'checks': value['total']} for kind, value in proof.items()}))
