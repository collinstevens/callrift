from pathlib import Path
import copy
import hashlib
import json

directory = Path('artifacts/receiver-context-delegate-corpus/Snapshots')
trace_directory = Path('artifacts/receiver-context-review-trace')

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def without_id(node):
    return {key: value for key, value in node.items() if key != 'id'}

def canonical_ids(value):
    value = copy.deepcopy(value)
    names = {node['id']: 'n' + str(index) for index, node in enumerate(nodes(value['trees']))}
    def replace(part):
        if isinstance(part, dict):
            for key, child in part.items():
                if key in ['id', 'referenceId'] and isinstance(child, str):
                    part[key] = names[child]
                else:
                    replace(child)
        elif isinstance(part, list):
            for child in part:
                replace(child)
    replace(value)
    return value

reports = []
views = ['autofac-held-pipeline-msbuild-focused', 'autofac-held-pipeline-source-focused', 'ocelot-poller-reentrancy-source-roots', 'polly-caller-cancellation-source-roots', 'polly-executor-continuations-source-roots']
for name in views:
    received = directory / (name + '-json.received.txt')
    before = read(directory / (name + '-json.verified.txt'))
    after = read(received)
    original_after = copy.deepcopy(after)
    if name.startswith('autofac'):
        call = next(node for node in nodes(after['trees']) if node['label'] == 'IComponentRegistration.BuildResolvePipeline')
        assert len(call['children']) == 4
        assert all(without_id(node) == without_id(call['children'][0]) for node in call['children'][:3])
        assert call['children'][0]['label'] == '⇢ ComponentRegistration.BuildResolvePipeline'
        assert call['children'][0]['change'] == 'removed'
        assert call['children'][3]['label'] == '⇢ ComponentRegistrationLifetimeDecorator.BuildResolvePipeline'
        call['children'] = [call['children'][0], call['children'][3]]
        old = '⇢ ComponentRegistration.BuildResolvePipeline (changes below depth limit)'
        new = '⇢ ComponentRegistration.BuildResolvePipeline ×3 (changes below depth limit)'
        changes = {'ComponentRegistration.BuildResolvePipeline': 3}
    elif name.startswith('ocelot'):
        call = next(node for node in nodes(after['trees']) if node['label'] == '_subscription.Dispose')
        assert len(call['children']) == 20
        changes = {'⇢ AcceptanceSteps.Dispose': 4, '⇢ ConcurrentSteps.Dispose': 2}
        for label, count in changes.items():
            selected = [node for node in call['children'] if node['label'] == label]
            assert len(selected) == count
            assert all(without_id(node) == without_id(selected[0]) for node in selected)
            assert selected[0]['change'] == 'unchanged'
            call['children'] = [node for node in call['children'] if node['label'] != label or node is selected[0]]
        old = '     ├─ ⇢ QualityOfServiceFactory.Dispose (depth limit)\n     ├─ ⇢ AcceptanceSteps.Dispose (depth limit)'
        new = '     ├─ ⇢ AcceptanceSteps.Dispose ×2 (depth limit)'
    else:
        call = next(node for node in nodes(after['trees']) if node['label'] == 'IAsyncPolicy<TResult>.ExecuteAsync')
        assert len(call['children']) == 11
        assert all(without_id(node) == without_id(call['children'][0]) for node in call['children'])
        target = call['children'][0]
        assert target['label'] == '⇢ AsyncPolicy<TResult>.ExecuteAsync'
        assert target['change'] == 'unchanged' and target['omission']['reason'] == 'depth-limit'
        for key in ['change', 'detail', 'omission', 'children']:
            call[key] = copy.deepcopy(target[key])
        call['label'] += ' → AsyncPolicy<TResult>.ExecuteAsync'
        old = new = None
        changes = {'AsyncPolicy<TResult>.ExecuteAsync': 11}
    assert canonical_ids(before) == canonical_ids(after), name
    text_path = directory / (name + '.received.txt')
    previous_text = (directory / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    if old is None:
        assert not text_path.exists(), name
        text_evidence = 'The full harness reports no text or Markdown snapshot difference.'
    else:
        assert previous_text.count(old) == 2
        assert previous_text.replace(old, new) == text_path.read_text(encoding='utf-8-sig')
        text_evidence = {'old': old, 'new': new, 'occurrences': 2}
    reports.append({'view': name, 'roots': len(before['trees']), 'contexts': changes,
                    'jsonSha256': hashlib.sha256(received.read_bytes()).hexdigest(),
                    'remainingJsonExactAfterRepresentationNormalization': True,
                    'textAndMarkdown': text_evidence})

trace_reviews = []
for case in ['autofac-held-pipeline', 'autofac-held-pipeline-source', 'ocelot-poller-reentrancy', 'polly-caller-cancellation', 'polly-executor-continuations']:
    for side in ['before', 'after']:
        path = trace_directory / (case + '-' + side + '.jsonl')
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        members = {row['Key']: row for row in rows[1:]}
        if case.startswith('autofac'):
            candidates = [row for row in members.values() if row['Label'] == 'ComponentRegistration.BuildResolvePipeline' and ';this=' in row['Key']]
            assert len(candidates) == 3
            assert rows[0]['Diagnostics'] == (174 if case.endswith('-source') else 0)
            for candidate in candidates:
                call = next(call for call in candidate['Calls'] if call['Label'] == 'ComponentRegistration.BuildResolvePipeline')
                assert len(call['Targets']) == 1
                expected = 'ExternalComponentRegistration.BuildResolvePipeline' if 'global::Autofac.Core.Registration.ExternalComponentRegistration' in candidate['Key'].split(';this=')[1] else 'Registration.ComponentRegistration.BuildResolvePipeline'
                assert expected in call['Targets'][0]
        elif case.startswith('polly'):
            root = next(row for row in members.values() if row['Label'] == 'Helper.ExecuteAsync' and '\x1e' not in row['Key'])
            call = next(call for call in root['Calls'] if call['Label'] == 'IAsyncPolicy<TResult>.ExecuteAsync')
            assert len(call['Targets']) == 11
            assert sum(';this=' not in target for target in call['Targets']) == 1
            assert all('System.Private.CoreLib::string<>' in target for target in call['Targets'])
            candidates = [row for row in members.values() if row['Label'] == 'AsyncPolicy<TResult>.ExecuteInternalAsync' and ';this=' in row['Key'] and 'System.Private.CoreLib::string<>' in row['Key']]
            assert len(candidates) == 10
            for candidate in candidates:
                call = next(call for call in candidate['Calls'] if call['Label'] == 'AsyncPolicy<TResult>.ImplementationAsync')
                assert len(call['Targets']) == 1
                receiver = candidate['Key'].split(';this=Callrift.Source::global::')[1].split('<')[0]
                assert call['Targets'][0].startswith('source::' + receiver + '<TResult>.ImplementationAsync(')
        else:
            root = next(row for row in members.values() if row['Label'] == 'WatchKube.Dispose' and '\x1e' not in row['Key'])
            call = next(call for call in root['Calls'] if call['Label'] == '_subscription.Dispose')
            assert len(call['Targets']) == 20
            acceptance = [target for target in call['Targets'] if 'AcceptanceSteps.Dispose()' in target]
            concurrent = [target for target in call['Targets'] if 'ConcurrentSteps.Dispose()' in target]
            assert len(acceptance) == 4 and len(concurrent) == 2
            assert {target.split(';this=Callrift.Source::global::Ocelot.Testing.')[1] for target in acceptance} == {'AcceptanceSteps<>!', 'Steps.RateLimitingSteps<>!', 'Steps.TimeoutSteps<>!', 'Steps.WebSocketsSteps<>!'}
            assert {target.split(';this=Callrift.Source::global::Ocelot.Testing.Steps.')[1] for target in concurrent} == {'ConcurrentSteps<>!', 'DiscoverySteps<>!'}
            for target in acceptance:
                candidate = members[target]
                nested = next(call for call in candidate['Calls'] if call['Label'] == 'AcceptanceSteps.Dispose')
                assert len(nested['Targets']) == 1 and nested['Targets'][0].split(';this=')[1] == target.split(';this=')[1]
        trace_reviews.append({'case': case, 'side': side, **rows[0], 'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest()})
report = {'coreSha256': hashlib.sha256((trace_directory / 'build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(), 'reviewedViews': reports, 'traces': trace_reviews, 'promoted': False}
Path('artifacts/receiver-context-inherited-review.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reports), 'traces': len(trace_reviews), 'promoted': False}))
