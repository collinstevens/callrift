import collections
import json
import subprocess
from pathlib import Path
import static_review_support as support
support.snapshots = Path('artifacts/static-interceptor-orchard-roots-review/Snapshots')
from static_review_support import root, manifest, digest, flatten, prior_fields_and_diagnostics, initializer_evidence

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
permission_path = 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Security/Permissions/Permission.cs'
workflow_path = 'src/OrchardCore/OrchardCore.Workflows.Abstractions/WorkflowsPermissions.cs'
options_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/JOptions.cs'
array_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JArray.cs'
report_path = root / 'static-initializer-body-source-review/orchard-permissions-report.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
assert report['checks'] == 8 and report['failed'] == 0 and all(record['passed'] for record in report['records'])
body_key = lambda value: json.dumps({name: value[name] for name in ['revision', 'definition', 'signature', 'callSites']}, sort_keys=True)
body_records = {body_key(record['check']): record for record in report['records']}
depth = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
reviews = []
for case_id, suffixes in [('orchardcore-workflow-startup', ['msbuild-roots'])]:
    case = manifest[case_id]
    key, proven = initializer_evidence(case_id)
    blobs = {}
    for path in ([workflow_path, permission_path, options_path, array_path] if 'workflow' in case_id else [options_path]):
        versions = []
        for side in ['before', 'after']:
            revision = case[side]
            source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
            if path == workflow_path:
                expected = ['public static readonly Permission ManageWorkflows = new("ManageWorkflows", "Manage workflows", isSecurityCritical: true);', 'public static readonly Permission ExecuteWorkflows = new("ExecuteWorkflows", "Execute workflows", isSecurityCritical: true);', 'public static readonly Permission ManageWorkflowSettings = new("ManageWorkflowSettings", "Manage workflow settings", [ManageWorkflows]);']
                assert [line.strip() for line in source.splitlines() if 'static readonly' in line] == expected
            elif path == permission_path:
                assert 'public Permission(string name, string description, bool isSecurityCritical = false) : this(name)' in source
                assert 'public Permission(string name, string description, IEnumerable<Permission> impliedBy, bool isSecurityCritical = false) : this(name, description, isSecurityCritical)' in source
            elif path == array_path:
                assert 'return JsonArray.Create(JsonSerializer.SerializeToElement(obj, options ?? JOptions.Default));' in source
            else:
                assert 'DynamicJsonConverter.Instance,' in source and 'new JsonStringEnumConverter()' in source and 'Default = new JsonSerializerOptions(Base);' in source
                assert 'foreach (var converter in KnownConverters)' in source and 'Default.Converters.Add(converter);' in source
            versions.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
        assert versions[0] == versions[1], path
        blobs[path] = versions[0]
    for suffix in suffixes:
        name = case_id + '-' + suffix
        def prior(value):
            if suffix == 'msbuild-roots':
                targets = [node for node in flatten(value['trees']) if node['label'] == 'JArray.FromObject']
                assert len(targets) == 1
                assert targets[0]['detail'] is None and targets[0]['omission'] is None
                targets[0]['detail'] = 'depth limit'
                targets[0]['omission'] = depth
            return value
        before, after, review = prior_fields_and_diagnostics(name, prior_json_transform=prior)
        branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
        counts = collections.Counter(branch['label'] for branch in branches)
        expected = {'possible initialization of JOptions': 1}
        if 'workflow' in case_id:
            expected = {'possible initialization of WorkflowsPermissions': 2}
            if suffix.endswith('focused'):
                expected['possible initialization of JOptions'] = 1
        assert counts == expected, (name, counts)
        locations = []
        for branch in branches:
            assert branch['kind'] == 'branch' and branch['change'] == 'unchanged' and branch['omission'] is None and len(branch['children']) == 1
            initializer = branch['children'][0]
            assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == 'unchanged'
            expanded = branch['label'] == 'possible initialization of WorkflowsPermissions' and suffix.endswith('focused')
            assert initializer['omission'] == (None if expanded else depth)
            if expanded:
                assert len(initializer['children']) == 3
                for index, child in enumerate(initializer['children']):
                    assert child['label'] == 'new Permission' and child['change'] == 'unchanged' and child['children'] == [] and child['omission'] == depth
                    for side in ['before', 'after']:
                        value = child[side]
                        assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call'
                        assert value['targetIds'] == [value['symbolId']]
                        assert value['callSites'][0]['startLine'] == [7, 9, 11][index]
                        evidence = body_records[body_key({'revision': case[side], **value})]
                        assert evidence['passed']
            else:
                assert initializer['children'] == []
            for side in ['before', 'after']:
                value = initializer[side]
                structural = branch[side]
                assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['symbolId'] is None
                assert structural['callSites'] == value['callSites']
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
                evidence = proven[key({'revision': case[side], **value})]
                assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
                locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
        review.update(snapshotDirectory=support.snapshots.as_posix(), initializerBranches=len(branches), initializerCounts=dict(counts), immutableSourceBlobs=blobs, sourceLocations=locations, permissionBindings={'report': report_path.as_posix(), 'sha256': digest(report_path)}, reviewedPriorFieldChanges=['JArray.FromObject gains a depth omission for conditional JOptions.Default initialization.'] if suffix == 'msbuild-roots' else [], review='The original two workflow controller roots are preserved. Both permission-field reads expose the source WorkflowsPermissions initializer with depth omissions for its three Permission constructors. JArray.FromObject gains one depth marker for conditional JOptions.Default initialization. Text and Markdown remain unchanged. The generated-name fix removes all five false pager/controller roots from the prior candidate. All other prior JSON fields and diagnostics remain unchanged.')
        reviews.append(review)
provenance_paths = [root / 'static-initializer-body-source-review' / name for name in ['Program.cs', 'Check.csproj', 'orchard-permissions.json', 'orchard-permissions-report.json', 'build/bin/Check/debug/Check.dll', 'build/bin/Check/debug/Callrift.Core.dll']]
(root / 'static-orchard-workflow-restored-root-review.json').write_text(json.dumps({'views': reviews, 'independentCompilerProvenance': {path.as_posix(): digest(path) for path in provenance_paths}}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed workflow restored automatic view: two initializer branches, one depth marker, and preserved original roots; repeat pending.')
