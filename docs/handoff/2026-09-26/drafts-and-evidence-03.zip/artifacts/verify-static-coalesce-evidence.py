from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
inputs_path = root / 'static-coalesce-initialization-cli-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected
results = {}
for version in ['baseline', 'candidate']:
    directory = root / 'static-coalesce-initialization-cli-tests' / (version + '-ready')
    for name, expected in inputs['versions'][version].items():
        assert digest(directory / name) == expected
    reports = list((root / ('static-coalesce-cli-' + version + '-results')).glob('*.trx'))
    assert len(reports) == 1
    tree = ET.parse(reports[0])
    counters = tree.find('.//{*}Counters').attrib
    assert counters['total'] == counters['executed'] == '12'
    assert counters['passed'] == ('12' if version == 'candidate' else '0')
    assert counters['failed'] == ('0' if version == 'candidate' else '12')
    records = tree.findall('.//{*}UnitTestResult')
    assert len(records) == 12
    for record in records:
        assert record.attrib['outcome'] == ('Passed' if version == 'candidate' else 'Failed')
        if version == 'baseline':
            message = record.find('.//{*}Message').text
            assert 'Assert.Equal() Failure' in message or 'Assert.Single() Failure' in message
    runtime_directory = root / ('static-coalesce-initialization-' + version)
    runtime_report = runtime_directory / 'report.json'
    runtime = json.loads(runtime_report.read_text(encoding='utf-8'))
    assert len(runtime) == 6 and all(record['runtime'] == record['expectedRuntime'] and record['receiverOnce'] and record['diagnostics'] == 0 for record in runtime)
    assert all(record['passed'] == (version == 'candidate') for record in runtime)
    for path in runtime_directory.glob('*-tree.json'):
        jsonschema.validate(json.loads(path.read_text(encoding='utf-8')), schema)
    probe = root / ('static-coalesce-initialization-probe' if version == 'baseline' else 'static-coalesce-initialization-candidate-probe')
    assert digest(probe / 'bin/Debug/net11.0/Callrift.Core.dll') == inputs['versions'][version]['Callrift.Core.dll']
    results[version] = {'trx': reports[0].as_posix(), 'trxSha256': digest(reports[0]), 'counters': counters, 'runtime': {path.as_posix(): digest(path) for path in runtime_directory.glob('*.json')}, 'probe': {path.as_posix(): digest(path) for path in probe.rglob('*') if path.is_file() and path.suffix in ['.cs', '.csproj', '.dll'] and 'obj' not in path.parts}}
assert digest(root / 'static-coalesce-initialization-probe/Program.cs') == digest(root / 'static-coalesce-initialization-candidate-probe/Program.cs')
interceptor_directory = root / 'static-coalesce-interceptor-results'
interceptors = json.loads((interceptor_directory / 'report.json').read_text(encoding='utf-8'))
assert len(interceptors) == 16 and all(record['passed'] for record in interceptors)
assert digest(root / 'static-coalesce-interceptor-probe/Program.cs') == digest(root / 'static-interceptor-identity-probe/Program.cs')
assert digest(root / 'static-coalesce-interceptor-probe/bin/Debug/net11.0/Callrift.Core.dll') == inputs['versions']['candidate']['Callrift.Core.dll']
for path in interceptor_directory.glob('*-*.json'):
    jsonschema.validate(json.loads(path.read_text(encoding='utf-8')), schema)
proof = {'core': inputs['versions']['candidate']['Callrift.Core.dll'], 'worker': inputs['versions']['candidate']['Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'results': results, 'interceptorCompatibility': {path.as_posix(): digest(path) for path in interceptor_directory.glob('*.json')}}
(root / 'static-coalesce-initialization-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified six compiler/runtime/API cases and12 CLI cases fail before/pass after, with16 generated-identity compatibility cases passing. All frozen hashes and44 JSON outputs verified.')
