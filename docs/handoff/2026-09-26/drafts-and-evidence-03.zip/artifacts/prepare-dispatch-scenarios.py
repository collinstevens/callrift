from pathlib import Path
import shutil

root = Path.cwd()
source = root / 'tests/Callrift.Scenarios'
target = root / 'artifacts/dispatch-cardinality-scenarios'
assert not target.exists()
target.mkdir()
for file in source.glob('*.cs'):
    shutil.copy2(file, target / file.name)
shutil.copytree(source / 'Snapshots', target / 'Snapshots')
shutil.copy2(source / 'Callrift.Scenarios.csproj', target / 'Check.csproj')
