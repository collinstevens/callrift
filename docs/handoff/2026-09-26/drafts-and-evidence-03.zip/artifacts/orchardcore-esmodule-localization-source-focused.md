```diff
  JSLocalizerExtensions.GetMergedLocalizations
  ├─ …
  ├─ ArgumentNullException.ThrowIfNull
  ├─ new Dictionary<string, string>
  └─ foreach (var group in groups)
     └─ foreach (var jsLocalizer in jsLocalizers)
-       ├─ IJSLocalizer.GetLocalizations → MediaJSLocalizer.GetLocalizations (depth limit)
+       └─ IJSLocalizer.GetLocalizations
+          ├─ ⇢ AdminMenuJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ ContentFieldsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ CorsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ FormsJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ LocalizationJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ MediaJSLocalizer.GetLocalizations (depth limit)
+          ├─ ⇢ MenuJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ OpenIdJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ SeoJSLocalizer.GetLocalizations (changes below depth limit)
+          ├─ ⇢ ShortcodesJSLocalizer.GetLocalizations (changes below depth limit)
+          └─ ⇢ TaxonomiesJSLocalizer.GetLocalizations (changes below depth limit)

  ResourceManagementOptionsConfiguration.BuildManifest
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetDependencies
- │  └─ Dependencies.AddRange
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetUrl
- │  └─ ArgumentException.ThrowIfNullOrEmpty
- ├─ ResourceDefinition.SetCdn
- │  └─ ResourceDefinition.SetCdn (depth limit)
- ├─ ResourceDefinition.SetCdnIntegrity
- │  └─ ArgumentException.ThrowIfNullOrEmpty
- ├─ ResourceDefinition.SetVersion
- │  ├─ System.Version.TryParse
- │  └─ if (!System.Version.TryParse(version, out _))
- │     └─ new FormatException
- ├─ ResourceManifest.DefineScript
- │  └─ ResourceManifest.DefineResource (depth limit)
  ├─ ResourceDefinition.SetDependencies
- ├─ ResourceDefinition.SetUrl
- │  └─ ResourceDefinition.SetUrl (depth limit)
- ├─ ResourceDefinition.SetCdn
- │  └─ ResourceDefinition.SetCdn (depth limit)
- ├─ ResourceDefinition.SetCdnIntegrity
- │  └─ ResourceDefinition.SetCdnIntegrity (depth limit)
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetDependencies ↑ as above
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ResourceDefinition.SetDependencies ↑ as above
- ├─ ResourceDefinition.SetUrl ↑ as above
  ├─ ResourceDefinition.SetCdn
  ├─ ResourceDefinition.SetCdnIntegrity
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineStyle
- ├─ ResourceDefinition.SetUrl ↑ as above
- ├─ ResourceDefinition.SetCdn ↑ as above
- ├─ ResourceDefinition.SetCdnIntegrity ↑ as above
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineStyle
- │  └─ ResourceManifest.DefineResource (depth limit)
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceDefinition.SetVersion
  ├─ ResourceManifest.DefineScript
- ├─ ResourceDefinition.SetDependencies ↑ as above
  ├─ ResourceDefinition.SetUrl
  ├─ ResourceDefinition.SetCdn
  ├─ …
  ├─ ResourceManifest.DefineScript
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetCdn ↑ as above
- ├─ ResourceDefinition.SetCdnIntegrity ↑ as above
  ├─ ResourceDefinition.SetVersion
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ResourceDefinition.SetUrl ↑ as above
- ├─ ResourceDefinition.SetPosition
- ├─ ResourceDefinition.SetVersion ↑ as above
- ├─ ResourceManifest.DefineScript ↑ as above
- ├─ ? manifest.DefineScript("monaco").SetAttribute
+ ├─ ResourceManifest.DefineStyle
+ │  └─ ResourceManifest.DefineResource (depth limit)
  ├─ ResourceDefinition.SetUrl
- ├─ ResourceDefinition.SetDependencies ↑ as above
  └─ ResourceDefinition.SetVersion
```
