from pathlib import Path
import hashlib
import json
import shutil

artifacts = Path.cwd() / 'artifacts'
directory = artifacts / 'constructor-reviewed-scenarios'
log = (artifacts / 'constructor-reviewed-scenarios-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
ready = directory / 'candidate-ready'
assert not ready.exists()
shutil.copytree(directory / 'build/bin/Check/debug', ready)
frozen = artifacts / 'top-level-constructor-cli-tests/candidate-ready'
shutil.copytree(frozen / 'msbuild', ready / 'msbuild', dirs_exist_ok=True)
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(frozen / name, ready / name)
hashes = {file.relative_to(ready).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in ready.rglob('*') if file.is_file()}
assert hashes['Callrift.Core.dll'] == hashes['msbuild/Callrift.Core.dll'] == 'e94daf21a34d0ff093c0ebbec85da5c450b540ade524c8f66d2ce662a3053116'
inputs = {file.relative_to(directory).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for pattern in ['*.cs', 'Snapshots/*.verified.txt'] for file in directory.glob(pattern)}
(artifacts / 'constructor-reviewed-scenario-inputs.json').write_text(json.dumps({'binaries': hashes, 'sourcesAndSnapshots': inputs}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen latest constructor Core and matching packaged worker for reviewed scenario replay.')
