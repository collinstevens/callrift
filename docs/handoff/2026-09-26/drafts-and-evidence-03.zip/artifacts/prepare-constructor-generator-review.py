from pathlib import Path

root = Path.cwd() / 'artifacts/constructor-generator-review'
assert not root.exists()
project = '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net10.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><EmitCompilerGeneratedFiles>true</EmitCompilerGeneratedFiles><CompilerGeneratedFilesOutputPath>obj/generated</CompilerGeneratedFilesOutputPath></PropertyGroup></Project>\n'
for name in ['before', 'after']:
    target = root / name
    target.mkdir(parents=True)
    (target / 'App.csproj').write_text(project, encoding='utf-8', newline='\n')
    source = 'using System.Text.RegularExpressions; partial class Flow { public bool Match(string value) => Pattern().IsMatch(value); [GeneratedRegex("' + name + '")] private static partial Regex Pattern(); }\n'
    (target / 'Flow.cs').write_text(source, encoding='utf-8', newline='\n')
print('Prepared independent copies of the workspace generator fixture for emitted-source review.')
