from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/static-coalesce-initialization-cli-tests/candidate-ready/callrift.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
jobs = [
    ('orchardcore-esmodule-localization', 'orchardcore', 'b304fcd78a70b792c6f63916c0ce6e6957bb1aa0', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', 'LICENSE', '183936c000fa2cc5969ba724afc1bdc5bfae5080'),
    ('aspnetcore-stream-cts-disposal', 'aspnetcore', '4cab91a40393e7d0341cf43cb88930588a0b4876', '3563a8e77e0e09055a7f0f18ef9ab026dcd59ad2', 'LICENSE.txt', '984713a49622a96da110443c15477613bc12656b')
]
records = []
for identifier, cache, before, after, license_file, license_blob in jobs:
    repository = Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / cache
    git = lambda *arguments: subprocess.check_output(['git', '-C', str(repository), *arguments]).decode('utf-8-sig').strip()
    assert git('rev-parse', after + '^') == before
    assert git('rev-parse', before + ':' + license_file) == git('rev-parse', after + ':' + license_file) == license_blob
    output = root / 'artifacts' / (identifier + '-static-candidate-source-roots.json')
    error = output.with_suffix('.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), 'diff', before, after, '--depth', '1', '--format', 'json', '--color', 'never']
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=repository, stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    assert code == 0, error.read_text(encoding='utf-8')
    data = json.loads(output.read_text(encoding='utf-8'))
    record = {'id': identifier, 'before': before, 'after': after, 'repository': str(repository), 'licenseFile': license_file, 'licenseBlob': license_blob, 'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'output': output.relative_to(root).as_posix(), 'outputSha256': digest(output), 'stderrSha256': digest(error), 'roots': [node['label'] for node in data['trees']], 'diagnostics': len(data['diagnostics']), 'truncated': data['truncated'], 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'accepted': False}
    records.append(record)
    (root / 'artifacts/next-static-candidate-trial-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'id': identifier, 'roots': len(data['trees']), 'diagnostics': len(data['diagnostics']), 'seconds': round(record['seconds'], 1)}), flush=True)
