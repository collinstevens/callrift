from pathlib import Path
import collections
import hashlib
import json
import subprocess

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'constructor-exact-corpus/Snapshots'
case = next(case for case in json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8')) if case['id'] == 'aspnetcore-js-task-handling')
repo = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore'
paths = ['src/Servers/HttpSys/src/HttpSysOptions.cs', 'src/Servers/HttpSys/src/SourceBuildStubs.cs']
sources = {}
for revision in [case['before'], case['after']]:
    for path in paths:
        text = subprocess.check_output(['git', '-C', repo, 'show', revision + ':' + path]).decode('utf-8-sig')
        assert 'public class HttpSysOptions' in text and 'public HttpSysOptions()' in text
        assert 'namespace Microsoft.AspNetCore.Server.HttpSys' in text
        blob = subprocess.check_output(['git', '-C', repo, 'rev-parse', revision + ':' + path], text=True).strip()
        sources[(revision, path)] = (blob, text.splitlines())
for path in paths:
    assert sources[(case['before'], path)][0] == sources[(case['after'], path)][0]
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
records = []
for view in ['source-roots', 'source-focused']:
    name = case['id'] + '-' + view + '-json'
    before = read(directory / (name + '.verified.txt'))
    after = read(directory / (name + '.received.txt'))
    original = collections.Counter(json.dumps(item, sort_keys=True) for item in before['diagnostics'])
    current = collections.Counter(json.dumps(item, sort_keys=True) for item in after['diagnostics'])
    removed = [json.loads(item) for item in (original - current).elements()]
    assert len(removed) == 6
    for item in removed:
        assert item['code'] == 'unresolved-call'
        location = item['location']
        assert location['path'] in paths and location['startLine'] == location['endLine']
        for revision in [case['before'], case['after']]:
            line = sources[(revision, location['path'])][1][location['startLine'] - 1]
            token = line[location['startColumn'] - 1:location['endColumn'] - 1]
            assert token in ['new UrlPrefixCollection()', 'new AuthenticationManager()', 'new TimeoutManager()']
            assert item['message'].startswith('Cannot bind ' + token.removesuffix('()') + '; candidates: ')
    duplicates_before = [item for item in before['diagnostics'] if item['code'] == 'duplicate-member' and 'HttpSysOptions..ctor()' in item['message']]
    duplicates_after = [item for item in after['diagnostics'] if item['code'] == 'duplicate-member' and 'HttpSysOptions..ctor()' in item['message']]
    assert len(duplicates_before) == 1 and duplicates_before == duplicates_after
    records.append({'view': view, 'removedDiagnosticOccurrences': len(removed), 'omittedConstructorDiagnosticPreserved': duplicates_after[0],
        'sourceTokensCheckedAtBothPins': True, 'removed': removed})
report = {'reviewedDiagnosticRemovals': True, 'fullViewReviewed': False, 'productionPromoted': False,
    'reason': 'The real and source-build-stub constructors collide in source mode. Existing duplicate-member omission remains; field/property initialization is no longer collected for that omitted constructor.',
    'sourceBlobs': {revision + ':' + path: value[0] for (revision, path), value in sources.items()}, 'views': records}
(artifacts / 'constructor-aspnetcore-omitted-initializer-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed six removed diagnostic occurrences per ASP.NET Core view against both immutable declarations; the duplicate-constructor omission remains explicit.')
