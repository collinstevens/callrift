from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-coalesce-complete-scenarios'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
binaries = inputs['versions']['candidate']
for name, expected in binaries.items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
assert digest(root / 'static-coalesce-initialization-cli-inputs.json') == inputs['candidateInputsSha256']
assert digest(root / 'static-six-view-review.json') == inputs['snapshotReviewSha256']
reports = list((root / (directory.name + '-results')).glob('*.trx'))
assert len(reports) == 1
trx = reports[0]
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '639'
assert counters['failed'] == counters['error'] == counters['aborted'] == '0'
results = [result.attrib for result in tree.findall('.//{*}UnitTestResult')]
assert len(results) == 639 and all(result['outcome'] == 'Passed' for result in results)
assert len({result['testName'] for result in results}) == 639
assert not list(directory.rglob('*.received.*'))
proof = {'core': binaries['Callrift.Core.dll'], 'worker': binaries['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': results}
(root / (directory.name + '-terminal.json')).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified all 639 scenarios passed with unchanged frozen binaries, sources, snapshots, and review inputs.')
