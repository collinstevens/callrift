from pathlib import Path
import json

artifacts = Path('artifacts')
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
for config_path in (artifacts / 'constructor-depth-leaf-source-review/configs').glob('*.json'):
    config = json.loads(config_path.read_text(encoding='utf-8'))
    case = next(case for case in manifest if case['id'] == config_path.stem)
    for leaf in config['leaves']:
        view_id = leaf['view'].removeprefix(case['id'] + '-')
        view = next(view for view in case['views'] if view['id'] == view_id)
        leaf['includeExternals'] = '--externals' in case['options'] + view['options']
    config_path.write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
path = artifacts / 'constructor-depth-leaf-source-review/configs/polly-telemetry-source.json'
configuration = json.loads(path.read_text(encoding='utf-8'))
configuration['projectUsingFile'] = 'Directory.Build.targets'
path.write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
driver = (artifacts / 'run-depth-leaf-source-review.py').read_text(encoding='utf-8')
driver = driver.replace("name + '-report.json'", "name + '-compiler-report.json'").replace("name + '.log'", "name + '-compiler.log'").replace("'summary.json'", "'compiler-summary.json'")
(artifacts / 'run-depth-leaf-refined-review.py').write_text(driver, encoding='utf-8', newline='\n')
print('Preserved conservative reports and prepared compiler-aware nameof/project-using follow-up.')
