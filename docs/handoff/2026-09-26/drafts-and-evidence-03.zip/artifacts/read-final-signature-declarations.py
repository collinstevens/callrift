from pathlib import Path
import json,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
root=Path.cwd();records=json.loads((root/'artifacts/declaration-signatures-final-snapshot-differences.json').read_text(encoding='utf-8'))['signatures']
manifest=json.loads((root/'real-world-cases/manifest.json').read_text(encoding='utf-8'))
for record in records:
    witness=record['witness'];name=Path(witness['file']).name
    matches=[c for c in manifest if name.startswith(c['id']+'-')]
    if not matches:continue
    case=max(matches,key=lambda c:len(c['id']));location=witness['definition']
    print(record['id'],record['after'])
    if not location:print('METADATA (no source declaration)');continue
    side='before' if witness['path'].endswith('/before/signature') else 'after'
    command=['git','-C',str(Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases')/case['cacheName']),'show',case[side]+':'+location['path']]
    result=subprocess.run(command,capture_output=True)
    if result.returncode:print('GENERATED OR MISSING',location['path']);continue
    lines=result.stdout.decode('utf-8-sig').splitlines()
    start=location['startLine']-1
    print(location['path']+':'+str(start+1))
    header=[]
    for line in lines[start:start+8]:
        header.append(line.strip())
        if '{' in line or '=>' in line:break
    print('\n'.join(header))
