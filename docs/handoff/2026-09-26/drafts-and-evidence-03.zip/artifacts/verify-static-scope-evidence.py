from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def records(name):
    return [json.loads(line) for line in (root / name).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
def terminal(directory, total, passed):
    paths = list((root / directory).glob('*.trx'))
    assert len(paths) == 1, paths
    tree = ET.parse(paths[0])
    counters = tree.find('.//{*}Counters').attrib
    assert int(counters['total']) == int(counters['executed']) == total
    assert int(counters['passed']) == passed and int(counters['failed']) == total - passed
    failures = [{'name': result.attrib['testName'], 'message': result.find('.//{*}Message').text} for result in tree.findall('.//{*}UnitTestResult') if result.attrib['outcome'] == 'Failed']
    return {'path': paths[0].as_posix(), 'sha256': digest(paths[0]), 'counters': counters, 'failures': failures}
inputs = json.loads((root / 'static-initialization-scope-cli-inputs.json').read_text(encoding='utf-8'))
for version, files in inputs['versions'].items():
    for name, expected in files.items():
        assert digest(root / 'static-initialization-scope-cli' / (version + '-ready') / name) == expected, name
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
runtime = records('static-trigger-scope.log')
assert len(runtime) == 23 and all(row['runtimePassed'] and row['semanticPassed'] for row in runtime)
declarations = records('static-declaration-scope.log')
assert len(declarations) == 7
expected = {
    'extern-constructor': ([], ['unavailable-static-initializer'], 1, 0, True, False),
    'duplicate-constructor': (['CS0111'], ['duplicate-member'], 1, 0, True, False),
    'duplicate-class': (['CS0101'], ['unresolved-static-initializer'], 1, 0, True, False),
    'missing-partial': (['CS0260'], ['unresolved-static-initializer'], 1, 0, True, False),
    'valid-partial': ([], [], 1, 1, True, True),
    'invalid-static-constant': (['CS0504', 'CS0133'], [], 0, 0, False, False),
    'empty-static-constructor': ([], [], 1, 1, True, False),
}
for row in declarations:
    assert tuple(row[key] for key in ['compilerErrors', 'graphDiagnostics', 'initializerIndexed', 'initializerBodies', 'initializerReached', 'sinkReached']) == expected[row['Name']], row
partial = records('static-partial-scope.log')
assert len(partial) == 2
for row in partial:
    assert row['runtime'] == ('B1,B2,A1,A2,body,touch' if row['reverse'] else 'A1,A2,B1,B2,body,touch')
    assert row['partGroups'] == 2 and row['diagnostics'] == ['static-initializer-order']
    assert row['initializerCallPaths'] == ['A.cs', 'A.cs', 'B.cs', 'B.cs', 'Common.cs', 'Common.cs']
assert (root / 'static-partial-scope/output/forward.json').read_bytes() == (root / 'static-partial-scope/output/reverse.json').read_bytes()
scope = records('static-identity-scope.log')
assert len(scope) == 2 and all(row['passed'] and row['sinks'] == [row['side'] + 'Sink.Before'] for row in scope)
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
validator = jsonschema.validators.validator_for(schema)(schema)
envelopes = {}
for folder in ['static-trigger-scope/output', 'static-partial-scope/output', 'static-identity-scope/output']:
    for path in (root / folder).glob('*.json'):
        validator.validate(json.loads(path.read_text(encoding='utf-8-sig')))
        envelopes[path.as_posix()] = digest(path)
assert len(envelopes) == 72
declaration_cli = terminal('static-initialization-validation-cli-results', 94, 90)
assert all('git commit failed' in failure['message'] for failure in declaration_cli['failures'])
assert all(any(case in failure['name'] for case in ['extern-constructor', 'empty-static-constructor']) for failure in declaration_cli['failures'])
old_identity = terminal('static-initialization-identity-baseline-results', 6, 0)
assert sum('Assert.StartsWith()' in failure['message'] for failure in old_identity['failures']) == 2
identity = terminal('static-initialization-identity-reviewed-baseline-results', 6, 0)
assert all('exit: 2' not in failure['message'] and 'git commit' not in failure['message'] for failure in identity['failures'])
assert sum('PartialDeclarations' in failure['name'] and 'Expected: 3' in failure['message'] and 'Actual:   5' in failure['message'] for failure in identity['failures']) == 4
result = {'core': inputs['versions']['candidate']['Callrift.Core.dll'], 'worker': inputs['versions']['candidate']['Callrift.MSBuild.dll'], 'runtimeCases': runtime, 'declarations': declarations, 'partialOrder': partial, 'projectScope': scope, 'schemaV1Envelopes': envelopes, 'declarationCli': declaration_cli, 'invalidSolutionBaseline': old_identity, 'validSolutionBaseline': identity, 'generalCompilerDiagnosticsComplete': False}
(root / 'static-initialization-scope-evidence.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 23 runtime/API fixtures, seven declaration fixtures, both partial orders, two project scopes, 72 schema-v1 envelopes, and terminal CLI failure classifications.')
