from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
path = root / 'src/Callrift.Core/Git/GitRepository.cs'
original = path.read_bytes()
assert hashlib.sha256(original).hexdigest() == '027272061391ec91659d0bdd9ee494c744629494637be3b39da699c297b9c3d2'
(root / 'artifacts/GitRepository.probe-first.cs').write_bytes(original)
text = original.decode('utf-8').replace('\r\n', '\n')
old = '''        await FetchMissingBlobsAsync(entries, cancellationToken);
        using var process = Start(Root, ["cat-file", "--batch"]);'''
new = '''        var noLazyFetch = Environment.GetEnvironmentVariable("GIT_NO_LAZY_FETCH");
        var canFetch = string.IsNullOrEmpty(noLazyFetch) || noLazyFetch.ToLowerInvariant() is "0" or "false" or "no" or "off";
        List<int>? missing = canFetch && entries.All(e => e.ObjectId.Length is 40 or 64 && e.ObjectId.All(Uri.IsHexDigit)) ? [] : null;
        var available = await ReadAvailableBlobsAsync(entries, missing, cancellationToken, preserveBytes);
        if (missing is null || missing.Count == 0)
            return available;
        var required = missing.Select(i => entries[i]).ToArray();
        await FetchMissingBlobsAsync(required, cancellationToken);
        var fetched = await ReadAvailableBlobsAsync(required, null, cancellationToken, preserveBytes);
        var files = new SourceFile[entries.Count];
        var fetchedIndex = 0;
        var availableIndex = 0;
        for (var i = 0; i < files.Length; i++)
            files[i] = fetchedIndex < missing.Count && missing[fetchedIndex] == i ? fetched[fetchedIndex++] : available[availableIndex++];
        return files;
    }

    private async Task<IReadOnlyList<SourceFile>> ReadAvailableBlobsAsync(IReadOnlyList<GitEntry> entries, List<int>? missing,
        CancellationToken cancellationToken, bool preserveBytes)
    {
        using var process = Start(Root, ["cat-file", "--batch"], noLazyFetch: missing is not null);'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''            foreach (var entry in entries)
            {
                var header = await ReadLineAsync(stream, cancellationToken);
                var fields = header.Split(' ');'''
new = '''            for (var i = 0; i < entries.Count; i++)
            {
                var entry = entries[i];
                var header = await ReadLineAsync(stream, cancellationToken);
                var fields = header.Split(' ');
                if (missing is not null && fields.Length == 2 && fields[1] == "missing" && fields[0].Equals(entry.ObjectId, StringComparison.OrdinalIgnoreCase))
                {
                    missing.Add(i);
                    continue;
                }'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''        var noLazyFetch = Environment.GetEnvironmentVariable("GIT_NO_LAZY_FETCH");
        if (!string.IsNullOrEmpty(noLazyFetch) && noLazyFetch.ToLowerInvariant() is not ("0" or "false" or "no" or "off"))
            return;
        if (entries.Any(e => e.ObjectId.Length is not (40 or 64) || e.ObjectId.Any(c => !Uri.IsHexDigit(c))))
            return;
'''
assert text.count(old) == 1
text = text.replace(old, '')
text = text.replace('private static Process Start(string directory, IReadOnlyList<string> arguments)', 'private static Process Start(string directory, IReadOnlyList<string> arguments, bool noLazyFetch = false)')
text = text.replace('''        foreach (var argument in arguments)
            start.ArgumentList.Add(argument);''', '''        if (noLazyFetch)
            start.Environment["GIT_NO_LAZY_FETCH"] = "1";
        foreach (var argument in arguments)
            start.ArgumentList.Add(argument);''')
path.write_text(text, encoding='utf-8', newline='\n')
print(hashlib.sha256(path.read_bytes()).hexdigest())
