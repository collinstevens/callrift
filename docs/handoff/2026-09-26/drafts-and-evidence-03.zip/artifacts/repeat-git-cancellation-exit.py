from pathlib import Path
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path.cwd()
output = root / 'artifacts/git-cancellation-exit-repeat-results'
assert not output.exists()
output.mkdir()
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
results = []
for index in range(10):
    name = f'cancellation-{index + 1:02}.trx'
    command = ['dotnet', 'vstest', str(root / 'artifacts/git-cancellation-exit-tests/candidate-ready/Check.dll'),
        '--TestCaseFilter:FullyQualifiedName~CancelledReadDoesNotStartFetching|FullyQualifiedName~CancellationStopsAnActiveFetch',
        '--ResultsDirectory:' + str(output), '--logger:trx;LogFileName=' + name]
    run = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding='utf-8', timeout=90)
    (output / (name + '.log')).write_text(run.stdout + run.stderr, encoding='utf-8', newline='\n')
    assert run.returncode == 0, run.stdout + run.stderr
    counters = ET.parse(output / name).find('.//t:Counters', namespace)
    counts = {key: int(counters.attrib[key]) for key in ['total', 'passed', 'failed']}
    assert counts == {'total': 2, 'passed': 2, 'failed': 0}, counts
    results.append({'iteration': index + 1, **counts})
    print(json.dumps(results[-1]), flush=True)
(output / 'summary.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
