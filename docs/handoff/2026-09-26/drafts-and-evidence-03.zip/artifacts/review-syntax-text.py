import difflib
import pathlib
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')
directory = pathlib.Path(__file__).resolve().parent.parent / 'tests/Callrift.RealWorldCases/Snapshots'
seen = set()
files = 0
for file in sorted(directory.glob('*.received.txt')):
    if '-json.' in file.name:
        continue
    text = file.read_text(encoding='utf-8-sig')
    plain, markdown = text.split('\nformat: md\n', 1)
    plain = plain.split('stdout:\n', 1)[1].split('stderr:\n', 1)[0].strip()
    markdown = markdown.split('stdout:\n', 1)[1].split('stderr:\n', 1)[0].strip()
    markdown = re.sub(r'^```diff\n|\n```$', '', markdown).strip()
    assert plain == markdown, file.name
    old = file.with_name(file.name.replace('.received.', '.verified.')).read_text(encoding='utf-8-sig')
    print(file.name)
    for line in difflib.unified_diff(old.splitlines(), text.splitlines()):
        if line[:1] not in ['+', '-'] or line.startswith(('+++', '---')) or line in seen:
            continue
        seen.add(line)
        print(line)
    files += 1
print('text/Markdown comparisons:', files)
