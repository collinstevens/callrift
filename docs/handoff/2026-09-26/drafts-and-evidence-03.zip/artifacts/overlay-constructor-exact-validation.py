from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path.cwd()
name = sys.argv[1]
assert name in ['cli', 'workspaces', 'scenarios', 'corpus']
artifacts = root / 'artifacts'
log = (artifacts / f'constructor-exact-{name}-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
target = artifacts / f'constructor-exact-{name}/build/bin/Check/debug'
assert (target / ('Callrift.RealWorldCases.Tests.dll' if name == 'corpus' else 'Check.dll')).exists()
source = artifacts / 'constructor-diagnostic-cli-tests/candidate-ready'
expected = '23d1c8c6d2e86a8e65226dbdf2413a3ec519b01c9cffc1ac8f77b8914612052c'
assert hashlib.sha256((source / 'Callrift.Core.dll').read_bytes()).hexdigest() == expected
shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
for file in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(source / file, target / file)
assert hashlib.sha256((target / 'msbuild/Callrift.Core.dll').read_bytes()).hexdigest() == expected
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(artifacts / f'constructor-exact-{name}-binary-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen ' + name + ' with exact constructor Core and matching worker.')
