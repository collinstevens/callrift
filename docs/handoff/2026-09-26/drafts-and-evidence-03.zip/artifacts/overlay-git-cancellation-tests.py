from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
for name in ['core', 'tests']:
    log = (artifacts / f'git-cancellation-exit-{name}-build.log').read_text(encoding='utf-8-sig')
    assert 'Build succeeded.' in log and '0 Error(s)' in log
build = artifacts / 'git-cancellation-exit-tests/build/bin/Check/debug'
baseline = artifacts / 'dispatch-cardinality-cli-tests/baseline-ready'
candidate = artifacts / 'git-cancellation-exit-core/bin/Debug/net11.0/Callrift.Core.dll'
inputs = {}
for version in ['baseline', 'candidate']:
    target = artifacts / 'git-cancellation-exit-tests' / (version + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(baseline / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(baseline / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    core = baseline / 'Callrift.Core.dll' if version == 'baseline' else candidate
    for path in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']:
        shutil.copy2(core, target / path)
    inputs[version] = {name: hashlib.sha256((target / name).read_bytes()).hexdigest() for name in ['Check.dll', 'Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']}
inputs['source'] = hashlib.sha256((artifacts / 'git-cancellation-exit-core/Git/GitRepository.cs').read_bytes()).hexdigest()
inputs['tests'] = hashlib.sha256((artifacts / 'GitCancellationTests.cs').read_bytes()).hexdigest()
(artifacts / 'git-cancellation-exit-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({version: inputs[version]['Callrift.Core.dll'] for version in ['baseline', 'candidate']}))
