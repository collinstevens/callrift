import json
import subprocess
from pathlib import Path
import static_review_support as support
support.snapshots = Path('artifacts/static-interceptor-orchard-roots-review/Snapshots')
from static_review_support import root, manifest, flatten, prior_fields_and_diagnostics, initializer_evidence

case_id = 'orchardcore-role-submission'
case = manifest[case_id]
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
key, proven = initializer_evidence(case_id)
blobs = {}
permission_path = 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Security/Permissions/Permission.cs'
roles_path = 'src/OrchardCore/OrchardCore.Roles.Core/RolesPermissions.cs'
for path in [roles_path, permission_path]:
    ids = []
    for side in ['before', 'after']:
        revision = case[side]
        text = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
        if path == roles_path:
            lines = text.splitlines()
            assert lines[6].strip() == 'public static readonly Permission ManageRoles = new("ManageRoles", "Manage Roles", isSecurityCritical: true);'
            assert lines[7].strip() == 'public static readonly Permission ViewRoles = new("ViewRoles", "View Roles", [ManageRoles]);'
        else:
            assert 'public Permission(string name, string description, bool isSecurityCritical = false) : this(name)' in text
            assert 'public Permission(string name, string description, IEnumerable<Permission> impliedBy, bool isSecurityCritical = false) : this(name, description, isSecurityCritical)' in text
        ids.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
    assert ids[0] == ids[1]
    blobs[path] = ids[0]
reviews = []
for suffix in ['msbuild-roots']:
    name = case_id + '-' + suffix
    def rendered_expected(value):
        for method in ['Create', 'EditPost']:
            header = '~ AdminController.' + method + ' (signature changed)\n'
            assert value.count(header) == 1
            value = value.replace(header, header + '  ├─ possible initialization of RolesPermissions\n')
        for line in ['  ├─ if (ModelState.IsValid)\n', '  ├─ IRoleService.IsAdminRoleAsync → RoleService.IsAdminRoleAsync (depth limit)\n']:
            assert value.count(line) == 1
            value = value.replace(line, '')
        return value
    before, after, review = prior_fields_and_diagnostics(name, stdout_transform=rendered_expected)
    branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
    assert len(branches) == 2
    locations = []
    for branch in branches:
        assert branch['label'] == 'possible initialization of RolesPermissions' and branch['kind'] == 'branch' and branch['change'] == 'unchanged'
        assert branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == 'initialization of RolesPermissions' and initializer['change'] == 'unchanged'
        if suffix.endswith('roots'):
            assert initializer['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and initializer['children'] == []
        else:
            assert initializer['omission'] is None and len(initializer['children']) == 2
            for index, child in enumerate(initializer['children']):
                assert child['label'] == 'new Permission' and child['change'] == 'unchanged' and child['children'] == []
                assert child['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
                signature = 'OrchardCore.Security.Permissions.Permission..ctor(string,string,bool)' if index == 0 else 'OrchardCore.Security.Permissions.Permission..ctor(string,string,global::System.Collections.Generic.IEnumerable<global::OrchardCore.Security.Permissions.Permission>,bool)'
                for side in ['before', 'after']:
                    value = child[side]
                    assert value['symbolId'].endswith('::' + signature) and value['targetIds'] == [value['symbolId']]
                    assert value['callSites'] == [{'path': roles_path, 'startLine': 7 + index, 'startColumn': 53 if index == 0 else 51, 'endLine': 7 + index, 'endColumn': 113 if index == 0 else 96}]
                    assert value['definition'] == {'path': permission_path, 'startLine': 39 if index == 0 else 55, 'startColumn': 5, 'endLine': 43 if index == 0 else 58, 'endColumn': 6}
                    assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call'
        for side in ['before', 'after']:
            value = initializer[side]
            structural = branch[side]
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['symbolId'] is None
            assert structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source'
            assert value['targetIds'] == [value['symbolId']]
            check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
            evidence = proven[key(check)]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
    review.update(snapshotDirectory=support.snapshots.as_posix(), initializerBranches=2, immutableSourceBlobs=blobs, sourceLocations=locations, review='ManageRoles initializes before ViewRoles. ViewRoles refers to the already initializing type without adding a recursive initializer. The selected Permission constructor overloads chain through source constructors; depth omissions preserve those hidden calls. The two new unchanged initializer branches shift the first two rendered context siblings beneath the signature-changed roots. All other rendered lines and prior JSON fields remain unchanged. The generated-name fix removes all three false pager roots from the prior candidate.')
    reviews.append(review)
(root / 'static-orchard-role-restored-root-review.json').write_text(json.dumps({'views': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed restored role automatic view: two initializer branches, exact context shifts, and no false pager roots; repeat pending.')
