from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
build = artifacts / 'constructor-initialization-cli-tests/build/bin/Check/debug'
log = (artifacts / 'constructor-initialization-cli-tests-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
base = artifacts / 'dispatch-cycle-cli-tests/corrected-ready'
latest = artifacts / 'constructor-initialization-core/bin/Debug/net11.0/Callrift.Core.dll'
record = {}
for version in ['baseline', 'candidate']:
    target = artifacts / 'constructor-initialization-cli-tests' / (version + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(base / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(base / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    core = base / 'Callrift.Core.dll' if version == 'baseline' else latest
    shutil.copy2(core, target / 'Callrift.Core.dll')
    shutil.copy2(core, target / 'msbuild/Callrift.Core.dll')
    record[version] = {name: hashlib.sha256((target / name).read_bytes()).hexdigest() for name in ['Check.dll', 'Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']}
record['sources'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in (artifacts / 'constructor-initialization-core').rglob('*.cs') if not any(part in ['bin', 'obj'] for part in file.parts)}
record['tests'] = hashlib.sha256((artifacts / 'ConstructorInitializationTests.cs').read_bytes()).hexdigest()
(artifacts / 'constructor-initialization-cli-inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({version: record[version]['Callrift.Core.dll'] for version in ['baseline', 'candidate']}))
