from pathlib import Path
import hashlib,json,subprocess

root=Path(__file__).resolve().parents[1]
target=root/'benchmarks/baselines'
records=[]
for filename,prefix in [('git-batch-controlled-runs.json','initial'),('git-batch-refined-controlled-runs.json','refined')]:
    source=json.loads((root/'artifacts'/filename).read_text(encoding='utf-8'))
    assert len(source['runs'])==(4 if prefix=='initial' else 3)
    for run in source['runs']:
        export=Path(run['export'])
        document=json.loads(export.read_text(encoding='utf-8-sig'))
        for benchmark in document['Benchmarks']:
            assert benchmark['Statistics']['N']>=10
        name=f"git-batching-windows-{prefix}-{run['version']}-{run['stage']}.json"
        (target/name).write_text(json.dumps(document,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
        records.append({**run,'export':name,'variant':prefix,'statistics':[{'name':b['FullName'],'n':b['Statistics']['N'],'meanNanoseconds':b['Statistics']['Mean'],'standardDeviationNanoseconds':b['Statistics']['StandardDeviation'],'confidenceInterval':b['Statistics']['ConfidenceInterval'],'managedParentBytesAllocatedPerOperation':b['Memory']['BytesAllocatedPerOperation']} for b in document['Benchmarks']]})
inputs=source['inputs']
inputs.pop('status',None)
manifest=json.loads((root/'real-world-cases/manifest.json').read_text(encoding='utf-8'))
workloads=[]
for case in ['serilog-alignment-guard','polly-secondary-action']:
    entry=next(e for e in manifest if e['id']==case)
    cache=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases')/entry['cacheName']
    listing=subprocess.run(['git','-C',str(cache),'ls-tree','-r','-z',entry['after']],capture_output=True,check=True).stdout
    files=[]
    for item in listing.split(b'\0'):
        if not item:continue
        info,path=item.split(b'\t',1)
        mode,kind,oid=info.decode('ascii').split()
        if mode not in ['100644','100755']:continue
        files.append({'path':path.decode('utf-8'),'objectId':oid.decode('ascii') if isinstance(oid,bytes) else oid})
    selected=sorted([f for f in files if f['path'].startswith('src/') and f['path'].endswith('.cs')],key=lambda f:f['path'])[:20]
    assert len(selected)==20
    workload={'case':case,'repository':entry['repository'],'revision':entry['after'],'coldSelectedBlobs':selected}
    if case=='serilog-alignment-guard':
        warm=[f for f in files if f['path'].lower().endswith(('.cs','.csproj','.props')) and not any(p.lower() in ['bin','obj'] for p in f['path'].split('/'))]
        workload['warmBlobCount']=len(warm)
        workload['warmBlobs']=sorted(warm,key=lambda f:f['path'])
    workloads.append(workload)
metadata={
    'description':'Same-machine before/after Git blob hydration measurements, including the discarded probe-before-read variant and the final read-before-fetch variant.',
    'implementations':inputs,
    'gitVersion':subprocess.run(['git','--version'],capture_output=True,check=True,text=True).stdout.strip(),
    'workloads':workloads,
    'conditions':{
        'cold':'Fresh shallow filtered client per iteration; existing local file-transport server and filesystem caches warm. Client preparation and removal excluded from measurement.',
        'warm':'Pinned Serilog analysis inputs already available in the external no-checkout repository; no network or missing-object hydration in the measured operation.',
        'concurrency':'Validation/build suites stopped before measurement. Each benchmark build completed before that phase measured operations. Benchmark phases ran sequentially.',
        'memory':'MemoryDiagnoser managed allocations in the parent benchmark process only; excludes native Git subprocess heaps.',
        'statistics':'One launch, three warmups, fifteen requested measurement iterations. Full exports preserve measurements and BenchmarkDotNet outlier filtering; accepted N is at least ten.',
        'scope':'Git blob reads only; not internet transport, cold disk, full analysis, restore, or workspace-worker allocations.'},
    'runs':records
}
(target/'git-batching-windows-metadata.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'exports':len(records),'workloads':[{k:v for k,v in w.items() if k not in ['warmBlobs','coldSelectedBlobs']} for w in workloads]},indent=2))
