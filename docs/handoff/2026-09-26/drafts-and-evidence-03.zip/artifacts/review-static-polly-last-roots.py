import collections
import json
import re
import subprocess
from static_review_support import root, manifest, flatten, prior_fields_and_diagnostics, initializer_evidence

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/polly'
records = []
for case_id, mode in [('polly-executor-continuations', 'source'), ('polly-secondary-action', 'msbuild')]:
    case = manifest[case_id]
    executor = case_id == 'polly-executor-continuations'
    expectations = {
        'src/Polly.Core/ResilienceContextPool.cs': ['public static ResilienceContextPool Shared { get; } = new SharedPool();'],
        'src/Polly.Core/ResilienceContextPool.Shared.cs': ['private sealed class SharedPool : ResilienceContextPool', 'private readonly ObjectPool<ResilienceContext> _pool = new(static () => new ResilienceContext(), static c => c.Reset());'],
        'src/Polly.Core/ResiliencePipeline.cs': ['public static readonly ResiliencePipeline Empty = new(PipelineComponent.Empty, DisposeBehavior.Ignore, null);']
    } if executor else {'src/Polly.Core/VoidResult.cs': ['private VoidResult()', 'public static readonly VoidResult Instance = new();']}
    blobs = {}
    for path, snippets in expectations.items():
        values = []
        for side in ['before', 'after']:
            source = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            assert all(snippet in source for snippet in snippets)
            values.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip())
        assert values[0] == values[1]
        blobs[path] = values[0]
    def render_check(old, new):
        def normalized(text):
            return [re.sub(r'^[ │├└─]*', '', line) for line in text.splitlines() if 'possible initialization of ' not in line]
        left, right = normalized(old), normalized(new)
        if executor:
            index = right.index('ResiliencePipelineBenchmark.ExecuteOutcomeAsync')
            assert right[index + 1] == '…'
            right.pop(index + 1)
        else:
            assert new.count('↑ as above') - old.count('↑ as above') == 4
            right = [line.removesuffix(' ↑ as above') if line.startswith('~') and ('PipelineComponent.ExecuteCoreSync' in line or 'ResiliencePipeline.Execute (changes below depth limit)' in line) else line for line in right]
        assert left == right
    before, after, proof = prior_fields_and_diagnostics(case_id + '-' + mode + '-roots', stdout_check=render_check)
    branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
    assert collections.Counter(item['label'] for item in branches) == ({'possible initialization of ResilienceContextPool': 5, 'possible initialization of ResiliencePipeline': 1} if executor else {'possible initialization of VoidResult': 6})
    key, proven = initializer_evidence(case_id)
    locations = []
    for branch in branches:
        assert branch['change'] == 'unchanged' and branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == 'unchanged' and initializer['children'] == []
        assert initializer['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
        for side in ['before', 'after']:
            value, structural = initializer[side], branch[side]
            assert structural['binding'] == 'structural' and structural['relation'] == ('branch' if executor else 'callback') and structural['origin'] == 'structural' and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
            evidence = proven[key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']})]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
    proof.update({'initializerBranches': 6, 'sourceLocations': locations, 'unchangedSourceBlobs': blobs, 'review': 'Pool.Shared, Pipeline.Empty, and VoidResult.Instance have source constructor calls beneath their initializer depth boundaries. VoidResult branches belong to the six callback bodies. Four repeated rendered callback subtrees now reference the first displayed equivalent subtree; all JSON call locations remain separate. Executor output has the previously reviewed initializer-context ellipsis. All remaining JSON fields and rendered lines are preserved.'})
    records.append(proof)
(root / 'static-polly-last-roots-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed final two changed Polly views with twelve initializer branches and independently checked source locations.')
