from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
log = (artifacts / 'top-level-constructor-cli-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
build = artifacts / 'top-level-constructor-cli-tests/build/bin/Check/debug'
baseline = artifacts / 'constructor-diagnostic-cli-tests/candidate-ready'
core = artifacts / 'constructor-top-level-core/bin/Debug/net11.0/Callrift.Core.dll'
record = {}
for version in ['baseline', 'candidate']:
    target = artifacts / 'top-level-constructor-cli-tests' / (version + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(baseline / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(baseline / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    selected = baseline / 'Callrift.Core.dll' if version == 'baseline' else core
    for name in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']:
        shutil.copy2(selected, target / name)
    record[version] = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
record['sources'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in (artifacts / 'constructor-top-level-core').rglob('*.cs') if not any(part in ['bin', 'obj'] for part in file.parts)}
record['newTestsSha256'] = hashlib.sha256((artifacts / 'TopLevelConstructorTests.cs').read_bytes()).hexdigest()
(artifacts / 'top-level-constructor-cli-inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({version: record[version]['Callrift.Core.dll'] for version in ['baseline', 'candidate']}))
