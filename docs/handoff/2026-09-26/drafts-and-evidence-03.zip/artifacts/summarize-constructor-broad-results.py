from pathlib import Path
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
reports = {}
for name in ['constructor-exact-scenarios', 'constructor-exact-corpus']:
    files = list((root / 'artifacts' / (name + '-results')).glob('*.trx'))
    assert len(files) == 1
    document = ET.parse(files[0])
    report = {'trx': str(files[0].relative_to(root)), 'counters': document.find('.//t:Counters', ns).attrib,
              'failures': [{'name': node.attrib['testName'], 'message': node.findtext('.//t:Message', '', ns)[:500]} for node in document.findall('.//t:UnitTestResult', ns) if node.attrib['outcome'] != 'Passed']}
    reports[name] = report
    print(json.dumps({'suite': name, 'counters': report['counters'], 'failures': [item['name'] for item in report['failures']]}))
(root / 'artifacts/constructor-broad-results.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8', newline='\n')
