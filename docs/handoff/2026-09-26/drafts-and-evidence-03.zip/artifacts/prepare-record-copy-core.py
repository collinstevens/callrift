from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/constructor-initialization-core'
target = root / 'artifacts/record-copy-core'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
(root / 'artifacts/record-copy-original-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Copied constructor prototype without mutating frozen validation inputs.')
