from pathlib import Path
import collections
import json

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'constructor-exact-corpus/Snapshots'
target = artifacts / 'constructor-diagnostic-source-review'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
cases = {}
for path in sorted(directory.glob('*-source-*-json.received.txt')):
    name = path.name.removesuffix('-json.received.txt')
    case = next(case for case in manifest if name.startswith(case['id'] + '-source-'))
    before = collections.Counter(json.dumps(item, sort_keys=True) for item in read(path.with_name(path.name.replace('.received.', '.verified.')))['diagnostics'])
    after = collections.Counter(json.dumps(item, sort_keys=True) for item in read(path)['diagnostics'])
    added = after - before
    if not added:
        continue
    removed = before - after
    if removed:
        assert case['id'] == 'aspnetcore-js-task-handling' and sum(removed.values()) == 6, name
        assert all(json.loads(item)['code'] == 'unresolved-call' and json.loads(item)['location']['path'] in ['src/Servers/HttpSys/src/HttpSysOptions.cs', 'src/Servers/HttpSys/src/SourceBuildStubs.cs'] for item in removed), name
    assert all(json.loads(item)['code'] == 'unresolved-call' and json.loads(item)['message'].startswith('Cannot bind implicit base constructor for ') for item in added), name
    if case['id'] in cases:
        assert cases[case['id']]['added'] == added
        cases[case['id']]['views'].append(name)
        cases[case['id']]['removedByView'][name] = [json.loads(item) for item in removed.elements()]
    else:
        cases[case['id']] = {'case': case, 'added': added, 'removedByView': {name: [json.loads(item) for item in removed.elements()]}, 'views': [name]}
jobs = []
for name, entry in cases.items():
    if name == 'orchardcore-role-submission':
        continue
    case = entry['case']
    config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'revisions': [case['before'], case['after']],
        'diagnostics': [json.loads(item) for item in entry['added'].elements()], 'views': entry['views'],
        'removedDiagnosticsForSeparateReview': entry['removedByView']}
    (target / (name + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
    jobs.append(name)
(target / 'batch-jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'cases': jobs, 'diagnosticOccurrences': sum(sum(entry['added'].values()) for name, entry in cases.items() if name != 'orchardcore-role-submission')}))
