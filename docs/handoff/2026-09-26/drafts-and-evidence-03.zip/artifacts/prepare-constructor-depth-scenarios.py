from pathlib import Path
import shutil

artifacts = Path.cwd() / 'artifacts'
source = artifacts / 'constructor-reviewed-scenarios'
target = artifacts / 'constructor-depth-scenarios'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.txt'))
shutil.copy2(artifacts / 'DepthVisibilityTests.cs', target / 'DepthVisibilityTests.cs')
print('Copied the reviewed constructor harness and added 20 depth-boundary regressions; active prior inputs remain unchanged.')
