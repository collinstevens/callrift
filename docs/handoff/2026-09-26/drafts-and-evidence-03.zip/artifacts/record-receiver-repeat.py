from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
results = root / 'artifacts/receiver-context-accepted-corpus-results'
files = list(results.glob('*.trx'))
assert len(files) == 1, files
tree = ET.parse(files[0])
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
counters = tree.find('.//t:Counters', namespace).attrib
assert counters['total'] == '81' and counters['passed'] == '81' and counters['failed'] == '0', counters
harness = root / 'artifacts/receiver-context-accepted-corpus'
assert not list((harness / 'Snapshots').glob('*.received.txt'))
inputs = json.loads((root / 'artifacts/receiver-context-integrated-inputs.json').read_text(encoding='utf-8'))
for item in inputs['files']:
    assert hashlib.sha256((root / item['target']).read_bytes()).hexdigest() == item['sha256'], item
promotion_file = root / 'artifacts/receiver-context-snapshot-promotion.json'
promotion = json.loads(promotion_file.read_text(encoding='utf-8'))
for item in promotion['files']:
    assert hashlib.sha256((root / item['target']).read_bytes()).hexdigest() == item['promotedSha256'], item
for file in (root / 'tests/Callrift.RealWorldCases/Snapshots').glob('*.verified.txt'):
    assert file.read_bytes() == (harness / 'Snapshots' / file.name).read_bytes(), file
for relative, expected in [('Callrift.Core.dll', '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'), ('Callrift.MSBuild.dll', '039cf4cdca0851530b0eca7aaedfe75a4235a40101dc63169431d05a630eda7d')]:
    for directory in ['', 'msbuild/']:
        file = harness / 'build/bin/Check/debug' / (directory + relative)
        assert hashlib.sha256(file.read_bytes()).hexdigest() == expected, file
record = {'resultsFile': files[0].relative_to(root).as_posix(), 'counters': counters, 'times': tree.find('t:Times', namespace).attrib, 'sourceHashesMatch': True, 'allSnapshotInputsMatch': True, 'parentWorkerHashesMatch': True}
promotion.update(repeatPending=False, repeat=record)
promotion_file.write_text(json.dumps(promotion, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / 'artifacts/receiver-context-reviewed-corpus-completion.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record, indent=2))
