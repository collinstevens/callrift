from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path('artifacts')
source = root / 'static-initialization-callback-corpus'
target = root / sys.argv[1]
assert not target.exists()
records = []
reviews = {}
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name in sys.argv[2:]:
    path = root / name
    review = json.loads(path.read_text(encoding='utf-8'))
    records.extend(review['views'] if 'views' in review else [review])
    reviews[name] = digest(path)
names = sorted(record['view'] for record in records)
assert names and len(names) == len(set(names))
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
path = target / 'RealWorldCaseTests.cs'
text = path.read_text(encoding='utf-8-sig')
old = '.SelectMany(e => (e.Views ?? []).Where(v => !Routine || v.Routine).Select(v => new object[] { e.Id, v.Id }));'
new = '.SelectMany(e => (e.Views ?? []).Where(v => new[] { ' + ', '.join(json.dumps(name) for name in names) + ' }.Contains(e.Id + "-" + v.Id)).Select(v => new object[] { e.Id, v.Id }));'
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
for record in records:
    for name, expected in record['files'].items():
        path = source / 'Snapshots' / name
        assert digest(path) == expected
        shutil.copy2(path, target / 'Snapshots' / name.replace('.received.', '.verified.'))
(root / (target.name + '-reviews.json')).write_text(json.dumps({'views': names, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared ' + str(len(names)) + ' independently reviewed views in ' + target.name)
