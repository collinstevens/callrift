from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
ids = (root / 'orchard-missing-object-ids.txt').read_text(encoding='utf-8').splitlines()
assert ids and all(len(value) == 40 and all(c in '0123456789abcdef' for c in value) for value in ids)
started = time.monotonic()
with (root / 'orchard-prefetch.log').open('wb') as output:
    result = subprocess.run(['git', '-C', 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', '-c', 'fetch.negotiationAlgorithm=noop', 'fetch', 'origin', '--no-tags', '--no-write-fetch-head', '--recurse-submodules=no', '--filter=blob:none', '--stdin'], input=('\n'.join(ids) + '\n').encode(), stdout=output, stderr=subprocess.STDOUT)
print(f'Fetched {len(ids)} bounded revision objects; exit {result.returncode}; elapsed {time.monotonic()-started:.1f}s', flush=True)
raise SystemExit(result.returncode)
