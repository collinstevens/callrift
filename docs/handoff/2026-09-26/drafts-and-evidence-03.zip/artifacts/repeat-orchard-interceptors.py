import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
command = ['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe', str(root / 'interceptor-audit/bin/Callrift.Cli/debug/callrift.dll'), 'diff', 'cd7d8430905d2f2ab3ba3aef49577d73647ccfbf', '4910d1722d33f1b06d9ddb1cf8f6de2aa871dc8a', '--project', 'src/OrchardCore.Modules/OrchardCore.AdminDashboard/OrchardCore.AdminDashboard.csproj', '--framework', 'net10.0', '--depth', '1', '--format', 'json']
results = []
for number in [1, 2]:
    result = subprocess.run(command, cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', capture_output=True)
    (root / f'orchard-breadcrumb-final-{number}.json').write_bytes(result.stdout)
    (root / f'orchard-breadcrumb-final-{number}.err').write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode('utf-8')
    data = json.loads(result.stdout)
    assert not data['diagnostics'], data['diagnostics']
    print('run', number, 'roots', len(data['trees']), 'diagnostics', len(data['diagnostics']), flush=True)
    results.append(result.stdout)
assert results[0] == results[1], 'Raw JSON output differs between repeated runs'
print('Complete raw JSON matches across both runs', flush=True)
