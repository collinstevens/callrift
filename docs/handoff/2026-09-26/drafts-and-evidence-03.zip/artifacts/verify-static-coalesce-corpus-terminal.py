from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
historical_path = root / (directory.name + '-reviews.json')
assert digest(historical_path) == inputs['reviewsSha256']
historical = json.loads(historical_path.read_text(encoding='utf-8'))
for name, expected in historical['reviews'].items():
    assert digest(Path(name)) == expected, name
historical_files = {Path(record['target']).name: record for record in historical['promotions']}
incremental = {}
review_hashes = {}
for path in sorted(root.glob('static-coalesce-*-review.json')):
    value = json.loads(path.read_text(encoding='utf-8'))
    for record in value['views'] if 'views' in value else [value]:
        if 'view' not in record:
            continue
        assert record['view'] not in incremental, record['view']
        for name, expected in record['files'].items():
            assert digest(Path(record['snapshotDirectory']) / name) == expected
        for name, expected in record['baselineFiles'].items():
            assert digest(directory / 'Snapshots' / name) == expected
        incremental[record['view']] = {**record, 'reviewFile': path.as_posix(), 'reviewSha256': digest(path)}
    review_hashes[path.as_posix()] = digest(path)
assert len(incremental) == 17
trx_files = list((root / (directory.name + '-results')).glob('*.trx'))
assert len(trx_files) == 1
trx = trx_files[0]
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == '89' and counters['passed'] == '72' and counters['failed'] == '17'
results = tree.findall('.//{*}UnitTestResult')
assert len(results) == 89
failures = [result for result in results if result.attrib['outcome'] == 'Failed']
assert len(failures) == 17
assert all('VerifyException' in result.find('.//{*}Message').text for result in failures)
failed_views = []
for result in failures:
    match = re.search(r'ReviewedView\(id: "([^"]+)", viewId: "([^"]+)"\)', result.attrib['testName'])
    assert match, result.attrib['testName']
    failed_views.append('-'.join(match.groups()))
assert set(failed_views) == set(incremental)
production = Path('tests/Callrift.RealWorldCases/Snapshots')
assert production.is_dir()
files = []
received_names = set()
for verified in sorted((directory / 'Snapshots').glob('*.verified.txt')):
    name = verified.name.removesuffix('.verified.txt')
    view = name.removesuffix('-json')
    received = verified.with_name(verified.name.replace('.verified.', '.received.'))
    actual = received if received.exists() else verified
    if received.exists():
        received_names.add(received.name)
    review = incremental.get(view)
    if review:
        assert review['files'].get(actual.name) == digest(actual), actual.name
    else:
        assert not received.exists(), received.name
    prior = historical_files.get(verified.name)
    if prior:
        assert digest(verified) == prior['sha256']
        assert digest(Path(prior['source'])) == prior['sha256']
    else:
        assert digest(verified) == digest(production / verified.name), verified.name
    files.append({'view': view, 'source': actual.as_posix(), 'target': (production / verified.name).as_posix(), 'sha256': digest(actual), 'baselineSha256': digest(verified), 'productionPriorSha256': digest(production / verified.name), 'historicalReview': prior, 'incrementalReview': None if review is None else review['reviewFile']})
assert received_names == {path.name for path in (directory / 'Snapshots').glob('*.received.txt')}
assert {path.name for path in production.glob('*.verified.txt')} == {Path(record['target']).name for record in files}
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'allFailuresAreReviewedVerifyDifferences': True, 'reviewedDifferences': sorted(failed_views), 'reviews': review_hashes, 'historicalReviewsSha256': digest(historical_path), 'files': files, 'results': [result.attrib for result in results]}
(root / (directory.name + '-terminal.json')).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 89 terminal results: 72 passed, 17 independently reviewed Verify differences, every frozen input and final snapshot accounted for.')
print('Snapshot files:', len(files), 'production changes:', sum(record['sha256'] != record['productionPriorSha256'] for record in files))
