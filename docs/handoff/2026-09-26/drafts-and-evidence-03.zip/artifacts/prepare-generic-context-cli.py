from pathlib import Path

root = Path(__file__).resolve().parent.parent
target = root / 'artifacts/generic-context-cli-tests'
target.mkdir(exist_ok=True)
source = (root / 'artifacts/generic-context-traversal/Program.cs').read_text(encoding='utf-8')
fixtures = source[source.index('const string handlers'):source.index('foreach (var item in cases)')]
project = (root / 'artifacts/constraint-cli-tests/Check.csproj').read_text(encoding='utf-8')
project = project.replace('    <Compile Include="../ConstraintDispatchTests.cs" Link="ConstraintDispatchTests.cs" />\n', '')
(target / 'Check.csproj').write_text(project, encoding='utf-8')
body = '''using System.Text.Json;
using Xunit;

namespace Callrift.Scenarios;

public sealed class GenericContextTests
{
    public static IEnumerable<object[]> Cases()
    {
FIXTURES
        foreach (var item in cases)
            foreach (var workspace in new[] { false, true })
                yield return [item.Name, item.Source, item.Entry, item.Sinks, workspace];
    }

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task CallsRetainGenericInvocationArguments(string name, string source, string entry, string[] sinks, bool workspace)
    {
        var before = source.Replace("public static void Text() {}", "public static void Text() {} public static void After() {}", StringComparison.Ordinal);
        var after = before.Replace("=> Sink.Text();", "=> Sink.After();", StringComparison.Ordinal);
        const string project = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>";
        await using var fixture = await GitFixture.CreateAsync(new Scenario("generic-context-" + name, "Generic invocation arguments constrain possible downstream dispatch.",
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = before },
            new Dictionary<string, string> { ["App.csproj"] = project, ["Flow.cs"] = after }, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        var output = await fixture.RunAsync(["tree", fixture.Before, "--entry", entry, "--depth", "16", .. mode, "--format", "json"]);
        using var tree = Parse(output);
        Assert.Empty(tree.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.DoesNotContain("\\\\u001e", output, StringComparison.OrdinalIgnoreCase);
        var reached = Flatten(tree.RootElement.GetProperty("trees")).Select(n => n.GetProperty("label").GetString()!)
            .Where(label => label.StartsWith("Sink.", StringComparison.Ordinal)).Order(StringComparer.Ordinal).ToArray();
        Assert.Equal(sinks, reached);
        foreach (var sink in sinks)
        {
            using var reach = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", entry, "--to", sink, "--depth", "16", .. mode, "--format", "json"]));
            Assert.Empty(reach.RootElement.GetProperty("diagnostics").EnumerateArray());
            Assert.Single(reach.RootElement.GetProperty("paths").EnumerateArray());
        }
        var excluded = sinks.Contains("Sink.Text", StringComparer.Ordinal) ? "Sink.Number" : "Sink.Text";
        using var absent = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", entry, "--to", excluded, "--depth", "16", .. mode, "--format", "json"]));
        Assert.Empty(absent.RootElement.GetProperty("diagnostics").EnumerateArray());
        Assert.Empty(absent.RootElement.GetProperty("paths").EnumerateArray());
        using var diff = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, .. mode, "--format", "json"]));
        Assert.Empty(diff.RootElement.GetProperty("diagnostics").EnumerateArray());
        var expected = name switch
        {
            "closed-class-number" or "closed-class-text" => "Entry.Text",
            "inherited-implementation" or "generic-interface-method" => "TextSink.Call",
            _ => "TextHandler.Run"
        };
        Assert.Equal(expected, Assert.Single(diff.RootElement.GetProperty("trees").EnumerateArray()).GetProperty("label").GetString());
    }

    private static IEnumerable<JsonElement> Flatten(JsonElement nodes)
    {
        foreach (var node in nodes.EnumerateArray())
        {
            yield return node;
            foreach (var child in Flatten(node.GetProperty("children"))) yield return child;
        }
    }

    private static JsonDocument Parse(string output)
    {
        Assert.True(output.StartsWith("exit: 0\\n", StringComparison.Ordinal), output);
        return JsonDocument.Parse(output.Split("stdout:\\n", StringSplitOptions.None)[1].Split("stderr:\\n", StringSplitOptions.None)[0]);
    }
}
'''.replace('FIXTURES', '\n'.join('        ' + line for line in fixtures.splitlines()))
(target / 'GenericContextTests.cs').write_text(body, encoding='utf-8')
print('Prepared source/MSBuild CLI cases in', target)
