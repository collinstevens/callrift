import collections
import json
import re
import subprocess
from static_review_support import root, snapshots, manifest, flatten, prior_fields_and_diagnostics, digest, initializer_evidence

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
records = []
for case_id in ['autofac-any-key-cache', 'autofac-service-key-inheritance']:
    case = manifest[case_id]
    any_key = case_id == 'autofac-any-key-cache'
    blobs = {}
    paths = ['src/Autofac/Core/KeyedService.cs'] if any_key else ['src/Autofac/Core/ReflectionCacheSet.cs', 'src/Autofac/Core/ServiceKeyAttributeCache.cs', 'src/Autofac/Core/Activators/Reflection/ReflectionActivator.cs']
    sources = {}
    for path in paths:
        blobs[path] = {}
        for side in ['before', 'after']:
            source = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            sources[(side, path)] = source
            blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
    if any_key:
        assert all('public static object AnyKey { get; } = new object();' in source for source in sources.values())
    else:
        for side in ['before', 'after']:
            assert 'private static readonly object _cacheAllocationLock = new();' in sources[(side, paths[0])]
            assert all(value in sources[(side, paths[1])] for value in ['ReflectionCacheSet.Shared.Internal.ServiceKeyParameterAttributes.GetOrAdd(', 'ReflectionCacheSet.Shared.Internal.ServiceKeyPropertyAttributes.GetOrAdd('])
        assert '=> ReflectionCacheSet.Shared.Internal.ServiceKeyUsageByType.GetOrAdd(' in sources[('after', paths[2])]
    for mode in ['source', 'msbuild']:
        name = case_id + '-' + mode + '-focused'
        def check_stdout(before, after):
            if any_key:
                assert before == after
            else:
                def normalized(text):
                    return [(line[0], re.sub(r'^[ │├└─]*', '', line[2:])) for line in text.splitlines() if line and 'initialization of ReflectionCacheSet' not in line]
                assert normalized(before) == normalized(after)
        before, after, proof = prior_fields_and_diagnostics(name, stdout_check=check_stdout)
        assert before['diagnostics'] == after['diagnostics']
        branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
        assert len(branches) == (2 if any_key else 5)
        assert collections.Counter(item['change'] for item in branches) == ({'unchanged': 2} if any_key else {'removed': 2, 'added': 3})
        key, proven = initializer_evidence(case_id)
        for index, branch in enumerate(branches):
            assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
            initializer = branch['children'][0]
            expected_omission = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if any_key and index == 0 else None
            assert initializer['change'] == branch['change'] and initializer['omission'] == expected_omission
            assert len(initializer['children']) == (1 if any_key and index == 1 else 0)
            for side in ['before', 'after']:
                value, structural = initializer[side], branch[side]
                if value is None:
                    assert structural is None and not any_key
                    continue
                assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['callSites'] == value['callSites'] and structural['origin'] == 'structural'
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']]
                source_record = proven[key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']})]['record']
                assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in source_record['constructors']]
            for child in initializer['children']:
                assert child['label'] == 'new object' and child['change'] == 'unchanged' and child['omission'] is None and child['children'] == []
                assert child['before'] == child['after']
                for side in ['before', 'after']:
                    value = child[side]
                    assert value['origin'] == 'metadata' and value['definition'] is None and value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call'
                    assert value['symbolId'].endswith('::object..ctor()') and value['targetIds'] == [value['symbolId']]
                    assert len(value['callSites']) == 1
                    site = value['callSites'][0]
                    assert site['startLine'] == site['endLine']
                    assert sources[(side, site['path'])].splitlines()[site['startLine'] - 1][site['startColumn'] - 1:site['endColumn'] - 1] == 'new object()'
        proof.update({'initializerBranches': len(branches), 'sourceBlobs': blobs, 'review': 'Existing JSON fields and diagnostics are preserved. The wildcard key initializer constructs the object sentinel; one occurrence is depth limited and the expanded occurrence binds the exact object constructor expression. The inheritance view keeps removed and added control-flow paths distinct, including a possible cache initializer before the new base-type memoization call. Existing recursion markers remain unchanged. Rendered changes contain only those initializer branches.'})
        records.append(proof)
(root / 'static-autofac-simple-focused-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed four Autofac focused views with fourteen independently checked initializer branches and preserved prior fields.')
