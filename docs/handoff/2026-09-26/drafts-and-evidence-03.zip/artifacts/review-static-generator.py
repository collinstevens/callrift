from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path('artifacts')
snapshot = root / 'static-initialization-compatibility-workspaces/Snapshots/generator.received.txt'
text = snapshot.read_text(encoding='utf-8-sig')
json_text = text[text.index('format: json'):]
document, end = json.JSONDecoder().raw_decode(json_text[json_text.index('{'):])
assert json_text[json_text.index('{') + end:] == '\nstderr:\n'
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
jsonschema.validators.validator_for(schema)(schema).validate(document)
assert not document['diagnostics'] and not document['truncated']
def flatten(nodes):
    for node in nodes:
        yield node
        yield from flatten(node['children'])
nodes = list(flatten(document['trees']))
expected_labels = [
    'Pattern_0.RunnerFactory.Runner.Scan', 'Pattern_0.RunnerFactory.Runner.TryFindNextPossibleStartingPosition',
    'if (pos <= inputSpan.Length - 6)', 'possible initialization of Utilities', 'initialization of Utilities',
    'if (pos <= inputSpan.Length - 5)', 'possible initialization of Utilities', 'initialization of Utilities',
    'Flow.Match', 'Flow.Pattern', 'possible initialization of Pattern_0', 'initialization of Pattern_0',
    'new Pattern_0', 'possible initialization of Utilities', 'initialization of Utilities', 'new Pattern_0.RunnerFactory'
]
assert [node['label'] for node in nodes] == expected_labels
assert [node['change'] for node in nodes] == ['unchanged'] * 2 + ['removed'] * 3 + ['added'] * 3 + ['unchanged'] * 6 + ['modified', 'unchanged']
assert [node['detail'] for node in nodes] == [None] * 14 + ['body changed; visible calls unchanged', None]
assert all(node['omission'] is None for node in nodes)
assert [node['label'] for node in document['trees']] == [expected_labels[0], 'Flow.Match']
generated_path = 'obj/Debug/net10.0/System.Text.RegularExpressions.Generator/System.Text.RegularExpressions.Generator.RegexGenerator/RegexGenerator.g.cs'
generated_scope = 'project:App.csproj@net10.0/file:' + generated_path + '::System.Text.RegularExpressions.Generated.'
identities = {
    0: ('Pattern_0.RunnerFactory.Runner.Scan(global::System.ReadOnlySpan<char>)', 'Pattern_0.RunnerFactory.Runner.Scan(System.ReadOnlySpan<char>) -> void', (60, 17, 69, 18)),
    1: ('Pattern_0.RunnerFactory.Runner.TryFindNextPossibleStartingPosition(global::System.ReadOnlySpan<char>)', 'Pattern_0.RunnerFactory.Runner.TryFindNextPossibleStartingPosition(System.ReadOnlySpan<char>) -> bool', (74, 17, 94, 18)),
    4: ('Utilities..cctor()', 'Utilities.Utilities() -> void', (101, 5, 112, 6)),
    7: ('Utilities..cctor()', 'Utilities.Utilities() -> void', (101, 5, 112, 6)),
    8: ('project:App.csproj@net10.0::Flow.Match(string)', 'Flow.Match(string) -> bool', (1, 60, 1, 120)),
    9: ('project:App.csproj@net10.0::Flow.Pattern()', 'Flow.Pattern() -> System.Text.RegularExpressions.Regex', (15, 5, 16, 154)),
    11: ('Pattern_0..cctor()', 'Pattern_0.Pattern_0() -> void', (32, 5, 98, 6)),
    12: ('Pattern_0..ctor()', 'Pattern_0.Pattern_0() -> void', (39, 9, 47, 10)),
    14: ('Utilities..cctor()', 'Utilities.Utilities() -> void', (101, 5, 112, 6)),
    15: ('Pattern_0.RunnerFactory..ctor()', 'Pattern_0.RunnerFactory.RunnerFactory() -> void', (50, 9, 96, 10))
}
call_text = {1: 'TryFindNextPossibleStartingPosition(inputSpan)', 9: 'Pattern()', 10: 'global::System.Text.RegularExpressions.Generated.Pattern_0.Instance', 11: 'global::System.Text.RegularExpressions.Generated.Pattern_0.Instance', 12: 'new()', 13: 'Utilities.s_defaultTimeout', 14: 'Utilities.s_defaultTimeout', 15: 'new RunnerFactory()'}
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {}
checked_locations = []
for version in ['before', 'after']:
    folder = root / 'constructor-generator-review' / version
    generated = list(folder.rglob('RegexGenerator.g.cs'))
    assert len(generated) == 1
    paths = {'Flow.cs': folder / 'Flow.cs', generated_path: generated[0]}
    sources.update({path.as_posix(): digest(path) for path in paths.values()})
    def excerpt(location):
        assert location['path'] in paths
        lines = paths[location['path']].read_text(encoding='utf-8-sig').splitlines()
        first, last = location['startLine'] - 1, location['endLine'] - 1
        assert 0 <= first <= last < len(lines)
        assert 0 < location['startColumn'] <= len(lines[first]) + 1 and 0 < location['endColumn'] <= len(lines[last]) + 1
        segment = lines[first:last + 1]
        segment[-1] = segment[-1][:location['endColumn'] - 1]
        segment[0] = segment[0][location['startColumn'] - 1:]
        return '\n'.join(segment)
    for index, node in enumerate(nodes):
        side = node[version]
        if side is None:
            assert (version == 'before' and index in [5, 6, 7]) or (version == 'after' and index in [2, 3, 4])
            continue
        if index in identities:
            identity, signature, location = identities[index]
            if index not in [8, 9]:
                identity = generated_scope + identity
                signature = 'System.Text.RegularExpressions.Generated.' + signature
            assert side['symbolId'] == identity and side['targetIds'] == [identity] and side['signature'] == signature
            assert side['binding'] == 'resolved' and side['dispatch'] == 'direct' and side['origin'] == 'source'
            actual_location = side['definition']
            assert tuple(actual_location[key] for key in ['startLine', 'startColumn', 'endLine', 'endColumn']) == location
            assert actual_location['path'] == ('Flow.cs' if index == 8 else generated_path)
            content = excerpt(actual_location)
            assert content and (content.endswith('}') or content.endswith(';'))
            checked_locations.append({'version': version, 'node': index, 'kind': 'definition', 'location': actual_location, 'excerptSha256': hashlib.sha256(content.encode()).hexdigest()})
        else:
            assert side['symbolId'] is None and side['signature'] is None and side['definition'] is None and side['targetIds'] == []
            assert side['binding'] == 'structural' and side['dispatch'] == 'none' and side['origin'] == 'structural'
        if index in [0, 8]:
            assert side['relation'] == 'definition' and side['callSites'] == [] and side['candidates'] is None
            continue
        assert side['relation'] == ('call' if index in identities else 'branch')
        assert side['candidates'] == ([] if index in identities else None)
        assert len(side['callSites']) == 1
        location = side['callSites'][0]
        content = excerpt(location)
        if index in [2, 5]:
            assert content.startswith('if (pos <= inputSpan.Length - ' + ('6' if version == 'before' else '5') + ')') and content.endswith('}')
        elif index in [3, 4, 6, 7]:
            assert content == 'Utilities.s_indexOfString_' + version + '_Ordinal'
        else:
            assert content == call_text[index], (index, content)
        checked_locations.append({'version': version, 'node': index, 'kind': 'call', 'location': location, 'excerptSha256': hashlib.sha256(content.encode()).hexdigest()})
plain = text.split('format: text\nexit: 0\nstdout:\n')[1].split('stderr:\n')[0]
markdown = text.split('format: md\nexit: 0\nstdout:\n```diff\n')[1].split('```\nstderr:\n')[0]
assert plain == markdown
assert plain.count('possible initialization of Utilities') == 3
assert plain.count('possible initialization of Pattern_0') == 1
assert plain.index('Flow.Match') < plain.index('Flow.Pattern') < plain.index('new Pattern_0') < plain.index('new Pattern_0.RunnerFactory')
proof = {'snapshot': snapshot.as_posix(), 'snapshotSha256': digest(snapshot), 'sources': sources, 'nodesReviewed': len(nodes), 'locations': checked_locations, 'schemaV1': True, 'textMatchesMarkdown': True, 'latestCandidateRepeat': 'pending'}
(root / 'static-generator-snapshot-review.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
target = root / 'static-initialization-reviewed-workspaces'
assert not target.exists()
source = root / 'static-initialization-compatibility-workspaces'
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
description = 'SDK regex generator bodies participate in change detection; static initialization links Flow.Match to the regex constructor, while metadata dispatch leaves the generated runner as a separate root.'
old_description = 'SDK regex generator bodies participate in change detection; static fields and property accessors do not link the runner back to Flow.Match.'
test = target / 'WorkspaceTests.cs'
assert old_description in test.read_text(encoding='utf-8-sig')
test.write_text(test.read_text(encoding='utf-8-sig').replace(old_description, description), encoding='utf-8', newline='\n')
assert text.startswith(old_description)
(target / 'Snapshots/generator.verified.txt').write_text(text.replace(old_description, description, 1), encoding='utf-8-sig', newline='\n')
print('Reviewed all 16 nodes, every identity and source range, and both rendered formats; prepared isolated workspace repeat with one reviewed snapshot.')
