from pathlib import Path
import shutil

root = Path.cwd()
target = root / 'artifacts/dispatch-cardinality-complete-corpus'
source = root / 'artifacts/receiver-context-accepted-corpus'
assert not target.exists()
target.mkdir()
for name in ['Check.csproj', 'RealWorldCaseTests.cs']:
    shutil.copy2(source / name, target / name)
shutil.copytree(root / 'real-world-cases', target / 'real-world-cases')
shutil.copytree(root / 'tests/Callrift.RealWorldCases/Snapshots', target / 'Snapshots')
