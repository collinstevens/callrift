from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parents[1]
artifacts = root / 'artifacts'
snapshot_dir = root / 'tests/Callrift.RealWorldCases/Snapshots'
manifest_path = root / 'real-world-cases/manifest.json'
manifest = json.loads(manifest_path.read_text())
ocelot = json.loads((artifacts / 'ocelot-manifest-draft.json').read_text())
orchard = [entry for entry in json.loads((artifacts / 'orchard-manifest-draft.json').read_text())
           if entry['id'] in ['orchardcore-workflow-startup', 'orchardcore-role-submission']]
assert len(ocelot) == 5 and len(orchard) == 2
assert json.loads((artifacts / 'ocelot-harness-comparison.json').read_text())['complete']
assert len(json.loads((artifacts / 'orchard-small-harness-comparison.json').read_text())) == 16
assert not set(entry['id'] for entry in ocelot + orchard) & set(entry['id'] for entry in manifest)
copies = []
for entry in ocelot + orchard:
    entry['routine'] = entry['id'] in ['ocelot-poller-reentrancy', 'orchardcore-role-submission']
    for view in entry['views']:
        view['routine'] = entry['id'] == 'ocelot-poller-reentrancy' and view['id'] in ['source-roots', 'msbuild-roots'] or entry['id'] == 'orchardcore-role-submission' and view['id'] == 'source-roots'
        for suffix in ['', '-json']:
            stem = entry['id'] + '-' + view['id'] + suffix
            source = snapshot_dir / (stem + '.received.txt') if entry in ocelot else artifacts / 'orchard-small-snapshots' / (stem + '.verified.txt')
            destination = snapshot_dir / (stem + '.verified.txt')
            assert source.exists() and not destination.exists(), stem
            contents = source.read_bytes()
            assert b'virtual-nonabstract-dispatch' not in contents, stem
            copies.append((source, destination, contents))
assert len(copies) == 56
for source, destination, contents in copies:
    destination.write_bytes(contents)
for entry in ocelot:
    review = (artifacts / 'ocelot-review-drafts' / (entry['id'] + '.md')).read_text()
    review = review.replace('Status: source and trial review in progress; snapshots are not accepted.', 'Status: accepted after source review and independent harness comparison.')
    review = review.replace('Independent harness regeneration and snapshot acceptance remain pending.', 'Independent harness regeneration matched all twenty views in text, Markdown, and every JSON field. Forty snapshots are accepted across these five pairs. The full suite will repeat them against the current implementation. Cross-platform CI repeat remains pending.')
    (root / 'real-world-cases' / entry['review']).write_text(review, encoding='utf-8', newline='\n')
for entry in orchard:
    review = (artifacts / (entry['id'] + '-review.md')).read_text()
    review = review.replace(' review draft', ' review')
    review = review.replace('Not accepted. Harness generation and repeat validation remain pending.', 'Accepted after independent source review, harness comparison, and repeat validation. All eight views across these two pairs matched the reviewed output in text, Markdown, and every JSON field. Sixteen snapshots are accepted. Cross-platform CI repeat remains pending.')
    (root / 'real-world-cases' / entry['review']).write_text(review, encoding='utf-8', newline='\n')
manifest_path.write_text(json.dumps(manifest + ocelot + orchard, indent=2) + '\n', encoding='utf-8', newline='\n')
(artifacts / 'reviewed-pair-promotion.json').write_text(json.dumps({
    'pairs': [entry['id'] for entry in ocelot + orchard],
    'snapshots': [{'source': str(source.relative_to(root)), 'destination': str(destination.relative_to(root)), 'sha256': hashlib.sha256(contents).hexdigest()} for source, destination, contents in copies]
}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Added seven reviewed pairs, seven reviews, and 56 independently compared snapshots.')
