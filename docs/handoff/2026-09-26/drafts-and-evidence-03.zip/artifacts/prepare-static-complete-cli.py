from pathlib import Path
import shutil

root = Path('artifacts')
directory = root / 'static-initialization-complete-cli'
assert not directory.exists()
directory.mkdir()
for path in (root / 'static-initialization-identity-reviewed-cli').iterdir():
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, directory / path.name)
shutil.copy2(root / 'static-event-order-cli/StaticEventOrderTests.cs', directory / 'StaticEventOrderTests.cs')
path = directory / 'Check.csproj'
text = path.read_text(encoding='utf-8-sig').replace('    <Compile Include="StaticInitializationIdentityTests.cs" />', '    <Compile Include="StaticInitializationIdentityTests.cs" />\n    <Compile Include="StaticEventOrderTests.cs" />')
path.write_text(text, encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-event-order-cli.py').read_text(encoding='utf-8')
freeze = freeze.replace("directory = root / 'static-event-order-cli'", "directory = root / 'static-initialization-complete-cli'")
freeze = freeze.replace("'static-event-order-cli-build.log'", "'static-initialization-complete-cli-build.log'")
freeze = freeze.replace("'static-event-order-cli-inputs.json'", "'static-initialization-complete-cli-inputs.json'")
freeze = freeze.replace("[('candidate', worker), ('baseline', root / 'static-initialization-compatibility-scenarios/candidate-ready/msbuild')]", "[('candidate', worker)]")
(root / 'freeze-static-complete-cli.py').write_text(freeze, encoding='utf-8', newline='\n')
print(directory)
