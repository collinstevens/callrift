import json
from pathlib import Path
import subprocess

root=Path('artifacts').resolve()
repo='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/ocelot'
entries=json.loads((root/'ocelot-candidates.json').read_text(encoding='utf-8'))
pins=sorted({e[s] for e in entries for s in ['before','after']})
def git(*args):return subprocess.check_output(['git','-C',repo,*args]).decode('utf-8')
selected=set()
for pin in pins:
 for record in git('ls-tree','-r','-z',pin).split('\0'):
  if not record:continue
  meta,path=record.split('\t',1)
  if Path(path).suffix.lower() in ['.cs','.csproj','.props'] and not any(p.lower() in ['bin','obj'] for p in Path(path).parts):selected.add(meta.split()[2])
missing={line[1:] for line in git('rev-list','--objects','--missing=print','--no-object-names',*[p+'^{tree}' for p in pins]).splitlines() if line.startswith('?')}
needed=sorted(selected & missing)
print('selected analysis objects',len(selected),'missing selected objects',len(needed),flush=True)
if needed:
 result=subprocess.run(['git','-C',repo,'-c','fetch.negotiationAlgorithm=noop','fetch','origin','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--filter=blob:none','--stdin'],input=('\n'.join(needed)+'\n').encode('ascii'),capture_output=True,timeout=120)
 assert result.returncode==0,result.stderr.decode('utf-8')
print('Bounded source cache preparation complete; no analyzer performance claim.',flush=True)
