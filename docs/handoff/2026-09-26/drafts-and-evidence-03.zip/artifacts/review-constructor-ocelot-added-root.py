from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path('artifacts')
directory = root / 'constructor-depth-corpus/Snapshots'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
proofs = {}
for folder in ['constructor-depth-leaf-source-review', 'constructor-depth-leaf-batch2', 'constructor-depth-leaf-batch3', 'constructor-depth-leaf-batch4', 'constructor-depth-leaf-batch5']:
    for path in (root / folder).glob('*-compiler-report.json'):
        for record in json.loads(path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    start = text.index('{')
    document, length = json.JSONDecoder().raw_decode(text[start:])
    return document, text[:start], text[start + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def diagnostic_output(items):
    lines = []
    for item in items[:8]:
        location = item.get('location')
        start = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(start + item['code'] + ': ' + item['message'])
    if len(items) > 8:
        lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

jobs = {}
added_root_labels = {'ocelot-custom-json-merge': ['new DefaultInfo']}
for path in (root / 'constructor-depth-leaf-batch4-supplement').glob('*-report.json'):
    for record in json.loads(path.read_text(encoding='utf-8'))['records']:
        assert record['provenNoVisibleCalls']
        leaf = record['leaf']
        proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf
reviews = []
for view in [name + '-source-roots' for name in added_root_labels]:
    case = next(case for case in manifest if view.startswith(case['id'] + '-'))
    original, prefix, suffix = read(directory / (view + '-json.verified.txt'))
    path = directory / (view + '-json.received.txt')
    actual, new_prefix, new_suffix = read(path)
    expected = copy.deepcopy(original)
    assert prefix == new_prefix
    diagnostic_directory = root / 'constructor-diagnostic-source-review'
    if not (diagnostic_directory / (case['id'] + '.json')).exists():
        diagnostic_directory = root / 'constructor-remaining-diagnostic-review'
    configuration = json.loads((diagnostic_directory / (case['id'] + '.json')).read_text(encoding='utf-8'))
    proof = json.loads((diagnostic_directory / (case['id'] + '-report.json')).read_text(encoding='utf-8'))
    assert not proof['unmatched'] and proof['provenMissingBaseCount'] == proof['diagnosticCount']
    counter = lambda items: collections.Counter(json.dumps(item, sort_keys=True) for item in items)
    added = counter(configuration['diagnostics'])
    assert counter(actual['diagnostics']) == counter(original['diagnostics']) + added
    assert [item for item in actual['diagnostics'] if json.dumps(item, sort_keys=True) not in added] == original['diagnostics']
    expected['diagnostics'] = actual['diagnostics']
    old_errors = diagnostic_output(original['diagnostics'])
    new_errors = diagnostic_output(actual['diagnostics'])
    assert suffix.strip() == 'stderr:\n' + old_errors and new_suffix.strip() == 'stderr:\n' + new_errors
    original_labels = {node['label'] for node in original['trees']}
    added_roots = [node for node in actual['trees'] if node['label'] not in original_labels]
    assert [node['label'] for node in added_roots] == added_root_labels[case['id']]
    job = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'beforeRevision': case['before'], 'checks': []})
    root_checks = 0
    for node in added_roots:
        assert node['kind'] == 'member' and node['change'] == 'added' and node['before'] is None and node['detail'] is None and node['omission'] is None
        derived = node['label'] == 'new ContainerBuildInheritedMembersBenchmark.Derived<T>'
        assert len(node['children']) == (1 if derived else 0)
        for member in [node] + node['children']:
            value = member['after']
            assert value['symbolId'].startswith('source::') and value['symbolId'].endswith('..ctor()')
            assert value == {'symbolId': value['symbolId'], 'signature': value['signature'], 'binding': 'resolved', 'dispatch': 'direct',
                             'targetIds': [value['symbolId']], 'definition': value['definition'], 'callSites': [] if member is node else [node['after']['definition']],
                             'relation': 'definition' if member is node else 'call', 'candidates': None if member is node else [], 'origin': 'source'}
            if member is not node:
                assert member['label'] == 'new ContainerBuildInheritedMembersBenchmark.WideBase' and member['kind'] == 'call' and member['change'] == 'added'
                assert member['before'] is None and member['detail'] is None and member['omission'] is None and not member['children']
            expected_base = 'Autofac.Benchmarks.ContainerBuildInheritedMembersBenchmark.WideBase' if member is node and derived else 'object'
            job['checks'].append({'view': view, 'nodeId': member['id'], 'side': 'after', 'revision': case['after'], 'symbolId': value['symbolId'],
                                  'signature': value['signature'], 'definition': value['definition'], 'requireSourceBase': member is node and derived,
                                  'newRoot': member is node, 'requireNoInitializers': True, 'expectedBase': expected_base})
            root_checks += 1
    comparable_actual = copy.deepcopy(actual)
    comparable_actual['trees'] = [node for node in comparable_actual['trees'] if node['label'] in original_labels]
    old_nodes = list(nodes(expected['trees']))
    new_nodes = list(nodes(comparable_actual['trees']))
    assert len(old_nodes) == len(new_nodes)
    mapping = {new['id']: old['id'] for old, new in zip(old_nodes, new_nodes)}
    reverse_mapping = {old: new for new, old in mapping.items()}
    for node in new_nodes:
        node['id'] = mapping[node['id']]
        if node['omission'] and node['omission']['referenceId']:
            node['omission']['referenceId'] = mapping[node['omission']['referenceId']]
    assert len(old_nodes) == len(new_nodes)
    added_markers = 0
    removed_markers = 0
    metadata_checks = 0
    changed_labels = set()
    for old, new in zip(old_nodes, new_nodes):
        assert old['id'] == new['id']
        new_boundary = old['omission'] is None and new['omission'] is not None
        checked_sides = []
        for side in ['before', 'after']:
            assert (old[side] is None) == (new[side] is None)
            if old[side] is None:
                continue
            if old[side]['signature'] != new[side]['signature'] or old[side]['definition'] != new[side]['definition']:
                assert old[side]['signature'] is None or new[side]['signature'] == old[side]['signature'] + ' -> void'
                assert old[side]['definition'] is None or old[side]['definition'] == new[side]['definition']
                assert new[side]['symbolId'].endswith('..ctor()') and new[side]['definition'] is not None
                check = {'view': view, 'nodeId': reverse_mapping[new['id']], 'side': side, 'revision': case[side], 'symbolId': new[side]['symbolId'],
                         'signature': new[side]['signature'], 'definition': new[side]['definition'], 'requireSourceBase': new_boundary}
                job = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': []})
                job['checks'].append(check)
                old[side]['signature'] = new[side]['signature']
                old[side]['definition'] = new[side]['definition']
                metadata_checks += 1
                checked_sides.append(side)
        if old['omission'] != new['omission']:
            changed_labels.add(new['label'])
            if new_boundary:
                assert new['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and new['detail'] == 'depth limit'
                assert old['detail'] is None and not new['children']
                assert all(side in checked_sides for side in ['before', 'after'] if new[side])
                added_markers += 1
            else:
                assert old['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and old['detail'] in ['depth limit', 'changes below depth limit']
                assert new['omission'] is None and new['detail'] is None
                for side in ['before', 'after']:
                    if new[side]:
                        proof = proofs[(view, reverse_mapping[new['id']], side)]
                        assert proof['definition'] == new[side]['definition'] and proof['symbolId'] == new[side]['symbolId']
                removed_markers += 1
            old['omission'] = new['omission']
            old['detail'] = new['detail']
    assert expected == comparable_actual, view
    old_text = (directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = directory / (view + '.received.txt')
    if not text_path.exists():
        text_path = directory / (view + '.verified.txt')
    new_text = text_path.read_text(encoding='utf-8-sig')
    assert old_text.count(old_errors) == new_text.count(new_errors) == 2
    old_text = old_text.replace(old_errors, new_errors)
    for node in added_roots:
        block = '+ ' + node['label'] + '\n'
        if node['children']:
            block += '+ â””â”€ ' + node['children'][0]['label'] + '\n'
        block += '\n'
        assert new_text.count(block) == 2, (view, block)
        new_text = new_text.replace(block, '')
    old_lines = old_text.splitlines()
    new_lines = new_text.splitlines()
    assert len(old_lines) == len(new_lines)
    for old, new in zip(old_lines, new_lines):
        if old == new:
            continue
        assert any(label in old and label in new for label in changed_labels)
        assert old.replace(' (depth limit)', '').replace(' (changes below depth limit)', '') == new.replace(' (depth limit)', '')
    reviews.append({'view': view, 'sourceProofPending': True, 'metadataChecks': metadata_checks, 'rootChecks': root_checks, 'addedRoots': len(added_roots), 'addedDepthMarkers': added_markers,
                    'removedDepthMarkers': removed_markers, 'allOtherJsonAndRenderedOutputExact': True,
                    'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(text_path.read_bytes()).hexdigest()})
for name, configuration in jobs.items():
    (root / 'constructor-ocelot-added-root-source-review' / (name + '.json')).write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / 'constructor-ocelot-added-root-view-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reviews))
