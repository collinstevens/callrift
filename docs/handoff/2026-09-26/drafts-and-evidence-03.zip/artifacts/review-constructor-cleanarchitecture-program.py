from pathlib import Path
import copy
import hashlib
import json
import re
import subprocess

root = Path.cwd()
artifacts = root / 'artifacts'
target = artifacts / 'constructor-cleanarchitecture-program-trial'
assert not target.exists()
target.mkdir()
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
cli = artifacts / 'top-level-constructor-cli-tests/candidate-ready/callrift.dll'
assert hashlib.sha256(cli.with_name('Callrift.Core.dll').read_bytes()).hexdigest() == 'e94daf21a34d0ff093c0ebbec85da5c450b540ade524c8f66d2ce662a3053116'
reports = []
for name in ['cleanarchitecture-handler-rename', 'cleanarchitecture-logging-di', 'cleanarchitecture-validation-lambda']:
    case = next(case for case in manifest if case['id'] == name)
    baseline = artifacts / 'constructor-exact-corpus/Snapshots'
    raw = (baseline / (name + '-json.received.txt')).read_text(encoding='utf-8-sig').split('stdout:\n', 1)[1]
    old, length = json.JSONDecoder().raw_decode(raw)
    old_json_error = raw[length:].removeprefix('\n').split('stderr:\n', 1)[1]
    expected = copy.deepcopy(old)
    removed = [item for item in old['diagnostics'] if item['message'] == 'Cannot bind implicit base constructor for new Program.' and item['location']['path'] == 'src/Web/Program.cs']
    assert len(removed) == 1
    expected['diagnostics'] = [item for item in old['diagnostics'] if item not in removed]
    rendered = (baseline / (name + '.received.txt')).read_text(encoding='utf-8-sig')
    for format in ['text', 'md', 'json']:
        result = subprocess.run(['dotnet', str(cli), 'diff', case['before'], case['after'], '--format', format, '--color', 'never', *case['options']],
            cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / case['cacheName'], capture_output=True, text=True, encoding='utf-8', timeout=180)
        for suffix, content in [('stdout', result.stdout), ('stderr', result.stderr)]:
            (target / (name + '-' + format + '.' + suffix)).write_text(content, encoding='utf-8', newline='\n')
        assert result.returncode == 0
        if format == 'json':
            assert expected == json.loads(result.stdout), name
            error = old_json_error
        else:
            section = rendered.split('format: ' + format + '\nexit: 0\nstdout:\n', 1)[1]
            output, error = section.split('stderr:\n', 1)
            error = error.split('\nformat: ', 1)[0]
            assert output == result.stdout, (name, format)
        assert 'Cannot bind implicit base constructor for new Program.' not in error
        expected_error, count = re.subn(r'(\d+) additional diagnostics;', lambda match: str(int(match.group(1)) - 1) + ' additional diagnostics;', error)
        assert count == 1 and expected_error.rstrip('\n') == result.stderr.rstrip('\n'), (name, format, 'stderr')
    reports.append({'case': name, 'removedDiagnostic': removed[0], 'allOtherJsonExact': True, 'renderedStdoutExact': True, 'stderrDelta': 'one fewer additional diagnostic'})
    print(json.dumps(reports[-1]), flush=True)
(target / 'review.json').write_text(json.dumps({'productionPromoted': False, 'fullConstructorViewsReviewed': False, 'reviews': reports}, indent=2) + '\n', encoding='utf-8', newline='\n')
