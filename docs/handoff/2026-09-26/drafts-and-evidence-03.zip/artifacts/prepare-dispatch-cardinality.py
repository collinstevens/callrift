from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/receiver-context-core'
target = root / 'artifacts/dispatch-cardinality-core'
assert not target.exists()
target.mkdir()
files = []
for file in source.rglob('*'):
    relative = file.relative_to(source)
    if not file.is_file() or any(part in ['bin', 'obj'] for part in relative.parts):
        continue
    destination = target / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(file, destination)
    files.append({'path': relative.as_posix(), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
(root / 'artifacts/dispatch-cardinality-original-inputs.json').write_text(json.dumps(files, indent=2) + '\n', encoding='utf-8', newline='\n')
file = target / 'Diffing/TreeExpander.cs'
text = file.read_text(encoding='utf-8')
text = text.replace('    internal string? InvocationKey { get; init; }', '    internal string? InvocationKey { get; init; }\n    internal string? DispatchLabel { get; init; }\n    internal Func<CallTree>? ExpandDispatch { get; init; }')
text = text.replace('        return tree with\n        {\n            Kind = "member",', '        CallTree AsRoot(CallTree value) => value with\n        {\n            Kind = "member",')
text = text.replace('BodyChanged = tree.BodyChanged || changed.Contains(key),\n            Side = tree.Side! with { Relation = "definition", CallSites = [] }\n        };', 'BodyChanged = value.BodyChanged || changed.Contains(key),\n            Side = value.Side! with { Relation = "definition", CallSites = [] },\n            ExpandDispatch = value.ExpandDispatch is { } expand ? () => AsRoot(expand()) : null\n        };\n        return AsRoot(tree);')
text = text.replace('            trees.Add(tree with\n            {', '            tree = tree with\n            {')
text = text.replace('            });\n        }\n        return trees;', '''            };
            if (possibleTargets.Count > 0)
                tree = tree with { DispatchLabel = call.Label };
            if (possibleTargets.Count == 1)
            {
                var compact = tree;
                tree = tree with
                {
                    ExpandDispatch = () =>
                    {
                        var implementation = ExpandMember(possibleTargets[0], active, depth + 1);
                        var target = implementation with
                        {
                            Key = call.SemanticTargets?[0] ?? possibleTargets[0],
                            Label = "⇢ " + implementation.Label,
                            Kind = "dispatchTarget"
                        };
                        return compact with
                        {
                            Label = call.Label,
                            MatchName = call.Key,
                            Signature = call.Key,
                            Children = new[] { target }.Concat(children).ToArray(),
                            BodyChanged = false,
                            Detail = null,
                            Omission = null,
                            ExpandDispatch = null
                        };
                    }
                };
            }
            trees.Add(tree);
        }
        return trees;''')
file.write_text(text, encoding='utf-8', newline='\n')
file = target / 'Diffing/TreeDiffer.cs'
text = file.read_text(encoding='utf-8')
text = text.replace('            if (left.Key == right.Key && left.Label == right.Label) return true;', '            if (left.Key == right.Key && (left.Label == right.Label\n                || left.DispatchLabel is not null && left.DispatchLabel == right.DispatchLabel)) return true;')
text = text.replace('                var right = after[newIndex++];', '                var right = after[newIndex++];\n                if (left.Label != right.Label && left.DispatchLabel is not null && left.DispatchLabel == right.DispatchLabel)\n                {\n                    left = left.ExpandDispatch?.Invoke() ?? left;\n                    right = right.ExpandDispatch?.Invoke() ?? right;\n                }')
file.write_text(text, encoding='utf-8', newline='\n')
check = root / 'artifacts/dispatch-cardinality-check/Check.csproj'
check.write_text(check.read_text(encoding='utf-8').replace('../receiver-context-core/', '../dispatch-cardinality-core/'), encoding='utf-8', newline='\n')
