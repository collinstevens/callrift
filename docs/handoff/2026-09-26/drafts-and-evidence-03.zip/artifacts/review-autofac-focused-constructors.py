from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path('artifacts')
directory = root / 'constructor-depth-corpus/Snapshots'
output = root / 'constructor-autofac-focused-review'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
base_checks = []
definition_checks = []
reviews = []
depth_proofs = {}
for folder in ['constructor-depth-leaf-source-review', 'constructor-depth-leaf-batch2', 'constructor-depth-leaf-batch3']:
    for report_path in (root / folder).glob('*-compiler-report.json'):
        for record in json.loads(report_path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                depth_proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    start = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[start:])
    return document, content[:start], content[start + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def counter(items):
    return collections.Counter(json.dumps(item, sort_keys=True) for item in items)

for name in ['autofac-any-key-cache', 'autofac-held-pipeline']:
    case = next(case for case in manifest if case['id'] == name)
    for mode in ['source', 'msbuild']:
        view = name + '-' + mode + '-focused'
        path = directory / (view + '-json.received.txt')
        original, prefix, suffix = read(path.with_name(path.name.replace('.received.', '.verified.')))
        actual, new_prefix, new_suffix = read(path)
        expected = copy.deepcopy(actual)
        assert prefix == new_prefix
        if mode == 'source':
            evidence_directory = root / ('constructor-remaining-diagnostic-review' if name == 'autofac-any-key-cache' else 'constructor-diagnostic-source-review')
            configuration = json.loads((evidence_directory / (name + '.json')).read_text(encoding='utf-8'))
            proof = json.loads((evidence_directory / (name + '-report.json')).read_text(encoding='utf-8'))
            assert configuration['revisions'] == [case['before'], case['after']] and not proof['unmatched']
            assert len(proof['records']) == 4 and all(record['provenMissingBase'] for record in proof['records'])
            assert counter(actual['diagnostics']) - counter(original['diagnostics']) == counter(configuration['diagnostics'])
            assert not counter(original['diagnostics']) - counter(actual['diagnostics'])
            expected['diagnostics'] = original['diagnostics']
            assert suffix.replace('166 additional diagnostics;', '168 additional diagnostics;') == new_suffix
        else:
            assert suffix == new_suffix
        removed = []
        mapping = {node['id']: node['id'] for node in nodes(expected['trees'])}
        if name == 'autofac-any-key-cache':
            def strip(items, parent=None):
                result = []
                for index, node in enumerate(items):
                    if node['label'] == 'new Service':
                        assert parent['label'] == 'new KeyedService' and index == 0
                        assert node['kind'] == 'call' and node['change'] == 'unchanged' and node['detail'] is None and node['omission'] is None
                        assert len(node['children']) == 1
                        child = node['children'][0]
                        assert child['label'] == 'new Object' and child['kind'] == 'call' and child['change'] == 'unchanged'
                        assert child['children'] == [] and child['detail'] is None and child['omission'] is None
                        for side in ['before', 'after']:
                            value = node[side]
                            scope = 'source::' if mode == 'source' else 'project:src/Autofac/Autofac.csproj@net10.0::'
                            identity = scope + 'Autofac.Core.Service..ctor()'
                            definition = {'path': 'src/Autofac/Core/Service.cs', 'startLine': 9, 'startColumn': 1, 'endLine': 79, 'endColumn': 2}
                            call_site = parent[side]['definition']
                            assert value == {'symbolId': identity, 'signature': 'Autofac.Core.Service.Service() -> void', 'binding': 'resolved', 'dispatch': 'direct',
                                             'targetIds': [identity], 'definition': definition, 'callSites': [call_site], 'relation': 'call', 'candidates': [], 'origin': 'source'}
                            object_identity = 'source::object..ctor()' if mode == 'source' else 'metadata:System.Runtime::object..ctor()'
                            assert child[side] == {'symbolId': object_identity, 'signature': None, 'binding': 'resolved', 'dispatch': 'direct',
                                                  'targetIds': [object_identity], 'definition': None, 'callSites': [definition], 'relation': 'call', 'candidates': [], 'origin': 'metadata'}
                            base_checks.append({'view': view, 'revision': case[side], 'type': 'Autofac.Core.Service', 'definition': definition, 'callSite': call_site})
                        removed.append(node)
                        continue
                    node['children'] = strip(node['children'], node)
                    result.append(node)
                return result
            expected['trees'] = strip(expected['trees'])
            assert len(removed) == 1
            original_nodes = list(nodes(original['trees']))
            expected_nodes = list(nodes(expected['trees']))
            assert len(original_nodes) == len(expected_nodes)
            mapping = {new['id']: old['id'] for old, new in zip(original_nodes, expected_nodes)}
            for node in expected_nodes:
                node['id'] = mapping[node['id']]
                if node['omission'] and node['omission']['referenceId']:
                    node['omission']['referenceId'] = mapping[node['omission']['referenceId']]
        else:
            selected = [node for node in nodes(expected['trees']) if node['label'] == 'new DefaultRegisteredServicesTracker.DeferredImplementationMap']
            assert len(selected) == 1
            node = selected[0]
            assert not node['children'] and node['omission'] is None
            for side in ['before', 'after']:
                value = node[side]
                assert value['signature'] == 'Autofac.Core.Registration.DefaultRegisteredServicesTracker.DeferredImplementationMap.DeferredImplementationMap() -> void'
                definition_checks.append({'kind': 'implicit-metadata-base-definition', 'revision': case[side], 'view': view, 'location': value['definition'],
                                          'type': 'Autofac.Core.Registration.DefaultRegisteredServicesTracker.DeferredImplementationMap', 'parameterTypes': [],
                                          'baseType': 'System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>'})
                value['signature'] = None
                value['definition'] = None
        comparable_original = copy.deepcopy(original)
        reverse_mapping = {old: new for new, old in mapping.items()}
        removed_depth_markers = 0
        for old, new in zip(nodes(comparable_original['trees']), nodes(expected['trees'])):
            if old['omission'] == new['omission']:
                continue
            assert old['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and old['detail'] == 'depth limit'
            assert new['omission'] is None and new['detail'] is None
            for side in ['before', 'after']:
                if new.get(side):
                    proof = depth_proofs[(view, reverse_mapping[new['id']], side)]
                    assert proof['definition'] == new[side]['definition'] and proof['symbolId'] == new[side]['symbolId']
            old['omission'] = None
            old['detail'] = None
            removed_depth_markers += 1
        assert expected == comparable_original, view
        old_text = (directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
        text_path = directory / (view + '.received.txt')
        if not text_path.exists():
            text_path = directory / (view + '.verified.txt')
        new_text = text_path.read_text(encoding='utf-8-sig')
        assert new_text == (old_text.replace('166 additional diagnostics;', '168 additional diagnostics;') if mode == 'source' else old_text)
        reviews.append({'view': view, 'sourceProofPending': True, 'jsonAndRenderedDifferencesBounded': True, 'removedProductionDepthMarkers': removed_depth_markers,
                        'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(text_path.read_bytes()).hexdigest()})

for filename, key, checks in [('base-config.json', 'calls', base_checks), ('definition-config.json', 'checks', definition_checks)]:
    (output / filename).write_text(json.dumps({'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac', key: checks}, indent=2) + '\n', encoding='utf-8', newline='\n')
(output / 'output-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'views': len(reviews), 'baseCalls': len(base_checks), 'definitions': len(definition_checks)}))
