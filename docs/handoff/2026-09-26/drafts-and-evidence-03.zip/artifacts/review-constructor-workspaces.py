from pathlib import Path
import copy
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

artifacts = Path.cwd() / 'artifacts'
directory = artifacts / 'constructor-exact-workspaces/Snapshots'
result = ET.parse(next((artifacts / 'constructor-exact-workspaces-results').glob('*.trx'))).getroot()
counters = result.find('.//{*}Counters').attrib
assert (counters['passed'], counters['failed'], counters['total']) == ('19', '3', '22')
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    index = text.index('format: json\n')
    start = text.index('{', index)
    value, length = json.JSONDecoder().raw_decode(text[start:])
    return value, text[:start], text[start + length:]
def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])
records = []
for name, signature in [('orders', 'Order.Order(OrderRequest, decimal)'), ('records-partials', 'Order.Order(string)'), ('generator', 'System.Text.RegularExpressions.Generated.Pattern_0.RunnerFactory.RunnerFactory()')]:
    original, prefix, suffix = read(directory / (name + '.verified.txt'))
    received, new_prefix, new_suffix = read(directory / (name + '.received.txt'))
    assert prefix == new_prefix and suffix == new_suffix
    expected = copy.deepcopy(original)
    changed = 0
    for node in nodes(expected['trees']):
        for side in ['before', 'after']:
            value = node.get(side)
            if not value:
                continue
            if name != 'generator' and value['signature'] == signature:
                value['signature'] = signature + ' -> void'
                changed += 1
            if name == 'generator' and value['symbolId'].endswith('.RunnerFactory..ctor()'):
                assert value['signature'] is None and value['definition'] is None
                value['signature'] = signature + ' -> void'
                sources = list((artifacts / 'constructor-generator-review' / side / 'obj/generated').rglob('RegexGenerator.g.cs'))
                assert len(sources) == 1
                source = sources[0].read_text(encoding='utf-8-sig').splitlines()
                assert source[49] == '        private sealed class RunnerFactory : RegexRunnerFactory'
                balance = 0
                end = None
                for index in range(50, len(source)):
                    balance += source[index].count('{') - source[index].count('}')
                    if balance == 0:
                        end = index + 1
                        break
                assert end == 96 and source[95] == '        }'
                value['definition'] = {'path': 'obj/Debug/net10.0/System.Text.RegularExpressions.Generator/System.Text.RegularExpressions.Generator.RegexGenerator/RegexGenerator.g.cs', 'startLine': 50, 'startColumn': 9, 'endLine': 96, 'endColumn': 10}
                changed += 1
    assert changed == 2, (name, changed)
    assert expected == received, name
    path = directory / (name + '.received.txt')
    records.append({'name': name, 'changedSides': changed, 'renderedTextAndMarkdownUnchanged': True, 'allOtherJsonExact': True, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
report = {'reviewed': True, 'productionPromoted': False, 'reviews': records, 'generatedSources': {str(path.relative_to(artifacts)): hashlib.sha256(path.read_bytes()).hexdigest() for path in (artifacts / 'constructor-generator-review').rglob('RegexGenerator.g.cs')}}
(artifacts / 'constructor-workspace-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
for record in records:
    source = directory / (record['name'] + '.received.txt')
    shutil.copy2(source, source.with_name(record['name'] + '.verified.txt'))
print('Reviewed three workspace deltas against literal fixtures and independently emitted generated source; updated only the completed private harness.')
