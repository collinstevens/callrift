from pathlib import Path
import collections
import json
import sys

directory = Path('artifacts/constructor-exact-corpus/Snapshots')

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    if 'format: json\n' in text:
        text = text.split('format: json\n', 1)[1]
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def flatten(nodes, path=()):
    occurrences = collections.Counter()
    for node in nodes:
        side = node.get('after') or node.get('before') or {}
        identity = node['label'] + '|' + str(side.get('symbolId'))
        ordinal = occurrences[identity]
        occurrences[identity] += 1
        key = path + ((identity, ordinal),)
        yield key, node
        yield from flatten(node['children'], key)

for name in sys.argv[1:]:
    suffix = '' if name == 'serilog-msbuild' else '-json'
    before = read(directory / (name + suffix + '.verified.txt'))
    after = read(directory / (name + suffix + '.received.txt'))
    old = dict(flatten(before['trees']))
    new = dict(flatten(after['trees']))
    print(json.dumps({'view': name, 'oldRoots': [node['label'] for node in before['trees']], 'newRoots': [node['label'] for node in after['trees']]}))
    for action, left, right in [('added', new, old), ('removed', old, new)]:
        for path in left.keys() - right.keys():
            node = left[path]
            print(json.dumps({'action': action, 'path': [item[0] for item in path], 'mark': node['change'], 'before': node.get('before'), 'after': node.get('after'), 'omission': node.get('omission')}))
