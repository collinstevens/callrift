from pathlib import Path
import collections
import copy
import hashlib
import json
import re
import subprocess
import sys

root = Path('artifacts')
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema

case_id = sys.argv[1] if len(sys.argv) > 1 else 'autofac-multi-service-registration'
review_name = sys.argv[2] if len(sys.argv) > 2 else 'static-autofac-multi-service-roots-review.json'
name = case_id + '-msbuild-roots'
directory = root / 'static-initialization-callback-corpus/Snapshots'
case = next(value for value in json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8')) if value['id'] == case_id)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def document(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def flatten(nodes):
    for node in nodes:
        yield node
        yield from flatten(node['children'])

def clean(value):
    if isinstance(value, list):
        return [clean(item) for item in value if not isinstance(item, dict) or not item.get('label', '').startswith('possible initialization of ')]
    if isinstance(value, dict):
        return {key: clean(item) for key, item in value.items() if key != 'id'}
    return value

before_path = directory / (name + '-json.verified.txt')
after_path = directory / (name + '-json.received.txt')
before, after = document(before_path), document(after_path)
assert clean(before) == clean(after)
jsonschema.validate(after, json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8')))
source_report = root / ('static-initializer-source-review/' + case_id + '-report.json')
report = json.loads(source_report.read_text(encoding='utf-8'))
key = lambda value: json.dumps({name: value[name] for name in ['revision', 'symbolId', 'definition', 'callSites']}, sort_keys=True)
proven = {key(record['check']): record for record in report['records'] if record['passed']}
source_reports = {source_report.as_posix(): digest(source_report)}
for folder in ['static-initializer-source-batch2-review', 'static-initializer-source-batch3-review']:
    additional = root / folder / (case_id + '-report.json')
    if additional.exists():
        extra_report = json.loads(additional.read_text(encoding='utf-8'))
        proven.update({key(record['check']): record for record in extra_report['records'] if record['passed']})
        source_reports[additional.as_posix()] = digest(additional)
branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
expected_counts = {'possible initialization of ReflectionCacheSet': 1, 'possible initialization of DefaultPropertySelector': 6, 'possible initialization of ResolveRequest': 10, 'possible initialization of ResolutionValueExtensions': 1}
assert dict(collections.Counter(node['label'] for node in branches)) == expected_counts
for branch in branches:
    assert branch['kind'] == 'branch' and branch['change'] == 'unchanged' and branch['omission'] is None and len(branch['children']) == 1
    initializer = branch['children'][0]
    assert initializer['change'] == 'unchanged' and initializer['kind'] == 'call' and initializer['children'] == []
    expected_omission = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if initializer['label'] == 'initialization of DefaultPropertySelector' else None
    assert initializer['omission'] == expected_omission
    for side in ['before', 'after']:
        structural = branch[side]
        value = initializer[side]
        assert structural['relation'] == 'branch' and structural['binding'] == 'structural' and structural['origin'] == 'structural'
        assert structural['symbolId'] is None and structural['targetIds'] == [] and structural['definition'] is None and structural['callSites'] == value['callSites']
        assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call'
        assert value['targetIds'] == [value['symbolId']]
        check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
        record = proven[key(check)]
        assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in record['constructors']]
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
expectations = {
    'src/Autofac/Core/ReflectionCacheSet.cs': ['private static readonly object _cacheAllocationLock = new();'],
    'src/Autofac/Core/Activators/DefaultPropertySelector.cs': ['internal static IPropertySelector OverwriteSetValueInstance { get; } = new DefaultPropertySelector(false);', 'internal static IPropertySelector PreserveSetValueInstance { get; } = new DefaultPropertySelector(true);'],
    'src/Autofac/ResolveRequest.cs': ['internal static readonly IEnumerable<Parameter> NoParameters = Enumerable.Empty<Parameter>();'],
    'src/Autofac/ResolutionValueExtensions.cs': ['private static readonly IEnumerable<Parameter> _noParameters = Enumerable.Empty<Parameter>();']}
blobs = {}
for path, snippets in expectations.items():
    ids = []
    for side in ['before', 'after']:
        revision = case[side]
        source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
        assert all(snippet in source for snippet in snippets)
        ids.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
    assert ids[0] == ids[1]
    blobs[path] = ids[0]
before_text_path = directory / (name + '.verified.txt')
after_text_path = directory / (name + '.received.txt')
before_text = before_text_path.read_text(encoding='utf-8-sig')
after_text = after_text_path.read_text(encoding='utf-8-sig')
plain = after_text.split('format: text\nexit: 0\nstdout:\n')[1].split('stderr:\n')[0]
markdown = after_text.split('format: md\nexit: 0\nstdout:\n```diff\n')[1].split('```\nstderr:\n')[0]
assert plain == markdown
def lines(text):
    return [re.sub(r'^[ │├└─]*', '', line) for line in text.splitlines() if 'possible initialization of ' not in line]
old_lines, new_lines = lines(before_text), lines(after_text)
assert len(old_lines) == len(new_lines)
changed = [(left, right) for left, right in zip(old_lines, new_lines) if left != right]
assert changed == [('Enforce.ArgumentTypeIsFunction (depth limit)', '…')] * 2
proof = {'view': name, 'initializerBranches': len(branches), 'allPriorJsonPreservedExceptNodeIds': True, 'schemaV1': True, 'textMarkdownParity': True, 'sourceReport': source_report.as_posix(), 'sourceReportSha256': digest(source_report), 'unchangedSourceBlobs': blobs, 'files': {path.name: digest(path) for path in [after_path, after_text_path]}, 'repeatStatus': 'pending', 'review': 'DefaultPropertySelector contains two source constructor calls and retains depth-limit omission. The other three initializers contain only metadata calls, hidden without externals. Added unchanged branches shift the two-sibling rendering context for FactoryGenerator; all other prior JSON and normalized rendered lines are preserved. Accessor bodies remain outside this static initialization review.'}
proof['sourceReports'] = source_reports
(root / review_name).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed all 18 initializer branches in the latest Autofac restored automatic view, including independent source, depth omissions, and rendering context.')
