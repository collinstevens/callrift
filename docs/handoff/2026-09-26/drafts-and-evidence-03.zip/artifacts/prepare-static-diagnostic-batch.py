from pathlib import Path
import json
import shutil

root = Path('artifacts')
source = root / 'static-diagnostic-source-refined-review'
target = root / 'static-diagnostic-source-batch-review'
assert not target.exists()
target.mkdir()
for name in ['Program.cs', 'Check.csproj']:
    shutil.copy2(source / name, target / name)
path = target / 'Program.cs'
text = path.read_text(encoding='utf-8-sig')
marker = '        else if (diagnostic.GetProperty("code").GetString() == "unresolved-static-initializer")'
insert = '''        else if (diagnostic.GetProperty("code").GetString() == "static-initializer-order")
        {
            var node = matches.OfType<TypeDeclarationSyntax>().SingleOrDefault();
            if (node is null || model.GetDeclaredSymbol(node, timeout.Token) is not INamedTypeSymbol type) continue;
            var declarations = type.DeclaringSyntaxReferences.Select(reference => reference.GetSyntax(timeout.Token)).OfType<TypeDeclarationSyntax>()
                .OrderBy(declaration => declaration.SyntaxTree.FilePath, StringComparer.Ordinal).ThenBy(declaration => declaration.SpanStart).ToArray();
            var parts = declarations.Where(declaration => declaration.Members.Any(member => member switch
            {
                BaseFieldDeclarationSyntax field => field.Modifiers.Any(SyntaxKind.StaticKeyword) && !field.Modifiers.Any(SyntaxKind.ConstKeyword)
                    && field.Declaration.Variables.Any(variable => variable.Initializer is not null),
                PropertyDeclarationSyntax property => property.Modifiers.Any(SyntaxKind.StaticKeyword) && property.Initializer is not null,
                _ => false
            })).ToArray();
            var passed = parts.Length > 1 && declarations.All(declaration => declaration.Modifiers.Any(SyntaxKind.PartialKeyword))
                && declarations[0].SyntaxTree == tree && declarations[0].Span == node.Span;
            if (passed) proven.Add(index);
            records.Add(new { revision, index, path, type = type.ToDisplayString(), passed,
                parts = parts.Select(part => new { path = part.SyntaxTree.FilePath, line = part.GetLocation().GetLineSpan().StartLinePosition.Line + 1,
                    sourceBlob = snapshot.Files.Single(file => file.Path == part.SyntaxTree.FilePath).ContentId }).ToArray() });
        }
'''
assert marker in text
path.write_text(text.replace(marker, insert + marker), encoding='utf-8', newline='\n')
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
inventory = json.loads((root / 'static-initialization-corpus-review-inventory.json').read_text(encoding='utf-8'))
jobs = []
for case in manifest:
    if case['id'] == 'orchardcore-role-submission':
        continue
    views = [view for view in inventory['views'] if view['view'].startswith(case['id'] + '-source-') and view['addedDiagnostics']]
    if not views:
        continue
    unique = {json.dumps(value, sort_keys=True): value for view in views for value in view['addedDiagnostics']}
    config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'revisions': [case['before'], case['after']], 'diagnostics': list(unique.values()), 'views': [view['view'] for view in views]}
    (target / (case['id'] + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
    jobs.append(case['id'])
(target / 'jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(jobs))
