from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
artifacts = root / 'artifacts'
cli = artifacts / 'workspace-lock-cli-ready/callrift.dll'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = json.loads((artifacts / 'workspace-lock-validation-checkpoint.json').read_text(encoding='utf-8'))
for prefix in ('', 'msbuild/'):
    assert digest(cli.parent / (prefix + 'Callrift.Core.dll')) == expected['candidateCoreSha256']
    assert digest(cli.parent / (prefix + 'Callrift.MSBuild.dll')) == expected['candidateAdapterSha256']
inputs = {str(p.relative_to(cli.parent)): digest(p) for p in cli.parent.rglob('*') if p.is_file()}
(artifacts / 'orchardcore-esmodule-stable-json-repeat-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8')
prior = json.loads((artifacts / 'orchardcore-esmodule-stable-additional-all-formats-terminal.json').read_text(encoding='utf-8'))['records']
jobs = [r for r in prior if r['format'] == 'json']
assert len(jobs) == 4
records = []
for job in jobs:
    assert all(digest(cli.parent / name) == value for name, value in inputs.items())
    name = job['name'].replace('stable-additional', 'stable-json-repeat')
    output = artifacts / (name + '.json')
    error = artifacts / (name + '.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), *job['command'][2:]]
    assert all(not any(c in arg for c in ['"', '%', '!', '\r', '\n']) for arg in command)
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(['mise', 'exec', '-c', 'dotnet ' + ' '.join(chr(34) + arg + chr(34) for arg in command[1:])], cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=900)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    baseline = artifacts / (job['name'] + '.json')
    record = {'name': name, 'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'sha256': digest(output), 'baselineSha256': digest(baseline), 'stderrSha256': digest(error), 'byteIdentical': output.read_bytes() == baseline.read_bytes(), 'accepted': False}
    data = json.loads(output.read_text(encoding='utf-8-sig'))
    record.update(roots=len(data['trees']), diagnostics=len(data['diagnostics']), jsonEqual=data == json.loads(baseline.read_text(encoding='utf-8-sig')))
    records.append(record)
    (artifacts / 'orchardcore-esmodule-stable-json-repeat-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    assert code == 0 and record['byteIdentical'] and record['jsonEqual']
assert all(digest(cli.parent / name) == value for name, value in inputs.items())
(artifacts / 'orchardcore-esmodule-stable-json-repeat-terminal.json').write_text(json.dumps({'complete': True, 'allByteIdentical': True, 'records': records, 'accepted': False}, indent=2) + '\n', encoding='utf-8')
