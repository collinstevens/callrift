from pathlib import Path
import copy
import hashlib
import json
import re

root = Path.cwd()
artifacts = root / 'artifacts'
trial = artifacts / 'constructor-top-level-aspnetcore-trial'
baseline = artifacts / 'constructor-exact-corpus/Snapshots'
run = json.loads((trial / 'run.json').read_text(encoding='utf-8'))
assert len(run['runs']) == 6 and all(item['exitCode'] == 0 for item in run['runs'])
records = []
for view in ['source-roots', 'source-focused']:
    name = 'aspnetcore-js-task-handling-' + view
    raw = (baseline / (name + '-json.received.txt')).read_text(encoding='utf-8-sig')
    payload = raw.split('stdout:\n', 1)[1]
    original, length = json.JSONDecoder().raw_decode(payload)
    original_error = payload[length:].removeprefix('\n').split('stderr:\n', 1)[1]
    received = json.loads((trial / (view + '-json.stdout')).read_text(encoding='utf-8'))
    expected = copy.deepcopy(original)
    removed = [item for item in expected['diagnostics'] if item['code'] == 'unresolved-call'
        and item['message'] == 'Cannot bind implicit base constructor for new Program.'
        and item['location']['path'] == 'src/OpenApi/sample/Program.cs']
    assert len(removed) == 1
    expected['diagnostics'] = [item for item in expected['diagnostics'] if item not in removed]
    assert expected == received, view + ': unexpected JSON delta'
    rendered = (baseline / (name + '.received.txt')).read_text(encoding='utf-8-sig')
    for format in ['text', 'md', 'json']:
        if format == 'json':
            error = original_error
        else:
            section = rendered.split('format: ' + format + '\nexit: 0\nstdout:\n', 1)[1]
            output, error = section.split('stderr:\n', 1)
            error = error.split('\nformat: ', 1)[0]
            assert output == (trial / (view + '-' + format + '.stdout')).read_text(encoding='utf-8'), (view, format)
        assert 'Cannot bind implicit base constructor for new Program.' not in error
        expected_error, count = re.subn(r'(\d+) additional diagnostics;', lambda match: str(int(match.group(1)) - 1) + ' additional diagnostics;', error)
        assert count == 1
        actual_error = (trial / (view + '-' + format + '.stderr')).read_text(encoding='utf-8')
        assert expected_error.rstrip('\n') == actual_error.rstrip('\n'), (view, format, 'stderr')
    records.append({'view': view, 'removedDiagnostic': removed[0], 'allOtherJsonExact': True, 'renderedStdoutExact': True, 'stderrDelta': 'one fewer additional diagnostic',
        'jsonSha256': hashlib.sha256((trial / (view + '-json.stdout')).read_bytes()).hexdigest()})
report = {'coreSha256': run['coreSha256'], 'reviewedTopLevelCorrection': True, 'fullConstructorViewReviewComplete': False, 'productionPromoted': False, 'views': records}
(artifacts / 'constructor-top-level-aspnetcore-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Both pinned ASP.NET Core views remove exactly the false Program warning; all trees, locations, other diagnostics, text, and Markdown are unchanged.')
