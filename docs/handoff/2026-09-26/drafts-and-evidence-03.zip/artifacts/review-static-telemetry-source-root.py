import json
from static_review_support import root, digest, prior_fields_and_diagnostics

removed_text = '\n+ new TelemetrySource\n+ └─ TelemetrySource.GetVersion (changes below depth limit)\n'

def remove_constructor(text):
    assert text.count(removed_text) == 1
    return text.replace(removed_text, '')

before, after, review = prior_fields_and_diagnostics('polly-telemetry-source-source-roots', 'new TelemetrySource', remove_constructor)
removed = [node for node in before['trees'] if node['label'] == 'new TelemetrySource']
assert len(removed) == 1 and removed[0]['change'] == 'added'
assert removed[0]['after']['symbolId'] == 'source::Polly.Telemetry.TelemetrySource..ctor()'
assert len(after['trees']) == len(before['trees']) - 1
evidence_path = root / 'static-polly-telemetry-path-evidence.json'
evidence = json.loads(evidence_path.read_text(encoding='utf-8'))
assert len(evidence['paths']) == 2
for path in evidence['paths']:
    from pathlib import Path
    assert digest(Path(path['path'])) == path['sha256']
review.update(sourceAndCliEvidenceSha256=digest(evidence_path), review='The singleton initializer connects the formerly isolated private TelemetrySource constructor to TelemetryListenerImpl and its callers. Only that root disappears. All other prior fields and rendered lines remain unchanged; twenty added static initializer diagnostics have independent compiler evidence.')
(root / 'static-telemetry-source-root-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed latest source automatic telemetry view: one connected constructor root removed and twenty proven diagnostics added.')
