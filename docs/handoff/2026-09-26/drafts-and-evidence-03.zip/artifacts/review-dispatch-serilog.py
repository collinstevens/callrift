from pathlib import Path
import copy
import hashlib
import json
import subprocess

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'dispatch-cycle-corpus/Snapshots'
name = 'serilog-null-key'
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])
before = read(directory / (name + '-json.verified.txt'))
after = read(directory / (name + '-json.received.txt'))
expected = copy.deepcopy(before)
indexed = {node['id']: node for node in nodes(expected['trees'])}
visitor = indexed['n80']
assert visitor['label'] == 'LogEventPropertyValueVisitor<TState, TResult>.Visit'
for identifier in ['n136', 'n141', 'n167']:
    node = indexed[identifier]
    assert node['label'] == visitor['label'] and node['change'] == 'modified'
    assert node['detail'] == 'changes below depth limit' and node['omission']['reason'] == 'depth-limit'
    assert not node['children']
    assert all(node[side]['targetIds'] == visitor[side]['targetIds'] for side in ['before', 'after'])
    node['change'] = 'unchanged'
    node['detail'] = '↺ cycle'
    node['omission'] = {'reason': 'cycle', 'symbolId': node['before']['symbolId'], 'referenceId': 'n80'}
assert expected == after
traces = []
for side in ['before', 'after']:
    path = artifacts / f'dispatch-serilog-trace/{side}.jsonl'
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert rows[0]['Diagnostics'] == 1
    members = {row['Key']: row for row in rows[1:]}
    visitors = [row for row in members.values() if row['Label'] == visitor['label'] and 'this=Callrift.Source::global::Serilog.Formatting.Json.JsonValueFormatter<>' in row['Key']]
    assert len(visitors) == 1 and visitors[0]['Key'].endswith('!')
    current = visitors[0]
    for kind in ['Sequence', 'Structure', 'Dictionary']:
        call = next(call for call in current['Calls'] if call['Label'].endswith('.Visit' + kind + 'Value'))
        assert len(call['Targets']) == 1
        implementation = members[call['Targets'][0]]
        assert implementation['Label'] == 'JsonValueFormatter.Visit' + kind + 'Value'
        back = next(call for call in implementation['Calls'] if call['Label'] == visitor['label'])
        assert back['Targets'] == [current['Key']]
    traces.append({'side': side, 'revision': rows[0]['revision'], 'visitorKey': current['Key'], 'exactCyclePaths': 3, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
old_text = (directory / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
new_text = (directory / (name + '.received.txt')).read_text(encoding='utf-8-sig')
replacements = {
    '        ├─ Guard.AgainstNull\n        ├─ if (value is ScalarValue sv)\n': '        ├─ …\n',
    '        │  └─ LogEventPropertyValueVisitor<TState, TResult>.VisitSequenceValue → JsonValueFormatter.VisitSequenceValue\n        │     ├─ Guard.AgainstNull\n        │     └─ for (i < sequence.Elements.Count)\n~       │        └─ LogEventPropertyValueVisitor<TState, TResult>.Visit (changes below depth limit)\n': '',
    '        │  └─ LogEventPropertyValueVisitor<TState, TResult>.VisitStructureValue → JsonValueFormatter.VisitStructureValue\n        │     ├─ for (i < structure.Properties.Count)\n        │     │  ├─ JsonValueFormatter.WriteQuotedJsonString (depth limit)\n~       │     │  └─ LogEventPropertyValueVisitor<TState, TResult>.Visit (changes below depth limit)\n        │     └─ if (_typeTagName != null && structure.TypeTag != null)\n': '',
    '~       │        └─ LogEventPropertyValueVisitor<TState, TResult>.Visit (changes below depth limit)\n': '        │        └─ LogEventPropertyValueVisitor<TState, TResult>.Visit (↺ cycle)\n'
}
for old, new in replacements.items():
    assert old_text.count(old) == 2, repr(old)
    old_text = old_text.replace(old, new)
assert old_text == new_text
outputs = [part.split('stderr:\n', 1)[0].rstrip('\n') for part in new_text.split('stdout:\n')[1:]]
assert len(outputs) == 2 and outputs[1] == '```diff\n' + outputs[0] + '\n```'
repo = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/serilog'
sources = {}
for trace in traces:
    for path in ['src/Serilog/Data/LogEventPropertyValueVisitor.cs', 'src/Serilog/Formatting/Json/JsonValueFormatter.cs']:
        blob = subprocess.check_output(['git', '-C', repo, 'rev-parse', trace['revision'] + ':' + path], text=True).strip()
        sources[trace['revision'] + ':' + path] = blob
report = {'reviewed': True, 'promoted': False, 'jsonDelta': 'Exactly three depth-limit nodes become cycles referencing n80; all other JSON is identical.', 'textDelta': 'Those cycle nodes no longer mark changes below depth; the existing unchanged-context window hides unchanged sequence/structure paths.', 'allLocationsUnchanged': True, 'diagnosticsAndCoverageUnchanged': True, 'traces': traces, 'immutableSources': sources, 'snapshots': {file.name: hashlib.sha256(file.read_bytes()).hexdigest() for file in directory.glob(name + '*.received.txt')}}
(artifacts / 'dispatch-serilog-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed exactly three cycle corrections, both rendered formats, and six source-backed invocation paths. No production snapshots promoted.')
