from pathlib import Path
from datetime import datetime
import hashlib
import subprocess

root = Path.cwd()
stamp = datetime.now().astimezone().isoformat(timespec='seconds')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '9ccabc3c7bfe834cfa699b0ca7e6922f94115055'
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip() == ''
dispatch = f'''## Signed checkpoint, {stamp}

Signed master checkpoint {head} integrates five dispatch files, 24 CLI regressions, four independently reviewed snapshots, DESIGN.md, and real-world-cases/reviews/dispatch-cardinality.md. It preserves the separate signed Git cleanup fix405a245. Identity/signing configuration was inspected immediately before commit; signing and EditorConfig/format/conventional-commit hooks succeeded. No signature verification was performed. The tracked tree is clean.

Final isolated dispatch505bc5fe results: all403 scenarios pass in55m5s; all22 workspaces pass in6m15s; the89-view corpus finishes88PASS/1snapshotdifference in1h1m. The sole Serilog null-key difference is independently reviewed: exactly three depth-limit nodes become cycle references to active visitor n80. All other JSON, locations, diagnostics, and coverage are exact. Both immutable revisions' source and invocation traces establish six return paths. Text/Markdown changes follow the existing unchanged-context window. The focused replay passes1/1 in4s with reviewed expectations. Evidence: dispatch-serilog-review.json and dispatch-serilog-repeat-results. All89 views are accounted for by the full run plus this focused repeat; this is not a single89-pass run.

Integrated packaged Release binaries pass38 focused dispatch/Git checks in2m39s. An initial private38-case harness omitted production's DisableTestParallelization attribute and had36passes/2trace-file-sharing failures. A separate serialized harness restores the production setting and passes all38; both results are retained. Integrated formatting and package smoke pass, including installed tool, restored worker, consumer, and dnx. Package version0.1.0-dispatch-cardinality remains local.

The older405a245 push hook was invalidated by my update of two scenario snapshot files while it still used the preceding binary. It reported the dispatch-added mismatch at20m58s. The received output is preserved in git-push-interference-dispatch-added.received.txt and the full log in push-git-cancellation-exit.log. I stopped only the verified Git push process tree68196 after observing that mismatch. Taskkill reported an already-exited intermediary; subsequent process inspection confirmed all normal scenario processes stopped. This run provides no passing383-scenario claim. No product change was made to hide its failure.

The new exact9ccabc3 push began12:24 in session92694 and completed its build. Its full407-scenario hook is live, with Git PIDs32664/41696 and dotnet59940 confirmed12:26. origin/master remains a32cfc4 until the hook succeeds. The push includes both405a245 and9ccabc3. Do not rebuild normal Debug outputs, change scenario expectations, or otherwise mutate inputs read by this hook. Keep further implementation and expectations in isolated harnesses until it exits. After any such prior interference, rerun the complete affected gate against the coherent checkpoint.

Constructor-only23d1c8c6 and record-copy work remain unpromoted. No new real-world pair is accepted. Final actual three-OS CI, full performance evidence, at least30more pairs, remaining semantic functionality, and release checks remain mandatory.

'''
path = root / 'artifacts/dispatch-cardinality-progress.md'
old = path.read_text(encoding='utf-8')
heading, rest = old.split('\n', 1)
path.write_text(heading + '\n\n' + dispatch + rest.lstrip(), encoding='utf-8', newline='\n')
record_hash = hashlib.sha256((root / 'artifacts/record-copy-core/bin/Debug/net11.0/Callrift.Core.dll').read_bytes()).hexdigest()
initialization = f'''## Latest validation, {stamp}

Constructor Core23d1c8c6 passes all58 CLI checks on the exact build in8m36s (constructor-exact-cli-results). The22 workspace run finishes19PASS/3snapshotdifferences in5m25s. All three deltas have strict independent reviews in constructor-workspace-review.json: orders and records-partials add canonical -> void signatures to two sides each; generator resolves the implicit RunnerFactory constructor's signature and declaration span. A separately emitted regex generator source establishes the exact class span50:9–96:10 at both revisions. All other JSON, text, Markdown, and stderr are identical. Only the completed private workspace harness expectations were updated; focused three-case repeat session11398 is pending.

Full constructor-only validation remains live:465scenarios session98858 (dotnet46860) and89corpus views session50842 (dotnet45216), confirmed12:26. Both started12:11 with frozen Core23d1c8c6 and matching worker039cf4c. Existing expectations intentionally remain unchanged. Several scenario and corpus snapshots differ and need independent source review; no broad passing result is claimed. Do not mutate these sources/binaries or accept received files unread.

Record with-expression probes establish a separate omission on23d1c8c6. Both sealed and inherited record copies execute the copy constructor at runtime, but focused diff/reach omit the path. Explicit-copy and struct controls behave as expected. Isolated record-copy-core SHA256{record_hash} indexes synthesized clone members and binds with calls via IWithOperation.CloneMethod. Its four initial probes pass; wider validation is outstanding. It includes the constructor changes and is not production-ready. Exact source/probe evidence and remaining cases are artifacts/record-copy-progress.md. Do not infer record-copy coverage from constructor-only runs.

Static initialization remains unimplemented. Constructor performance and broad output review remain open. Production master9ccabc3 contains dispatch and Git cleanup only.

'''
path = root / 'artifacts/initialization-audit-progress.md'
old = path.read_text(encoding='utf-8')
heading, rest = old.split('\n', 1)
path.write_text(heading + '\n\n' + initialization + rest.lstrip(), encoding='utf-8', newline='\n')
goal = root / 'GOAL.md'
content = goal.read_text(encoding='utf-8')
rows = {
    '| Signed checkpoints and working tree |': '| Signed checkpoints and working tree | Signed master9ccabc3 preserves calls across dispatch target changes, adds24 regressions, and promotes4 independently reviewed snapshots. Its parent405a245 fixes cancelled Git-process cleanup. Latest pushed checkpoint is a32cfc4 after379 scenarios passed. Exact9ccabc3 push session92694 is running the full407-scenario hook after build. The tracked tree is clean. GOAL.md stays locally excluded. |',
    '| Repeatability and actual supported OS evidence |': '| Repeatability and actual supported OS evidence | Dispatch9ccabc3 has403 isolated scenarios,22 workspaces,24 byte-identical query comparisons,38 integrated packaged checks, and89 corpus views accounted for by88 full-run passes plus one reviewed/focused replay. a32cfc4 is pushed after379 scenarios passed. CI36177017184(a32) and36171714134(receiver) remain in progress; latest completed success36153634040 is older generic context. Prior automatic review blocked older failure-detail inspection and manual full-case dispatch. Final actual three-OS verification remains mandatory. |',
    '| Packaging |': '| Packaging | Dispatch9ccabc3 passes local installed tool, dnx, separate library consumer, and packaged MSBuild worker smoke checks with package version0.1.0-dispatch-cardinality. .NET11, identities, AGPL/license notices, and lowercase branding are preserved. Later unintegrated constructor changes have not passed packaging. No publication is authorized. |'
}
content = '\n'.join(next((replacement for prefix, replacement in rows.items() if line.startswith(prefix)), line) for line in content.split('\n'))
content += f'''\n{stamp}: This goal turn made implementation, independent review, and signed-checkpoint progress. Full dispatch validation completed403/403 scenarios and22/22 workspaces. The89-view corpus had88passes and one independently reviewed Serilog cycle correction; its focused repeat passed. Signed9ccabc3 integrates the reviewed dispatch implementation,24 regressions,four snapshots, and docs. All38 combined packaged checks, formatting, and package smoke pass. The first private combined harness lacked production's serialization setting and had two trace-file sharing failures; a separate corrected harness passes. The old405 push hook read the updated checkout snapshots with an older binary and failed dispatch-added; it was deliberately stopped and superseded by the full407-case hook on9ccabc3(session92694). No passing383 result is claimed. The tracked tree is clean and origin/master remainsa32 until the new hook succeeds.\n\nConstructor23d1c8c6 passes58 exact-build CLI checks. Its22 workspaces produced19passes plus3 strictly reviewed signature/implicit-definition differences; focused replay11398 is pending. Independently emitted regex generator sources confirm RunnerFactory's exact declaration span at both pins. Full465 constructor scenarios98858 and89-view corpus50842 are live from frozen inputs and already have unaccepted differences. Record with-expression probes reveal a separate silent copy-constructor path omission; an isolated compiler-bound clone prototype passes four initial runtime/API probes but lacks broad validation. Static initialization, other mandatory semantic work,30additional pairs, full performance matrix, and finalCI remain open. Current evidence and live handles are artifacts/dispatch-cardinality-progress.md, initialization-audit-progress.md, and record-copy-progress.md.\n'''
goal.write_text(content, encoding='utf-8', newline='\n')
print('Recorded signed checkpoint, validation provenance, invalidated run, and live next-stage work.')
