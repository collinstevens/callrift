from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ElementTree

root = Path.cwd()
source = root / 'artifacts/receiver-context-delegate-corpus/Snapshots'
target = root / 'tests/Callrift.RealWorldCases/Snapshots'
expected_core = '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'
reports = ['receiver-context-all-autofac-review.json', 'receiver-context-inherited-review.json', 'receiver-context-orchard-review.json', 'receiver-context-serilog-review.json']
approved = {}
for name in reports:
    report = json.loads((root / 'artifacts' / name).read_text(encoding='utf-8'))
    assert report['coreSha256'] == expected_core
    for view in report['reviewedViews']:
        assert view['view'] not in approved
        approved[view['view']] = {'review': name, 'sha256': view['jsonSha256']}
report = json.loads((root / 'artifacts/receiver-context-delegate-diagnostic-review.json').read_text(encoding='utf-8'))
assert report['coreSha256'] == expected_core
for view in report['reviewed']:
    name = Path(view['received']).name.removesuffix('-json.received.txt')
    assert name not in approved
    approved[name] = {'review': 'receiver-context-delegate-diagnostic-review.json', 'sha256': view['sha256']}
received = {path.name.removesuffix('-json.received.txt'): path for path in source.glob('*-json.received.txt')}
assert set(approved) == set(received) and len(approved) == 22
trx = root / 'artifacts/receiver-context-delegate-corpus-results/Admin_COLLIN_2026-09-25_08_58_25_net11.0.trx'
run = ElementTree.parse(trx)
namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
results = run.findall('.//t:UnitTestResult', namespace)
assert len(results) == 81
assert sum(result.attrib['outcome'] == 'Passed' for result in results) == 59
promotions = []
for name, evidence in sorted(approved.items()):
    assert hashlib.sha256(received[name].read_bytes()).hexdigest() == evidence['sha256']
    for suffix in ['', '-json']:
        path = source / (name + suffix + '.received.txt')
        if not path.exists():
            continue
        previous = source / (name + suffix + '.verified.txt')
        destination = target / previous.name
        assert destination.read_bytes() == previous.read_bytes(), destination
        value = path.read_text(encoding='utf-8-sig').replace('\r\n', '\n')
        data = b'\xef\xbb\xbf' + value.encode('utf-8')
        promotions.append({'view': name, 'review': evidence['review'], 'source': path.relative_to(root).as_posix(), 'target': destination.relative_to(root).as_posix(), 'beforeSha256': hashlib.sha256(previous.read_bytes()).hexdigest(), 'receivedSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'promotedSha256': hashlib.sha256(data).hexdigest()})
        destination.write_bytes(data)
report = {'coreSha256': expected_core, 'reviewedViews': len(approved), 'unchangedViews': 59, 'files': promotions, 'repeatPending': True}
(root / 'artifacts/receiver-context-snapshot-promotion.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
repeat = root / 'artifacts/receiver-context-accepted-corpus'
assert not repeat.exists()
repeat.mkdir()
for path in (source.parent).glob('*.cs'):
    shutil.copy2(path, repeat / path.name)
shutil.copy2(source.parent / 'Check.csproj', repeat / 'Check.csproj')
shutil.copytree(root / 'real-world-cases', repeat / 'real-world-cases')
shutil.copytree(target, repeat / 'Snapshots')
print(json.dumps({'reviewedViews': len(approved), 'promotedFiles': len(promotions), 'repeatHarnessPrepared': str(repeat.relative_to(root))}))
