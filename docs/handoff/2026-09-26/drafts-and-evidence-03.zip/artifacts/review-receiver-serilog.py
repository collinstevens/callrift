from pathlib import Path
import collections
import copy
import hashlib
import json
import subprocess

directory = Path('artifacts/receiver-context-delegate-corpus/Snapshots')
trace_directory = Path('artifacts/receiver-context-review-trace')
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
types = ['DictionaryValue', 'ScalarValue', 'SequenceValue', 'StructureValue']

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def clean(value):
    if isinstance(value, dict):
        return {key: clean(child) for key, child in value.items() if key not in ['id', 'referenceId']}
    if isinstance(value, list):
        return [clean(child) for child in value]
    return value

def collapse_tostring(nodes_to_visit):
    changes = 0
    for node in nodes_to_visit:
        selected = [child for child in node['children'] if child['label'] == '⇢ LogEventPropertyValue.ToString']
        if selected:
            assert len(selected) == 4 and all(clean(child) == clean(selected[0]) for child in selected)
            assert all(child['omission']['reason'] == 'depth-limit' and not child['children'] for child in selected)
            node['children'] = [child for child in node['children'] if child not in selected or child is selected[0]]
            changes += 1
        changes += collapse_tostring(node['children'])
    return changes

traces = []
for revision in ['0597ddf', '60935b4', '6c3fbcf']:
    path = trace_directory / ('serilog-' + revision + '.jsonl')
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    members = {row['Key']: row for row in rows[1:]}
    assert rows[0]['Diagnostics'] == 1
    for type_name in types:
        selected = [member for member in members.values() if member['Label'] == 'LogEventPropertyValue.ToString' and member['Key'].split('\x1e')[0].endswith('.ToString()') and ';this=Callrift.Source::global::Serilog.Events.' + type_name + '<>!' in member['Key']]
        assert len(selected) == 1
        call = next(call for call in selected[0]['Calls'] if call['Label'] == 'LogEventPropertyValue.ToString')
        assert len(call['Targets']) == 1
        formatter = members[call['Targets'][0]]
        render = next(call for call in formatter['Calls'] if call['Label'] == 'LogEventPropertyValue.Render')
        assert len(render['Targets']) == 1
        assert render['Targets'][0].startswith('source::Serilog.Events.' + type_name + '.Render(')
    visitors = [row for row in members.values() if row['Label'] == 'LogEventPropertyValueVisitor<TState, TResult>.Visit' and ';this=Callrift.Source::global::Serilog.Formatting.Json.JsonValueFormatter<>' in row['Key']]
    assert len(visitors) == 2
    assert {visitor['Key'].endswith('!') for visitor in visitors} == {False, True}
    for visitor in visitors:
        calls = [call for call in visitor['Calls'] if any(call['Label'].endswith('.Visit' + kind + 'Value') for kind in ['Dictionary', 'Sequence', 'Structure'])]
        assert len(calls) == 3
        for call in calls:
            assert len(call['Targets']) == 1 and call['Targets'][0].endswith(';this=Callrift.Source::global::Serilog.Formatting.Json.JsonValueFormatter<>!')
    traces.append({**rows[0], 'narrowedRenderTargets': types, 'visitorContexts': ['JsonValueFormatter', 'exact JsonValueFormatter'], 'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest()})

reports = []
location_reads = {}
for name in ['serilog-extra-arguments', 'serilog-null-key']:
    before = read(directory / (name + '-json.verified.txt'))
    after = read(directory / (name + '-json.received.txt'))
    assert {key: value for key, value in before.items() if key != 'trees'} == {key: value for key, value in after.items() if key != 'trees'}
    candidate = copy.deepcopy(after)
    if name == 'serilog-extra-arguments':
        assert collapse_tostring(candidate['trees']) == 2
        assert clean(candidate) == clean(before)
        assert not (directory / (name + '.received.txt')).exists()
    else:
        root = after['trees'][0]
        assert root['label'] == 'JsonValueFormatter.VisitDictionaryValue' and root['change'] == 'unchanged'
        loop = root['children'][0]
        assert loop['label'] == 'foreach (var element in dictionary.Elements)' and loop['change'] == 'unchanged'
        assert [child['label'] for child in loop['children']] == ['(element.Key.Value ?? "null").ToString', 'JsonValueFormatter.WriteQuotedJsonString', 'else (!(key is null))', 'LogEventPropertyValueVisitor<TState, TResult>.Visit']
        assert [child['change'] for child in loop['children']] == ['removed', 'removed', 'added', 'unchanged']
        removed_call = loop['children'][0]
        added_call = loop['children'][2]['children'][0]
        assert [child['label'] for child in loop['children'][2]['children']] == ['key.ToString', 'JsonValueFormatter.WriteQuotedJsonString']
        for call in [removed_call, added_call]:
            assert [child['label'] for child in call['children']] == ['⇢ LogEventPropertyValue.ToString'] * 4 + ['⇢ MessageTemplate.ToString', '⇢ PropertyToken.ToString', '⇢ TextToken.ToString']
            for target, type_name in zip(call['children'][:4], types):
                assert len(target['children']) == 1 and target['children'][0]['label'] == 'LogEventPropertyValue.ToString'
                inherited_calls = target['children'][0]['children']
                assert [child['label'] for child in inherited_calls] == ['ReusableStringWriter.GetOrCreate', 'LogEventPropertyValue.Render → ' + type_name + '.Render']
                render = inherited_calls[1]
                side = render['before'] or render['after']
                assert side['targetIds'] == ['source::Serilog.Events.' + type_name + '.Render(global::System.IO.TextWriter,string,global::System.IFormatProvider)']
                assert all(node['change'] == call['change'] for node in nodes(target['children']))
        expected_render_children = {
            'DictionaryValue': ['Guard.AgainstNull', 'foreach (var kvp in Elements)'],
            'ScalarValue': ['ScalarValue.Render'],
            'SequenceValue': ['Guard.AgainstNull', 'for (i < allButLast)', 'if (_elements.Length > 0)'],
            'StructureValue': ['Guard.AgainstNull', 'for (i < allButLast)', 'if (_properties.Length > 0)']}
        for target, type_name in zip(removed_call['children'][:4], types):
            render = target['children'][0]['children'][1]
            assert [child['label'] for child in render['children']] == expected_render_children[type_name]
        visitor = loop['children'][3]
        assert [child['label'] for child in visitor['children']] == ['Guard.AgainstNull', 'if (value is ScalarValue sv)', 'if (value is SequenceValue seqv)', 'if (value is StructureValue strv)', 'if (value is DictionaryValue dictv)', 'LogEventPropertyValueVisitor<TState, TResult>.VisitUnsupportedValue']
        for index, kind in [(2, 'Sequence'), (3, 'Structure'), (4, 'Dictionary')]:
            call = visitor['children'][index]['children'][0]
            assert call['label'].endswith(' → JsonValueFormatter.Visit' + kind + 'Value')
            assert call['change'] == 'unchanged' and call['omission'] is None
        all_nodes = list(nodes(after['trees']))
        cycles = [node for node in all_nodes if node['omission'] and node['omission']['reason'] == 'cycle']
        assert collections.Counter(node['label'] for node in cycles) == {'⇢ DictionaryValue.Render': 1, '⇢ SequenceValue.Render': 2}
        by_id = {node['id']: node for node in all_nodes}
        assert len(by_id) == len(all_nodes)
        for node in cycles:
            reference = by_id[node['omission']['referenceId']]
            assert reference['label'] == 'LogEventPropertyValue.Render → ' + node['label'].removeprefix('⇢ ')
            assert node['omission']['symbolId'] in (reference['before'] or reference['after'])['targetIds']
        outer_before = copy.deepcopy(before)
        outer_after = copy.deepcopy(after)
        outer_before['trees'][0]['children'][0]['children'] = []
        outer_after['trees'][0]['children'][0]['children'] = []
        assert clean(outer_before) == clean(outer_after)
        text = (directory / (name + '.received.txt')).read_text(encoding='utf-8-sig')
        outputs = [section.split('stderr:\n', 1)[0].rstrip('\n') for section in text.split('stdout:\n')[1:]]
        assert len(outputs) == 2 and outputs[1] == '```diff\n' + outputs[0] + '\n```'
    case = next(case for case in manifest if case['id'] == name)
    count = 0
    for node in nodes(after['trees']):
        for side_name in ['before', 'after']:
            side = node.get(side_name)
            if not side:
                continue
            for location in [side.get('definition'), *side['callSites']]:
                if not location:
                    continue
                key = (case[side_name], location['path'])
                if key not in location_reads:
                    location_reads[key] = subprocess.check_output(['git', '-C', 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/serilog', 'show', key[0] + ':' + key[1]]).decode('utf-8-sig').splitlines()
                lines = location_reads[key]
                assert 1 <= location['startLine'] <= location['endLine'] <= len(lines)
                assert 1 <= location['startColumn'] <= len(lines[location['startLine'] - 1]) + 1
                assert 1 <= location['endColumn'] <= len(lines[location['endLine'] - 1]) + 1
                count += 1
    reports.append({'view': name, 'jsonSha256': hashlib.sha256((directory / (name + '-json.received.txt')).read_bytes()).hexdigest(), 'roots': len(after['trees']), 'nodes': sum(1 for _ in nodes(after['trees'])), 'sourceLocationsChecked': count, 'diagnosticsAndCoverageExact': True})
report = {'coreSha256': hashlib.sha256((trace_directory / 'build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(), 'reviewedViews': reports, 'traces': traces, 'immutableRevisionPathReads': len(location_reads), 'promoted': False}
Path('artifacts/receiver-context-serilog-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reports), 'sourceLocationsChecked': sum(report['sourceLocationsChecked'] for report in reports), 'promoted': False}))
