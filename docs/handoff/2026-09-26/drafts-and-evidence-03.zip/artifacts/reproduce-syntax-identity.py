import json
import pathlib
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parent
fixture = pathlib.Path(tempfile.mkdtemp(prefix='callrift-syntax-identity-'))
dotnet = 'C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe'
cli = root.parent / 'src/Callrift.Cli/bin/Debug/net11.0/callrift.dll'

def git(*args):
    return subprocess.check_output(['git', '-C', str(fixture), *args], stderr=subprocess.STDOUT).decode().strip()

git('init', '-q')
git('config', 'user.name', 'Fixture')
git('config', 'user.email', 'fixture@example.invalid')
(fixture / 'App.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net10.0</TargetFramework></PropertyGroup></Project>')
before = 'public class Flow { public void Guard(bool ready) { if (ready && Check()) Work(); } public void Unresolved() { Missing.Create().Send(); } bool Check() => true; void Work() {} }'
after = before.replace('ready && Check()', 'ready&&Check()').replace('Missing.Create().Send()', 'Missing . Create() . Send()')
(fixture / 'Flow.cs').write_text(before)
git('add', '.')
git('-c', 'commit.gpgsign=false', 'commit', '-qm', 'fixture before')
old = git('rev-parse', 'HEAD')
(fixture / 'Flow.cs').write_text(after)
git('add', '.')
git('-c', 'commit.gpgsign=false', 'commit', '-qm', 'fixture after')
new = git('rev-parse', 'HEAD')
for mode in ['source', 'msbuild']:
    arguments = [] if mode == 'source' else ['--project', 'App.csproj']
    result = subprocess.run([dotnet, str(cli), 'diff', old, new, *arguments, '--format', 'json'], cwd=fixture, capture_output=True, encoding='utf-8')
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    (root / ('syntax-identity-' + mode + '.json')).write_text(result.stdout, encoding='utf-8')
    print(mode, 'hasChanges:', data['hasChanges'], 'roots:', [node['label'] for node in data['trees']], flush=True)
print('fixture:', fixture, flush=True)
