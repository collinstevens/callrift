from pathlib import Path

root = Path.cwd()
artifacts = root / 'artifacts'
tests = artifacts / 'constructor-equivalence-final'
assert not tests.exists()
tests.mkdir()
source = (artifacts / 'ConstructorEquivalenceTests.cs').read_text(encoding='utf-8')
source = source.replace('new[] { "explicit-base", "primary-base", "class-empty", "struct-empty" }', 'new[] { "explicit-base", "primary-base", "class-empty", "struct-empty", "object-base", "metadata-base", "metadata-primary" }')
source = source.replace('            "explicit-base" =>', '''            "object-base" => ("class Derived { public Derived() {} }", "class Derived { public Derived() : base() {} }"),
            "metadata-base" => ("class Derived : System.Exception { public Derived() {} }", "class Derived : System.Exception { public Derived() : base() {} }"),
            "metadata-primary" => ("class Derived() : System.Exception {}", "class Derived() : System.Exception() {}"),
            "explicit-base" =>''')
(tests / 'ConstructorEquivalenceTests.cs').write_text(source, encoding='utf-8', newline='\n')
target = artifacts / 'constructor-initialization-reviewed-cli-tests'
assert not target.exists()
target.mkdir()
project = (artifacts / 'constructor-initialization-final-cli-tests/Check.csproj').read_text(encoding='utf-8').replace('../ConstructorEquivalenceTests.cs', '../constructor-equivalence-final/ConstructorEquivalenceTests.cs')
(target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared 56 source/restored CLI cases, including metadata constructor equivalence.')
