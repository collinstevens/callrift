from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-compatibility-corpus'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs_path = root / 'static-initialization-broad-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))['corpus']
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
trx = next((root / (directory.name + '-results')).glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == '89' and counters['passed'] == '27' and counters['failed'] == '62'
results = tree.findall('.//{*}UnitTestResult')
assert all('VerifyException' in result.find('.//{*}Message').text for result in results if result.attrib['outcome'] == 'Failed')
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'allFailuresAreVerifyDifferences': True, 'acceptedViews': [], 'results': [result.attrib for result in results]}
(root / 'static-initialization-first-corpus-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified terminal 89-view run: 27 unchanged passes, 62 Verify differences, unchanged frozen f581/934 inputs.')
