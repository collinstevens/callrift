from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
for name, project in [('scenarios', 'Callrift.Scenarios'), ('workspaces', 'Callrift.Workspaces')]:
    target = artifacts / f'dispatch-cardinality-final-{name}'
    assert not target.exists(), target
    target.mkdir()
    source = root / 'tests' / project
    for file in source.glob('*.cs'):
        shutil.copy2(file, target / file.name)
    shutil.copytree(source / 'Snapshots', target / 'Snapshots')
    content = (source / f'{project}.csproj').read_text(encoding='utf-8')
    if name == 'workspaces':
        content = content.replace('../Callrift.Scenarios/', '../../tests/Callrift.Scenarios/')
    else:
        shutil.copy2(artifacts / 'DispatchCardinalityTests.cs', target / 'DispatchCardinalityTests.cs')
    (target / 'Check.csproj').write_text(content, encoding='utf-8', newline='\n')
    inputs = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    (artifacts / f'dispatch-cardinality-final-{name}-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared frozen scenario and workspace sources; no production changes.')
