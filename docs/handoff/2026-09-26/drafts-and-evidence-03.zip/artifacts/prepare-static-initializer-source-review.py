from pathlib import Path
import json

root = Path('artifacts')
target = root / 'static-initializer-source-review'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
inventory = json.loads((root / 'static-initialization-corpus-review-inventory.json').read_text(encoding='utf-8'))
jobs = []
for case in manifest:
    views = [view for view in inventory['views'] if view['view'].startswith(case['id'] + '-') and view['initializerOccurrences']]
    if not views:
        continue
    checks = {}
    for view in views:
        for occurrence in view['initializerOccurrences']:
            for side in ['before', 'after']:
                value = occurrence[side]
                if value is None:
                    continue
                check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
                key = json.dumps(check, sort_keys=True)
                checks.setdefault(key, dict(check, occurrences=[]))['occurrences'].append({'view': view['view'], 'node': occurrence['node'], 'side': side})
    config = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': list(checks.values())}
    (target / (case['id'] + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
    jobs.append(case['id'])
(target / 'jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(jobs))
