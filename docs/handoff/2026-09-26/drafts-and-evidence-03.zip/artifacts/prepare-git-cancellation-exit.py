from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'src/Callrift.Core'
target = root / 'artifacts/git-cancellation-exit-core'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*.cs')}
(root / 'artifacts/git-cancellation-exit-original.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Copied published receiver Core for an independent Git cancellation fix.')
