from pathlib import Path
import hashlib
import json
import shutil

artifacts = Path.cwd() / 'artifacts'
source = artifacts / 'constructor-exact-workspaces'
target = artifacts / 'constructor-depth-workspaces'
assert not target.exists()
for review in json.loads((artifacts / 'constructor-workspace-review.json').read_text(encoding='utf-8'))['reviews']:
    assert hashlib.sha256((source / 'Snapshots' / (review['name'] + '.verified.txt')).read_bytes()).hexdigest() == review['sha256']
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.txt'))
overlay = (artifacts / 'overlay-constructor-depth-scenarios.py').read_text(encoding='utf-8')
overlay = overlay.replace('constructor-depth-scenarios', 'constructor-depth-workspaces').replace('constructor-depth-scenario-inputs', 'constructor-depth-workspace-inputs').replace('491 scenarios', '22 workspace checks')
(artifacts / 'overlay-constructor-depth-workspaces.py').write_text(overlay, encoding='utf-8', newline='\n')
print('Prepared 22 workspace checks with independently reviewed constructor/generator expectations.')
