from pathlib import Path
import json,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
root=Path.cwd();records=json.loads((root/'artifacts/declaration-signatures-v5-snapshot-differences.json').read_text(encoding='utf-8'))['signatures']
manifest=json.loads((root/'real-world-cases/manifest.json').read_text(encoding='utf-8'))
reviewed=set(json.loads((root/'artifacts/declaration-signatures-v5-corpus-declaration-review.json').read_text(encoding='utf-8'))['reviewedSignatureIds'])
records=[record for record in records if Path(record['witness']['file']).name.startswith(sys.argv[1]+'-') and record['id'] not in reviewed]
if len(sys.argv)>3:records=records[int(sys.argv[2]):int(sys.argv[2])+int(sys.argv[3])]
for record in records:
    if record['id'] in reviewed:continue
    witness=record['witness'];name=Path(witness['file']).name
    matches=[c for c in manifest if name.startswith(c['id']+'-')]
    if not matches:continue
    case=max(matches,key=lambda c:len(c['id']));location=witness['definition']
    if len(sys.argv)>1 and not case['id'].startswith(sys.argv[1]):continue
    print(record['id'],record['after'])
    if not location:print('METADATA (no source declaration)');continue
    side='before' if witness['path'].endswith('/before/signature') else 'after'
    command=['git','-C',str(Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases')/case['cacheName']),'show',case[side]+':'+location['path']]
    result=subprocess.run(command,capture_output=True)
    if result.returncode:print('GENERATED OR MISSING',location['path']);continue
    lines=result.stdout.decode('utf-8-sig').splitlines()
    start=location['startLine']-1
    print(location['path']+':'+str(start+1))
    header=[]
    for line in lines[start:start+24]:
        header.append(line.strip())
        if (line.strip()=='{' or '=>' in line or line.rstrip().endswith(';')) and not line.lstrip().startswith('['):break
    print('\n'.join(header))
