import json
from pathlib import Path
import subprocess
import time

root=Path('artifacts').resolve()
entries=json.loads((root/'orchard-candidates.json').read_text(encoding='utf-8'))
modules={'4910d17':'AdminDashboard','22e6852':'Media','ee892e7':'Workflows','0e50949':'Roles','9866770':'OpenId'}
for e in entries:
 key=e['after'][:7]
 module='OrchardCore.'+modules[key]
 for mode in ['source','msbuild']:
  for view in ['roots','focused']:
   options=['--depth','1'] if view=='roots' else json.loads((root/f'orchard-{key}-{mode}-focused-trial.options.json').read_text(encoding='utf-8'))
   if mode=='msbuild' and view=='roots':options+=['--project',f'src/OrchardCore.Modules/{module}/{module}.csproj','--framework','net10.0']
   stem=root/f'orchard-{key}-{mode}-{view}-final'
   stem.with_suffix('.options.json').write_text(json.dumps(options,indent=2)+'\n',encoding='utf-8',newline='\n')
   for fmt in ['json','text','md']:
    command=['C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe',str(root/'delegate-audit/bin/Callrift.Cli/debug/callrift.dll'),'diff',e['before'],e['after'],*options,'--format',fmt,'--color','never']
    started=time.monotonic()
    with Path(str(stem)+'.'+fmt).open('wb') as stdout,Path(str(stem)+'.'+fmt+'.err').open('wb') as stderr:
     process=subprocess.Popen(command,cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore',stdout=stdout,stderr=stderr)
     try:code=process.wait(timeout=600)
     except subprocess.TimeoutExpired:
      subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
      process.wait()
      raise
    print(key,mode,view,fmt,'exit',code,'elapsed',round(time.monotonic()-started,1),flush=True)
    assert code==0,Path(str(stem)+'.'+fmt+'.err').read_text(encoding='utf-8')
