from collections import Counter
from pathlib import Path
import copy
import hashlib
import json
import sys

directory = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('artifacts/receiver-context-stable-corpus/Snapshots')
reports = []
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
def stdout(text):
    return [section.split('stderr:\n', 1)[0] for section in text.split('stdout:\n')[1:]]
for received in sorted(directory.glob('*-json.received.txt')):
    verified = received.with_name(received.name.replace('.received.', '.verified.'))
    before, after = read(verified), read(received)
    if before['trees'] != after['trees']:
        continue
    old, new = copy.deepcopy(before), copy.deepcopy(after)
    old_diagnostics, new_diagnostics = old.pop('diagnostics'), new.pop('diagnostics')
    removed = [d for d in old_diagnostics if d not in new_diagnostics]
    added = [d for d in new_diagnostics if d not in old_diagnostics]
    assert not added, (received.name, added)
    assert removed and all(d['code'] == 'generic-context-limit' for d in removed), received.name
    old['analysis']['limitations'] = [limitation for limitation in old['analysis']['limitations'] if limitation != 'generic-context-limit']
    assert old == new, received.name
    before_text = received.with_name(received.name.replace('-json.received.', '.verified.')).read_text(encoding='utf-8-sig')
    after_path = received.with_name(received.name.replace('-json.received.', '.received.'))
    after_text = after_path.read_text(encoding='utf-8-sig') if after_path.exists() else before_text
    assert stdout(before_text) == stdout(after_text), received.name
    reports.append({'received': str(received), 'sha256': hashlib.sha256(received.read_bytes()).hexdigest(),
                    'verifiedSha256': hashlib.sha256(verified.read_bytes()).hexdigest(), 'treesExact': True,
                    'textAndMarkdownStdoutExact': True, 'removedDiagnostics': dict(Counter(d['code'] for d in removed)),
                    'removedDiagnosticLocations': removed})
report = {'coreSha256': hashlib.sha256((directory.parent / 'build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(), 'reviewed': reports, 'promoted': False}
Path(sys.argv[2] if len(sys.argv) > 2 else 'artifacts/receiver-context-diagnostic-only-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reports), 'removedLimits': sum(r['removedDiagnostics']['generic-context-limit'] for r in reports), 'promoted': False}))
