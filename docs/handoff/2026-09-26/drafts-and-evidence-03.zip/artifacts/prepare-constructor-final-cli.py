from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
core = artifacts / 'constructor-initialization-core'
original = json.loads((artifacts / 'constructor-initialization-original.json').read_text(encoding='utf-8'))
git_file = core / 'Git/GitRepository.cs'
assert hashlib.sha256(git_file.read_bytes()).hexdigest() == original[str(Path('Git/GitRepository.cs'))]
shutil.copy2(root / 'src/Callrift.Core/Git/GitRepository.cs', git_file)
directory = artifacts / 'constructor-initialization-final-cli-tests'
assert not directory.exists()
directory.mkdir()
project = (artifacts / 'constructor-initialization-cli-tests/Check.csproj').read_text(encoding='utf-8')
project = project.replace('<Compile Include="../ConstructorInitializationTests.cs" />', '<Compile Include="../ConstructorInitializationTests.cs" />\n    <Compile Include="../ConstructorEquivalenceTests.cs" />')
(directory / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Included the signed Git cleanup fix and prepared 50 constructor CLI cases.')
