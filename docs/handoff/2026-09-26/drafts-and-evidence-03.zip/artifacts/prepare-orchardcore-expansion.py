from pathlib import Path
import json
import subprocess

root = Path.cwd()
repository = Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore')
def git(*arguments):
    return subprocess.check_output(['git', '-C', str(repository), *arguments], text=True, encoding='utf-8').strip()
definitions = [
    ('orchardcore-elasticsearch-authorization', '008eb1e7da318fb28a80b40083e01ef57480bccb', 'OrchardCore.Elasticsearch',
     ['OrchardCore.Elasticsearch.AdminController.IndexInfo(string)', 'OrchardCore.Elasticsearch.AdminController.QueryIndex(string,string,string)'],
     'Both endpoints gain an authorization call and a guarded Forbid return. Preserve index lookup, not-found branches, result formatting, and the existing query helper.'),
    ('orchardcore-openid-logout', '9866770c0e90e1e2b60681922e247fda7ec4ec01', 'OrchardCore.OpenId',
     ['OrchardCore.OpenId.Controllers.AccessController.Logout()', 'OrchardCore.OpenId.Controllers.AccessController.LogoutAccept()'],
     'Extract SignOutAndRedirectAsync and call it from both the confirmed and matching-hint paths. Preserve explicit cookie sign-out and redirect selection. Split nullable FindUserIdentifier from the throwing wrapper; retain the constant-time comparison and add both nonempty guards. Recipe/export assignments also change.'),
    ('orchardcore-esmodule-localization', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', None, [],
     'Large mixed-language change with 31 production C# files: module localizer classes/registrations, resource dependency rewiring, localization settings and services. Detailed C# diff review remains pending. JavaScript/TypeScript behavior is outside callrift analysis.'),
]
candidates = []
for identifier, after, module, entries, expectation in definitions:
    before = git('rev-parse', after + '^')
    before_license = git('rev-parse', before + ':LICENSE')
    after_license = git('rev-parse', after + ':LICENSE')
    assert before_license == after_license == '183936c000fa2cc5969ba724afc1bdc5bfae5080'
    project = None if module is None else f'src/OrchardCore.Modules/{module}/{module}.csproj'
    candidates.append({'id': identifier, 'repository': 'https://github.com/OrchardCMS/OrchardCore.git', 'before': before, 'after': after,
                       'license': 'BSD-3-Clause', 'licenseFile': 'LICENSE', 'beforeLicenseBlob': before_license, 'afterLicenseBlob': after_license,
                       'project': project, 'framework': 'net10.0' if project else None, 'entries': entries, 'independentExpectation': expectation,
                       'accepted': False, 'reviewStatus': 'Production diff and surrounding methods inspected for the first two candidates; no output reviewed.'})
(root / 'artifacts/orchardcore-expansion-candidates.json').write_text(json.dumps(candidates, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(candidates, indent=2))
