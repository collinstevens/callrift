import collections
import json
from pathlib import Path
import subprocess

repo = Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore')
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], encoding='utf-8').strip()

entries = []
for short in ['4910d1722', '22e6852c8', 'ee892e7e9', '0e50949da', '9866770c0']:
    after = git('rev-parse', short)
    before = git('rev-parse', short + '^')
    paths = git('ls-tree', '-r', '--name-only', after).splitlines()
    entry = dict(before=before, after=after, subject=git('show', '-s', '--format=%s', after),
        beforeLicenseBlob=git('rev-parse', before + ':LICENSE'),
        afterLicenseBlob=git('rev-parse', after + ':LICENSE'),
        counts=dict(collections.Counter(Path(p).suffix for p in paths)),
        changed=git('diff-tree', '--no-commit-id', '--name-only', '-r', after).splitlines())
    entries.append(entry)
    print(json.dumps({k:v for k,v in entry.items() if k not in ['counts', 'changed']}, indent=2))
    print('C#:', entry['counts'].get('.cs'), 'projects:', entry['counts'].get('.csproj'), 'changed:', len(entry['changed']))
    print('\n'.join(p for p in entry['changed'] if p.endswith('.cs') and p.startswith('src/')))
(Path(__file__).resolve().parent / 'orchard-candidates.json').write_text(json.dumps(entries,indent=2)+'\n',encoding='utf-8',newline='\n')
