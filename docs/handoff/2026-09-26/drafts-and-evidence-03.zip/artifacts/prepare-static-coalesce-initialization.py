from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['core', 'worker']:
    target = root / ('static-coalesce-initialization-' + suffix)
    assert not target.exists()
    shutil.copytree(root / ('static-interceptor-identity-' + suffix), target, ignore=shutil.ignore_patterns('build', 'bin', 'obj'))
path = root / 'static-coalesce-initialization-worker/Callrift.MSBuild.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-interceptor-identity-core', 'static-coalesce-initialization-core'), encoding='utf-8', newline='\n')
path = root / 'static-coalesce-initialization-core/Analysis/CallCollector.cs'
source = path.read_text(encoding='utf-8-sig')
old = '            case AssignmentExpressionSyntax assignment when StaticMember(assignment.Left) is { } assignedMember:'
new = '''            case AssignmentExpressionSyntax assignment when assignment.IsKind(SyntaxKind.CoalesceAssignmentExpression):
                Walk(assignment.Left, result);
                Branch("if (" + SymbolNames.Compact(assignment.Left) + " is null)", assignment, [assignment.Right], result);
                return;
''' + old
assert source.count(old) == 1
path.write_text(source.replace(old, new), encoding='utf-8', newline='\n')
probe = root / 'static-coalesce-initialization-candidate-probe'
assert not probe.exists()
probe.mkdir()
for path in (root / 'static-coalesce-initialization-probe').iterdir():
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, probe / path.name)
path = probe / 'Check.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-interceptor-identity-cli/candidate-ready', 'static-coalesce-initialization-worker/build/bin/Callrift.MSBuild/debug'), encoding='utf-8', newline='\n')
print('Prepared coalescing assignment branch fix without mutating frozen candidates.')
