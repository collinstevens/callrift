from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
proof = {}
for version, passed in [('baseline', 0), ('candidate', 6)]:
    inputs = json.loads((root / ('static-callback-initialization-' + version + '-inputs.json')).read_text(encoding='utf-8'))
    for name, expected in inputs['binaries'].items():
        assert digest(root / 'static-callback-initialization-cli' / (version + '-ready') / name) == expected, name
    for name, expected in inputs.get('sources', {}).items():
        assert digest(Path(name)) == expected, name
    trx = next((root / ('static-callback-initialization-' + version + '-results')).glob('*.trx'))
    tree = ET.parse(trx)
    counters = tree.find('.//{*}Counters').attrib
    assert counters['total'] == counters['executed'] == '6' and int(counters['passed']) == passed
    if version == 'baseline':
        messages = [result.find('.//{*}Message').text for result in tree.findall('.//{*}UnitTestResult')]
        assert all('Expected: 2' in message and 'Actual:   1' in message for message in messages)
    records = [json.loads(line) for line in (root / ('static-callback-runtime-' + version + '.log')).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(records) == 3 and all(row['runtimePassed'] and row['semanticPassed'] for row in records)
    assert all(row['actualRuntime'] == 'accept,before,done' for row in records)
    assert all(row['initializerCount'] == (3 if version == 'candidate' else 2) and row['callbackBranchCount'] == (2 if version == 'candidate' else 0) for row in records)
    proof[version] = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['Callrift.MSBuild.dll'], 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'runtimeAndApi': records}
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
validator = jsonschema.validators.validator_for(schema)(schema)
outputs = {}
for version in ['baseline', 'candidate']:
    for path in (root / ('static-callback-runtime-' + version) / 'output').glob('*.json'):
        validator.validate(json.loads(path.read_text(encoding='utf-8-sig')))
        outputs[path.as_posix()] = digest(path)
assert len(outputs) == 18
proof['schemaV1Envelopes'] = outputs
for name in ['static-initialization-callback-state-core-format.log', 'static-initialization-callback-state-worker-format.log']:
    assert not (root / name).read_text(encoding='utf-8-sig').strip()
    proof[name] = digest(root / name)
(root / 'static-callback-state-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
inputs = json.loads((root / 'static-initialization-complete-cli-inputs.json').read_text(encoding='utf-8'))
for name, expected in inputs['versions']['candidate'].items():
    assert digest(root / 'static-initialization-complete-cli/candidate-ready' / name) == expected, name
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
trx = next((root / 'static-initialization-complete-cli-results').glob('*.trx'))
counters = ET.parse(trx).find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '104' and counters['failed'] == '0'
(root / 'static-initialization-complete-cli-terminal.json').write_text(json.dumps({'core': inputs['versions']['candidate']['Callrift.Core.dll'], 'trx': trx.as_posix(), 'sha256': digest(trx), 'counters': counters, 'frozenInputsUnchanged': True}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified six callback regressions and fixes, runtime evidence, 18 schema envelopes, and the earlier 104-case terminal pass.')
