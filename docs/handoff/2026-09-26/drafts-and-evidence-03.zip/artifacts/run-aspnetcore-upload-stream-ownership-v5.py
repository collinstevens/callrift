from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/declaration-signatures-cli-v5-ready/callrift.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
expected = json.loads((root / 'artifacts/aspnetcore-upload-stream-ownership-source-expectations.json').read_text(encoding='utf-8'))
base = ['diff', expected['before'], expected['after']]
focused = base + ['--depth', '3', '--externals', '--entry', 'DefaultHubDispatcher<THub>.ReplaceArguments', '--entry', 'DefaultHubDispatcher<THub>.CleanupInvocation', '--entry', 'StreamTracker.AddStream', '--entry', 'StreamTracker.GetNextStreamOwner', '--entry', 'StreamTracker.CompleteAll']
jobs = [(f'aspnetcore-upload-stream-ownership-v5-source-{view}', 'aspnetcore', arguments, form) for view, arguments in [('roots', base + ['--depth', '1']), ('focused', focused)] for form in ['json', 'text', 'md']]
records = []
for name, cache, arguments, format in jobs:
    output = root / 'artifacts' / (name + '.' + format)
    error = output.with_suffix('.' + format + '.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), *arguments, '--format', format, '--color', 'never']
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(['mise', 'exec', '-c', subprocess.list2cmdline(command)], cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / cache, stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    record = {'name': name, 'format': format, 'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'accepted': False}
    if code == 0 and format == 'json':
        data = json.loads(output.read_text(encoding='utf-8'))
        record.update(roots=len(data.get('trees', [])), diagnostics=len(data['diagnostics']), truncated=data['truncated'])
    records.append(record)
    (root / 'artifacts/aspnetcore-upload-stream-ownership-v5-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(record), flush=True)
    if code != 0:
        print(error.read_text(encoding='utf-8'), flush=True)
