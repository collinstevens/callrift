from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['core', 'worker']:
    target = root / ('static-interceptor-identity-' + suffix)
    assert not target.exists()
    shutil.copytree(root / ('static-initialization-callback-state-' + suffix), target, ignore=shutil.ignore_patterns('bin', 'obj', 'build'))
path = root / 'static-interceptor-identity-worker/Callrift.MSBuild.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-initialization-callback-state-core', 'static-interceptor-identity-core'), encoding='utf-8', newline='\n')
path = root / 'static-interceptor-identity-core/Analysis/InterceptorSymbols.cs'
source = path.read_text(encoding='utf-8-sig')
old = '''        return result;
    }
}'''
new = '''        foreach (var group in result.ToArray().GroupBy(pair => pair.Key.ContainingType, SymbolEqualityComparer.Default))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var type = (INamedTypeSymbol)group.Key!;
            var ordered = group.Select(pair => pair.Value).OrderBy(identity => identity.Key, StringComparer.Ordinal).ToArray();
            var digest = Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\\0", ordered.Select(identity => identity.Key)))));
            var label = "initialization of interceptors for " + string.Join(", ", ordered.Select(identity => identity.Label));
            foreach (var constructor in type.StaticConstructors)
                result.Add(SymbolNames.Normalize(constructor), new InterceptorIdentity(
                    symbols.InitializationScope(type) + "::<interceptor-initializer>:" + digest, label));
        }
        return result;
    }
}'''
assert source.count(old) == 1
path.write_text(source.replace(old, new), encoding='utf-8', newline='\n')
print('Prepared isolated generated initializer identity candidate.')
