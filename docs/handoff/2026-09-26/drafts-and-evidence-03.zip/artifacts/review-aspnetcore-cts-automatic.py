from pathlib import Path
import collections
import copy
import hashlib
import json
import re
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import flatten, schema, jsonschema

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
path = root / 'aspnetcore-stream-cts-disposal-static-candidate-source-roots.json'
data = json.loads(path.read_text(encoding='utf-8'))
focused_path = root / 'aspnetcore-stream-cts-disposal-static-candidate-source-focused.json'
focused = json.loads(focused_path.read_text(encoding='utf-8'))
jsonschema.validate(data, schema)
assert data['analysis']['mode'] == 'source' and data['analysis']['status'] == 'partial'
assert data['hasChanges'] and data['truncated']
assert data['diagnostics'] == focused['diagnostics']
nodes = list(flatten(data['trees']))
assert len(data['trees']) == 1201 and len(nodes) == len({node['id'] for node in nodes}) == 20909
assert all(node['change'] == 'unchanged' for node in data['trees'])
assert len({node['before']['symbolId'] for node in data['trees']}) == 1201
changed = []
for node in nodes:
    assert node['before'] is not None and node['after'] is not None
    expected = copy.deepcopy(node['before'])
    for location in [expected['definition'], *expected['callSites']]:
        if location is None or location['path'] != 'src/SignalR/server/Core/src/Internal/DefaultHubDispatcher.cs':
            continue
        for field in ['startLine', 'endLine']:
            if location[field] is not None and location[field] >= 612:
                location[field] += 1
    assert expected == node['after'], node['id']
    if node['change'] != 'unchanged':
        assert node['change'] == 'modified' and node['detail'] == 'changes below depth limit'
        assert node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
        changed.append(node)
assert len(changed) == 3954
rendered = path.with_suffix('.text').read_text(encoding='utf-8')
markdown = path.with_suffix('.md').read_text(encoding='utf-8')
assert markdown == '```diff\n' + rendered + '```\n'
headers = [line[2:] for line in rendered.splitlines() if line.startswith('  ') and len(line) > 2 and line[2] not in ' │├└']
assert headers == [node['label'] for node in data['trees']]
expected_labels = {node['label'] for node in changed}
changed_lines = [line for line in rendered.splitlines() if line.startswith(('+ ', '- ', '~ '))]
assert len(changed_lines) == 2433
for line in changed_lines:
    assert line.startswith('~ ') and '(changes below depth limit)' in line
    label = line[:line.index(' (changes below depth limit)')].lstrip('~ │├└─')
    label = re.sub(r' ×\d+$', '', label)
    assert label in expected_labels, label
for format in ['text', 'md']:
    assert digest(path.with_suffix('.' + format + '.stderr')) == digest(path.with_suffix('.stderr'))
diagnostics = []
for diagnostic in data['diagnostics'][:8]:
    location = diagnostic['location']
    prefix = '' if location is None else location['path'] + ':' + str(location['startLine']) + ': '
    diagnostics.append(prefix + diagnostic['code'] + ': ' + diagnostic['message'])
diagnostics.append(str(len(data['diagnostics']) - 8) + ' additional diagnostics; use --diagnostics full.')
assert path.with_suffix('.stderr').read_text(encoding='utf-8').strip() == '\n'.join(diagnostics)
generic_path = root / 'aspnetcore-cts-generic-review.json'
generic = json.loads(generic_path.read_text(encoding='utf-8'))
assert [record['revision'] for record in generic] == [data['from']['commit'], data['to']['commit']]
for record in generic:
    assert record['forbiddenComparerPaths'] == [] and record['contextLimitDiagnostics'] == 0
    assert record['reachableMembers'] == 9
    assert len(record['equality']) == 1
    equality = record['equality'][0]
    assert equality['DispatchType']['Arguments'][0]['Name'] == 'Callrift.Source::global::Microsoft.AspNetCore.Mvc.ModelBinding.ModelMetadata'
    assert equality['targets'] == ['source::Microsoft.AspNetCore.Routing.RouteValueEqualityComparer.Equals(object,object)']
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore'
pins = [data['from']['commit'], data['to']['commit']]
assert subprocess.check_output(['git', '-C', repository, 'rev-parse', pins[1] + '^'], text=True).strip() == pins[0]
license_blobs = [subprocess.check_output(['git', '-C', repository, 'rev-parse', pin + ':LICENSE.txt'], text=True).strip() for pin in pins]
assert license_blobs == ['984713a49622a96da110443c15477613bc12656b'] * 2
source_paths = [
    'src/Mvc/Mvc.Abstractions/src/ModelBinding/ModelMetadata.cs',
    'src/Mvc/Mvc.Core/src/ModelBinding/Validation/DefaultComplexObjectValidationStrategy.cs',
    'src/Shared/Dictionary/AdaptiveCapacityDictionary.cs',
    'src/Shared/Razor/CaseSensitiveBoundAttributeComparer.cs',
    'src/Http/Routing/src/RouteValueEqualityComparer.cs'
]
source_blobs = {}
for source in source_paths:
    blobs = [subprocess.check_output(['git', '-C', repository, 'rev-parse', pin + ':' + source], text=True).strip() for pin in pins]
    assert blobs[0] == blobs[1]
    source_blobs[source] = blobs[0]
witness_path = root / 'aspnetcore-stream-cts-disposal-all-root-witnesses.json'
witnesses = json.loads(witness_path.read_text(encoding='utf-8'))
assert len(witnesses['changes']) == 5
for side in witnesses['sides']:
    assert len(side['witnesses']) == 1201
    assert all(witness['entry'] is not None and witness['changedTarget'] is not None for witness in side['witnesses'])
restored_path = root / 'aspnetcore-cts-restored-trial-record.json'
restored = json.loads(restored_path.read_text(encoding='utf-8'))
assert restored['exitCode'] == 2 and 'src/submodules/MessagePack-CSharp' in restored['stderr']
counts = {}
for side, pin in zip(['before', 'after'], pins):
    files = subprocess.check_output(['git', '-C', repository, 'ls-tree', '-r', '--name-only', pin]).decode('utf-8').splitlines()
    counts[side] = dict(collections.Counter(Path(name).suffix for name in files))
proof = {
    'before': pins[0], 'after': pins[1], 'parentVerified': True, 'licenseBlobs': license_blobs,
    'files': {candidate.as_posix(): digest(candidate) for candidate in [path, path.with_suffix('.text'), path.with_suffix('.md'), focused_path, generic_path, witness_path, restored_path, root / 'aspnetcore-stream-cts-disposal-location-audit.json', root / 'aspnetcore-cts-focused-json-review.json']},
    'genericProbeSources': {candidate.as_posix(): digest(candidate) for candidate in (root / 'aspnetcore-cts-generic-review').glob('*') if candidate.suffix in ['.cs', '.csproj']},
    'genericProbeBinaries': {candidate.as_posix(): digest(candidate) for candidate in (root / 'aspnetcore-cts-generic-review/build/bin/Check/debug').glob('*') if candidate.is_file()},
    'sourceBlobsForIndependentGenericExpectation': source_blobs,
    'repositoryFileCounts': counts,
    'roots': 1201, 'nodes': 20909, 'modifiedDepthOmissions': 3954, 'renderedChangedLines': 2433,
    'allSidesPreservedExceptExpectedSourceLineShift': True,
    'allRenderedRootsPreservedInOrder': True,
    'allRenderedChangesAreDepthOmissions': True,
    'diagnosticCounts': dict(collections.Counter(item['code'] for item in data['diagnostics'])),
    'specificModelMetadataComparerBugAbsentOnBothPins': True,
    'graphWitnessesDoNotProveRuntimeFeasibility': True,
    'review': 'The focused view independently establishes the only source change. Every automatic node retains its before/after binding, targets, signature, relation, origin and locations apart from the one inserted source line. All changes in the depth-one view are explicit omissions toward that edit. Every rendered root remains visible and ordered; every changed rendered line corresponds to a modified JSON depth omission. Source coverage and all diagnostics remain explicit. Broad possible interface dispatch and stored callbacks explain the distant root connections without establishing runtime feasibility. The previous incompatible ModelMetadata-to-TagHelperAttribute comparer edge is absent on both pins with the current candidate. Restored analysis explicitly fails on the unsupported MessagePack submodule; this is source-only coverage.',
    'reviewed': True, 'repeatPending': True, 'accepted': False
}
(root / 'aspnetcore-cts-automatic-review.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed both automatic sides and all rendered roots, depth-change markers, diagnostics, previous generic defect, and explicit restored failure.')
