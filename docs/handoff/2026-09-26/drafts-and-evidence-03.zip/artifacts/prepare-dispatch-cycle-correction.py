from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
source = root / 'artifacts/dispatch-cardinality-complete-core'
target = root / 'artifacts/dispatch-cardinality-cycle-core'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
original = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*.cs')}
(root / 'artifacts/dispatch-cardinality-cycle-original.json').write_text(json.dumps(original, indent=2) + '\n', encoding='utf-8', newline='\n')
file = target / 'Diffing/TreeExpander.cs'
text = file.read_text(encoding='utf-8')
old = 'var side = new NodeSide(definition, member.Signature, "resolved", "direct", [definition], member.Location, [], "definition");'
assert text.count(old) == 1
text = text.replace(old, old[:-1] + '\n        { ContextTargetKey = key };')
file.write_text(text, encoding='utf-8', newline='\n')
file = target / 'Rendering/JsonRenderer.cs'
text = file.read_text(encoding='utf-8')
start = text.index('            path[node.Key] = id;')
end = text.index('            var reference =', start)
text = text[:start] + '            if (!node.Children.Any(child => child.Kind == "dispatchTarget"))\n            {\n' + ''.join('    ' + line + '\n' for line in text[start:end].splitlines()) + '            }\n' + text[end:]
file.write_text(text, encoding='utf-8', newline='\n')
probe = root / 'artifacts/dispatch-self-cycle-corrected-check'
assert not probe.exists()
probe.mkdir()
shutil.copy2(root / 'artifacts/dispatch-self-cycle-check/Program.cs', probe / 'Program.cs')
project = (root / 'artifacts/dispatch-self-cycle-check/Check.csproj').read_text(encoding='utf-8').replace('dispatch-cardinality-complete-core', 'dispatch-cardinality-cycle-core')
(probe / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared separate cycle correction; prior sources and frozen runs preserved.')
