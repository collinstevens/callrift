from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
cli = root / 'artifacts/static-coalesce-initialization-cli-tests/candidate-ready/callrift.dll'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior = json.loads((root / 'artifacts/next-static-candidate-focused-records.json').read_text(encoding='utf-8'))
orchard = next(record for record in prior if record['name'].startswith('orchardcore'))
orchard_args = orchard['command'][2:orchard['command'].index('--format')]
jobs = [
    ('aspnetcore-stream-cts-disposal-static-candidate-source-focused', 'aspnetcore', ['diff', '4cab91a40393e7d0341cf43cb88930588a0b4876', '3563a8e77e0e09055a7f0f18ef9ab026dcd59ad2', '--entry', 'DefaultHubDispatcher<THub>.StreamAsync', '--depth', '3', '--externals'], 'json'),
    ('aspnetcore-http-response-callback-review', 'aspnetcore', ['tree', '3563a8e77e0e09055a7f0f18ef9ab026dcd59ad2', '--entry', 'source::Microsoft.AspNetCore.Http.HttpResponse..cctor()', '--depth', '2', '--externals'], 'json'),
    ('orchardcore-esmodule-localization-static-candidate-source-focused', 'orchardcore', orchard_args, 'text'),
    ('orchardcore-esmodule-localization-static-candidate-source-focused', 'orchardcore', orchard_args, 'md'),
    ('orchardcore-esmodule-localization-static-candidate-source-roots', 'orchardcore', ['diff', 'b304fcd78a70b792c6f63916c0ce6e6957bb1aa0', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', '--depth', '1'], 'text'),
    ('orchardcore-esmodule-localization-static-candidate-source-roots', 'orchardcore', ['diff', 'b304fcd78a70b792c6f63916c0ce6e6957bb1aa0', '4c1d10e68dd443c8bc9fc8d8a02059081fc6be12', '--depth', '1'], 'md')
]
records = []
for name, cache, arguments, format in jobs:
    output = root / 'artifacts' / (name + '.' + format)
    error = output.with_suffix('.' + format + '.stderr')
    assert not output.exists()
    command = ['dotnet', str(cli), *arguments, '--format', format, '--color', 'never']
    started = time.monotonic()
    with output.open('wb') as stdout, error.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases') / cache, stdout=stdout, stderr=stderr)
        try:
            code = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=True)
            process.wait()
            raise
    record = {'name': name, 'format': format, 'command': command, 'exitCode': code, 'seconds': time.monotonic() - started, 'outputSha256': digest(output), 'stderrSha256': digest(error), 'coreSha256': digest(cli.parent / 'Callrift.Core.dll'), 'accepted': False}
    if code == 0 and format == 'json':
        data = json.loads(output.read_text(encoding='utf-8'))
        record.update(roots=len(data.get('trees', [])), diagnostics=len(data['diagnostics']), truncated=data['truncated'])
    records.append(record)
    (root / 'artifacts/next-candidate-review-output-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(record), flush=True)
    if code != 0:
        print(error.read_text(encoding='utf-8'), flush=True)
