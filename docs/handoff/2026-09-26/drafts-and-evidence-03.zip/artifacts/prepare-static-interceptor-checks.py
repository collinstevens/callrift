from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
worker = root / 'static-interceptor-identity-worker/build/bin/Callrift.MSBuild/debug'
log = (root / 'static-interceptor-identity-worker-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
probe = root / 'static-interceptor-identity-candidate-probe'
assert not probe.exists()
probe.mkdir()
for path in (root / 'static-interceptor-identity-probe').glob('*'):
    if path.suffix in ['.cs', '.csproj']:
        shutil.copy2(path, probe / path.name)
path = probe / 'Check.csproj'
path.write_text(path.read_text(encoding='utf-8').replace('static-callback-initialization-cli/candidate-ready', 'static-interceptor-identity-worker/build/bin/Callrift.MSBuild/debug'), encoding='utf-8', newline='\n')
ready = root / 'static-interceptor-identity-cli/candidate-ready'
assert not ready.exists()
shutil.copytree(root / 'static-callback-initialization-cli/candidate-ready', ready, ignore=shutil.ignore_patterns('msbuild'))
shutil.copytree(worker, ready / 'msbuild')
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(worker / name, ready / name)
binary_hashes = {path.relative_to(ready).as_posix(): digest(path) for path in ready.rglob('*') if path.is_file()}
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    assert binary_hashes[name] == binary_hashes['msbuild/' + name]
sources = {path.as_posix(): digest(path) for folder in [root / 'static-interceptor-identity-core', root / 'static-interceptor-identity-worker', probe] for path in folder.rglob('*') if path.is_file() and path.suffix in ['.cs', '.csproj'] and not any(part in path.parts for part in ['bin', 'obj', 'build'])}
(root / 'static-interceptor-identity-cli-inputs.json').write_text(json.dumps({'binaries': binary_hashes, 'sources': sources}, indent=2) + '\n', encoding='utf-8', newline='\n')
script = (root / 'inspect-static-orchard-pager.py').read_text(encoding='utf-8')
script = script.replace('static-callback-initialization-cli', 'static-interceptor-identity-cli').replace('static-orchard-pager-depth6', 'static-interceptor-orchard-pager-depth6')
(root / 'inspect-static-interceptor-orchard-pager.py').write_text(script, encoding='utf-8', newline='\n')
print(json.dumps({name: binary_hashes[name] for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']}))
