from pathlib import Path
import json
import os
import subprocess
import tempfile

root = Path.cwd()
directory = Path(tempfile.mkdtemp(prefix='callrift-static-scope-review-'))
project = '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework><AssemblyName>Shared</AssemblyName></PropertyGroup></Project>'
files = {
    'Left/Left.csproj': project,
    'Right/Right.csproj': project,
    'Left/Flow.cs': 'public static class State { public static int Value = LeftSink.Before(); } public static class LeftSink { public static int Before() => 1; }',
    'Right/Flow.cs': 'public static class State { public static int Value = RightSink.Before(); } public static class RightSink { public static int Before() => 2; }',
    'Consumer/Consumer.csproj': '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup><ItemGroup><ProjectReference Include="../Left/Left.csproj"/></ItemGroup></Project>',
    'Consumer/Flow.cs': 'public static class Consumer { public static int Run() => State.Value; }',
    'App.slnx': '<Solution><Project Path="Left/Left.csproj"/><Project Path="Right/Right.csproj"/><Project Path="Consumer/Consumer.csproj"/></Solution>',
}
for name, content in files.items():
    path = directory / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8', newline='\n')
def run(command, **kwargs):
    return subprocess.run(command, cwd=directory, text=True, capture_output=True, timeout=180, **kwargs)
for arguments in [['init', '--initial-branch=main'], ['add', '.'], ['commit', '--no-gpg-sign', '-m', 'test: create static scope fixture']]:
    result = run(['git', *arguments])
    assert result.returncode == 0, result.stderr
environment = dict(os.environ, CALLRIFT_WORKSPACE_CACHE=str(directory / 'cache'))
cli = root / 'artifacts/static-initialization-scope-cli/candidate-ready/callrift.dll'
result = run(['dotnet', str(cli), 'tree', 'HEAD', '--entry', 'Consumer.Run', '--solution', 'App.slnx', '--depth', '20', '--format', 'json'], env=environment)
report = {'directory': str(directory), 'exitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
(root / 'artifacts/static-scope-worker-valid-solution.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report))
