from pathlib import Path
import json
import subprocess

root = Path.cwd()
ids = {'autofac-any-key-cache', 'autofac-pipeline-callbacks', 'autofac-multi-service-registration'}
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
revisions = sorted({entry[side] for entry in manifest if entry['id'] in ids for side in ['before', 'after']})
reports = []
for revision in revisions:
    path = root / ('artifacts/receiver-context-autofac-trace-' + revision + '.jsonl')
    with path.open('w', encoding='utf-8', newline='\n') as output:
        code = subprocess.run(['dotnet', 'artifacts/receiver-context-autofac-trace/build/bin/Check/debug/Check.dll', revision], cwd=root, stdout=output, stderr=subprocess.STDOUT, timeout=360).returncode
    assert code == 0, revision
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    assert rows[0]['Diagnostics'] == 0 and len(rows[0]['Targets']) == 2, revision
    assert sorted(row['Result'] for row in rows[1:]) == ['DefaultRegisteredServicesTracker.AddRegistration', 'ScopeRestrictedRegisteredServicesTracker.AddRegistration'], revision
    reports.append({'revision': revision, 'trace': str(path.relative_to(root)), 'runtimeReceiverContexts': 2, 'distinctOverrides': True})
    print(json.dumps(reports[-1]), flush=True)
(root / 'artifacts/receiver-context-autofac-traces.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8', newline='\n')
