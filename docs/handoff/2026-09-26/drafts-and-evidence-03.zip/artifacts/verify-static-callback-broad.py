from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
proof = {}
directory = root / 'static-initialization-six-view-repeat'
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
assert digest(root / 'static-six-view-review.json') == inputs['reviewSha256']
trx = next((root / (directory.name + '-results')).glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '6'
assert counters['failed'] == '0'
assert not list((directory / 'Snapshots').glob('*.received.*'))
proof['sixReviewedViews'] = {'trx': trx.as_posix(), 'sha256': digest(trx), 'counters': counters, 'inputsSha256': digest(inputs_path), 'reviewSha256': inputs['reviewSha256']}
for name, count in [('static-trigger', 23), ('static-declaration', 7), ('static-partial', 2), ('static-identity', 2)]:
    log_path = root / (name + '-callback.log')
    records = [json.loads(line) for line in log_path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    old_records = [json.loads(line) for line in (root / (name + '-final.log')).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(records) == count and records == old_records, name
    if name == 'static-trigger':
        assert all(r['runtimePassed'] and r['semanticPassed'] for r in records)
    if name == 'static-identity':
        assert all(r['passed'] for r in records)
    output = root / (name + '-callback/output')
    old_output = root / (name + '-final/output')
    files = {p.relative_to(output).as_posix(): digest(p) for p in output.rglob('*.json')}
    old_files = {p.relative_to(old_output).as_posix(): digest(p) for p in old_output.rglob('*.json')}
    assert files == old_files, name
    proof[name] = {'records': records, 'logSha256': digest(log_path), 'unchangedOutputs': files}
proof['unchangedOutputCount'] = sum(len(v.get('unchangedOutputs', {})) for v in proof.values() if isinstance(v, dict))
assert proof['unchangedOutputCount'] == 72
(root / 'static-initialization-callback-api-six-view-evidence.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
directory = root / 'static-initialization-callback-workspaces'
log = (root / (directory.name + '-build.log')).read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
candidate = root / 'static-callback-initialization-cli/candidate-ready'
ready = directory / 'candidate-ready'
assert not ready.exists()
shutil.copytree(directory / 'build/bin/Check/debug', ready, ignore=shutil.ignore_patterns('msbuild'))
shutil.copytree(candidate / 'msbuild', ready / 'msbuild')
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    shutil.copy2(candidate / name, ready / name)
binaries = {p.relative_to(ready).as_posix(): digest(p) for p in ready.rglob('*') if p.is_file()}
for name in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
    assert binaries[name] == binaries['msbuild/' + name] == inputs['binaries'][name]
sources = {p.relative_to(directory).as_posix(): digest(p) for pattern in ['*.cs', '*.csproj', 'Snapshots/*.verified.txt'] for p in directory.glob(pattern) if p.is_file()}
reviews = {name: digest(root / name) for name in ['static-generator-snapshot-review.json', 'static-initialization-callback-api-six-view-evidence.json']}
(root / (directory.name + '-inputs.json')).write_text(json.dumps({'binaries': binaries, 'sourcesAndSnapshots': sources, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified six reviewed corpus repeats, 34 API/runtime records, and 72 unchanged JSON outputs. Froze latest workspace inputs.')
