from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

r = Path('artifacts')
sys.path.insert(0, str(r / 'schema-review-python'))
import jsonschema

schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
validator = jsonschema.Draft202012Validator(schema)
log = r / 'static-trigger-candidate.log'
rows = [json.loads(line) for line in log.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
assert len(rows) == 23 and all(row['runtimePassed'] and row['semanticPassed'] and row['diagnostics'] == 0 for row in rows)
flatten = lambda nodes: [item for node in nodes for item in [node] + flatten(node['children'])]
expected_counts = {'explicit-method-repeated': (1,2), 'explicit-instance': (1,0), 'closed-generic-types': (2,0), 'self-reference': (1,2), 'mutual-reference': (1,0)}
for name, (before_count, touch_count) in expected_counts.items():
    tree = json.loads((r / 'static-trigger-candidate/output' / (name + '-tree.json')).read_text(encoding='utf-8'))
    nodes = flatten(tree['trees'])
    assert sum(node['label'] == 'Sink.Before' for node in nodes) == before_count
    assert sum(node['label'] == 'State.Touch' for node in nodes) == touch_count
    assert not any(node.get('omission', {}).get('reason') == 'cycle' for node in nodes if node.get('omission'))
for name in ['explicit-field-write-order', 'explicit-method-argument-order', 'fields-before-constructor']:
    tree = json.loads((r / 'static-trigger-candidate/output' / (name + '-tree.json')).read_text(encoding='utf-8'))
    labels = [node['label'] for node in flatten(tree['trees'])]
    first, second = ('Sink.Before', 'Sink.Argument') if name == 'fields-before-constructor' else ('Sink.Argument', 'Sink.Before')
    assert labels.index(first) < labels.index(second)
files = sorted((r / 'static-trigger-candidate/output').glob('*.json'))
assert len(files) == 69
for path in files:
    validator.validate(json.loads(path.read_text(encoding='utf-8')))
workspace_inputs = json.loads((r / 'record-copy-repeat-inputs.json').read_text(encoding='utf-8'))['harnesses']['record-copy-compatibility-workspaces']
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
base = r / 'record-copy-compatibility-workspaces'
for group, directory in [('binaries', base / 'candidate-ready'), ('sourcesAndSnapshots', base)]:
    for path, expected in workspace_inputs[group].items():
        assert digest(directory / path) == expected, path
trx = next((r / 'record-copy-compatibility-workspaces-results').glob('*.trx'))
counters = ET.parse(trx).find('.//{*}Counters').attrib
assert counters['passed'] == counters['executed'] == counters['total'] == '22' and counters['failed'] == '0'
proof_files = [log, r / 'static-trigger-candidate/Program.cs', r / 'static-trigger-matrix/Program.cs', r / 'static-initialization-cli-inputs.json', trx, Path('schemas/output-v1.schema.json')]
report = {'staticRuntimeAndApiCasesPassed': 23, 'schemaV1EnvelopesValidated': 69, 'staticOrderingAndInitializationCountsPassed': True, 'recordWorkspaceCounters': counters, 'files': {p.as_posix(): digest(p) for p in proof_files}}
(r / 'static-initialization-api-validation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Validated 23 runtime/API fixtures, explicit ordering/count expectations, 69 schema-v1 envelopes, and 22 record-copy workspace passes with unchanged inputs.')
