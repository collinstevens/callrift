from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
target = root / 'static-coalesce-initialization-corpus'
assert not target.exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
old_index = json.loads((root / 'static-reviewed-views-index.json').read_text(encoding='utf-8'))
reviews = sorted({Path(view['review']).name for view in old_index['views']}) + [
    'static-orchard-workflow-openid-five-review.json', 'static-orchard-elastic-three-review.json', 'static-openid-source-roots-review.json',
    'static-orchard-elastic-restored-root-review.json', 'static-orchard-workflow-restored-root-review.json', 'static-orchard-role-restored-root-review.json', 'static-openid-restored-unchanged-review.json']
records = []
review_hashes = {}
for name in reviews:
    path = root / name
    value = json.loads(path.read_text(encoding='utf-8'))
    review_hashes[path.as_posix()] = digest(path)
    for record in value['views'] if 'views' in value else [value]:
        records.append({**record, 'review': path.as_posix(), 'reviewSha256': digest(path)})
assert len(records) == len({record['view'] for record in records}) == 62
inventory = json.loads((root / 'static-initialization-corpus-review-inventory.json').read_text(encoding='utf-8'))
assert {record['view'] for record in records} == {record['view'] for record in inventory['views']}
source = root / 'static-interceptor-identity-corpus'
shutil.copytree(source, target, ignore=shutil.ignore_patterns('build', 'bin', 'obj', '*-ready', '*.received.*', 'packages.lock.json'))
promotions = []
for record in records:
    for name, expected in record['files'].items():
        folders = [Path(record.get('snapshotDirectory', 'artifacts/static-initialization-callback-corpus/Snapshots')),
            root / 'static-initialization-compatibility-corpus/Snapshots', root / 'static-initialization-six-view-repeat/Snapshots', source / 'Snapshots']
        matches = [folder / filename for folder in folders for filename in [name, name.replace('.received.', '.verified.')] if (folder / filename).exists() and digest(folder / filename) == expected]
        assert matches, (record['view'], name)
        destination = target / 'Snapshots' / name.replace('.received.', '.verified.')
        shutil.copy2(matches[0], destination)
        promotions.append({'view': record['view'], 'source': matches[0].as_posix(), 'target': destination.as_posix(), 'sha256': expected})
(root / (target.name + '-reviews.json')).write_text(json.dumps({'historicalCandidateReviews': records, 'reviews': review_hashes, 'promotions': promotions, 'newCoalesceDifferencesAccepted': False}, indent=2) + '\n', encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-interceptor-corpus.py').read_text(encoding='utf-8').replace("'static-interceptor-identity-corpus'", "'static-coalesce-initialization-corpus'").replace("'static-interceptor-identity-cli/candidate-ready'", "'static-coalesce-initialization-cli-tests/candidate-ready'")
(root / 'freeze-static-coalesce-corpus.py').write_text(freeze, encoding='utf-8', newline='\n')
print('Prepared all89 corpus checks with all62 historical changed-view reviews accounted for. New coalescing differences remain unaccepted.')
