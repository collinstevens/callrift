from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
build = artifacts / 'dispatch-cycle-cli-tests/build/bin/Check/debug'
log = (artifacts / 'dispatch-cycle-cli-tests-build.log').read_text(encoding='utf-8-sig')
assert 'Build succeeded.' in log and '0 Error(s)' in log
base = artifacts / 'dispatch-cardinality-cli-tests/complete-ready'
latest = artifacts / 'dispatch-cardinality-cycle-core/bin/Debug/net11.0/Callrift.Core.dll'
assert hashlib.sha256(latest.read_bytes()).hexdigest() == '505bc5fec6c5d90b49fdab9f358b92c1a509126cda9c064a6c4d4272bda89c8e'
records = {}
for version in ['baseline', 'corrected']:
    target = artifacts / 'dispatch-cycle-cli-tests' / (version + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(base / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    shutil.copy2(base / 'Callrift.MSBuild.dll', target / 'Callrift.MSBuild.dll')
    core = base / 'Callrift.Core.dll' if version == 'baseline' else latest
    shutil.copy2(core, target / 'Callrift.Core.dll')
    shutil.copy2(core, target / 'msbuild/Callrift.Core.dll')
    records[version] = {name: hashlib.sha256((target / name).read_bytes()).hexdigest() for name in ['Check.dll', 'Callrift.Core.dll', 'Callrift.MSBuild.dll', 'msbuild/Callrift.Core.dll', 'msbuild/Callrift.MSBuild.dll']}
records['sources'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in (artifacts / 'dispatch-cardinality-cycle-core').rglob('*.cs') if 'obj' not in file.parts and 'bin' not in file.parts}
(artifacts / 'dispatch-cycle-cli-inputs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['check', 'matrix', 'boundaries']:
    source = artifacts / ('dispatch-cardinality-complete-' + name)
    target = artifacts / ('dispatch-cycle-' + name)
    assert not target.exists()
    target.mkdir()
    shutil.copy2(source / 'Program.cs', target / 'Program.cs')
    project = (source / 'Check.csproj').read_text(encoding='utf-8').replace('dispatch-cardinality-complete-core', 'dispatch-cardinality-cycle-core')
    (target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared two frozen CLI versions and three API matrices.')
