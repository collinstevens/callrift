from pathlib import Path
import collections,copy,hashlib,json
root=Path('artifacts')
directory=root/'constructor-depth-corpus/Snapshots'
manifest=json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
case=next(case for case in manifest if case['id']=='aspnetcore-js-task-handling')
proofs={}
for record in json.loads((root/'constructor-depth-leaf-batch2/aspnetcore-js-task-handling-compiler-report.json').read_text(encoding='utf-8'))['records']:
 if record['provenNoVisibleCalls']:
  leaf=record['leaf'];proofs[(leaf['view'],leaf['nodeId'],leaf['side'])]=leaf

def read(path):
 text=path.read_text(encoding='utf-8-sig');start=text.index('{');document,length=json.JSONDecoder().raw_decode(text[start:]);return document,text[:start],text[start+length:]
def nodes(items):
 for node in items:
  yield node
  yield from nodes(node['children'])
def counter(items):return collections.Counter(json.dumps(item,sort_keys=True) for item in items)
def diagnostic_output(items):
 lines=[]
 for item in items[:8]:
  location=item.get('location');start=(location['path']+':'+str(location['startLine'])+': ') if location else '';lines.append(start+item['code']+': '+item['message'])
 if len(items)>8:lines.append(str(len(items)-8)+' additional diagnostics; use --diagnostics full.')
 return '\n'.join(lines)
checks=[];reviews=[]
for selector in ['focused','roots']:
 view=case['id']+'-source-'+selector
 original,prefix,suffix=read(directory/(view+'-json.verified.txt'));path=directory/(view+'-json.received.txt');actual,new_prefix,new_suffix=read(path)
 assert prefix==new_prefix
 expected=copy.deepcopy(original);reduced=copy.deepcopy(actual)
 configuration=json.loads((root/'constructor-diagnostic-source-review/aspnetcore-js-task-handling.json').read_text(encoding='utf-8'))
 proof=json.loads((root/'constructor-diagnostic-source-review/aspnetcore-base-candidate-review.json').read_text(encoding='utf-8'))
 assert proof['unmatched']==[146] and proof['provenUnboundCount']==204
 top_level=json.loads((root/'constructor-top-level-aspnetcore-review.json').read_text(encoding='utf-8'))
 false_program=next(item['removedDiagnostic'] for item in top_level['views'] if item['view']=='source-'+selector)
 assert configuration['diagnostics'][146]==false_program
 added=[item for index,item in enumerate(configuration['diagnostics']) if index!=146]
 assert len(added)==204
 removed_review=json.loads((root/'constructor-aspnetcore-omitted-initializer-review.json').read_text(encoding='utf-8'))
 removal=next(item for item in removed_review['views'] if item['view']=='source-'+selector)
 removed=removal['removed'];assert len(removed)==6 and removal['sourceTokensCheckedAtBothPins']
 assert removal['omittedConstructorDiagnosticPreserved'] in actual['diagnostics']
 assert counter(actual['diagnostics'])==counter(original['diagnostics'])-counter(removed)+counter(added)
 added_keys=set(counter(added));removed_keys=set(counter(removed))
 assert [item for item in actual['diagnostics'] if json.dumps(item,sort_keys=True) not in added_keys]==[item for item in original['diagnostics'] if json.dumps(item,sort_keys=True) not in removed_keys]
 expected['diagnostics']=actual['diagnostics']
 old_errors=diagnostic_output(original['diagnostics']);new_errors=diagnostic_output(actual['diagnostics'])
 assert suffix.strip()==('stderr:\n'+old_errors).strip() and new_suffix.strip()==('stderr:\n'+new_errors).strip()
 settings=next(item['options'] for item in case['views'] if item['id']=='source-'+selector);depth_limit=int(settings[settings.index('--depth')+1]);externals='--externals' in settings
 depths={};added_nodes=[]
 def add_check(node,side,**extra):
  value=node[side]
  parameter_types=['System.Reflection.PropertyInfo'] if 'ReflectionTaskResultGetter..ctor' in value['symbolId'] else ['string','int'] if value['symbolId'].endswith('..ctor(string,int)') else []
  check={'view':view,'nodeId':node['id'],'side':side,'revision':case[side],'symbolId':value['symbolId'],'signature':value['signature'],'definition':value['definition'],'parameterTypes':parameter_types,'requireSourceBase':False}
  check.update(extra);checks.append(check)
 def strip(items,parent=None,depth=0):
  result=[]
  for index,node in enumerate(items):
   depths[node['id']]=depth
   if depth==0 and node['after'] and node['after']['symbolId']=='source::NativeAotTestApp.Models.AsyncInteropResult..ctor()':
    assert selector=='roots' and node['kind']=='member' and node['change']=='added' and node['before'] is None and node['label']=='new AsyncInteropResult'
    assert node['detail'] is None and node['omission'] is None and node['children']==[]
    value=node['after'];identity='source::NativeAotTestApp.Models.AsyncInteropResult..ctor()'
    definition={'path':'src/Components/Testing/testassets/NativeAotTestApp/Models/Contracts.cs','startLine':17,'startColumn':1,'endLine':17,'endColumn':76}
    assert value=={'symbolId':identity,'signature':'NativeAotTestApp.Models.AsyncInteropResult.AsyncInteropResult() -> void','binding':'resolved','dispatch':'direct','targetIds':[identity],'definition':definition,'callSites':[],'relation':'definition','candidates':None,'origin':'source'}
    add_check(node,'after',newRoot=True);added_nodes.append(node);continue
   if node['label']=='new Object' and parent and parent['label']=='new TaskGenericsUtil.VoidTaskResultGetter':
    assert selector=='focused' and externals and index==0 and depth<=depth_limit
    assert node['kind']=='call' and node['change']==parent['change'] and node['detail'] is None and node['omission'] is None and not node['children']
    for side in ['before','after']:
     value=node[side];assert (value is None)==(parent[side] is None)
     if value:
      identity='source::object..ctor()'
      assert value=={'symbolId':identity,'signature':None,'binding':'resolved','dispatch':'direct','targetIds':[identity],'definition':None,'callSites':[parent[side]['definition']],'relation':'call','candidates':[],'origin':'metadata'}
      add_check(parent,side,expectedBase='object',expectedInitializers=[])
    added_nodes.append(node);continue
   node['children']=strip(node['children'],node,depth+1);result.append(node)
  return result
 reduced['trees']=strip(reduced['trees']);assert len(added_nodes)==1
 old_nodes=list(nodes(expected['trees']));new_nodes=list(nodes(reduced['trees']));assert len(old_nodes)==len(new_nodes)
 metadata=added_markers=removed_markers=0;changed_labels=set()
 for old,new in zip(old_nodes,new_nodes):
  assert old['kind']==new['kind'] and old['label']==new['label']
  for side in ['before','after']:
   assert (old[side] is None)==(new[side] is None)
   if old[side] and any(old[side][key]!=new[side][key] for key in ['signature','definition']):
    assert old[side]['signature'] is None or new[side]['signature']==old[side]['signature']+' -> void'
    assert old[side]['definition'] is None or old[side]['definition']==new[side]['definition']
    assert new['label'] in ['new TaskGenericsUtil.VoidTaskResultGetter','new TaskGenericsUtil.ReflectionTaskResultGetter','new AsyncInteropResult']
    add_check(new,side);old[side]['signature']=new[side]['signature'];old[side]['definition']=new[side]['definition'];metadata+=1
  if old['omission']!=new['omission']:
   changed_labels.add(new['label'])
   if old['omission'] is None:
    assert new['label']=='new TaskGenericsUtil.VoidTaskResultGetter' and externals and depths[new['id']]>=depth_limit, (new['label'],externals,depths[new['id']],depth_limit)
    assert old['detail'] is None and new['detail']=='depth limit' and new['omission']=={'reason':'depth-limit','symbolId':None,'referenceId':None} and not new['children']
    for side in ['before','after']:
     if new[side]:add_check(new,side,expectedBase='object',expectedInitializers=[])
    added_markers+=1
   else:
    assert old['omission']=={'reason':'depth-limit','symbolId':None,'referenceId':None} and old['detail'] in ['depth limit','changes below depth limit']
    assert new['omission'] is None and new['detail'] is None
    for side in ['before','after']:
     if new[side]:
      proof=proofs[(view,new['id'],side)];assert proof['definition']==new[side]['definition'] and proof['symbolId']==new[side]['symbolId']
    removed_markers+=1
   old['omission']=new['omission'];old['detail']=new['detail']
 mapping={new['id']:old['id'] for old,new in zip(old_nodes,new_nodes)}
 for node in new_nodes:
  node['id']=mapping[node['id']]
  if node['omission'] and node['omission']['referenceId']:node['omission']['referenceId']=mapping[node['omission']['referenceId']]
 assert expected==reduced,view
 old_text=(directory/(view+'.verified.txt')).read_text(encoding='utf-8-sig');text_path=directory/(view+'.received.txt');new_text=text_path.read_text(encoding='utf-8-sig')
 assert old_text.count(old_errors)==new_text.count(new_errors)==2;old_text=old_text.replace(old_errors,new_errors)
 if selector=='roots':
  assert new_text.count('\n+ new AsyncInteropResult\n')==4
  old_count=old_text.count('\n+ new AsyncInteropResult\n');assert old_count==2
  new_text=new_text.replace('\n+ new AsyncInteropResult\n\n+ new AsyncInteropResult\n','\n+ new AsyncInteropResult\n')
 old_lines=old_text.splitlines();new_lines=new_text.splitlines();assert len(old_lines)==len(new_lines)
 for old,new in zip(old_lines,new_lines):
  if old==new:continue
  assert any(label in old and label in new for label in changed_labels)
  assert old.replace(' (depth limit)','').replace(' (changes below depth limit)','')==new.replace(' (depth limit)','')
 reviews.append({'view':view,'sourceProofPending':True,'metadataChecks':metadata,'addedNodes':len(added_nodes),'addedDepthMarkers':added_markers,'removedDepthMarkers':removed_markers,'allOtherJsonAndRenderedOutputExact':True,'jsonSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'textSha256':hashlib.sha256(text_path.read_bytes()).hexdigest()})
configuration={'repository':'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/'+case['cacheName'],'beforeRevision':case['before'],'checks':checks}
(root/'constructor-aspnet-source-review/config.json').write_text(json.dumps(configuration,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'constructor-aspnet-view-review.json').write_text(json.dumps({'productionPromoted':False,'reviews':reviews},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(reviews))
