from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
corpus_path = root / 'static-coalesce-initialization-corpus-terminal.json'
corpus = json.loads(corpus_path.read_text(encoding='utf-8'))
repeats = [
    'static-coalesce-ocelot-focused-repeat',
    'static-coalesce-three-roots-repeat',
    'static-coalesce-autofac-pipeline-repeat',
    'static-coalesce-four-views-repeat',
    'static-coalesce-last-two-repeat',
    'static-coalesce-autofac-multi-source-repeat-confirmed',
    'static-coalesce-ocelot-claims-restored-repeat',
    'static-coalesce-final-four-repeat'
]
passed = {}
repeat_proofs = {}
for name in repeats:
    terminal_path = root / (name + '-terminal.json')
    terminal = json.loads(terminal_path.read_text(encoding='utf-8'))
    assert terminal['core'] == corpus['core'] and terminal['worker'] == corpus['worker']
    trx = Path(terminal['trx'])
    assert digest(trx) == terminal['trxSha256']
    tree = ET.parse(trx)
    counters = tree.find('.//{*}Counters').attrib
    assert counters == terminal['counters']
    assert counters['total'] == counters['executed'] == counters['passed'] == str(len(terminal['views']))
    assert all(result.attrib['outcome'] == 'Passed' for result in tree.findall('.//{*}UnitTestResult'))
    directory_name = name.removesuffix('-confirmed')
    inputs_path = root / (directory_name + '-inputs.json')
    assert digest(inputs_path) == terminal['inputsSha256']
    inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
    for filename, expected in inputs['binaries'].items():
        assert digest(root / directory_name / 'candidate-ready' / filename) == expected
    for filename, expected in inputs['sourcesAndSnapshots'].items():
        assert digest(root / directory_name / filename) == expected
    for filename, expected in inputs['reviews'].items():
        assert digest(root / filename) == expected
    for view in terminal['views']:
        assert view not in passed
        passed[view] = terminal_path.as_posix()
    repeat_proofs[terminal_path.as_posix()] = digest(terminal_path)
assert set(passed) == set(corpus['reviewedDifferences'])
for filename, expected in corpus['reviews'].items():
    assert digest(Path(filename)) == expected
assert digest(Path(corpus['trx'])) == corpus['trxSha256']
assert digest(root / 'static-coalesce-initialization-corpus-reviews.json') == corpus['historicalReviewsSha256']
integration = json.loads((root / 'static-production-integration.json').read_text(encoding='utf-8'))
for record in integration['files']:
    assert digest(Path(record['source'])) == digest(Path(record['target'])) == record['sha256']
changes = [record for record in corpus['files'] if record['sha256'] != record['productionPriorSha256']]
for record in corpus['files']:
    assert digest(Path(record['source'])) == record['sha256']
    assert digest(Path(record['target'])) == record['productionPriorSha256']
    data = Path(record['source']).read_bytes()
    assert data.startswith(b'\xef\xbb\xbf') and b'\r' not in data
for record in changes:
    shutil.copy2(record['source'], record['target'])
for record in corpus['files']:
    assert digest(Path(record['target'])) == record['sha256']
proof = {'corpusTerminalSha256': digest(corpus_path), 'core': corpus['core'], 'worker': corpus['worker'], 'repeatProofs': repeat_proofs, 'passedReviewedViews': passed, 'promoted': changes, 'allFinalSnapshots': len(corpus['files'])}
(root / 'static-production-corpus-promotion.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Promoted', len(changes), 'reviewed snapshot files; all', len(corpus['files']), 'final production snapshots match the reviewed full run and 17 passing repeats.')
