from pathlib import Path
import copy
import hashlib
import json
import re

root = Path.cwd()
snapshots = root / 'artifacts/generic-context-final-corpus/Snapshots'
audit = json.loads((root / 'artifacts/generic-context-limit-location-audit.json').read_text(encoding='utf-8'))
located = {(r['snapshot'], r['message'], json.dumps(r['location'], sort_keys=True)) for r in audit}
reviewed, outstanding = [], []
for received in sorted(snapshots.glob('*-json.received.txt')):
    stem = received.name.removesuffix('-json.received.txt')
    try:
        def read_json(path):
            text = path.read_text(encoding='utf-8-sig')
            assert text.startswith('exit: 0\nstdout:\n')
            content, stderr = text.split('stdout:\n', 1)[1].split('stderr:\n', 1)
            return json.loads(content), stderr
        old, old_error = read_json(snapshots / (stem + '-json.verified.txt'))
        new, new_error = read_json(received)
        limits = [d for d in new['diagnostics'] if d['code'] == 'generic-context-limit']
        assert limits, 'no added bound diagnostics'
        assert [d for d in new['diagnostics'] if d['code'] != 'generic-context-limit'] == old['diagnostics'], 'existing diagnostics or their order changed'
        for diagnostic in limits:
            assert re.fullmatch(r'Generic invocation expansion for .+ exceeded (?:128 type nodes|65536 additional invocation states)(?: and (?:128 type nodes|65536 additional invocation states))?\.', diagnostic['message']), diagnostic
            assert (received.name, diagnostic['message'], json.dumps(diagnostic['location'], sort_keys=True)) in located, 'location audit pending'
        candidate = copy.deepcopy(new)
        candidate['diagnostics'] = old['diagnostics']
        assert candidate['analysis']['limitations'] == old['analysis']['limitations'] + ['generic-context-limit'], 'unexpected coverage changes'
        assert candidate['analysis']['status'] == 'partial'
        candidate['analysis'] = old['analysis']
        assert candidate['truncated'] is True
        candidate['truncated'] = old['truncated']
        assert candidate == old, 'non-diagnostic JSON changed'
        expected_error = ''.join((f"{d['location']['path']}:{d['location']['startLine']}: " if d.get('location') else '') + d['code'] + ': ' + d['message'] + '\n' for d in new['diagnostics'][:8])
        if len(new['diagnostics']) > 8: expected_error += f"{len(new['diagnostics']) - 8} additional diagnostics; use --diagnostics full.\n"
        assert new_error.strip() == expected_error.strip(), 'JSON stderr disagrees with diagnostics'
        pattern = r'format: (text|md)\nexit: 0\nstdout:\n(.*?)stderr:\n(.*?)(?=\nformat: (?:text|md)\n|\Z)'
        old_text = (snapshots / (stem + '.verified.txt')).read_text(encoding='utf-8-sig')
        new_text = (snapshots / (stem + '.received.txt')).read_text(encoding='utf-8-sig')
        old_formats = re.findall(pattern, old_text, re.S)
        new_formats = re.findall(pattern, new_text, re.S)
        assert len(old_formats) == len(new_formats) == 2
        assert [f[0] for f in new_formats] == ['text', 'md']
        for before, after in zip(old_formats, new_formats):
            assert before[:2] == after[:2], 'rendered call-flow text changed'
            assert after[2].strip() == expected_error.strip(), 'rendered stderr disagrees with JSON'
        files = []
        for suffix in ['', '-json']:
            path = snapshots / (stem + suffix + '.received.txt')
            files.append({'received': path.relative_to(root).as_posix(), 'target': 'tests/Callrift.RealWorldCases/Snapshots/' + stem + suffix + '.verified.txt', 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        reviewed.append({'view': stem, 'limitDiagnostics': len(limits), 'unchangedJsonTrees': True, 'unchangedRenderedBodies': True, 'files': files})
    except AssertionError as error:
        outstanding.append({'view': stem, 'reason': str(error)})
result = {'reviewedDiagnosticOnlyViews': reviewed, 'outstanding': outstanding, 'promoted': False}
(root / 'artifacts/generic-context-diagnostic-update-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reviewed), 'outstanding': outstanding, 'promoted': False}))
