from pathlib import Path
import collections
import json
import re
import subprocess
from static_review_support import root, manifest, flatten, prior_fields_and_diagnostics, initializer_evidence, digest

case_id = 'aspnetcore-js-task-handling'
case = manifest[case_id]
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore'
key, proven = initializer_evidence(case_id)
call_directory = root / 'static-initializer-call-source-review'
call_report_path = call_directory / 'aspnet-report.json'
call_report = json.loads(call_report_path.read_text(encoding='utf-8'))
assert call_report['checks'] == 14 and call_report['failures'] == 0 and all(record['passed'] for record in call_report['records'])
assert digest(call_directory / 'build/bin/Check/debug/Callrift.Core.dll') == '6070cfce625d61e38897de8f7af35eb887826407f56cfeaa06593b6ace347032'
call_key = lambda revision, location: json.dumps({'revision': revision, 'location': location}, sort_keys=True)
calls = {call_key(record['check']['revision'], record['check']['location']): record for record in call_report['records']}
runtime_path = 'src/Components/WebAssembly/WebAssembly/src/Services/DefaultWebAssemblyJSRuntime.cs'
queue_path = 'src/Components/WebAssembly/WebAssembly/src/Hosting/WebAssemblyCallQueue.cs'
task_path = 'src/JSInterop/Microsoft.JSInterop/src/Infrastructure/TaskGenericsUtil.cs'
dispatcher_path = 'src/JSInterop/Microsoft.JSInterop/src/Infrastructure/DotNetDispatcher.cs'
blobs = {}
for path in [runtime_path, queue_path, task_path, dispatcher_path]:
    blobs[path] = {}
    for side in ['before', 'after']:
        revision = case[side]
        text = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
        if path == runtime_path:
            assert 'public static readonly DefaultWebAssemblyJSRuntime Instance = new();' in text
            assert 'DotNetDispatcher.BeginInvokeDotNet(Instance, state.callInfo, state.argsJson);' in text
            assert 'return DotNetDispatcher.Invoke(Instance, callInfo, argsJson);' in text
        elif path == queue_path:
            assert 'private static readonly Queue<Action> _pendingWork = new();' in text
            assert 'if (_isCallInProgress)' in text and '_pendingWork.Enqueue(() => callback(state));' in text
        elif path == task_path:
            assert text.index('= new ConcurrentDictionary<Type, ITaskResultGetter>();') < text.index('= new ConcurrentDictionary<Type, ITcsResultSetter>();')
        else:
            snippets = ['JsonEncodedText.Encode("__dotNetObject")', '_cachedMethodsByAssembly = new()', '_cachedMethodsByType = new()', '_cachedConvertToTaskByType = new()', 'typeof(DotNetDispatcher).GetMethod(nameof(CreateValueTaskConverter), BindingFlags.NonPublic | BindingFlags.Static)']
            assert [text.index(value) for value in snippets] == sorted(text.index(value) for value in snippets)
        blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip()
assert blobs[runtime_path]['before'] == blobs[runtime_path]['after'] and blobs[queue_path]['before'] == blobs[queue_path]['after']

def roots_json(expected):
    nodes = [node for node in flatten(expected['trees']) if node['label'] == 'WebAssemblyCallQueue.Schedule']
    assert len(nodes) == 1 and nodes[0]['detail'] is None and nodes[0]['omission'] is None
    nodes[0]['detail'] = 'depth limit'
    nodes[0]['omission'] = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
    return expected

def roots_render(old, new):
    normalize = lambda text: [re.sub(r'^[ │├└─]*', '', line) for line in text.splitlines() if 'possible initialization of ' not in line]
    left, right = normalize(old), normalize(new)
    assert right.count('WebAssemblyCallQueue.Schedule (depth limit)') == 1
    right[right.index('WebAssemblyCallQueue.Schedule (depth limit)')] = 'WebAssemblyCallQueue.Schedule'
    assert left == right

def focused_render(old, new):
    additions = [
        '- │  ├─ possible initialization of TaskGenericsUtil\n',
        '- │  │  └─ initialization of TaskGenericsUtil\n',
        '- │  │     ├─ new ConcurrentDictionary<Type, ITaskResultGetter>\n',
        '- │  │     └─ new ConcurrentDictionary<Type, ITcsResultSetter>\n',
        '+ │     ├─ possible initialization of TaskGenericsUtil\n',
        '+ │     │  └─ initialization of TaskGenericsUtil (depth limit)\n',
        '  ├─ possible initialization of DotNetDispatcher\n',
        '  ├─ possible initialization of TaskGenericsUtil\n']
    for line in additions:
        assert new.count(line) == 1
        new = new.replace(line, '')
    assert old == new

reviews = []
for suffix, check_render, transform in [('source-focused', focused_render, None), ('source-roots', roots_render, roots_json)]:
    before, after, review = prior_fields_and_diagnostics(case_id + '-' + suffix, stdout_check=check_render, prior_json_transform=transform)
    branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
    expected = [('possible initialization of TaskGenericsUtil', 'removed', 2), ('possible initialization of TaskGenericsUtil', 'added', 0), ('possible initialization of DotNetDispatcher', 'unchanged', 5), ('possible initialization of TaskGenericsUtil', 'unchanged', 2)] if suffix == 'source-focused' else [('possible initialization of DefaultWebAssemblyJSRuntime', 'unchanged', 0)] * 2
    assert [(branch['label'], branch['change'], len(branch['children'][0]['children'])) for branch in branches] == expected
    evidence_records = []
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == branch['change']
        depth_limited = suffix == 'source-roots' or branch['change'] == 'added'
        assert initializer['omission'] == ({'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} if depth_limited else None)
        for side in ['before', 'after']:
            value, structural = initializer[side], branch[side]
            if value is None:
                assert structural is None and (side, branch['change']) in [('before', 'added'), ('after', 'removed')]
                continue
            relation = 'callback' if suffix == 'source-roots' and value['callSites'][0]['startLine'] == 92 else 'branch'
            assert structural['relation'] == relation and structural['binding'] == 'structural' and structural['origin'] == 'structural'
            assert structural['symbolId'] is None and structural['targetIds'] == [] and structural['definition'] is None and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']]
            evidence = proven[key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']})]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            evidence_records.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
        if initializer['children']:
            if 'TaskGenericsUtil' in initializer['label']:
                assert [child['label'] for child in initializer['children']] == ['new ConcurrentDictionary<Type, ITaskResultGetter>', 'new ConcurrentDictionary<Type, ITcsResultSetter>']
            else:
                assert [child['label'] for child in initializer['children']] == ['JsonEncodedText.Encode', 'new', 'new', 'new', 'typeof(DotNetDispatcher).GetMethod']
        for child in initializer['children']:
            assert child['children'] == [] and child['omission'] is None and child['change'] == initializer['change']
            for side in ['before', 'after']:
                value = child[side]
                if value is None:
                    continue
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'metadata' and value['relation'] == 'call'
                assert value['definition'] is None and value['signature'] is None and value['targetIds'] == [value['symbolId']]
                call = calls[call_key(case[side], value['callSites'][0])]
                assert call['passed']
                suffix_id = {'System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>': 'System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>..ctor()', 'System.Text.Json.JsonEncodedText': 'System.Text.Json.JsonEncodedText.Encode(string,global::System.Text.Encodings.Web.JavaScriptEncoder)', 'System.Type': 'System.Type.GetMethod(string,global::System.Reflection.BindingFlags)'}[call['check']['type']]
                assert value['symbolId'] == 'source::' + suffix_id
    review.update(initializerBranches=len(branches), immutableSourceBlobs=blobs, sourceLocations=evidence_records, metadataCallSourceReportSha256=digest(call_report_path), metadataCallReviewerSourceSha256=digest(call_directory / 'Program.cs'), metadataCallConfigSha256=digest(call_directory / 'aspnet.json'), review='New dictionary/JSON/reflection calls are source-ordered metadata bindings. DefaultWebAssemblyJSRuntime singleton construction stays depth-limited, and the BeginInvokeDotNet initializer retains callback relation. Schedule now has hidden initialization work from its static field reads. Other JSON fields and rendered lines are unchanged outside the explicitly checked branches, one depth marker, and 172 independently proven diagnostics.')
    reviews.append(review)
(root / 'static-aspnet-views-review.json').write_text(json.dumps({'views': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed both ASP.NET Core views: six initializer branches, fourteen independent metadata binding checks, one depth marker, and 344 diagnostic occurrences.')
