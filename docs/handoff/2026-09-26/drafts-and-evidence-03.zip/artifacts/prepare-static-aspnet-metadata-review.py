from pathlib import Path
import json
from static_review_support import root, manifest, document, snapshots, flatten

case = manifest['aspnetcore-js-task-handling']
after = document(snapshots / 'aspnetcore-js-task-handling-source-focused-json.received.txt')
checks = {}
for branch in flatten(after['trees']):
    if not branch['label'].startswith('possible initialization of '):
        continue
    initializer = branch['children'][0]
    for node in initializer['children']:
        for side in ['before', 'after']:
            value = node[side]
            if value is None:
                continue
            if node['label'].startswith('new'):
                expected_type, expected_name, parameters = 'System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>', '.ctor', []
            elif node['label'] == 'JsonEncodedText.Encode':
                expected_type, expected_name, parameters = 'System.Text.Json.JsonEncodedText', 'Encode', ['string', 'System.Text.Encodings.Web.JavaScriptEncoder?']
            else:
                assert node['label'] == 'typeof(DotNetDispatcher).GetMethod'
                expected_type, expected_name, parameters = 'System.Type', 'GetMethod', ['string', 'System.Reflection.BindingFlags']
            assert len(value['callSites']) == 1
            check = {'revision': case[side], 'location': value['callSites'][0], 'type': expected_type, 'name': expected_name, 'parameters': parameters}
            checks[json.dumps(check, sort_keys=True)] = check
target = root / 'static-initializer-call-source-review'
(target / 'aspnet.json').write_text(json.dumps({'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/aspnetcore', 'checks': list(checks.values())}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared ' + str(len(checks)) + ' distinct immutable-source metadata call checks.')
