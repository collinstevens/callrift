from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
for name in ['cli', 'workspaces']:
    target = artifacts / f'constructor-exact-{name}'
    assert not target.exists()
    target.mkdir()
    source = artifacts / ('constructor-integration-tests' if name == 'cli' else 'dispatch-cycle-workspaces')
    for file in source.glob('*.cs'):
        shutil.copy2(file, target / file.name)
    project = (source / 'Check.csproj').read_text(encoding='utf-8')
    if name == 'cli':
        shutil.copy2(artifacts / 'ConstructorDiagnosticTests.cs', target / 'ConstructorDiagnosticTests.cs')
        project = project.replace('<Compile Include="ConstructorInitializationTests.cs" />', '<Compile Include="ConstructorInitializationTests.cs" />\n    <Compile Include="ConstructorDiagnosticTests.cs" />')
    else:
        shutil.copytree(source / 'Snapshots', target / 'Snapshots', ignore=shutil.ignore_patterns('*.received.*'))
    (target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
    inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    (artifacts / f'constructor-exact-{name}-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared frozen sources for 58 constructor CLI checks and 22 workspace checks.')
