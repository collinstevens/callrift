from pathlib import Path
import collections
import copy
import hashlib
import json
import sys

root = Path('artifacts')
snapshots = root / 'static-initialization-callback-corpus/Snapshots'
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema

digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
manifest = {value['id']: value for value in json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))}
source_coverage_path = root / 'static-corpus-source-coverage.json'
source_coverage = {value['view']: value for value in json.loads(source_coverage_path.read_text(encoding='utf-8'))['views']}

def document(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def flatten(nodes):
    for node in nodes:
        yield node
        yield from flatten(node['children'])

def clean(value):
    if isinstance(value, list):
        return [clean(item) for item in value if not isinstance(item, dict) or not item.get('label', '').startswith('possible initialization of ')]
    if isinstance(value, dict):
        return {key: clean(item) for key, item in value.items() if key not in ['id', 'diagnostics']}
    return value

def rendered(path):
    text = path.read_text(encoding='utf-8-sig')
    first, second = text.split('format: md\nexit: 0\nstdout:\n')
    first = first.split('format: text\nexit: 0\nstdout:\n')[1]
    plain, first_error = first.split('stderr:\n')
    markdown, second_error = second.split('stderr:\n')
    assert markdown.startswith('```diff\n') and markdown.endswith('```\n')
    assert plain == markdown.removeprefix('```diff\n').removesuffix('```\n')
    assert first_error.strip('\n') == second_error.strip('\n')
    return plain, first_error.strip('\n')

def prior_fields_and_diagnostics(name, remove_root=None, stdout_transform=None, stdout_check=None, prior_json_transform=None):
    before_path = snapshots / (name + '-json.verified.txt')
    after_path = snapshots / (name + '-json.received.txt')
    before, after = document(before_path), document(after_path)
    jsonschema.validate(after, schema)
    expected = before if remove_root is None else {**before, 'trees': [node for node in before['trees'] if node['label'] != remove_root]}
    if prior_json_transform is not None:
        expected = prior_json_transform(copy.deepcopy(expected))
    assert clean(expected) == clean(after), name
    counter = lambda values: collections.Counter(json.dumps(value, sort_keys=True) for value in values)
    old, new = counter(before['diagnostics']), counter(after['diagnostics'])
    assert not old - new
    evidence = source_coverage[name]['diagnostics']
    assert new - old == counter([record['diagnostic'] for record in evidence]), name
    for record in evidence:
        assert digest(Path(record['report'])) == record['reportSha256']
        assert digest(Path(record['config'])) == record['configSha256']
    before_text_path = snapshots / (name + '.verified.txt')
    after_text_path = snapshots / (name + '.received.txt')
    if not after_text_path.exists():
        after_text_path = before_text_path
    plain, stderr = rendered(after_text_path)
    expected_stderr = []
    for diagnostic in after['diagnostics'][:8]:
        location = diagnostic['location']
        prefix = '' if location is None else f"{location['path']}:{location['startLine']}: "
        expected_stderr.append(prefix + diagnostic['code'] + ': ' + diagnostic['message'])
    if len(after['diagnostics']) > 8:
        expected_stderr.append(f"{len(after['diagnostics']) - 8} additional diagnostics; use --diagnostics full.")
    assert stderr == '\n'.join(expected_stderr), name
    old_plain = rendered(before_text_path)[0]
    if stdout_check is None:
        assert plain == (old_plain if stdout_transform is None else stdout_transform(old_plain)), name
    else:
        stdout_check(old_plain, plain)
    record = {'view': name, 'allPriorJsonPreservedExceptNodeIdsAndReviewedDiagnosticsAndNamedRootRemoval': True, 'removedRoot': remove_root, 'unchangedRenderedStdout': stdout_transform is None and stdout_check is None, 'schemaV1': True, 'addedDiagnostics': sum((new - old).values()), 'sourceCoverageSha256': digest(source_coverage_path), 'files': {path.name: digest(path) for path in [after_path, after_text_path]}, 'repeatStatus': 'pending'}
    return before, after, record

def initializer_evidence(case_id):
    proven = {}
    key = lambda value: json.dumps({name: value[name] for name in ['revision', 'symbolId', 'definition', 'callSites']}, sort_keys=True)
    for folder in ['static-initializer-source-review', 'static-initializer-source-batch2-review', 'static-initializer-source-batch3-review']:
        path = root / folder / (case_id + '-report.json')
        if not path.exists():
            continue
        report = json.loads(path.read_text(encoding='utf-8'))
        for record in report['records']:
            if record.get('passed'):
                proven[key(record['check'])] = {'record': record, 'path': path.as_posix(), 'sha256': digest(path)}
    return key, proven
