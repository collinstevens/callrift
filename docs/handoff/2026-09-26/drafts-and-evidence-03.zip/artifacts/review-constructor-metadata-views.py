from pathlib import Path
import collections
import copy
import hashlib
import json

root = Path('artifacts')
directory = root / 'constructor-depth-corpus/Snapshots'
manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
proofs = {}
for folder in ['constructor-depth-leaf-source-review', 'constructor-depth-leaf-batch2', 'constructor-depth-leaf-batch3', 'constructor-depth-leaf-batch4', 'constructor-depth-leaf-batch5']:
    for path in (root / folder).glob('*-compiler-report.json'):
        for record in json.loads(path.read_text(encoding='utf-8'))['records']:
            if record['provenNoVisibleCalls']:
                leaf = record['leaf']
                proofs[(leaf['view'], leaf['nodeId'], leaf['side'])] = leaf

def read(path):
    text = path.read_text(encoding='utf-8-sig')
    start = text.index('{')
    document, length = json.JSONDecoder().raw_decode(text[start:])
    return document, text[:start], text[start + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

def diagnostic_output(items):
    lines = []
    for item in items[:8]:
        location = item.get('location')
        start = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
        lines.append(start + item['code'] + ': ' + item['message'])
    if len(items) > 8:
        lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
    return '\n'.join(lines)

jobs = {}
reviews = []
for view in ['polly-caller-cancellation-source-focused', 'polly-caller-cancellation-source-roots', 'polly-executor-continuations-source-roots',
             'polly-telemetry-source-source-roots', 'autofac-held-pipeline-source-roots']:
    case = next(case for case in manifest if view.startswith(case['id'] + '-'))
    original, prefix, suffix = read(directory / (view + '-json.verified.txt'))
    path = directory / (view + '-json.received.txt')
    actual, new_prefix, new_suffix = read(path)
    expected = copy.deepcopy(original)
    assert prefix == new_prefix
    diagnostic_directory = root / 'constructor-diagnostic-source-review'
    configuration = json.loads((diagnostic_directory / (case['id'] + '.json')).read_text(encoding='utf-8'))
    proof = json.loads((diagnostic_directory / (case['id'] + '-report.json')).read_text(encoding='utf-8'))
    assert not proof['unmatched'] and proof['provenMissingBaseCount'] == proof['diagnosticCount']
    counter = lambda items: collections.Counter(json.dumps(item, sort_keys=True) for item in items)
    added = counter(configuration['diagnostics'])
    assert counter(actual['diagnostics']) == counter(original['diagnostics']) + added
    assert [item for item in actual['diagnostics'] if json.dumps(item, sort_keys=True) not in added] == original['diagnostics']
    expected['diagnostics'] = actual['diagnostics']
    old_errors = diagnostic_output(original['diagnostics'])
    new_errors = diagnostic_output(actual['diagnostics'])
    assert suffix.strip() == 'stderr:\n' + old_errors and new_suffix.strip() == 'stderr:\n' + new_errors
    old_nodes = list(nodes(expected['trees']))
    new_nodes = list(nodes(actual['trees']))
    assert len(old_nodes) == len(new_nodes)
    added_markers = 0
    removed_markers = 0
    metadata_checks = 0
    changed_labels = set()
    for old, new in zip(old_nodes, new_nodes):
        assert old['id'] == new['id']
        new_boundary = old['omission'] is None and new['omission'] is not None
        checked_sides = []
        for side in ['before', 'after']:
            assert (old[side] is None) == (new[side] is None)
            if old[side] is None:
                continue
            if old[side]['signature'] != new[side]['signature'] or old[side]['definition'] != new[side]['definition']:
                assert old[side]['signature'] is None or new[side]['signature'] == old[side]['signature'] + ' -> void'
                assert old[side]['definition'] is None or old[side]['definition'] == new[side]['definition']
                assert new[side]['symbolId'].endswith('..ctor()') and new[side]['definition'] is not None
                check = {'view': view, 'nodeId': new['id'], 'side': side, 'revision': case[side], 'symbolId': new[side]['symbolId'],
                         'signature': new[side]['signature'], 'definition': new[side]['definition'], 'requireSourceBase': new_boundary}
                job = jobs.setdefault(case['id'], {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': []})
                job['checks'].append(check)
                old[side]['signature'] = new[side]['signature']
                old[side]['definition'] = new[side]['definition']
                metadata_checks += 1
                checked_sides.append(side)
        if old['omission'] != new['omission']:
            changed_labels.add(new['label'])
            if new_boundary:
                assert new['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and new['detail'] == 'depth limit'
                assert old['detail'] is None and not new['children']
                assert all(side in checked_sides for side in ['before', 'after'] if new[side])
                added_markers += 1
            else:
                assert old['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None} and old['detail'] in ['depth limit', 'changes below depth limit']
                assert new['omission'] is None and new['detail'] is None
                for side in ['before', 'after']:
                    if new[side]:
                        proof = proofs[(view, new['id'], side)]
                        assert proof['definition'] == new[side]['definition'] and proof['symbolId'] == new[side]['symbolId']
                removed_markers += 1
            old['omission'] = new['omission']
            old['detail'] = new['detail']
    assert expected == actual, view
    old_text = (directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = directory / (view + '.received.txt')
    if not text_path.exists():
        text_path = directory / (view + '.verified.txt')
    new_text = text_path.read_text(encoding='utf-8-sig')
    assert old_text.count(old_errors) == new_text.count(new_errors) == 2
    old_text = old_text.replace(old_errors, new_errors)
    old_lines = old_text.splitlines()
    new_lines = new_text.splitlines()
    assert len(old_lines) == len(new_lines)
    for old, new in zip(old_lines, new_lines):
        if old == new:
            continue
        assert any(label in old and label in new for label in changed_labels)
        assert old.replace(' (depth limit)', '').replace(' (changes below depth limit)', '') == new.replace(' (depth limit)', '')
    reviews.append({'view': view, 'sourceProofPending': True, 'metadataChecks': metadata_checks, 'addedDepthMarkers': added_markers,
                    'removedDepthMarkers': removed_markers, 'allOtherJsonAndRenderedOutputExact': True,
                    'jsonSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'textSha256': hashlib.sha256(text_path.read_bytes()).hexdigest()})
for name, configuration in jobs.items():
    (root / 'constructor-metadata-source-review' / (name + '.json')).write_text(json.dumps(configuration, indent=2) + '\n', encoding='utf-8', newline='\n')
(root / 'constructor-metadata-view-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reviews))
