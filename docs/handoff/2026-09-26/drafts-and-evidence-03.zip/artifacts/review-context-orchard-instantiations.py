from pathlib import Path
import collections
import copy
import hashlib
import json
import re
import subprocess
import sys

root = Path.cwd()
folder = root / 'artifacts/generic-context-final-corpus/Snapshots'
source_mode = 'source' in sys.argv
mode = 'source' if source_mode else 'msbuild'
stem = 'orchardcore-workflow-startup-' + mode + '-focused'
def read(version):
    text = (folder / f'{stem}-json.{version}.txt').read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
old, new = read('verified'), read('received')
def call(data):
    return data['trees'][0]['children'][5]['children'][0]['children'][8]['children'][0]
assert len(call(old)['children']) == 2
assert len(call(new)['children']) == (82 if source_mode else 31)
assert call(old)['before'] == call(new)['before']
assert call(old)['after'] == call(new)['after']
candidate = copy.deepcopy(new)
if source_mode:
    limits = [d for d in new['diagnostics'] if d['code'] == 'generic-context-limit']
    assert len(limits) == 41
    assert [d for d in new['diagnostics'] if d['code'] != 'generic-context-limit'] == old['diagnostics']
    audit = json.loads((root / 'artifacts/generic-context-limit-location-audit.json').read_text(encoding='utf-8'))
    located = {(r['snapshot'], r['message'], json.dumps(r['location'], sort_keys=True)) for r in audit}
    for diagnostic in limits:
        assert diagnostic['message'].endswith(' exceeded 65536 additional invocation states.')
        assert (stem + '-json.received.txt', diagnostic['message'], json.dumps(diagnostic['location'], sort_keys=True)) in located
    assert candidate['analysis']['limitations'] == old['analysis']['limitations'] + ['generic-context-limit']
    assert candidate['analysis']['status'] == 'partial'
    candidate['analysis'] = old['analysis']
    candidate['diagnostics'] = old['diagnostics']
seen, kept = set(), []
for child in call(candidate)['children']:
    assert child['change'] == 'unchanged'
    assert child['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
    assert not child['children']
    key = json.dumps({k: v for k, v in child.items() if k != 'id'}, sort_keys=True)
    if key not in seen:
        seen.add(key)
        kept.append(child)
call(candidate)['children'] = kept
def nodes(trees):
    for tree in trees:
        yield tree
        yield from nodes(tree['children'])
all_nodes = list(nodes(candidate['trees']))
ids = {node['id']: 'n' + str(index) for index, node in enumerate(all_nodes)}
for node in all_nodes:
    node['id'] = ids[node['id']]
    if node['omission'] and node['omission'].get('referenceId'):
        node['omission']['referenceId'] = ids[node['omission']['referenceId']]
assert candidate == old, 'Other JSON behavior changed'
if source_mode:
    old_text = (folder / (stem + '.verified.txt')).read_text(encoding='utf-8-sig')
    new_text = (folder / (stem + '.received.txt')).read_text(encoding='utf-8-sig')
    pattern = r'format: (text|md)\nexit: 0\nstdout:\n(.*?)stderr:\n(.*?)(?=\nformat: (?:text|md)\n|\Z)'
    before_formats, after_formats = re.findall(pattern, old_text, re.S), re.findall(pattern, new_text, re.S)
    assert len(before_formats) == len(after_formats) == 2
    error = ''.join((f"{d['location']['path']}:{d['location']['startLine']}: " if d.get('location') else '') + d['code'] + ': ' + d['message'] + '\n' for d in new['diagnostics'][:8])
    error += f"{len(new['diagnostics']) - 8} additional diagnostics; use --diagnostics full.\n"
    for before, after in zip(before_formats, after_formats):
        assert before[:2] == after[:2]
        assert after[2].strip() == error.strip()
else:
    assert not (folder / (stem + '.received.txt')).exists(), 'Rendered output changed'
trace_name = 'generic-context-orchard-source-bindings.log' if source_mode else 'generic-context-orchard-bindings.log'
trace = [json.loads(line) for line in (root / 'artifacts' / trace_name).read_text(encoding='utf-8-sig').splitlines()]
assert len(trace) == (83 if source_mode else 32)
assert trace[0]['DispatchType']['Arguments'][0]['Name'].endswith('::global::OrchardCore.Workflows.Activities.IActivity')
concrete = []
for target in trace[1:]:
    bindings = target['Key'].split('\x1e')[1]
    match = re.search(r':1=(?:OrchardCore.Workflows|Callrift.Source)::global::([\w.]+)<>;', bindings) if 'TConcrete' in target['Label'] else None
    if match:
        concrete.append(match[1].split('.')[-1])
assert len(concrete) == len(set(concrete)) == (67 if source_mode else 24)
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
revision = 'ee892e7e9fb30305110504bf553dcf4265e6c02a'
declarations = subprocess.check_output(['git', '-C', repository, 'grep', '-n', 'DisplayDriver<', revision, '--', 'src'], text=True, encoding='utf-8').splitlines()
matches = {name: [line for line in declarations if re.search(r'DisplayDriver<' + name + r'(?:,|>)', line)] for name in concrete}
assert all(lines for lines in matches.values()), {k: v for k, v in matches.items() if not v}
received = folder / (stem + '-json.received.txt')
report = {
    'view': stem,
    'oldNodes': sum(1 for _ in nodes(old['trees'])),
    'newNodes': sum(1 for _ in nodes(new['trees'])),
    'declarationTargets': 2,
    'instantiatedTargets': len(trace) - 1,
    'closedActivityTargets': matches,
    'otherConservativeContexts': len(trace) - 1 - len(concrete),
    'onlyIdenticalDepthLimitedInstancesAndTraversalIdsChanged': True,
    'unchangedRenderedBodies': True,
    'addedLimitDiagnostics': 41 if source_mode else 0,
    'received': received.relative_to(root).as_posix(),
    'target': 'tests/Callrift.RealWorldCases/Snapshots/' + stem + '-json.verified.txt',
    'sha256': hashlib.sha256(received.read_bytes()).hexdigest(),
    'promoted': False
}
(root / ('artifacts/generic-context-orchard-' + mode + '-instantiation-review.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: value for key, value in report.items() if key != 'closedActivityTargets'}))
