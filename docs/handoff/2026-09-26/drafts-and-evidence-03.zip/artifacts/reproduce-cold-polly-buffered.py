import json
import os
from pathlib import Path
import subprocess
import time

root = Path('C:/Users/Admin/AppData/Local/Callrift/inspection/cold-polly-20260924-buffered')
root.mkdir(parents=True, exist_ok=False)
out = Path('artifacts').resolve()
revision = 'f2a07e687b3020f6cbaaf9192f14e1f8845682e3'
repo = root / 'polly'

def run(args, **kwargs):
    result = subprocess.run(args, capture_output=True, timeout=120, **kwargs)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace'))
    return result.stdout

started = time.monotonic()
run(['git', 'clone', '--filter=blob:none', '--no-checkout', '--single-branch', 'https://github.com/App-vNext/Polly.git', str(repo)])
run(['git', '-C', str(repo), 'cat-file', '-e', revision + '^{commit}'])
entries = run(['git', '-C', str(repo), 'ls-tree', '-r', '-z', revision]).decode('utf-8').split('\0')
selected = []
for entry in entries:
    if not entry:
        continue
    info, path = entry.split('\t', 1)
    mode, kind, oid = info.split()
    if path.startswith('src/') and path.endswith('.cs'):
        selected.append((oid, path))
    if len(selected) == 20:
        break
ids = ('\n'.join(oid for oid, path in selected) + '\n').encode('ascii')
missing = run(['git', '--no-lazy-fetch', '-C', str(repo), 'cat-file', '--batch-check'], input=ids).decode('utf-8').splitlines()
assert len(missing) == 20 and all(line.endswith(' missing') for line in missing), missing
trace = out / 'cold-polly-buffered-trace.jsonl'
env = dict(os.environ, GIT_TRACE2_EVENT=str(trace))
read_start = time.monotonic()
content = run(['git', '-C', str(repo), 'cat-file', '--batch-command', '--buffer'], input=('\n'.join('contents ' + oid for oid, path in selected) + '\nflush\n').encode('ascii'), env=env)
read_elapsed = time.monotonic() - read_start
(out / 'cold-polly-buffered-bytes.bin').write_bytes(content)
events = [json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines()]
fetches = [event['argv'] for event in events if event.get('event') == 'child_start' and 'fetch' in event.get('argv', [])]
report = {'repository': 'https://github.com/App-vNext/Polly.git', 'revision': revision, 'cache': str(repo), 'selected': selected, 'initiallyMissing': len(missing), 'fetchProcesses': len(fetches), 'fetchCommands': fetches, 'readSeconds': read_elapsed, 'totalSeconds': time.monotonic() - started, 'bytes': len(content), 'conditions': 'fresh blob-filtered clone; 20 source blobs; concurrent validation; operational reproduction only, not a benchmark'}
(out / 'cold-polly-buffered.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in report.items() if key not in ['selected', 'fetchCommands']}), flush=True)

assert content == (out / 'cold-polly-baseline-bytes.bin').read_bytes()
