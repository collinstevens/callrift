from pathlib import Path

artifacts = Path.cwd() / 'artifacts'
target = artifacts / 'dispatch-integrated-serial'
assert not target.exists()
target.mkdir()
project = (artifacts / 'dispatch-integrated-check/Check.csproj').read_text(encoding='utf-8')
project = project.replace('<ItemGroup>', '<ItemGroup>\n    <Compile Include="AssemblySettings.cs" />', 1)
(target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
(target / 'AssemblySettings.cs').write_text('using Xunit;\n\n[assembly: CollectionBehavior(DisableTestParallelization = true)]\n', encoding='utf-8', newline='\n')
print('Prepared private harness with the production suite serialization setting.')
