from pathlib import Path
from datetime import datetime
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
artifacts = root / 'artifacts'
stamp = datetime.now().astimezone().isoformat(timespec='seconds')
results = {}
for directory in ['top-level-constructor-cli-candidate-results', 'constructor-discovery-cli-candidate-results', 'constructor-workspace-reviewed-repeat-results']:
    files = list((artifacts / directory).glob('*.trx'))
    assert len(files) == 1
    counters = ET.parse(files[0]).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
    assert counters['failed'] == '0' and counters['passed'] == counters['total']
    results[directory] = counters['passed']
assert list(results.values()) == ['62', '22', '3']
matrix = [json.loads(line) for line in (artifacts / 'record-copy-matrix-duplicate-safe.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
assert len(matrix) == 9 and all(item['passed'] for item in matrix)
inputs = json.loads((artifacts / 'record-copy-cli-inputs.json').read_text(encoding='utf-8'))
constructor = f'''\n\n{stamp}: The previous status turn was a verified wait: live Git/test processes confirmed that the dispatch push and both broad constructor runs remained active. This continuation reproduced and corrected a separate record-copy prototype crash and launched isolated CLI validation; no production snapshot was promoted.

Constructor Core e94daf21 corrects partial Program implicit-base binding when the first declaration reference is a compilation unit. The split-file fixture fails on 23d1c8c6; same-file controls pass. All 62 exact-candidate CLI checks pass, including four Program cases. Twenty revised dispatch checks and two new automatic constructor-discovery checks pass together; both new discovery checks fail on production 9ccabc3. These tests remain drafts under artifacts. The 20 dispatch revisions select the intended automatic root and validate additional constructor roots. They do not hide incorrect method roots.

The frozen 23d1 constructor run remains independent: 58 focused checks pass; all 22 workspace cases are accounted for by 19 unchanged passes plus three strictly reviewed focused passes. Its 465-scenario and 89-view corpus runs remain active with unaccepted differences. Existing broad expectations predate the accepted Serilog cycle correction. The latest e94 candidate needs final broad validation after all differences are reviewed.

Original-symbol/source review proves 404 new Orchard role warnings stem from unbound base types. The other captured cases add 1,100 occurrences: 895 outside ASP.NET Core have error base types; ASP.NET Core has 166 error base types, 38 missing accessible zero-argument base candidates, and one real Program-binding defect corrected by e94. The ASP.NET six-format comparison proves exactly the false Program warning is removed. Its full constructor trees remain unreviewed. Separate source checks explain six removed ASP.NET initializer warnings from already-omitted duplicate constructors. Three restored Autofac views have exactly six canonical signature field changes; all other fields/rendered output match. Reports are constructor-diagnostic-source-review, constructor-top-level-aspnetcore-review.json, constructor-aspnetcore-omitted-initializer-review.json, and constructor-autofac-signature-review.json. These targeted reviews do not authorize wholesale snapshot acceptance.

Latest known CI: receiver 36171714134 failed, a32cfc4 run 36177017184 was still running, and 7cfb72b run 36153634040 passed. Reading receiver job failure details was rejected by automatic approval review because command approval is Never; a request is pending. No rejected action was retried. The tracked tree is clean at 9ccabc3 and origin/master remains a32cfc4 while its 407-scenario push hook is live. Counts remain 30 reviewed pairs/seven repositories and 20 both-mode pairs. Remaining semantic work, 30 additional pairs, full performance evidence, packaging on the final implementation, and final three-OS CI are mandatory.
'''
record = f'''\n\n{stamp}: Record-copy follow-up now has nine compiler-valid runtime/API cases covering sealed/inherited/abstract/generic records, exact receiver control, field-initializer exclusion, record structs, initializer ordering, and anonymous types. Runtime execution independently checks sink order; focused diff/reach checks match the expected changes. All nine pass after updating ConstructorBindings to the e94 Program correction.

Two invalid duplicate-copy fixtures reproduced crashes at AddRecordClones.SingleOrDefault (record-copy-invalid-audit.log). The corrected prototype counts copy candidates, indexes ambiguous clone bodies as unavailable, and emits unresolved-record-copy instead of choosing a body. Both now return explicit diagnostics without crashing; two other malformed-source controls do not crash but still lack semantic compilation diagnostics, so this is not complete invalid-source coverage. All nine valid runtime/API cases pass again (record-copy-matrix-duplicate-safe.log).

Latest frozen candidate Core is {inputs['candidate']['Callrift.Core.dll']}; baseline is {inputs['baseline']['Callrift.Core.dll']}. Parent and packaged worker Core hashes are equal in each harness. record-copy-cli-inputs.json records all frozen files and source hashes. Twenty real CLI source/MSBuild cases cover diff automatic/focused roots, tree, reach, text, Markdown, and JSON, including a cross-project record. Two further source-only cases require diagnostics for ambiguous copies. Candidate22 session9679 and baseline20 session46598 are active. Test formatting passes. The first overlay attempt failed on Windows path-key spelling before either test run; corrected normalized metadata and full matching parent/worker copies were verified before launch. No record source or tests have been promoted; clone presentation, comprehensive location checks, invalid-source handling, broad compatibility, and performance remain open.
'''
for path in [root / 'GOAL.md', artifacts / 'initialization-audit-progress.md']:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(constructor)
with (artifacts / 'record-copy-progress.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write(record)
print('Recorded verified constructor evidence, record-copy crash correction, frozen versions, and active gates.')
