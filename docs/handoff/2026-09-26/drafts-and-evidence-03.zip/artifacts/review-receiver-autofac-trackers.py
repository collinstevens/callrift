from pathlib import Path
import copy
import hashlib
import json
import sys

directory = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('artifacts/receiver-context-stable-corpus/Snapshots')
traces = json.loads(Path('artifacts/receiver-context-autofac-traces.json').read_text(encoding='utf-8'))
assert len(traces) == 5 and all(trace['runtimeReceiverContexts'] == 2 and trace['distinctOverrides'] for trace in traces)
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
def canonical_ids(value):
    result = copy.deepcopy(value)
    names = {}
    def collect(nodes):
        for node in nodes:
            names[node['id']] = 'n' + str(len(names))
            collect(node['children'])
    collect(result['trees'])
    def replace(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ['id', 'referenceId'] and isinstance(child, str):
                    value[key] = names[child]
                else:
                    replace(child)
        elif isinstance(value, list):
            for child in value:
                replace(child)
    replace(result)
    return result
reports = []
views = [(case, 'msbuild') for case in ['autofac-any-key-cache', 'autofac-multi-service-registration', 'autofac-pipeline-callbacks']]
if len(sys.argv) > 3 and sys.argv[3] == 'all':
    traces = json.loads(Path('artifacts/receiver-context-all-autofac-traces/report.json').read_text(encoding='utf-8'))
    manifest = json.loads(Path('real-world-cases/manifest.json').read_text(encoding='utf-8'))
    cases = [case for case in manifest if case['cacheName'] == 'autofac']
    expected = {(mode, case[side]) for case in cases for mode in ['source', 'msbuild'] for side in ['before', 'after']}
    assert {(trace['mode'], trace['revision']) for trace in traces} == expected
    assert all(trace['contexts'] == 2 and trace['distinctOverrides'] for trace in traces)
    views = [(case['id'], mode) for case in cases for mode in ['source', 'msbuild']]
if len(sys.argv) > 3 and sys.argv[3] == 'include-source':
    for revision in ['cdf6a83', '0f0be58']:
        path = Path('artifacts/receiver-context-autofac-source-' + revision + '.jsonl')
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        assert rows[0]['Diagnostics'] == 174 and len(rows[0]['Targets']) == 2
        assert sorted(row['Result'] for row in rows[1:]) == ['DefaultRegisteredServicesTracker.AddRegistration', 'ScopeRestrictedRegisteredServicesTracker.AddRegistration']
        traces.append({'revision': rows[0]['revision'], 'mode': 'source', 'trace': str(path), 'runtimeReceiverContexts': 2, 'distinctOverrides': True,
                       'coreSha256': '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc'})
    views.append(('autofac-service-key-inheritance', 'source'))
for case, mode in views:
    name = case + '-' + mode + '-roots'
    received = directory / (name + '-json.received.txt')
    verified = directory / (name + '-json.verified.txt')
    before, after = read(verified), read(received)
    root = next(node for node in after['trees'] if node['label'] == 'ComponentRegistry.TryGetRegistration')
    assert len(root['children']) == 1
    call = root['children'][0]
    assert call['label'] == 'IComponentRegistryServices.TryGetRegistration'
    assert len(call['children']) == 2
    targets = call['children']
    def without_id(node):
        return {key: value for key, value in node.items() if key != 'id'}
    assert without_id(targets[0]) == without_id(targets[1])
    target = targets[0]
    assert target['label'] == '⇢ DefaultRegisteredServicesTracker.TryGetRegistration'
    assert target['kind'] == 'dispatchTarget' and target['children'] == []
    assert target['omission']['reason'] == 'depth-limit'
    for key in ['change', 'detail', 'omission', 'children']:
        call[key] = copy.deepcopy(target[key])
    call['label'] += ' → DefaultRegisteredServicesTracker.TryGetRegistration'
    extra_disposal = case == 'autofac-any-key-cache' and mode == 'source'
    if extra_disposal:
        cleanup = next(node for node in after['trees'] if node['label'] == 'KeyedAnyKeyChildScopeBenchmark.Cleanup')
        disposal = cleanup['children'][0]
        assert disposal['label'] == '_existingScope.Dispose' and len(disposal['children']) == 2
        target = disposal['children'][0]
        assert without_id(target) == without_id(disposal['children'][1])
        assert target['label'] == '⇢ Disposable.Dispose' and target['change'] == 'added'
        for key in ['change', 'detail', 'omission', 'children']:
            disposal[key] = copy.deepcopy(target[key])
        disposal['label'] += ' → Disposable.Dispose'
        path = Path('artifacts/receiver-context-review-trace/autofac-any-key-dispose-after.jsonl')
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        members = {row['Key']: row for row in rows[1:]}
        root_trace = next(row for row in members.values() if row['Label'] == 'KeyedAnyKeyChildScopeBenchmark.Cleanup')
        invocation = next(call for call in root_trace['Calls'] if call['Label'] == '_existingScope.Dispose')
        assert len(invocation['Targets']) == 2
        assert {target.split(';this=')[1] for target in invocation['Targets']} == {'Callrift.Source::global::Autofac.Core.Container<>!', 'Callrift.Source::global::Autofac.Core.Lifetime.LifetimeScope<>!'}
        for target_key in invocation['Targets']:
            nested = next(call for call in members[target_key]['Calls'] if call['Label'] == 'Disposable.Dispose')
            assert len(nested['Targets']) == 1
            expected = 'Container.Dispose(bool)' if '.Container<>' in target_key else 'LifetimeScope.Dispose(bool)'
            assert expected in nested['Targets'][0]
    assert canonical_ids(before) == canonical_ids(after), name
    text_before = (directory / (name + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_after = (directory / (name + '.received.txt')).read_text(encoding='utf-8-sig')
    old = '~ └─ IComponentRegistryServices.TryGetRegistration → DefaultRegisteredServicesTracker.TryGetRegistration (changes below depth limit)'
    new = '  └─ IComponentRegistryServices.TryGetRegistration\n~    └─ ⇢ DefaultRegisteredServicesTracker.TryGetRegistration ×2 (changes below depth limit)'
    assert text_before.count(old) == 2
    expected_text = text_before.replace(old, new)
    if extra_disposal:
        old_disposal = '+ ├─ _existingScope.Dispose → Disposable.Dispose (depth limit)'
        new_disposal = '+ ├─ _existingScope.Dispose\n+ │  └─ ⇢ Disposable.Dispose ×2 (depth limit)'
        assert expected_text.count(old_disposal) == 2
        expected_text = expected_text.replace(old_disposal, new_disposal)
    assert expected_text == text_after, name
    reports.append({'view': name, 'jsonSha256': hashlib.sha256(received.read_bytes()).hexdigest(),
                    'textSha256': hashlib.sha256((directory / (name + '.received.txt')).read_bytes()).hexdigest(),
                    'roots': len(before['trees']), 'changedCallSites': 2 if extra_disposal else 1, 'contexts': 2,
                    'remainingJsonExactAfterRepresentationNormalization': True,
                    'textAndMarkdownOnlyChange': 'Inherited tracker declaration is shown with two receiver contexts; the new child-scope cleanup also retains Container and LifetimeScope disposal contexts.' if extra_disposal else 'The one inherited declaration is shown with two receiver contexts.'})
report = {'coreSha256': hashlib.sha256((directory.parent / 'build/bin/Check/debug/Callrift.Core.dll').read_bytes()).hexdigest(),
          'traceCoreSha256': '228d547234aa0a4b971112aed2be8d683d1419d64ba80202a88d01bed5b77bdc' if len(sys.argv) > 3 and sys.argv[3] == 'all' else '88a701636880adc34ff53d923167cb4c2bdce175b43ddaf424156b9bc369c019',
          'traces': traces, 'reviewedViews': reports, 'promoted': False}
Path(sys.argv[2] if len(sys.argv) > 2 else 'artifacts/receiver-context-autofac-tracker-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reviewedViews': len(reports), 'immutableRevisionsTraced': len(traces), 'promoted': False}))
