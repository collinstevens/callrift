from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd()
case=next(c for c in json.loads((root/'real-world-cases/manifest.json').read_text(encoding='utf-8')) if c['id']=='autofac-multi-service-registration')
view=next(v for v in case['views'] if v['id']=='msbuild-roots')
cli=root/'artifacts/declaration-signatures-cli-v4-ready/callrift.dll'
output=root/'artifacts/declaration-signatures-v4-autofac-roots.json'
error=output.with_suffix('.stderr')
assert not output.exists()
command=['dotnet',str(cli),'diff',case['before'],case['after'],'--format','json',*case['options'],*view['options']]
started=time.monotonic()
with output.open('wb') as stdout,error.open('wb') as stderr:
    process=subprocess.Popen(['mise','exec','-c',subprocess.list2cmdline(command)],cwd=Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases')/case['cacheName'],stdout=stdout,stderr=stderr,env=dict(os.environ,NO_COLOR='1'))
    code=process.wait(timeout=600)
assert code==0,error.read_text(encoding='utf-8')
a=json.JSONDecoder().raw_decode((root/'tests/Callrift.RealWorldCases/Snapshots/autofac-multi-service-registration-msbuild-roots-json.received.txt').read_text(encoding='utf-8-sig').split('stdout:\n',1)[1])[0]
b=json.loads(output.read_text(encoding='utf-8'))
def strip(value):
    if isinstance(value,dict):return {k:strip(v) for k,v in value.items() if k!='signature'}
    if isinstance(value,list):return [strip(v) for v in value]
    return value
assert strip(a)==strip(b),'Non-signature fields changed'
changes=[]
def compare(x,y,path=''):
    if isinstance(x,dict):
        for k in x:
            if k=='signature' and x[k]!=y[k]:changes.append({'path':path+'/'+k,'before':x[k],'after':y[k]})
            elif k!='signature':compare(x[k],y[k],path+'/'+k)
    elif isinstance(x,list):
        for i,(xx,yy) in enumerate(zip(x,y)):compare(xx,yy,path+'/'+str(i))
compare(a,b)
for change in changes:
    result=change['after']
    if result is not None:assert ' where ' not in result.split(' -> ',1)[1].split(' [within ',1)[0],result
record={'case':case['id'],'view':view['id'],'command':command,'seconds':time.monotonic()-started,'exitCode':code,'allNonSignatureFieldsEqual':True,'signatureChanges':changes,'outputSha256':hashlib.sha256(output.read_bytes()).hexdigest(),'accepted':False}
(root/'artifacts/declaration-signatures-v4-autofac-review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['command','signatureChanges']}))
print('Signature fields corrected:',len(changes))
