from pathlib import Path
import json
import shutil

root = Path('artifacts')
source = root / 'static-interceptor-identity-corpus'
target = root / 'static-interceptor-orchard-roots-review'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('build', 'bin', 'obj', '*-ready', '*.received.*', 'packages.lock.json'))
names = ['orchardcore-' + name + '-msbuild-roots' for name in ['elasticsearch-authorization', 'openid-logout', 'role-submission', 'workflow-startup']]
path = target / 'RealWorldCaseTests.cs'
text = path.read_text(encoding='utf-8-sig')
old = '.SelectMany(e => (e.Views ?? []).Where(v => !Routine || v.Routine).Select(v => new object[] { e.Id, v.Id }));'
new = '.SelectMany(e => (e.Views ?? []).Where(v => new[] { ' + ', '.join(json.dumps(name) for name in names) + ' }.Contains(e.Id + "-" + v.Id)).Select(v => new object[] { e.Id, v.Id }));'
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
(root / (target.name + '-reviews.json')).write_text(json.dumps({'selectedViews': names, 'status': 'unaccepted-current-root-review-inputs', 'productionSnapshotsPromoted': False}, indent=2) + '\n', encoding='utf-8', newline='\n')
freeze = (root / 'freeze-static-interceptor-corpus.py').read_text(encoding='utf-8').replace("'static-interceptor-identity-corpus'", "'static-interceptor-orchard-roots-review'")
(root / 'freeze-static-interceptor-root-review.py').write_text(freeze, encoding='utf-8', newline='\n')
print('Prepared four current restored automatic views for review; no unreviewed snapshots accepted.')
