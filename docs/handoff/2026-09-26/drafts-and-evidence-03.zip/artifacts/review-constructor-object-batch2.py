from pathlib import Path
import copy
import collections
import hashlib
import json

root = Path.cwd()
artifacts = root / 'artifacts'
old_directory = artifacts / 'constructor-depth-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
jobs = {}
reports = []

def read(path):
    content = path.read_text(encoding='utf-8-sig')
    index = content.index('{')
    document, length = json.JSONDecoder().raw_decode(content[index:])
    return document, content[:index], content[index + length:]

def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])

for name, mode in [('polly-executor-continuations', 'source'), ('polly-telemetry-source', 'source'), ('polly-telemetry-source', 'msbuild'), ('ocelot-route-claims-keys', 'source'), ('ocelot-route-claims-keys', 'msbuild'), ('ocelot-timeout-status', 'source'), ('ocelot-custom-json-merge', 'source')]:
    case = next(case for case in manifest if case['id'] == name)
    view = name + '-' + mode + '-focused'
    settings = next(view for view in case['views'] if view['id'] == mode + '-focused')['options']
    assert '--externals' in settings
    depth_limit = int(settings[settings.index('--depth') + 1])
    original, prefix, suffix = read(old_directory / (view + '-json.verified.txt'))
    actual, new_prefix, new_suffix = read(old_directory / (view + '-json.received.txt'))
    assert prefix == new_prefix
    expected = copy.deepcopy(actual)
    def diagnostic_output(items):
        lines = []
        for item in items[:8]:
            location = item.get('location')
            start = (location['path'] + ':' + str(location['startLine']) + ': ') if location else ''
            lines.append(start + item['code'] + ': ' + item['message'])
        if len(items) > 8:
            lines.append(str(len(items) - 8) + ' additional diagnostics; use --diagnostics full.')
        return '\n'.join(lines)
    old_errors = diagnostic_output(original['diagnostics'])
    new_errors = diagnostic_output(actual['diagnostics'])
    assert suffix.strip() == 'stderr:\n' + old_errors if old_errors else suffix.strip() == 'stderr:'
    assert new_suffix.strip() == 'stderr:\n' + new_errors if new_errors else new_suffix.strip() == 'stderr:'
    if mode == 'source':
        proof_directory = artifacts / 'constructor-diagnostic-source-review'
        configuration = json.loads((proof_directory / (name + '.json')).read_text(encoding='utf-8'))
        proof = json.loads((proof_directory / (name + '-report.json')).read_text(encoding='utf-8'))
        assert not proof['unmatched'] and proof['provenMissingBaseCount'] == proof['diagnosticCount']
        counter = lambda items: collections.Counter(json.dumps(item, sort_keys=True) for item in items)
        assert counter(actual['diagnostics']) - counter(original['diagnostics']) == counter(configuration['diagnostics'])
        assert not counter(original['diagnostics']) - counter(actual['diagnostics'])
        expected['diagnostics'] = original['diagnostics']
    else:
        assert original['diagnostics'] == actual['diagnostics']
    checks = []
    removed = []
    def strip(items, parent=None, depth=0):
        result = []
        for index, node in enumerate(items):
            if node['label'] == 'new Object' and parent and parent['label'] in ['new FileConfiguration', 'new FileGlobalConfiguration', 'new Error', 'new ScheduledTaskExecutor.Entry', 'new TelemetrySource', 'new OcelotBuilder', 'new RouteClaimsRequirementPostConfigureOptions']:
                assert index == 0 and node['change'] == parent['change']
                assert node['kind'] == 'call' and not node['children'] and node['detail'] is None and node['omission'] is None
                for side in ['before', 'after']:
                    value = node.get(side)
                    assert (value is None) == (parent.get(side) is None)
                    if not value:
                        continue
                    location = parent[side]['definition']
                    object_identity = 'source::object..ctor()' if mode == 'source' else 'metadata:System.Runtime::object..ctor()'
                    assert value == {'symbolId': object_identity, 'signature': None, 'binding': 'resolved', 'dispatch': 'direct',
                        'targetIds': [object_identity], 'definition': None, 'callSites': [location], 'relation': 'call', 'candidates': [], 'origin': 'metadata'}
                    checks.append({'kind': 'object-base', 'revision': case[side], 'view': view, 'location': location})
                removed.append(node)
                continue
            node['children'] = strip(node['children'], node, depth + 1)
            if node['label'] == 'new FileServiceDiscoveryProvider':
                assert depth == depth_limit and node['detail'] == 'depth limit' and node['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
                assert not node['children']
                node['detail'] = None
                node['omission'] = None
                for side in ['before', 'after']:
                    value = node.get(side)
                    if value:
                        assert value['signature'] == 'Ocelot.Configuration.File.FileServiceDiscoveryProvider.FileServiceDiscoveryProvider() -> void'
                        assert value['definition'] == {'path': 'src/Configuration/File/FileServiceDiscoveryProvider.cs', 'startLine': 3, 'startColumn': 1, 'endLine': 13, 'endColumn': 2}
                        checks.append({'kind': 'implicit-definition', 'revision': case[side], 'view': view, 'location': value['definition'], 'type': 'Ocelot.Configuration.File.FileServiceDiscoveryProvider', 'parameterTypes': []})
                        value['signature'] = None
                        value['definition'] = None
            if node['label'] in ['new RequestTimedOutError', 'new ScheduledTaskExecutor.Entry']:
                for side in ['before', 'after']:
                    value = node.get(side)
                    if value and value['signature'].endswith(' -> void') and (node['label'] == 'new ScheduledTaskExecutor.Entry' or side == 'after'):
                        type_name = 'Ocelot.Errors.RequestTimedOutError' if node['label'] == 'new RequestTimedOutError' else 'Polly.CircuitBreaker.ScheduledTaskExecutor.Entry'
                        parameter_types = ['System.Exception'] if node['label'] == 'new RequestTimedOutError' else ['System.Func<System.Threading.Tasks.Task>', 'System.Threading.Tasks.TaskCompletionSource<object>']
                        checks.append({'kind': 'primary-definition', 'revision': case[side], 'view': view, 'location': value['definition'], 'type': type_name, 'parameterTypes': parameter_types})
                        value['signature'] = value['signature'].removesuffix(' -> void')
            result.append(node)
        return result
    expected['trees'] = strip(expected['trees'])
    old_nodes = list(nodes(original['trees']))
    new_nodes = list(nodes(expected['trees']))
    assert len(old_nodes) == len(new_nodes)
    mapping = {new['id']: old['id'] for old, new in zip(old_nodes, new_nodes)}
    for node in new_nodes:
        node['id'] = mapping[node['id']]
        if node['omission'] and node['omission']['referenceId']:
            node['omission']['referenceId'] = mapping[node['omission']['referenceId']]
    assert expected == original, view
    assert len(removed) == {'ocelot-custom-json-merge': 3, 'ocelot-timeout-status': 1, 'polly-executor-continuations': 1, 'polly-telemetry-source': 1, 'ocelot-route-claims-keys': 3}[name]
    old_text = (old_directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
    text_path = old_directory / (view + '.received.txt')
    if not text_path.exists():
        text_path = old_directory / (view + '.verified.txt')
    new_text = text_path.read_text(encoding='utf-8-sig')
    if old_errors != new_errors:
        assert old_text.count(old_errors) == 2 and new_text.count(new_errors) == 2
        old_text = old_text.replace(old_errors, new_errors)
    added_lines = {
        'ocelot-custom-json-merge': ['+ │     ├─ new Object\n'],
        'polly-telemetry-source': ['+ ├─ new Object\n'],
        'ocelot-route-claims-keys': ['+ │  └─ new Object\n', '  ├─ new Object\n'],
    }.get(name, [])
    for line in added_lines:
        assert new_text.count(line) == 2
        new_text = new_text.replace(line, '')
    if name == 'ocelot-custom-json-merge':
        assert new_text.count('new FileServiceDiscoveryProvider (depth limit)') == 2
        new_text = new_text.replace('new FileServiceDiscoveryProvider (depth limit)', 'new FileServiceDiscoveryProvider')
    assert new_text == old_text, view
    jobs[view] = {'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName'], 'checks': checks}
    reports.append({'view': view, 'objectBaseCalls': len(removed), 'sourceChecks': len(checks), 'jsonAndTextDifferencesBounded': True, 'sourceProofPending': True,
                    'sha256': hashlib.sha256((old_directory / (view + '-json.received.txt')).read_bytes()).hexdigest()})
for name, config in jobs.items():
    (artifacts / 'constructor-object-batch2-source-review' / (name + '.json')).write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
(artifacts / 'constructor-object-batch2-focused-review.json').write_text(json.dumps({'productionPromoted': False, 'reviews': reports}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(reports))
