import json,pathlib,subprocess,tempfile

root=pathlib.Path(__file__).resolve().parents[1]
fixture=pathlib.Path(tempfile.mkdtemp(prefix='callrift-generic-variance-'))
dotnet='C:/Users/Admin/AppData/Local/mise/dotnet-root/dotnet.exe'
cli=root/'src/Callrift.Cli/bin/Debug/net11.0/callrift.dll'
def git(*args):return subprocess.check_output(['git','-C',str(fixture),*args],stderr=subprocess.STDOUT).decode().strip()
git('init','-q')
git('config','user.name','Fixture')
git('config','user.email','fixture@example.invalid')
(fixture/'App.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net11.0</TargetFramework></PropertyGroup></Project>',encoding='utf-8')
before='''public interface IProducer<out T> { T Produce(); }
public sealed class TextProducer : IProducer<string> { public string Produce() => "text"; }
public sealed class ObjectProducer : IProducer<object> { public object Produce() { Sink.Before(); return new object(); } }
public static class Entry { public static object Run(IProducer<string> producer) => producer.Produce(); }
public static class Sink { public static void Before() {} public static void After() {} }
'''
(fixture/'Flow.cs').write_text(before,encoding='utf-8')
git('add','.')
git('-c','commit.gpgsign=false','commit','-qm','fixture before')
old=git('rev-parse','HEAD')
(fixture/'Flow.cs').write_text(before.replace('Sink.Before();', 'Sink.After();'),encoding='utf-8')
git('add','.')
git('-c','commit.gpgsign=false','commit','-qm','fixture after')
new=git('rev-parse','HEAD')
for mode in ['source','msbuild']:
    options=[] if mode=='source' else ['--project','App.csproj']
    for operation in ['diff','tree']:
        args=['diff',old,new] if operation=='diff' else ['tree',new,'--entry','Entry.Run']
        result=subprocess.run([dotnet,str(cli),*args,*options,'--format','json'],cwd=fixture,capture_output=True,encoding='utf-8',timeout=180)
        assert result.returncode==0,result.stderr
        (root/'artifacts'/f'generic-variance-{mode}-{operation}.json').write_text(result.stdout,encoding='utf-8',newline='\n')
        data=json.loads(result.stdout)
        print(mode,operation,'roots:',[n['label'] for n in data['trees']],'diagnostics:',len(data['diagnostics']),flush=True)
print('fixture:',fixture,flush=True)
