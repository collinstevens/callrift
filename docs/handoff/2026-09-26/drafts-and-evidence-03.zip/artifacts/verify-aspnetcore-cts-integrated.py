from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs_path = root / 'aspnetcore-cts-integrated-observed-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for section in ['binaries', 'sources', 'snapshots']:
    for filename, expected in inputs[section].items():
        assert digest(Path(filename)) == expected, filename
integration_path = root / 'static-production-integration.json'
integration = json.loads(integration_path.read_text(encoding='utf-8'))
for record in integration['files']:
    assert digest(Path(record['target'])) == record['sha256']
reports = list((root / 'aspnetcore-cts-integrated-results').glob('*.trx'))
assert len(reports) == 1
trx = reports[0]
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '2'
assert counters['failed'] == counters['error'] == counters['aborted'] == '0'
results = [result.attrib for result in tree.findall('.//{*}UnitTestResult')]
assert len(results) == 2 and all(result['outcome'] == 'Passed' and 'aspnetcore-stream-cts-disposal' in result['testName'] for result in results)
assert all(sum(view in result['testName'] for result in results) == 1 for view in ['source-roots', 'source-focused'])
assert not list(Path('tests/Callrift.RealWorldCases/Snapshots').glob('aspnetcore-stream-cts-disposal*.received.*'))
proof = {'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': results, 'observedInputsSha256': digest(inputs_path), 'inputObservationAfterLaunch': True, 'observedInputsUnchangedAtCompletion': True, 'productionIntegrationMapSha256': digest(integration_path), 'snapshots': inputs['snapshots'], 'core': inputs['binaries']['tests/Callrift.RealWorldCases/bin/Debug/net11.0/Callrift.Core.dll'], 'worker': inputs['binaries']['tests/Callrift.RealWorldCases/bin/Debug/net11.0/msbuild/Callrift.MSBuild.dll']}
(root / 'aspnetcore-cts-integrated-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified two integrated passes, four unchanged snapshots, matching worker/Core, and inputs unchanged since the during-run observation.')
