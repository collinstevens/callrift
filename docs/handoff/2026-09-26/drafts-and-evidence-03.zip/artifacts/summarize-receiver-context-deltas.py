from collections import Counter
from pathlib import Path
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')
directory = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('artifacts/receiver-context-stable-corpus/Snapshots')
reports = []
for received in sorted(directory.glob('*-json.received.txt')):
    verified = received.with_name(received.name.replace('.received.', '.verified.'))
    def read(path):
        text = path.read_text(encoding='utf-8-sig')
        return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
    before, after = read(verified), read(received)
    differences = []
    def visit(left, right, path):
        if type(left) is not type(right):
            differences.append((path, left, right))
        elif isinstance(left, dict):
            for key in sorted(set(left) | set(right)):
                visit(left.get(key), right.get(key), path + '/' + key)
        elif isinstance(left, list):
            if len(left) != len(right): differences.append((path + '/length', len(left), len(right)))
            for index, (old, new) in enumerate(zip(left, right)): visit(old, new, path + '/' + str(index))
        elif left != right:
            differences.append((path, left, right))
    visit(before, after, '')
    tree_differences = [d for d in differences if d[0].startswith('/trees/')]
    old_diagnostics = {json.dumps(d, sort_keys=True) for d in before['diagnostics']}
    new_diagnostics = {json.dumps(d, sort_keys=True) for d in after['diagnostics']}
    added = [d for d in after['diagnostics'] if json.dumps(d, sort_keys=True) not in old_diagnostics]
    removed = [d for d in before['diagnostics'] if json.dumps(d, sort_keys=True) not in new_diagnostics]
    report = {'file': received.name, 'roots': [len(before['trees']), len(after['trees'])],
              'rootSymbolsBefore': [(n.get('after') or n.get('before') or {}).get('symbolId') for n in before['trees']],
              'rootSymbolsAfter': [(n.get('after') or n.get('before') or {}).get('symbolId') for n in after['trees']],
              'addedDiagnostics': dict(Counter(d['code'] for d in added)), 'removedDiagnostics': dict(Counter(d['code'] for d in removed)),
              'treeDifferenceCount': len(tree_differences), 'treeDifferenceFields': dict(Counter(d[0].split('/')[-1] for d in tree_differences)),
              'treeDifferenceSamples': tree_differences[:20],
              'otherDifferences': [d for d in differences if not d[0].startswith(('/trees/', '/diagnostics/'))]}
    reports.append(report)
    print(json.dumps({k: v for k, v in report.items() if k not in ['treeDifferenceSamples','rootSymbolsBefore','rootSymbolsAfter','otherDifferences']}, ensure_ascii=False))
Path(sys.argv[2] if len(sys.argv) > 2 else 'artifacts/receiver-context-stable-delta-report.json').write_text(json.dumps(reports, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
