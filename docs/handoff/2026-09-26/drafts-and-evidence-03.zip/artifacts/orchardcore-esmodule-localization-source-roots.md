```diff
  AliasPartRazorHelperExtensions.GetContentItemByAliasAsync
  ├─ AliasPartRazorHelperExtensions.GetContentItemIdByAliasAsync (depth limit)
  ├─ ? orchardHelper.HttpContext.RequestServices.GetService<IContentManager>
~ └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)

  AutoroutePartRazorHelperExtensions.GetContentItemBySlugAsync
  ├─ AutoroutePartRazorHelperExtensions.GetContentItemIdBySlugAsync (depth limit)
  ├─ ? orchardHelper.HttpContext.RequestServices.GetService<IContentManager>
~ └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)

  ContentOrchardRazorHelperExtensions.DisplayAsync
  ├─ ? orchardDisplayHelper.HttpContext.RequestServices.GetService<IContentItemDisplayManager>
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  LocalizationOrchardHelperExtensions.GetJSLocalizations
  ├─ ? orchardHelper.HttpContext.RequestServices.GetServices<IJSLocalizer>
~ └─ JSLocalizerExtensions.GetMergedLocalizations (changes below depth limit)

  AdminMenuFilter.OnResultExecutionAsync
  ├─ …
  ├─ new NavigationArguments
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~ ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  ├─ if (navigation is Shape shape)
  └─ ? next

  DashboardController.Index
  ├─ …
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!(model.CanManageDashboard))
  ├─ if (model.CanManageDashboard || await _authorizationService.AuthorizeAsync(User, Permissions.Acce…
  │  ├─ DashboardController.GetDashboardWidgetsAsync (depth limit)
  │  ├─ IAdminDashboardService.GetWidgetsAsync → AdminDashboardService.GetWidgetsAsync (depth limit)
  │  └─ foreach (var widget in widgets)
  │     ├─ if (!model.CanManageDashboard)
  │     ├─ new DashboardWrapper (depth limit)
~ │     └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  DashboardController.Manage
  ├─ …
  ├─ foreach (var ctd in widgetContentTypes.Values.OrderBy(x => x.DisplayName))
  ├─ IAdminDashboardService.GetWidgetsAsync → AdminDashboardService.GetWidgetsAsync (depth limit)
  ├─ foreach (var widget in widgets)
  │  ├─ if (!(!widgetContentTypes.ContainsKey(widget.ContentType)))
  │  ├─ new DashboardWrapper (depth limit)
~ │  └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  ├─ new AdminDashboardViewModel
  └─ ? View

  DashboardController.Update
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ManageAdminDashboard))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (latestItems == null)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ foreach (var contentItem in latestItems)
  ├─ if (Request.Headers != null && Request.Headers.XRequestedWith == "XMLHttpRequest")
  └─ …

  Migrations.CreateAsync
  ├─ ? SchemaBuilder.CreateMapIndexTableAsync<DashboardPartIndex>
  ├─ ? SchemaBuilder.AlterIndexTableAsync<DashboardPartIndex>
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  MenuController.List
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new AdminMenuListViewModel (depth limit)
  ├─ results.Select
  └─ …

  NodeController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.AdminNodeType) is not null)
  ├─ if (treeNode == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  NodeController.Create
  ├─ …
  ├─ if (treeNode == null)
  ├─ new AdminNodeEditViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  NodeController.Edit
  ├─ …
  ├─ AdminMenu.GetMenuItemById (depth limit)
  ├─ if (treeNode == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  ├─ ? _notifier.ErrorAsync
  └─ …

  NodeController.Edit
  ├─ …
  ├─ if (treeNode == null)
  ├─ new AdminNodeEditViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  NodeController.List
  ├─ …
  ├─ IAdminMenuService.GetAdminMenuById → AdminMenuService.GetAdminMenuById (depth limit)
  ├─ if (adminMenu == null)
~ ├─ NodeController.BuildDisplayViewModel (changes below depth limit)
  └─ ? View

+ new AdminMenuJSLocalizer

  AdminController.Display
  ├─ …
  ├─ IAuditTrailManager.GetEventAsync → AuditTrailManager.GetEventAsync (depth limit)
  ├─ if (auditTrailEvent == null)
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ new AuditTrailItemViewModel
  └─ ? View

  AdminController.Index
  ├─ …
  ├─ ? options.FilterResult.ToString
  ├─ ? options.RouteValues.TryAdd
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var auditTrailEvent in result.Events)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  └─ ? View

  AdminController.IndexFilterPOST
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!string.Equals(options.SearchText, options.OriginalSearchText, StringComparison.OrdinalIgnore…
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? options.FilterResult.ToString
  ├─ ? options.RouteValues.TryAdd
  └─ …

  AutoSetupMiddleware.InvokeAsync
  ├─ if (_setupOptions is not null)
  ├─ if (_setupOptions is not null && _shellSettings.IsUninitialized())
  │  ├─ DistributedLockExtensions.TryAcquireAutoSetupLockAsync (depth limit)
  │  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
  │  └─ if (_shellSettings.IsUninitialized())
  │     ├─ IShellSettingsManager.LoadSettingsAsync
  │     ├─ if (settings != null)
  │     │  ├─ ShellSettingsExtensions.AsDisposable (depth limit)
  │     │  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
  │     │  └─ if (!settings.IsUninitialized())
~ │     │     ├─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  │     │     └─ ? httpContext.Response.WriteAsync
  │     ├─ ? httpContext.RequestServices.GetRequiredService<IAutoSetupService>
~ │     ├─ IAutoSetupService.SetupTenantAsync → AutoSetupService.SetupTenantAsync (changes below depth limit)
  │     ├─ if (isSuccess)
  │     │  ├─ if (_setupOptions.IsDefault)
  │     │  │  └─ foreach (var setupOptions in _options.Tenants)
  │     │  │     └─ if (_setupOptions != setupOptions)
~ │     │  │        └─ IAutoSetupService.CreateTenantSettingsAsync → AutoSetupService.CreateTenantSettingsAsync (changes below depth limit)
  │     │  └─ ? httpContext.Response.Redirect
  │     └─ else (!(isSuccess))
  └─ ? _next.Invoke

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ ShellFeaturesManagerExtensions.IsFeatureEnabledAsync (depth limit)
~    └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  HttpBackgroundJob.ExecuteAfterEndOfRequestAsync
~ └─ HttpBackgroundJob.ExecuteAfterEndOfRequestAsync (changes below depth limit)

  BackgroundTaskController.Index
  ├─ …
  ├─ if (!string.IsNullOrEmpty(options.Status))
  ├─ new Pager (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new BackgroundTaskIndexViewModel
  ├─ Pager.GetStartIndex (depth limit)
  └─ …

  FluidShapeRenderBenchmark.ShapeRenderStatic
  ├─ ? input.ToObjectValue
  ├─ if (input.ToObjectValue()is IShape shape)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ if (!task.IsCompletedSuccessfully)
  │  ├─ new HtmlContentValue (depth limit)
  │  └─ …
  └─ ? ValueTask.FromResult<FluidValue>

  FluidShapeRenderBenchmark.ShapeRenderWithAmbientValues
  ├─ ? input.ToObjectValue
  ├─ if (input.ToObjectValue()is IShape shape)
  │  ├─ ? context.AmbientValues.TryGetValue
  │  ├─ if (!context.AmbientValues.TryGetValue("DisplayHelper", out var item) || item is not IDisplayHelp…
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ if (!task.IsCompletedSuccessfully)
  │  ├─ new HtmlContentValue (depth limit)
  │  └─ …
  └─ ? ValueTask.FromResult<FluidValue>

  ShapeDescriptorIndexBenchmark.SetupAsync
  ├─ ? new BlogContext
  ├─ ? content.InitializeAsync
  └─ ? content.UsingTenantScopeAsync
     ├─ ? scope.ServiceProvider.GetRequiredService<IEnumerable<IShapeTableProvider>>
     ├─ ? scope.ServiceProvider.GetRequiredService<ITypeFeatureProvider>
     └─ foreach (var bindingStrategy in bindingStrategies)
        ├─ ITypeFeatureProvider.GetFeatureForDependency → TypeFeatureProvider.GetFeatureForDependency (depth limit)
        ├─ new ShapeTableBuilder (depth limit)
        ├─ IShapeTableProvider.DiscoverAsync
        │  ├─ …
        │  ├─ ⇢ MediaShapes.DiscoverAsync (depth limit)
        │  ├─ ⇢ AdminDashboardShapeTableProvider.DiscoverAsync (depth limit)
~       │  ├─ ⇢ Shapes.DiscoverAsync (changes below depth limit)
        │  ├─ ⇢ DemoShapeProvider.DiscoverAsync (depth limit)
        │  ├─ ⇢ ShapeAttributeBindingStrategy.DiscoverAsync (depth limit)
        │  ├─ …
        │  ├─ ⇢ LiquidShapes.DiscoverAsync (depth limit)
        │  ├─ ⇢ MediaShapes.DiscoverAsync (depth limit)
~       │  ├─ ⇢ MenuShapes.DiscoverAsync (changes below depth limit)
        │  ├─ ⇢ NavigationShapes.DiscoverAsync (depth limit)
        │  ├─ ⇢ PagerShapesTableProvider.DiscoverAsync (depth limit)
~       │  ├─ ⇢ TermShapes.DiscoverAsync (changes below depth limit)
        │  ├─ ⇢ TenantFeatureProfileShapeTableProvider.DiscoverAsync (depth limit)
        │  ├─ ⇢ TenantFeatureShapeTableProvider.DiscoverAsync (depth limit)
        │  └─ …
        ├─ ShapeTableBuilder.BuildAlterations (depth limit)
        └─ ShapeDescriptorIndexBenchmark.BuildDescriptors (depth limit)

  ContentPickerAdminController.SearchContentItems
  ├─ …
  ├─ new ContentPickerSearchContext
  ├─ IContentPickerResultProvider.Search
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ foreach (var result in results)
  └─ ? new ObjectResult

+ new ContentFieldsJSLocalizer

  AdminController.Localize
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ …
  ├─ IContentLocalizationManager.GetContentItemAsync → DefaultContentLocalizationManager.GetContentItemAsync (depth limit)
  ├─ if (alreadyLocalizedContent != null)
  ├─ try
~ │  ├─ IContentLocalizationManager.LocalizeAsync → DefaultContentLocalizationManager.LocalizeAsync (changes below depth limit)
  │  ├─ ? _notifier.InformationAsync
  │  └─ ? RedirectToAction
  └─ catch (InvalidOperationException)

  ContentManagerExtensions.UpdateValidateAndCreateAsync
~ ├─ IContentManager.UpdateAsync → DefaultContentManager.UpdateAsync (changes below depth limit)
  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (depth limit)
  └─ if (result.Succeeded)
~    └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)

  DefaultContentManager.CreateContentItemVersionAsync
~ └─ DefaultContentManager.CreateContentItemVersionAsync (changes below depth limit)

  DefaultContentManager.RestoreAsync
  ├─ new RestoreContentContext (depth limit)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
~ ├─ DefaultContentManager.UpdateAsync (changes below depth limit)
  ├─ DefaultContentManager.ValidateAsync (depth limit)
  ├─ if (!validationResult.Succeeded)
  ├─ …
  ├─ ? _session.Query<ContentItem, ContentItemIndex>().Where(index => index.ContentItemId == contentItem.ContentItemId && index.Latest).FirstOrDefaultAsync
  ├─ if (latestVersion != null)
~ ├─ DefaultContentManager.CreateAsync (changes below depth limit)
  └─ InvokeExtensions.InvokeAsync (depth limit)

  DefaultContentManager.UpdateContentItemVersionAsync
~ └─ DefaultContentManager.UpdateContentItemVersionAsync (changes below depth limit)

  PreviewController.Display
  ├─ …
  ├─ IContentManagerSession.Store → DefaultContentManagerSession.Store (depth limit)
  ├─ if (!string.IsNullOrEmpty(draft.PreviewUrl))
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  new ResourceManagementOptionsConfiguration
  ├─ …
  ├─ ResourceManifest.DefineScript (depth limit)
  ├─ ResourceDefinition.SetUrl (depth limit)
- ├─ ResourceDefinition.SetDependencies (depth limit)
  └─ ResourceDefinition.SetVersion (depth limit)

  ContentRazorHelperExtensions.GetContentItemByHandleAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemByHandleAsync (changes below depth limit)

  ContentRazorHelperExtensions.GetContentItemByIdAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemByIdAsync (changes below depth limit)

  ContentRazorHelperExtensions.GetContentItemsByIdAsync
~ └─ ContentOrchardHelperExtensions.GetContentItemsByIdAsync (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ AdminController.GetTypeAsync (depth limit)
  ├─ if (typeViewModel == null)
~ ├─ IContentDefinitionDisplayManager.BuildTypeEditorAsync → DefaultContentDefinitionDisplayManager.BuildTypeEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditField
  ├─ …
  ├─ ContentPartFieldSettingsExtensions.DisplayMode (depth limit)
  ├─ ContentPartFieldSettingsExtensions.DisplayName (depth limit)
~ ├─ IContentDefinitionDisplayManager.BuildPartFieldEditorAsync → DefaultContentDefinitionDisplayManager.BuildPartFieldEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditFieldPOST
  ├─ …
  ├─ if (field == null)
  ├─ ContentPartFieldSettingsExtensions.DisplayName (depth limit)
  ├─ if (field.DisplayName() != viewModel.DisplayName)
  │  ├─ …
  │  ├─ (await LoadPartAsync(partViewModel.Name)).PartDefinition.Fields.Any
  │  ├─ if ((await LoadPartAsync(partViewModel.Name)).PartDefinition.Fields.Any(t => t.Name != viewModel.…
  │  ├─ if (!ModelState.IsValid)
~ │  │  ├─ IContentDefinitionDisplayManager.UpdatePartFieldEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartFieldEditorAsync (changes below depth limit)
  │  │  ├─ IDocumentStore.CancelAsync
  │  │  └─ ? View
  │  └─ ? _notifier.InformationAsync
  ├─ new AlterFieldContext
  ├─ IContentDefinitionService.AlterFieldAsync → ContentDefinitionService.AlterFieldAsync (depth limit)
  ├─ IContentDefinitionManager.LoadPartDefinitionAsync → ContentDefinitionManager.LoadPartDefinitionAsync (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdatePartFieldEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartFieldEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ else (!(!ModelState.IsValid))
  └─ …

  AdminController.EditPart
  ├─ …
  ├─ if (contentPartDefinition == null)
  ├─ new EditPartViewModel (depth limit)
~ ├─ IContentDefinitionDisplayManager.BuildPartEditorAsync → DefaultContentDefinitionDisplayManager.BuildPartEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPartPOST
  ├─ …
  ├─ if (contentPartDefinition == null)
  ├─ new EditPartViewModel (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdatePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdatePartEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ else (!(!ModelState.IsValid))
  └─ …

  AdminController.EditPost
  ├─ …
  ├─ IContentDefinitionManager.LoadTypeDefinitionAsync → ContentDefinitionManager.LoadTypeDefinitionAsync (depth limit)
  ├─ if (contentTypeDefinition == null)
~ ├─ IContentDefinitionDisplayManager.UpdateTypeEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypeEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ else (!(!ModelState.IsValid))
  └─ …

  AdminController.EditTypePart
  ├─ …
  ├─ ContentTypePartExtensions.DisplayName (depth limit)
  ├─ ContentTypePartExtensions.Description (depth limit)
~ ├─ IContentDefinitionDisplayManager.BuildTypePartEditorAsync → DefaultContentDefinitionDisplayManager.BuildTypePartEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditTypePartPOST
  ├─ …
  ├─ if (part == null)
  ├─ ContentPartSettingsExtensions.IsReusable (depth limit)
  ├─ if (part.PartDefinition.IsReusable())
  │  ├─ ContentTypePartExtensions.DisplayName (depth limit)
  │  └─ if (part.DisplayName() != viewModel.DisplayName)
  │     ├─ …
  │     ├─ typeDefinition.Parts.Any
  │     ├─ if (typeDefinition.Parts.Any(t => t.Name != viewModel.Name && string.Equals(t.DisplayName()?.Trim…
  │     └─ if (!ModelState.IsValid)
~ │        ├─ IContentDefinitionDisplayManager.UpdateTypePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypePartEditorAsync (changes below depth limit)
  │        ├─ IDocumentStore.CancelAsync
  │        └─ ? View
  ├─ else (!(part.PartDefinition.IsReusable()))
  ├─ new AlterTypePartContext
  ├─ IContentDefinitionService.AlterTypePartAsync → ContentDefinitionService.AlterTypePartAsync (depth limit)
  ├─ IContentDefinitionManager.LoadTypeDefinitionAsync → ContentDefinitionManager.LoadTypeDefinitionAsync (depth limit)
~ ├─ IContentDefinitionDisplayManager.UpdateTypePartEditorAsync → DefaultContentDefinitionDisplayManager.UpdateTypePartEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ else (!(!ModelState.IsValid))
  └─ …

  AdminController.Clone
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.CloneContent, contentItem))
  ├─ try
~ │  └─ IContentManager.CloneAsync → DefaultContentManager.CloneAsync (changes below depth limit)
  ├─ catch (InvalidOperationException)
  ├─ ? _notifier.InformationAsync
  └─ …

  AdminController.Create
  ├─ …
  ├─ ? _authorizationService.AuthorizeContentTypeAsync
  ├─ if (!await _authorizationService.AuthorizeContentTypeAsync(User, CommonPermissions.EditContent, i…
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreateAndPublishPOST
  ├─ …
  ├─ ? _authorizationService.AuthorizeContentTypeAsync
  ├─ if (!await _authorizationService.AuthorizeContentTypeAsync(User, CommonPermissions.PublishContent…
  └─ AdminController.CreateInternalAsync (changes below depth limit)
~    ├─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
     └─ if (await _contentManager.PublishAsync(contentItem))

  AdminController.CreatePOST
  └─ AdminController.CreateInternalAsync (changes below depth limit)
~    ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
     ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
     └─ ? _notifier.SuccessAsync

  AdminController.Delete
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.DeleteContent, contentItem))
~ ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  ├─ if (removed)
  ├─ else (!(removed))
  └─ …

  AdminController.DiscardDraft
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null || contentItem.Published)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.DeleteContent, contentItem))
~ ├─ IContentManager.DiscardDraftAsync → DefaultContentManager.DiscardDraftAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ …

  AdminController.Display
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.ViewContent, contentItem))
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  AdminController.Edit
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.EditContent, contentItem))
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditAndPublishPOST
~ └─ AdminController.PublishOrUnpublishAsync (changes below depth limit)

  AdminController.EditAndUnpublishPOST
~ └─ AdminController.PublishOrUnpublishAsync (changes below depth limit)

  AdminController.EditPOST
  └─ AdminController.EditInternalAsync (changes below depth limit)
~    ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
     ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
     └─ ? _notifier.SuccessAsync

  AdminController.List
  ├─ …
  ├─ ? query.Skip(pager.GetStartIndex()).Take(pager.PageSize).ListAsync
  ├─ foreach (var contentItem in pageOfContentItems)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? TempData.TryGetValue
  ├─ if (TempData.TryGetValue(nameof(ModelState), out var modelStateJson) && modelStateJson is string)
  └─ …

  AdminController.ListFilterPOST
  ├─ if (!string.Equals(options.SearchText, options.OriginalSearchText, StringComparison.OrdinalIgnore…
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? options.FilterResult.ToString
  ├─ ? options.RouteValues.TryAdd
  └─ …

  AdminController.Publish
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.PublishContent, contentItem))
~ ├─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ if (published)
  └─ …

  AdminController.Remove
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.DeleteContent, contentItem))
  ├─ if (contentItem != null)
~ │  ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  │  ├─ if (removed)
  │  └─ else (!(removed))
  ├─ ? Url.IsLocalUrl
  ├─ if (Url.IsLocalUrl(returnUrl))
  └─ …

  AdminController.Unpublish
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ AdminController.IsAuthorizedAsync (depth limit)
  ├─ if (!await IsAuthorizedAsync(CommonPermissions.PublishContent, contentItem))
~ ├─ IContentManager.UnpublishAsync → DefaultContentManager.UnpublishAsync (changes below depth limit)
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ if (unpublished)
  └─ …

  ItemController.Display
~ ├─ ContentManagerExtensions.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, CommonPermissions.ViewContent, contentItem))
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  ItemController.Preview
  ├─ if (contentItemId == null)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, CommonPermissions.PreviewContent, contentIt…
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  AddToDeploymentPlanController.AddContentItem
  ├─ …
  ├─ ? _session.GetAsync<DeploymentPlan>
  ├─ if (deploymentPlan == null)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  └─ …

  DownloadController.Display
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, DeploymentPermissions.Export))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  └─ …

  DownloadController.Download
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, DeploymentPermissions.Export))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  └─ …

  ExportContentToDeploymentTargetMigrations.CreateAsync
~ ├─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)
  ├─ IDeploymentPlanService.GetAllDeploymentPlansAsync → DeploymentPlanService.GetAllDeploymentPlansAsync (depth limit)
  └─ if (exportContentToDeploymentTargetPlan != null)

  CreateEndpoint.HandleAsync
  ├─ …
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
  ├─ if (model is null)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  │  ├─ …
  │  ├─ ContentItemExtensions.Merge (depth limit)
  │  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (depth limit)
  │  ├─ if (result.Succeeded)
~ │  │  └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  │  ├─ else (!(result.Succeeded))
  │  └─ if (!modelState.IsValid)
  ├─ else (!(contentItem == null))
  │  ├─ …
  │  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.EditContent, c…
  │  ├─ ContentItemExtensions.Merge (depth limit)
~ │  ├─ IContentManager.UpdateAsync → DefaultContentManager.UpdateAsync (changes below depth limit)
  │  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (depth limit)
  │  ├─ if (!result.Succeeded)
  │  └─ …
  ├─ if (!draft)
~ │  └─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  ├─ else (!(!draft))
~ │  └─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
  └─ ? Results.Json

  DeleteEndpoint.HandleAsync
  ├─ ? authorizationService.AuthorizeAsync
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? authorizationService.AuthorizeAsync
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.DeleteContent,…
~ ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  └─ ? Results.Json

  GetEndpoint.HandleAsync
  ├─ ? authorizationService.AuthorizeAsync
  ├─ if (!await authorizationService.AuthorizeAsync(httpContext.User, CommonPermissions.AccessContentA…
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? authorizationService.AuthorizeAsync
  └─ …

  ContentItemTag.WriteToAsync
~ └─ ShapeTag.WriteToAsync (changes below depth limit)

  new ContentMethodsProvider
  ├─ …
  ├─ callback
  ├─ new GlobalMethod
  ├─ callback ×2
  │  └─ callback
~ │     └─ ContentMethodsProvider.CreateContentItemAsync (changes below depth limit)
  ├─ new GlobalMethod
  ├─ callback ×2
  │  └─ callback
~ │     └─ ContentMethodsProvider.UpdateContentItemAsync (changes below depth limit)
  ├─ new GlobalMethod
  └─ callback ×2
     └─ callback
~       └─ ContentMethodsProvider.DeleteContentItemAsync (changes below depth limit)

  DisplayContentItemViewComponent.InvokeAsync
  ├─ if (contentItemId != null)
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  AdminController.IndexPOST
  ├─ …
  ├─ new CorsSettings
  ├─ CorsService.UpdateSettingsAsync (depth limit)
~ ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? View

+ new CorsJSLocalizer

  ContentApiController.AddContent
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.DemoAPIAccess))
~ ├─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  └─ ? new ObjectResult

  ContentApiController.GetAuthorizedById
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.DemoAPIAccess))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, CommonPermissions.ViewContent, contentItem))
  └─ …

  ContentController.Display
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(_httpContextAccessor.HttpContext.User, CommonPerm…
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  ContentController.Edit
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(_httpContextAccessor.HttpContext.User, CommonPerm…
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  ContentController.EditPost
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(_httpContextAccessor.HttpContext.User, CommonPerm…
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ ? _session.SaveAsync
  └─ …

  HomeController.Display
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  └─ ? View

  HomeController.DisplayShape
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  └─ …

  HomeController.Index
  ├─ …
  ├─ ContentItemExtensions.Apply (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  └─ ? RedirectToAction

  EditModel.OnGetAsync
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  └─ ? Page

  EditModel.OnPostDelete
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
~ ├─ IContentManager.RemoveAsync → DefaultContentManager.RemoveAsync (changes below depth limit)
  └─ ? RedirectToPage

  EditModel.OnPostUpdate
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ ? _session.SaveAsync
  └─ …

  ListModel.OnPostAsync
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ ├─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  └─ ? RedirectToPage

  DeploymentPlanController.Display
  ├─ …
  ├─ if (deploymentPlan == null)
  ├─ foreach (var step in deploymentPlan.DeploymentSteps)
  ├─ foreach (var factory in _factories.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
  │  ├─ IDeploymentStepFactory.Create
~ │  ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  │  ├─ new DisplayDeploymentPlanThumbnailViewModel
  │  └─ ? category.HtmlClassify
  ├─ new DisplayDeploymentPlanViewModel
  ├─ thumbnails.Where(x => !string.IsNullOrWhiteSpace(x.Category)).Select
  └─ …

  StepController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.DeploymentStepType) is not null)
  ├─ if (step == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  StepController.Create
  ├─ …
  ├─ if (step == null)
  ├─ new EditDeploymentPlanStepViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  DeploymentManager.ExecuteDeploymentPlanAsync
  ├─ foreach (var step in deploymentPlan.DeploymentSteps)
  │  └─ foreach (var source in _deploymentSources)
  │     └─ IDeploymentSource.ProcessDeploymentStepAsync
  │        ├─ …
  │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync ×2 (depth limit)
~ │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync (changes below depth limit)
  │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync ×2 (depth limit)
~ │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync (changes below depth limit)
  │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync ×2 (depth limit)
  │        ├─ …
  │        ├─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync ×2 (depth limit)
~ │        └─ ⇢ DeploymentSourceBase<TStep>.ProcessDeploymentStepAsync (changes below depth limit)
  └─ DeploymentPlanResult.FinalizeAsync (depth limit)

  DeploymentManager.ImportDeploymentPackageAsync
  └─ foreach (var deploymentTargetHandler in _deploymentTargetHandlers)
~    └─ IDeploymentTargetHandler.ImportFromFileAsync → RecipeDeploymentTargetHandler.ImportFromFileAsync (changes below depth limit)

  RemoteClientController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new RemoteClientIndexViewModel (depth limit)
  ├─ ? new SelectListItem
  └─ …

  RemoteInstanceController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new RemoteInstanceIndexViewModel (depth limit)
  ├─ ? new SelectListItem
  └─ …

  HttpContextExtensions.GetActionContextAsync
  ├─ …
  ├─ ? new ActionContext
  ├─ ? httpContext.RequestServices.GetServices<IAsyncViewActionFilter>
  └─ foreach (var filter in filters)
~    └─ IAsyncViewActionFilter.OnActionExecutionAsync → RazorViewActionFilter.OnActionExecutionAsync (changes below depth limit)

  DisplayDriverBase.Dynamic
  └─ DisplayDriverBase.Factory
     ├─ …
     ├─ ⇢ SiteDisplayDriver<TSettings>.Factory (depth limit)
     ├─ ⇢ DisplayDriverBase.Factory (depth limit)
~    └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  DisplayDriverBase.Dynamic
  └─ DisplayDriverBase.Factory ↑ as above

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DisplayDriverBase.Initialize
~ └─ DisplayDriverBase.Initialize (changes below depth limit)

  DefaultShapeFactory.TryInvokeMember
  ├─ Arguments.From (depth limit)
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  DisplayHelper.TryInvoke
  ├─ Arguments.From (depth limit)
~ └─ DisplayHelper.InvokeAsync (changes below depth limit)

  DisplayHelper.TryInvokeMember
  ├─ Arguments.From (depth limit)
~ └─ DisplayHelper.InvokeAsync (changes below depth limit)

  ShapeRenderFilter.ProcessAsync
  ├─ ? input.ToObjectValue
  ├─ if (input.ToObjectValue()is IShape shape)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ if (!task.IsCompletedSuccessfully)
  │  ├─ new HtmlContentValue (depth limit)
  │  └─ …
  ├─ ? new HtmlContentValue
  └─ ? ValueTask.FromResult<FluidValue>

  ShapeStringifyFilter.ProcessAsync
  ├─ ? input.ToObjectValue
  ├─ if (input.ToObjectValue()is IShape shape)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ if (!task.IsCompletedSuccessfully)
  │  ├─ ? new ZStringWriter
  │  └─ …
  └─ ? ValueTask.FromResult<FluidValue>

  RenderBodyTag.WriteToAsync
~ ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ ? htmlContent.WriteTo

  RenderSectionTag.WriteToAsync
~ ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  ├─ ? new NamedExpressionList
  ├─ ? nameExpression.EvaluateAsync
  ├─ …
  ├─ IShapeExtensions.IsNullOrEmpty (depth limit)
  ├─ if (zone.IsNullOrEmpty())
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ ? htmlContent.WriteTo

  ZoneTag.WriteToAsync
  ├─ for (i < argumentsList.Count)
  └─ if (statements != null && statements.Count > 0)
     ├─ new ViewBufferTextWriterContent (depth limit)
     ├─ ? statements.RenderStatementsAsync
~    ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
     └─ if (zone is Shape shape)

  NotifyFilter.OnResultExecutionAsync
  ├─ …
  ├─ if (!filterContext.IsViewOrPageResult())
  ├─ if (_existingEntries.Length == 0)
~ └─ NotifyFilter.OnResultExecutionAsyncCore (changes below depth limit)

  RazorPage<TModel>.DisplayAsAsync
  ├─ if (clearAlternates.Value)
  ├─ RazorPage<TModel>.EnsureDisplayHelper (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  RazorPage<TModel>.DisplayAsync
  ├─ if (shape is IShape s)
  │  ├─ RazorPage<TModel>.EnsureDisplayHelper (depth limit)
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ if (shape is IHtmlContent hc)
  └─ if (shape is string str)

  RazorPage<TModel>.RenderBodyAsync
~ └─ RazorPage<TModel>.DisplayAsync (changes below depth limit)

  RazorPage<TModel>.RenderSection
~ └─ RazorPage<TModel>.RenderSection (changes below depth limit)

  RazorPage<TModel>.RenderSectionAsync
~ └─ RazorPage<TModel>.RenderSectionAsync (changes below depth limit)

  RazorViewActionFilter.OnActionExecutionAsync.AwaitedSiteSettings
  ├─ if (razorViewFeature.ThemeLayout is null)
  │  └─ if (layoutAccessor is not null)
~ │     └─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  └─ if (razorViewFeature.Theme is null)

  Page.DisplayAsync
  ├─ if (shape is IShape s)
  │  ├─ Page.EnsureDisplayHelper (depth limit)
~ │  └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ if (shape is IHtmlContent hc)
  └─ if (shape is string str)

  Page.RenderSectionAsync
~ └─ Page.RenderSectionAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ IShapeFactory.CreateAsync → DefaultShapeFactory.CreateAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  ShapeFactoryExtensions.CreateAsync
~ └─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)

  CoreShapes.List
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var item in items)
     ├─ …
     ├─ if (index == 0)
     ├─ if (index == count - 1)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     ├─ ? itemTag.InnerHtml.AppendHtml
     └─ ? listTagBuilder.InnerHtml.AppendHtml

  CoreShapes.NotifyMessages
  ├─ shape.Properties.TryGetValue
  ├─ ? new HtmlContentBuilder
  └─ foreach (var entry in messages)
     ├─ Arguments.From (depth limit)
~    ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? htmlContentBuilder.AppendHtml

  GroupShapes.Card
  ├─ …
  ├─ ? tagBuilder.AddCssClass
  ├─ AlternatesCollection.Clear (depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ ? tagBuilder.InnerHtml.AppendHtml
  ├─ StringExtensions.HtmlClassify (depth limit)
  └─ …

  GroupShapes.CardContainer
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  ├─ ? tagBuilder.AddCssClass
  └─ foreach (var card in shape.Items.OfType<IShape>())
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? tagBuilder.InnerHtml.AppendHtml

  GroupShapes.Column
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  └─ foreach (var column in shape.Items)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? tagBuilder.InnerHtml.AppendHtml

  GroupShapes.ColumnContainer
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  ├─ ? tagBuilder.AddCssClass
  └─ foreach (var column in shape.Items)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? tagBuilder.InnerHtml.AppendHtml

  GroupShapes.LocalNavigation
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  GroupShapes.Tab
  ├─ …
  ├─ ? tagBuilder.AddCssClass
  ├─ AlternatesCollection.Clear (depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ ? tagBuilder.InnerHtml.AppendHtml

  GroupShapes.TabContainer
  ├─ new LocalNavigationArguments
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? new HtmlContentBuilder
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ ? htmlContentBuilder.AppendHtml
  ├─ IShapeExtensions.GetTagBuilder (depth limit)
  ├─ ? tagBuilder.AddCssClass
  ├─ ? htmlContentBuilder.AppendHtml
  └─ foreach (var tab in shape.Items.OfType<IShape>())
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? tagBuilder.InnerHtml.AppendHtml

  DateTimeTagHelper.ProcessAsync
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ ? output.Content.SetHtmlContent

  TimeSpanTagHelper.ProcessAsync
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  └─ ? output.Content.SetHtmlContent

  UserDisplayNameTagHelper.ProcessAsync
  ├─ …
  ├─ if (output.Attributes.TryGetAttribute("cache-context", out var cacheContext))
  ├─ else (!(output.Attributes.TryGetAttribute("cache-context", out var cacheContext)))
~ └─ BaseShapeTagHelper.ProcessAsync (changes below depth limit)

  ZoneTagHelper.ProcessAsync
  ├─ ? output.GetChildContentAsync
~ ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  ├─ if (zone is Shape shape)
  └─ ? output.SuppressOutput

  ThemeLayout.ExecuteAsync
  ├─ RazorPage<TModel>.RenderLayoutBody (depth limit)
  ├─ if (ThemeLayout != null)
  │  ├─ ? ThemeLayout.Zones["Content"].AddAsync
~ │  ├─ RazorPage<TModel>.DisplayAsync (changes below depth limit)
  │  ├─ ? PositionWrapper.TryWrap
  │  ├─ foreach (var zone in ThemeLayout.Properties.ToArray())
  │  │  └─ if (zone.Value is IShape shape)
  │  │     ├─ IShapeExtensions.IsNullOrEmpty (depth limit)
~ │  │     ├─ RazorPage<TModel>.DisplayAsync (changes below depth limit)
  │  │     └─ ? PositionWrapper.TryWrap
~ │  ├─ RazorPage<TModel>.DisplayAsync (changes below depth limit)
  │  └─ ? Write
  └─ else (!(ThemeLayout != null))

  ZoneShapes.CardGrouping
  ├─ ? new HtmlContentBuilder
  ├─ if (groupings.Count > 1)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ foreach (var orderedGrouping in orderedGroupings)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ foreach (var item in orderedGrouping)
  │  │  └─ IShapeExtensions.AddAsync (depth limit)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  └─ ? htmlContentBuilder.AppendHtml
  └─ else (!(groupings.Count > 1))
~    ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? htmlContentBuilder.AppendHtml

  ZoneShapes.ColumnGrouping
  ├─ ? new HtmlContentBuilder
  ├─ if (hasColumnItems)
  │  ├─ if (beforeRow is not null)
  │  │  └─ foreach (var item in beforeRow)
~ │  │     ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  │     └─ ? htmlContentBuilder.AppendHtml
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ foreach (var columnItem in sortedColumnItems)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ StringExtensions.HtmlClassify (depth limit)
  │  │  ├─ IShapeExtensions.AddAsync (depth limit)
  │  │  └─ …
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  ├─ ? htmlContentBuilder.AppendHtml
  │  └─ if (afterRow is not null)
  │     └─ foreach (var item in afterRow)
~ │        ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │        └─ ? htmlContentBuilder.AppendHtml
  └─ else (!(hasColumnItems))
     └─ foreach (var item in allItems)
~       ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
        └─ ? htmlContentBuilder.AppendHtml

  ZoneShapes.ContentZone
  ├─ ? new HtmlContentBuilder
  ├─ if (!isGrouped)
  │  └─ foreach (var item in shapes)
~ │     ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │     └─ ? htmlContentBuilder.AppendHtml
  ├─ if (groupings.Count > 1)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  ├─ foreach (var orderedGrouping in orderedGroupings)
~ │  │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  │  ├─ foreach (var item in orderedGrouping)
  │  │  └─ IShapeExtensions.AddAsync (depth limit)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  │  └─ ? htmlContentBuilder.AppendHtml
  └─ else (!(groupings.Count > 1))
     └─ if (groupings.Count == 1)
~       ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
~       ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
        └─ ? htmlContentBuilder.AppendHtml

  ZoneShapes.Zone
  ├─ ? new HtmlContentBuilder
  └─ foreach (var item in Shape)
~    ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
     └─ ? htmlContentBuilder.AppendHtml

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  EmailMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
     ├─ if (!(!string.IsNullOrEmpty(smtpSettings.DefaultSender)))
     └─ if (!string.IsNullOrEmpty(smtpSettings.DefaultSender) || scope.ServiceProvider.GetService<IOption…
~       └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  ShellConfigurationSourcesExtensions.AddSourcesAsync
  └─ IShellConfigurationSources.AddSourcesAsync
     ├─ ⇢ ShellConfigurationSources.AddSourcesAsync (depth limit)
     ├─ ⇢ BlobShellConfigurationSources.AddSourcesAsync (depth limit)
~    └─ ⇢ DatabaseShellConfigurationSources.AddSourcesAsync (changes below depth limit)

  ShellsSettingsSourcesExtensions.AddSourcesAsync
  └─ IShellsSettingsSources.AddSourcesAsync
     ├─ ⇢ ShellsSettingsSources.AddSourcesAsync (depth limit)
     ├─ ⇢ BlobShellsSettingsSources.AddSourcesAsync (depth limit)
~    └─ ⇢ DatabaseShellsSettingsSources.AddSourcesAsync (changes below depth limit)

  ShellsSettingsSourcesExtensions.AddSourcesAsync
  └─ IShellsSettingsSources.AddSourcesAsync
     ├─ ⇢ ShellsSettingsSources.AddSourcesAsync (depth limit)
     ├─ ⇢ BlobShellsSettingsSources.AddSourcesAsync (depth limit)
~    └─ ⇢ DatabaseShellsSettingsSources.AddSourcesAsync (changes below depth limit)

  new DistributedShellHostedService
  ├─ callback
~ │  └─ DistributedShellHostedService.LoadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReleasingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReloadingAsync (changes below depth limit)
  └─ callback
~    └─ DistributedShellHostedService.RemovingAsync (changes below depth limit)

  DistributedShellHostedService.ExecuteAsync
  ├─ while (!stoppingToken.IsCancellationRequested)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ IShellHost.TryGetShellContext → ShellHost.TryGetShellContext (depth limit)
  │  │  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
  │  │  ├─ if (defaultTenantSyncingSeconds++ > DefaultTenantSyncingPeriod)
  │  │  │  ├─ …
  │  │  │  ├─ ShellSettingsExtensions.AsDisposable (depth limit)
  │  │  │  ├─ ShellSettingsExtensions.IsRunning (depth limit)
  │  │  │  └─ if (loadedDefaultSettings.IsRunning())
~ │  │  │     └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  │  │  ├─ ShellSettingsExtensions.IsRunning (depth limit)
~ │  │  ├─ DistributedShellHostedService.GetOrCreateDistributedContextAsync (changes below depth limit)
  │  │  ├─ catch (Exception ex) when (!ex.IsFatal())
  │  │  ├─ catch (Exception ex) when (!ex.IsFatal())
  │  │  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings (depth limit)
  │  │  ├─ if (shellCountChangedId is not null && _shellCountChangedId != shellCountChangedId)
  │  │  └─ foreach (var settings in loadedSettings)
  │  │     ├─ DistributedShellHostedService.TryWaitAfterBusyTime (depth limit)
  │  │     ├─ try
  │  │     │  ├─ DistributedShellHostedService.ReleaseIdKey (depth limit)
  │  │     │  ├─ if (releaseId is not null && !tenantsToCreate.Contains(settings.Name))
  │  │     │  │  ├─ _identifiers.GetOrAdd
  │  │     │  │  └─ if (identifier.ReleaseId != releaseId)
~ │  │     │  │     └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  │  │     │  ├─ DistributedShellHostedService.ReloadIdKey (depth limit)
  │  │     │  ├─ if (reloadId is not null)
  │  │     │  │  ├─ _identifiers.GetOrAdd
  │  │     │  │  └─ if (identifier.ReloadId != reloadId)
~ │  │     │  │     └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  │  │     │  ├─ ShellSettingsExtensions.IsDefaultShell (depth limit)
  │  │     │  └─ if (!settings.IsDefaultShell() && tenantsToRemove.Contains(settings.Name))
  │  │     │     ├─ ShellSettingsExtensions.IsRemovable (depth limit)
  │  │     │     └─ if (settings.IsRemovable())
~ │  │     │        ├─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)
  │  │     │        └─ else (!(removingContext.FailedOnLockTimeout))
~ │  │     │           └─ IShellHost.RemoveShellContextAsync → ShellHost.RemoveShellContextAsync (changes below depth limit)
  │  │     └─ catch (Exception ex) when (!ex.IsFatal())
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ callback
~ │  └─ DistributedShellHostedService.LoadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReleasingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.ReloadingAsync (changes below depth limit)
  ├─ callback
~ │  └─ DistributedShellHostedService.RemovingAsync (changes below depth limit)
  └─ if (_context is not null)

  ShellScope.UsingChildScopeAsync
~ ├─ ShellScope.CreateChildScopeAsync (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)

  ShellScope.UsingChildScopeAsync
~ ├─ ShellScope.CreateChildScopeAsync (changes below depth limit)
~ └─ ShellScope.UsingAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.DisableFeaturesAsync
~ └─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.EnableFeaturesAsync
~ └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  ShellFeaturesManagerExtensions.UpdateFeaturesAsync
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
~ └─ IShellFeaturesManager.UpdateFeaturesAsync → ShellFeaturesManager.UpdateFeaturesAsync (changes below depth limit)

  ShellHostExtensions.ReleaseAllShellContextsAsync
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings (depth limit)
  └─ foreach (var settings in shellHost.GetAllSettings())
~    └─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)

  ShellHostExtensions.ReloadAllShellContextsAsync
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings (depth limit)
  └─ foreach (var settings in shellHost.GetAllSettings())
~    └─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)

  WidgetMigrations.CreateAsync
  ├─ ContentDefinitionManagerExtensions.AlterPartDefinitionAsync (depth limit)
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  AdminController.Disable
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, FeaturesPermissions.ManageFeatures))
  ├─ AdminController.ExecuteAsync (changes below depth limit)
~ │  ├─ FeatureService.GetAvailableFeature (changes below depth limit)
  │  ├─ if (!isProxy && id == FeaturesConstants.FeatureId)
~ │  └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit)
  │     └─ AdminController.NotifyAsync (depth limit)
  ├─ if (!found)
  ├─ AdminController.GetNextUrl (depth limit)
  └─ …

  AdminController.Enable
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, FeaturesPermissions.ManageFeatures))
  ├─ AdminController.ExecuteAsync (changes below depth limit)
~ │  ├─ FeatureService.GetAvailableFeature (changes below depth limit)
~ │  └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit) ↑ as above
  ├─ if (!found)
  ├─ AdminController.GetNextUrl (depth limit)
  └─ …

  AdminController.Features
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, FeaturesPermissions.ManageFeatures))
  ├─ if (model.FeatureIds == null || model.FeatureIds.Length == 0)
  ├─ if (ModelState.IsValid)
  │  └─ AdminController.ExecuteAsync (changes below depth limit)
~ │     ├─ FeatureService.GetAvailableFeatures (changes below depth limit)
~ │     └─ FeatureService.EnableOrDisableFeaturesAsync (changes below depth limit) ↑ as above
  └─ ? RedirectToAction

  AdminController.Features
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, FeaturesPermissions.ManageFeatures))
  ├─ new FeaturesViewModel
  ├─ AdminController.ExecuteAsync (changes below depth limit)
~ │  └─ FeatureService.GetModuleFeaturesAsync (changes below depth limit)
  └─ ? View

  ModuleService.DisableFeaturesAsync
~ └─ ModuleService.DisableFeaturesAsync (changes below depth limit)

  ModuleService.EnableFeaturesAsync
~ └─ ModuleService.EnableFeaturesAsync (changes below depth limit)

  FeedController.Index
  ├─ …
  ├─ _feedFormatProviders.Select
  ├─ if (bestFormatterMatch == null || bestFormatterMatch.FeedBuilder == null)
  ├─ foreach (var provider in _feedQueryProviders)
~ │  └─ IFeedQueryProvider.MatchAsync → ListFeedQuery.MatchAsync (changes below depth limit)
  ├─ if (bestQueryMatch == null || bestQueryMatch.FeedQuery == null)
  ├─ ? context.Builder.ProcessAsync
~ │  ├─ IFeedQuery.ExecuteAsync → ListFeedQuery.ExecuteAsync (changes below depth limit)
  │  ├─ IFeedItemBuilder.PopulateAsync → CommonFeedItemBuilder.PopulateAsync (depth limit)
  │  └─ foreach (var contextualizer in context.Response.Contextualizers)
  ├─ ? document.ToString
  └─ ? Content

  AdminController.BuildEditor
  ├─ …
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ if (flowMetadata)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ new BuildEditorViewModel
  └─ ? View

~ new ResourceManagementOptionsConfiguration (body changed; visible calls unchanged)
  ├─ new ResourceManifest (depth limit)
  ├─ ResourceManifest.DefineStyle (depth limit)
  └─ …

+ new FormsJSLocalizer

  AdminController.Create
  ├─ …
  ├─ new IndexProfileKey (depth limit)
  ├─ if (!_indexingOptions.Sources.TryGetValue(new IndexProfileKey(providerName, type), out var service))
~ ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ new IndexProfileKey (depth limit)
  ├─ if (!_indexingOptions.Sources.TryGetValue(new IndexProfileKey(providerName, type), out var service))
~ ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IIndexProfileManager.ValidateAsync → DefaultIndexProfileManager.ValidateAsync (depth limit)
  ├─ if (!validate.Succeeded && ModelState.IsValid)
  ├─ if (ModelState.IsValid)
  │  ├─ if (indexManager is null)
~ │  ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
  │  ├─ IIndexManager.CreateAsync
  │  ├─ if (!await indexManager.CreateAsync(indexProfile))
~ │  ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  ├─ ? _notifier.SuccessAsync
  │  └─ ? RedirectToAction
  └─ ? View

  AdminController.Edit
  ├─ …
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
  ├─ …
  ├─ if (indexProfile == null)
  ├─ new ModelViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IIndexProfileManager.ValidateAsync → DefaultIndexProfileManager.ValidateAsync (depth limit)
  ├─ if (!validate.Succeeded && ModelState.IsValid)
  ├─ if (ModelState.IsValid)
~ │  ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
  │  ├─ ? _notifier.SuccessAsync
  │  └─ ? RedirectToAction
  └─ ? View

  AdminController.Index
  ├─ …
  ├─ _indexingOptions.Sources.Select(x => new { Source = x.Key, ProviderName = x.Value.ProviderName, }).OrderBy(x => x.ProviderName, StringComparer.OrdinalIgnoreCase).ThenBy(x => x.Source.Type).GroupBy(x => x.ProviderName, StringComparer.OrdinalIgnoreCase).Select
  ├─ new AdminIndexViewModel (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var record in result.Models)
  │  ├─ new ModelEntry<T>
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ ? new SelectListItem ×2
  └─ …

  AdminController.IndexPost
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, IndexingPermissions.ManageIndexes))
  ├─ if (itemIds?.Any() == true)
  │  ├─ case IndexingEntityAction.Remove:
  │  ├─ case IndexingEntityAction.Reset:
  │  │  ├─ foreach (var id in itemIds)
  │  │  │  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
  │  │  │  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ │  │  │  ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~ │  │  │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  │  ├─ if (resetCounter == 0)
  │  │  └─ else (!(resetCounter == 0))
  │  ├─ case IndexingEntityAction.Synchronize:
  │  │  ├─ foreach (var id in itemIds)
  │  │  │  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
~ │  │  │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  │  ├─ if (synchronizedCounter == 0)
  │  │  └─ else (!(synchronizedCounter == 0))
  │  ├─ case IndexingEntityAction.Rebuild:
  │  │  ├─ foreach (var id in itemIds)
  │  │  │  ├─ …
  │  │  │  ├─ IIndexManager.RebuildAsync
  │  │  │  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ │  │  │  ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~ │  │  │  └─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  │  ├─ if (rebuildCounter == 0)
  │  │  └─ else (!(rebuildCounter == 0))
  │  └─ default:
  └─ ? RedirectToAction

  AdminController.Rebuild
  ├─ …
  ├─ if (indexManager is null)
  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
  ├─ IIndexManager.RebuildAsync
  ├─ if (await indexManager.RebuildAsync(indexProfile))
~ │  ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  │  └─ ? _notifier.SuccessAsync
  ├─ else (!(await indexManager.RebuildAsync(indexProfile)))
  └─ ? RedirectToAction

  AdminController.Reset
  ├─ …
  ├─ if (indexProfile == null)
  ├─ IIndexProfileManager.ResetAsync → DefaultIndexProfileManager.ResetAsync (depth limit)
~ ├─ IIndexProfileManager.UpdateAsync → DefaultIndexProfileManager.UpdateAsync (changes below depth limit)
~ ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Synchronize
  ├─ …
  ├─ IIndexProfileManager.FindByIdAsync → DefaultIndexProfileManager.FindByIdAsync (depth limit)
  ├─ if (indexProfile == null)
~ ├─ IIndexProfileManager.SynchronizeAsync → DefaultIndexProfileManager.SynchronizeAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  WorkerFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ ShellFeaturesManagerExtensions.IsFeatureEnabledAsync (depth limit)
     ├─ if (!(await featuresManager.IsFeatureEnabledAsync("OrchardCore.Search.Elasticsearch.Worker")))
~    └─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)

  AdminController.Edit
  ├─ …
  ├─ ILayerService.GetLayersAsync → LayerService.GetLayersAsync (depth limit)
  ├─ if (layer == null)
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ foreach (var factory in _conditionFactories)
  │  ├─ IConditionFactory.Create → ConditionFactory<TCondition>.Create (depth limit)
~ │  ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  │  └─ ? Url.ActionLink
  ├─ new LayerEditViewModel
  └─ ? View

  AdminController.Index
  ├─ …
  ├─ IContentDefinitionManager.ListTypeDefinitionsAsync → ContentDefinitionManager.ListTypeDefinitionsAsync (depth limit)
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ foreach (var widget in widgets.OrderBy(x => x.Position))
  │  ├─ if (contentDefinitions.Any(c => c.Name == widget.ContentItem.ContentType))
~ │  │  └─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  │  └─ else (!(contentDefinitions.Any(c => c.Name == widget.ContentItem.ContentType)))
  └─ ? View

  AdminController.UpdatePosition
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ManageLayers))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ …
  ├─ ? _session.SaveAsync
  ├─ ContentExtensions.IsPublished (depth limit)
  ├─ if (contentItem.IsPublished() == false)
~ │  ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  │  └─ if (publishedContentItem != null)
  ├─ new LayerState
  ├─ IDocumentManager<TDocument>.UpdateAsync → DocumentManager<TDocument>.UpdateAsync (depth limit)
  └─ …

  LayerRuleController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.ConditionType) is not null)
  ├─ if (condition == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  LayerRuleController.Create
  ├─ …
  ├─ if (condition == null)
  ├─ new LayerRuleCreateViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  LayerRuleController.Edit
  ├─ …
  ├─ LayerRuleController.FindCondition (depth limit)
  ├─ if (condition == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  ├─ ? _notifier.ErrorAsync
  └─ …

  LayerRuleController.Edit
  ├─ …
  ├─ if (condition == null)
  ├─ new LayerRuleEditViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  LayerFilter.OnResultExecutionAsync
  ├─ ResultExecutingContextExtensions.IsViewOrPageResult (depth limit)
  ├─ if (context.IsViewOrPageResult())
  ├─ if (context.IsViewOrPageResult() && !AdminAttribute.IsApplied(context.HttpContext))
  │  ├─ …
  │  ├─ if (!_memoryCache.TryGetValue<CacheEntry>(WidgetsKey, out var cacheEntry) || cacheEntry.Identifie…
  │  ├─ ILayerService.GetLayersAsync → LayerService.GetLayersAsync (depth limit)
~ │  ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  │  ├─ ContentDefinitionManagerExtensions.ListWidgetTypeDefinitionsAsync (depth limit)
  │  └─ foreach (var widget in widgets)
  │     ├─ if (!layersCache.TryGetValue(layer.Name, out display))
  │     ├─ if (widgetDefinitions.TryGetValue(widget.ContentItem.ContentType, out var definition))
  │     └─ if (widgetDefinitions.TryGetValue(widget.ContentItem.ContentType, out var definition) && (!defini…
  │        ├─ ContentItemExtensions.Clone (depth limit)
~ │        ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  │        ├─ StringExtensions.HtmlClassify (depth limit)
  │        ├─ new WidgetWrapper (depth limit)
  │        └─ …
  └─ ? next.Invoke

  OrderController.UpdateContentItemOrders
  ├─ …
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ if (!pageOfContentItems.First().TryGet<ContainedPart>(out var containedPart))
~ ├─ IContainerService.UpdateContentItemOrdersAsync → ContainerService.UpdateContentItemOrdersAsync (changes below depth limit)
  └─ ? Ok

  RemotePublishingController.Rsd
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  └─ …

~ new LocalizationSettings (body changed; visible calls unchanged)

+ new LocalizationJSLocalizer

  LegacyFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

~ new ResourceManagementOptionsConfiguration (body changed; visible calls unchanged)
  ├─ new ResourceManifest (depth limit)
  ├─ ResourceManifest.DefineScript (depth limit)
  └─ …

  LegacyImageCacheFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  LegacyImageCacheFeatureMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit) ↑ as above

  MediaProfilesController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new MediaProfileIndexViewModel (depth limit)
  ├─ mediaProfiles.Select
  └─ …

  GetLocalizationsEndpoint.HandleAsync
  ├─ ? cache.GetOrCreate
~ │  ├─ JSLocalizerExtensions.GetMergedLocalizations (changes below depth limit)
  │  └─ ? new EntityTagHeaderValue
  ├─ ? httpContext.Response.GetTypedHeaders
  ├─ ? new CacheControlHeaderValue
  └─ …

  ViewMediaFolderAuthorizationHandler.HandleRequirementAsync
  ├─ …
  ├─ ViewMediaFolderAuthorizationHandler.IsAuthorizedFolder (depth limit)
  ├─ if (!(IsAuthorizedFolder(_mediaFieldsFolder, path)))
  ├─ if (IsAuthorizedFolder(_mediaFieldsFolder, path) || IsDescendantOfAuthorizedFolder(_mediaFieldsFo…
~ │  └─ ViewMediaFolderAuthorizationHandler.AuthorizeAttachedMediaFieldsFolderAsync (changes below depth limit)
  ├─ ViewMediaFolderAuthorizationHandler.IsAuthorizedFolder (depth limit)
  ├─ if (!(IsAuthorizedFolder(_usersFolder, path)))
  └─ …

  AdminController.Create
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ManageMenu))
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (menu == null)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ if (menuItemId == null)
  ├─ else (!(menuItemId == null))
~ ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
  └─ ? RedirectToAction

  AdminController.Delete
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (menu == null)
  ├─ AdminController.FindMenuItem (depth limit)
  ├─ if (menuItem == null)
  ├─ JNode.SelectNode (depth limit)
~ ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Edit
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (menu == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ …
  ├─ if (menuItem == null)
  ├─ JNode.ToObject (depth limit)
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (menu == null)
  ├─ AdminController.FindMenuItem (depth limit)
  ├─ …
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ ContentItemExtensions.Merge (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ new JsonMergeSettings (depth limit)
  ├─ JObject.Merge (depth limit)
~ ├─ IContentManager.SaveDraftAsync → DefaultContentManager.SaveDraftAsync (changes below depth limit)
  └─ ? RedirectToAction

  MenuShapes.ShouldCreateAsync
  ├─ …
  ├─ if (contentItem.TryGet<MenuItemPermissionPart>(out var permissionPart) && permissionPart.Permissi…
  ├─ ContentItemExtensions.TryGet (depth limit)
  └─ if (contentItem.TryGet<ContentMenuItemPart>(out var menuItemPart))
     └─ if (menuItemPart.CheckContentPermissions)
~       ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
        ├─ IContentManager.LoadAsync → DefaultContentManager.LoadAsync (depth limit)
        └─ AuthorizationServiceExtensions.AuthorizeAsync (depth limit)

  Migrations.CreateAsync
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom2Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

+ new MenuJSLocalizer

  MiniProfilerFilter.OnResultExecutionAsync
  ├─ …
  ├─ ResultExecutingContextExtensions.IsViewOrPageResult (depth limit)
  ├─ if (context.IsViewOrPageResult())
  ├─ if (context.IsViewOrPageResult() && ((viewMiniProfilerOnFrontEnd && !AdminAttribute.IsApplied(con…
~ │  ├─ ILayoutAccessor.GetLayoutAsync → LayoutAccessor.GetLayoutAsync (changes below depth limit)
  │  └─ if (footerZone is Shape shape)
~ │     ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │     └─ IShapeExtensions.AddAsync (depth limit)
  └─ ? next.Invoke

  ModularBackgroundService.ExecuteAsync
  ├─ if (_options.ShellWarmup)
  │  ├─ try
~ │  │  └─ IShellHost.InitializeAsync → ShellHost.InitializeAsync (changes below depth limit)
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ while (GetRunningShells().Length == 0)
  └─ while (!stoppingToken.IsCancellationRequested)
     ├─ try
     │  ├─ ModularBackgroundService.GetRunningShells (depth limit)
~    │  ├─ ModularBackgroundService.UpdateAsync (changes below depth limit)
~    │  └─ ModularBackgroundService.RunAsync (changes below depth limit)
     ├─ catch (Exception ex) when (!ex.IsFatal())
     └─ ModularBackgroundService.WaitAsync (depth limit)

  ModularTenantContainerMiddleware.Invoke
~ ├─ IShellHost.InitializeAsync → ShellHost.InitializeAsync (changes below depth limit)
  ├─ RunningShellTableExtensions.Match (depth limit)
  └─ if (shellSettings is not null)
     ├─ …
     ├─ if (shellSettings.IsInitializing())
     ├─ HttpContextExtensions.UseShellScopeServices (depth limit)
~    ├─ IShellHost.GetScopeAsync → ShellHost.GetScopeAsync (changes below depth limit)
     ├─ new ShellContextFeature
     ├─ ? httpContext.Features.Set
     └─ …

  NavigationHelper.PopulateMenuAsync
~ ├─ NavigationHelper.PopulateMenuLevelAsync (changes below depth limit)
  └─ NavigationHelper.ApplySelection (depth limit)

  PagerShapes.Pager
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.PagerSlim
  ├─ …
  ├─ PagerShapes.SetCustomUrlParams (depth limit)
  ├─ IShapeExtensions.TryGetProperty (depth limit)
  ├─ if (shape.TryGetProperty("Before", out string before))
  │  ├─ …
  │  ├─ ? beforeRouteData.Remove
  │  ├─ Arguments.From (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
  ├─ else (!(shape.TryGetProperty("Before", out string before)))
  ├─ IShapeExtensions.TryGetProperty (depth limit)
  ├─ if (shape.TryGetProperty("After", out string after))
  │  ├─ …
  │  ├─ ? afterRouteData.Remove
  │  ├─ Arguments.From (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ IShapeExtensions.AddAsync (depth limit)
  ├─ else (!(shape.TryGetProperty("After", out string after)))
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ IShapeExtensions.TryGetProperty (depth limit)
~ ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  └─ ? WrapWithPageSizeSelector

  PagerShapes.Pager_CurrentPage
  ├─ …
  ├─ IShapeExtensions.GetProperty (depth limit)
  ├─ ? parentTag.AddCssClass
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_First
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Gap
  ├─ …
  ├─ IShapeExtensions.GetProperty (depth limit)
  ├─ ? parentTag.AddCssClass
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Last
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Link
  ├─ AlternatesCollection.Clear (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Links
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
  ├─ if (totalPageCount < 2)
~ │  ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
~ │  ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  │  └─ ? WrapWithPageSizeSelector
  ├─ PagerShapes.GetRouteData (depth limit)
  ├─ PagerShapes.SetCustomUrlParams (depth limit)
  ├─ …
  ├─ ? new RouteValueDictionary
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? shape.AddAsync
  ├─ ? new RouteValueDictionary
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? shape.AddAsync
  ├─ if (firstPage > 1 && numberOfPagesToShow > 0)
  │  ├─ ? new RouteValueDictionary
  │  ├─ Arguments.From (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ ? shape.AddAsync
  ├─ if (numberOfPagesToShow > 0 && lastPage > 1)
  │  └─ for (p <= lastPage)
  │     ├─ if (p == 1)
  │     ├─ if (p == currentPage)
  │     │  ├─ ? new RouteValueDictionary
  │     │  ├─ Arguments.From (depth limit)
~ │     │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │     │  └─ ? shape.AddAsync
  │     └─ else (!(p == currentPage))
  │        ├─ ? new RouteValueDictionary
  │        ├─ Arguments.From (depth limit)
~ │        ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │        └─ ? shape.AddAsync
  ├─ if (lastPage < totalPageCount && numberOfPagesToShow > 0)
  │  ├─ ? new RouteValueDictionary
  │  ├─ Arguments.From (depth limit)
~ │  ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  │  └─ ? shape.AddAsync
  ├─ ? new RouteValueDictionary
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? shape.AddAsync
  ├─ ? new RouteValueDictionary
  ├─ Arguments.From (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ ? shape.AddAsync
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
~ ├─ PagerShapes.RenderPageSizeSelectorAsync (changes below depth limit)
  └─ ? WrapWithPageSizeSelector

  PagerShapes.Pager_Next
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  PagerShapes.Pager_Previous
  ├─ AlternatesCollection.Clear (depth limit)
  ├─ shape.Attributes.ContainsKey → Arguments.NamedEnumerable<T>.Named.System.Collections.Generic.IDictionary<System.String,T>.ContainsKey (depth limit)
~ └─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)

  AdminController.List
  ├─ …
  ├─ new Pager (depth limit)
  ├─ INotificationsAdminListQueryService.QueryAsync → DefaultNotificationsAdminListQueryService.QueryAsync (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var notification in queryResult.Notifications)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  └─ ? View

  AdminController.ListFilterPOST
  ├─ if (!string.Equals(options.SearchText, options.OriginalSearchText, StringComparison.OrdinalIgnore…
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? options.FilterResult.ToString
  ├─ ? options.RouteValues.TryAdd
  └─ …

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
  ├─ if (settings.Authority != null)
~ ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
  └─ ? CreateTenantScope(settings.Tenant).UsingAsync

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
  └─ if (!string.IsNullOrEmpty(settings.Tenant) && !string.Equals(settings.Tenant, _shellSettings.Name…
~    ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
     └─ ? CreateTenantScope(settings.Tenant).UsingAsync
~       ├─ IShellHost.GetOrCreateShellContextAsync → ShellHost.GetOrCreateShellContextAsync (changes below depth limit)
~       ├─ ShellContext.AddDependentShellAsync (changes below depth limit)
        └─ ? scope.ServiceProvider.GetDataProtectionProvider

  OpenIdValidationConfiguration.Configure
~ ├─ OpenIdValidationConfiguration.GetValidationSettingsAsync (changes below depth limit)
  ├─ ? options.Handlers.Add
  ├─ if (settings.Authority != null)
~ ├─ OpenIdValidationConfiguration.CreateTenantScope (changes below depth limit)
  └─ ? CreateTenantScope(settings.Tenant).UsingAsync

  ApplicationController.Index
  ├─ …
  ├─ foreach (var application in _applicationManager.ListAsync(pager.PageSize, pager.GetStartIndex()))
  ├─ new OpenIdApplicationsIndexViewModel
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ ? View

  ScopeController.Index
  ├─ …
  ├─ ? _scopeManager.CountAsync
  ├─ new OpenIdScopeIndexViewModel (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ Pager.GetStartIndex (depth limit)
  ├─ ? _scopeManager.ListAsync
  └─ …

  ServerConfigurationController.Index
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, OpenIdPermissions.ManageServerSettings))
  ├─ IOpenIdServerService.GetSettingsAsync → OpenIdServerService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  ServerConfigurationController.IndexPost
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, OpenIdPermissions.ManageServerSettings))
  ├─ IOpenIdServerService.GetSettingsAsync → OpenIdServerService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ IOpenIdServerService.ValidateSettingsAsync → OpenIdServerService.ValidateSettingsAsync (depth limit)
  ├─ …
  ├─ IOpenIdServerService.UpdateSettingsAsync → OpenIdServerService.UpdateSettingsAsync (depth limit)
  ├─ ? _notifier.SuccessAsync
~ ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  └─ ? RedirectToAction

  ValidationConfigurationController.Index
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, OpenIdPermissions.ManageValidationSettings))
  ├─ IOpenIdValidationService.GetSettingsAsync → OpenIdValidationService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  ValidationConfigurationController.IndexPost
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, OpenIdPermissions.ManageValidationSettings))
  ├─ IOpenIdValidationService.GetSettingsAsync → OpenIdValidationService.GetSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
~ ├─ IOpenIdValidationService.ValidateSettingsAsync → OpenIdValidationService.ValidateSettingsAsync (changes below depth limit)
  ├─ foreach (var result in await _validationService.ValidateSettingsAsync(settings))
  ├─ if (!ModelState.IsValid)
  ├─ IOpenIdValidationService.UpdateSettingsAsync → OpenIdValidationService.UpdateSettingsAsync (depth limit)
  ├─ ? _notifier.SuccessAsync
~ ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  └─ ? RedirectToAction

+ new OpenIdJSLocalizer

  AdminController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new ListShapePlacementsViewModel (depth limit)
  ├─ ? new SelectListItem
  └─ …

  AdminController.Create
  ├─ …
  ├─ if (query == null)
  ├─ new QueriesCreateViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ IQueryManager.NewAsync → DefaultQueryManager.NewAsync (depth limit)
  ├─ if (query == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  AdminController.Edit
  ├─ …
  ├─ if (query == null)
  ├─ new QueriesEditViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
  ├─ …
  ├─ IQueryManager.GetQueryAsync → DefaultQueryManager.GetQueryAsync (depth limit)
  ├─ if (query == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  AdminController.Index
  ├─ …
  ├─ IQueryManager.PageQueriesAsync → DefaultQueryManager.PageQueriesAsync (depth limit)
  ├─ new QueriesIndexViewModel (depth limit)
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ foreach (var query in result.Records)
  │  ├─ new QueryEntry
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ ? new SelectListItem
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ IRateLimitPolicyStore.CreateAsync → RateLimitPolicyStore.CreateAsync (depth limit)
  ├─ AdminController.ShouldReloadPolicy (depth limit)
  ├─ if (ShouldReloadPolicy(wasEnabled: false, isEnabled: policy.IsEnabled))
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Delete
  ├─ …
  ├─ if (policy is null)
  ├─ IRateLimitPolicyStore.DeleteAsync → RateLimitPolicyStore.DeleteAsync (depth limit)
  ├─ if (policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Disable
  ├─ …
  ├─ if (policy.IsEnabled)
  ├─ if (policy.IsEnabled && !await _policyStore.SetStatusAsync(policyId, false))
  ├─ if (policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Edit
  ├─ …
  ├─ AdminController.GetCurrentPolicyAsync (depth limit)
  ├─ if (policy is null)
~ ├─ AdminController.CreateEditViewModelAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
~ └─ AdminController.SavePolicyAsync (changes below depth limit)

  AdminController.Enable
  ├─ …
  ├─ if (!policy.IsEnabled)
  ├─ if (!policy.IsEnabled && !await _policyStore.SetStatusAsync(policyId, true))
  ├─ if (!policy.IsEnabled)
~ │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Index
  ├─ …
  ├─ if (!string.IsNullOrWhiteSpace(searchText))
  ├─ new RateLimitsIndexViewModel (depth limit)
  ├─ pagedPolicies.Select
~ │  └─ AdminController.BuildPolicyEntryAsync (changes below depth limit)
  ├─ AdminController.BuildBuiltInRouteLimits (depth limit)
  ├─ AdminController.BuildBuiltInGroupLimits (depth limit)
  ├─ …
  ├─ ? new SelectListItem ×2
  ├─ if (totalCount > pager.PageSize)
~ │  └─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  └─ ? View

  AdminController.IndexPost
  ├─ …
  ├─ if (ids.Length == 0)
  ├─ AdminController.GetCurrentPoliciesAsync (depth limit)
  ├─ case RateLimitPolicyBulkAction.Enable:
  │  ├─ foreach (var policy in policies.Where(x => !x.IsEnabled))
  │  ├─ if (totalChanged == 0)
~ │  ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  │  ├─ HtmlLocalizerExtensions.Plural (depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  ├─ case RateLimitPolicyBulkAction.Disable:
  │  ├─ foreach (var policy in policies.Where(x => x.IsEnabled))
  │  ├─ if (totalChanged == 0)
~ │  ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  │  ├─ HtmlLocalizerExtensions.Plural (depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  ├─ case RateLimitPolicyBulkAction.Remove:
  │  ├─ foreach (var policy in policies)
  │  ├─ if (totalDeleted == 0)
  │  ├─ if (shouldReload)
~ │  │  └─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  │  ├─ HtmlLocalizerExtensions.Plural (depth limit)
  │  └─ NotifierExtensions.SuccessAsync (depth limit)
  ├─ default:
  └─ ? RedirectToAction

  LimiterController.Create
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  LimiterController.CreatePost
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ IRateLimitPolicyStore.UpdateAsync → RateLimitPolicyStore.UpdateAsync (depth limit)
  └─ …

  LimiterController.Edit
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  LimiterController.EditPost
  ├─ …
  ├─ new RateLimiterEditorViewModel
  ├─ LimiterController.GetLimiterDocumentationUrl (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ IRateLimitPolicyStore.UpdateAsync → RateLimitPolicyStore.UpdateAsync (depth limit)
  └─ …

  GlobalRateLimitsMigrations.CreateAsync
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  ReCaptchaTagHelper.ProcessAsync
  ├─ if (!string.IsNullOrWhiteSpace(Language))
  ├─ if (!string.IsNullOrWhiteSpace(OnLoad))
~ └─ BaseShapeTagHelper.ProcessAsync (changes below depth limit)

  AdminController.Execute
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, RecipePermissions.ManageRecipes))
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ AdminController.GetRecipesAsync (depth limit)
  ├─ if (recipe == null)
  ├─ InvokeExtensions.InvokeAsync (depth limit)
  ├─ try
~ │  ├─ IRecipeExecutor.ExecuteAsync → RecipeExecutor.ExecuteAsync (changes below depth limit)
~ │  ├─ IShellHost.ReleaseShellContextAsync → ShellHost.ReleaseShellContextAsync (changes below depth limit)
  │  └─ ? _notifier.SuccessAsync
  ├─ catch (RecipeExecutionException e)
  ├─ catch (Exception e)
  └─ …

  AdminController.Index
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, RecipePermissions.ManageRecipes))
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ AdminController.GetRecipesAsync (depth limit)
  ├─ recipes.Select
  └─ …

  ResourceManagementOptionsConfiguration.Configure
~ └─ ResourceManagementOptionsConfiguration.BuildManifest (changes below depth limit)

  RolesMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing (depth limit)
  └─ if (!_shellSettings.IsInitializing())
~    └─ RolesMigrations.MigrateSystemRoles (changes below depth limit)

  AzureAISearchIndexSettingsMigrations.UpdateFrom1
  ├─ ShellSettingsExtensions.IsInitializing (depth limit)
  └─ ? ShellScope.AddDeferredTask
     ├─ …
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     ├─ AzureAISearchIndexSettingsMigrations.GetDefaultSearchFields (depth limit)
     └─ foreach (var indexObject in indexesObject)
~       ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
        ├─ IIndexNameProvider.GetFullIndexName
        ├─ if (properties is not null && properties.Count > 0)
        ├─ …
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ EntityExtensions.Put (depth limit)
~       ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
        └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Azure AI Search")

  IndexingMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing (depth limit)
  └─ ? ShellScope.AddDeferredTask
     ├─ …
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     ├─ IndexingMigrations.GetDefaultSearchFields (depth limit)
     ├─ foreach (var indexObject in indexesObject)
     │  ├─ IIndexNameProvider.GetFullIndexName
~    │  ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
     │  ├─ while (await indexProfileManager.FindByNameAsync(indexProfile.Name)is not null)
     │  ├─ EntityExtensions.GetOrCreate (depth limit)
     │  ├─ …
     │  ├─ EntityExtensions.GetOrCreate (depth limit)
     │  ├─ EntityExtensions.Put (depth limit)
~    │  ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
     │  └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Elasticsearch")
~    ├─ IndexingMigrations.UpdateLegacyAnalyzerNameAsync (changes below depth limit)
     └─ IndexingMigrations.EnsureDefaultSearchSiteSettingAsync (depth limit)

  IndexingMigrations.UpdateFrom1
  └─ ShellScope.AddDeferredTask (depth limit)
~    └─ IndexingMigrations.UpdateLegacyAnalyzerNameAsync (changes below depth limit)

  IndexingMigrations.Create
  ├─ ShellSettingsExtensions.IsInitializing (depth limit)
  └─ ? ShellScope.AddDeferredTask
     ├─ …
     ├─ ? JsonNode.Parse
     ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
     └─ foreach (var indexObject in indexesObject)
        ├─ IIndexNameProvider.GetFullIndexName
~       ├─ IIndexProfileManager.NewAsync → DefaultIndexProfileManager.NewAsync (changes below depth limit)
        ├─ while (await indexProfileManager.FindByNameAsync(indexProfile.Name)is not null)
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ …
        ├─ EntityExtensions.GetOrCreate (depth limit)
        ├─ EntityExtensions.Put (depth limit)
~       ├─ IIndexProfileManager.CreateAsync → DefaultIndexProfileManager.CreateAsync (changes below depth limit)
        └─ if (indexName == defaultSearchIndexName && defaultSearchProvider == "Lucene")

  SearchController.Search
  ├─ …
  ├─ ? containedItems.OrderBy(x => searchResult.ContentItemIds.IndexOf(x.ContentItemId)).Take
  ├─ ? containedItems.OrderBy(x => searchResult.ContentItemIds.IndexOf(x.ContentItemId)).Take(pager.PageSize).ToList
~ ├─ ShapeFactoryExtensions.PagerSlimAsync (changes below depth limit)
  └─ ? View

  Migrations.CreateAsync
  ├─ ContentDefinitionManagerExtensions.AlterPartDefinitionAsync (depth limit)
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

  Migrations.UpdateFrom1Async
~ └─ IRecipeMigrator.ExecuteAsync → RecipeMigrator.ExecuteAsync (changes below depth limit)

+ new SeoJSLocalizer

  AdminController.Index
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, SettingsPermissions.ManageGroupSettings, (o…
  ├─ ISiteService.GetSiteSettingsAsync → SiteService.GetSiteSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  ├─ IShapeExtensions.HasItemsInAnyZone (depth limit)
  ├─ if (!shape.HasItemsInAnyZone(ActionsZone))
  └─ …

  AdminController.IndexPost
  ├─ …
  ├─ if (!await _authorizationService.AuthorizeAsync(User, SettingsPermissions.ManageGroupSettings, (o…
  ├─ ISiteService.LoadSiteSettingsAsync → SiteService.LoadSiteSettingsAsync (depth limit)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ IShapeExtensions.HasItemsInAnyZone (depth limit)
  ├─ if (!shape.HasItemsInAnyZone(ActionsZone))
  └─ …

  SetupController.Index
  ├─ ISetupService.GetSetupRecipesAsync → SetupService.GetSetupRecipesAsync (depth limit)
~ ├─ SetupController.ShouldProceedWithTokenAsync (changes below depth limit)
  ├─ if (!await ShouldProceedWithTokenAsync(token))
  ├─ new SetupViewModel (depth limit)
  └─ …

  SetupController.IndexPOST
~ ├─ SetupController.ShouldProceedWithTokenAsync (changes below depth limit)
  ├─ if (!await ShouldProceedWithTokenAsync(model.Secret))
  ├─ ISetupService.GetSetupRecipesAsync → SetupService.GetSetupRecipesAsync (depth limit)
  ├─ …
  ├─ SetupController.GetPresetDatabaseProvider (depth limit)
  ├─ SetupController.HasPresetDatabaseConfiguration (depth limit)
  ├─ try
~ │  └─ ISetupService.SetupAsync → SetupService.SetupAsync (changes below depth limit)
  ├─ catch (Exception ex) when (!ex.IsFatal())
  ├─ if (setupContext.Errors.Count > 0)
  └─ …

  AdminController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new ShortcodeTemplateIndexViewModel (depth limit)
  ├─ shortcodeTemplates.Select
  └─ …

+ new ShortcodesJSLocalizer

  AdminController.Display
  ├─ …
  ├─ ISitemapManager.GetSitemapAsync → SitemapManager.GetSitemapAsync (depth limit)
  ├─ if (sitemap == null)
  ├─ foreach (var source in sitemap.SitemapSources)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ foreach (var factory in _sourceFactories)
  │  ├─ ISitemapSourceFactory.Create → SitemapSourceFactory<TSitemapSource>.Create (depth limit)
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ new DisplaySitemapViewModel
  └─ ? View

  AdminController.List
  ├─ …
  ├─ new ListSitemapViewModel (depth limit)
  ├─ results.Select
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ ? new SelectListItem
  └─ ? View

  SitemapIndexController.List
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new ListSitemapIndexViewModel (depth limit)
  ├─ results.Select
  └─ …

  SourceController.Create
  ├─ …
  ├─ if (_factories.FirstOrDefault(x => x.Name == model.SitemapSourceType) is not null)
  ├─ if (source == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  SourceController.Create
  ├─ …
  ├─ if (source == null)
  ├─ new CreateSourceViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  SourceController.Edit
  ├─ …
  ├─ if (sitemap == null)
  ├─ if (source == null)
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  ├─ ? _notifier.ErrorAsync
  └─ …

  SourceController.Edit
  ├─ …
  ├─ if (source == null)
  ├─ new EditSourceViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.Create
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (taxonomy == null)
  ├─ IContentManager.NewAsync → DefaultContentManager.NewAsync (depth limit)
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ if (taxonomyItemId == null)
  └─ …

  AdminController.Delete
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (taxonomy == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  └─ …

  AdminController.Edit
  ├─ if (string.IsNullOrWhiteSpace(taxonomyContentItemId) || string.IsNullOrWhiteSpace(taxonomyItemId))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (taxonomy == null)
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.BuildEditorAsync → ContentItemDisplayManager.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (!contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ else (!(!contentTypeDefinition.IsDraftable()))
~ │  └─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (taxonomy == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ …
  ├─ ContentExtensions.Weld (depth limit)
  ├─ ContentItemExtensions.Alter (depth limit)
~ ├─ IContentItemDisplayManager.UpdateEditorAsync → ContentItemDisplayManager.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ new JsonMergeSettings (depth limit)
  └─ …

  TagController.CreatePost
  ├─ …
  ├─ IContentDefinitionManager.GetTypeDefinitionAsync → ContentDefinitionManager.GetTypeDefinitionAsync (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (taxonomy == null)
  ├─ ContentItemExtensions.TryGet (depth limit)
  ├─ …
  ├─ ContentItemExtensions.Alter (depth limit)
  ├─ IContentManager.ValidateAsync → DefaultContentManager.ValidateAsync (depth limit)
  ├─ if (result.Succeeded)
~ │  └─ IContentManager.CreateAsync → DefaultContentManager.CreateAsync (changes below depth limit)
  ├─ else (!(result.Succeeded))
  ├─ if (!ModelState.IsValid)
  ├─ ContentItemExtensions.Alter (depth limit)
  ├─ ContentTypeExtensions.IsDraftable (depth limit)
  ├─ if (contentTypeDefinition.IsDraftable())
~ │  └─ IContentManager.PublishAsync → DefaultContentManager.PublishAsync (changes below depth limit)
  ├─ else (!(contentTypeDefinition.IsDraftable()))
  ├─ new CreatedTagViewModel
  └─ …

  TaxonomyTermsFilter.ProcessAsync
  ├─ if (input.Type == FluidValues.Object)
  ├─ else (!(input.Type == FluidValues.Object && input.ToObjectValue()is TaxonomyField field))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ foreach (var termContentItemId in termContentItemIds)
  └─ ? FluidValue.Create

+ new TaxonomiesJSLocalizer

  PreviewController.Render
  ├─ …
  ├─ else (!(string.IsNullOrEmpty(handle) || handle == _homeUrl))
  ├─ if (string.IsNullOrEmpty(contentItemId))
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  ├─ if (contentItem is null)
~ ├─ IContentItemDisplayManager.BuildDisplayAsync → ContentItemDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  TemplateController.Admin
~ └─ TemplateController.Index (changes below depth limit)

  AdminController.Create
  ├─ …
  ├─ AdminController.ApplyConfiguredDatabasePatterns (depth limit)
  ├─ if (ModelState.IsValid)
  ├─ if (ModelState.IsValid)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ ShellSettingsExtensions.AsUninitialized (depth limit)
  │  │  ├─ ShellSettingsExtensions.AsDisposable (depth limit)
~ │  │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  │  ├─ if (action == CreateAndSetupValue)
  │  │  └─ ? RedirectToAction
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ _recipeHarvesters.Select
  ├─ AdminController.GetFeatureProfilesAsync (depth limit)
  └─ …

  AdminController.Disable
  ├─ …
  ├─ if (!shellSettings.IsRunning())
  ├─ ShellSettingsExtensions.AsDisabled (depth limit)
~ ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  └─ ? RedirectToAction

  AdminController.Edit
  ├─ …
  ├─ AdminController.ApplyConfiguredDatabasePatterns (depth limit)
  ├─ if (ModelState.IsValid)
  ├─ if (ModelState.IsValid)
  │  ├─ try
  │  │  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
~ │  │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  │  └─ ? RedirectToAction
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
  ├─ if (shellSettings.IsUninitialized())
  └─ …

  AdminController.Enable
  ├─ …
  ├─ if (!shellSettings.IsDisabled())
  ├─ ShellSettingsExtensions.AsRunning (depth limit)
~ ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  └─ ? RedirectToAction

  AdminController.Index
  ├─ …
  ├─ if (model.BulkAction.ToString() == nameof(TenantsBulkAction.Remove) && !_tenantsOptions.TenantRem…
  ├─ IShellHost.GetAllSettings → ShellHost.GetAllSettings (depth limit)
  ├─ foreach (var tenantName in model.TenantNames ?? [])
  │  ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings (depth limit)
  │  ├─ case "Disable":
  │  │  ├─ ShellSettingsExtensions.IsDefaultShell (depth limit)
  │  │  ├─ if (shellSettings.IsDefaultShell())
  │  │  └─ else (!(shellSettings.IsDefaultShell()))
  │  │     ├─ ShellSettingsExtensions.IsRunning (depth limit)
  │  │     ├─ if (!shellSettings.IsRunning())
  │  │     └─ else (!(!shellSettings.IsRunning()))
  │  │        ├─ ShellSettingsExtensions.AsDisabled (depth limit)
~ │  │        └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  └─ case "Enable":
  │     ├─ ShellSettingsExtensions.IsDisabled (depth limit)
  │     ├─ if (!shellSettings.IsDisabled())
  │     └─ else (!(!shellSettings.IsDisabled()))
  │        ├─ ShellSettingsExtensions.AsRunning (depth limit)
~ │        └─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  └─ ? RedirectToAction

  AdminController.Index
  ├─ …
  ├─ if (!string.IsNullOrEmpty(options.Category))
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new AdminIndexViewModel (depth limit)
  ├─ ? allSettings.OrderBy(settings => settings.Name).GroupBy(settings => settings["Category"]).Where(group => !string.IsNullOrEmpty(group.Key)).Select
  └─ …

  AdminController.Reload
  ├─ …
  ├─ if (!_shellHost.TryGetSettings(id, out var shellSettings))
  ├─ ? Url.Action
~ ├─ IShellHost.ReloadShellContextAsync → ShellHost.ReloadShellContextAsync (changes below depth limit)
  └─ ? Redirect

  AdminController.Remove
  ├─ …
  ├─ ShellSettingsExtensions.IsRemovable (depth limit)
  ├─ if (!shellSettings.IsRemovable())
~ ├─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)
  ├─ if (!context.Success)
  ├─ else (!(!context.Success))
  └─ …

  FeatureProfilesController.Index
  ├─ …
  ├─ ? new RouteData
  ├─ if (!string.IsNullOrEmpty(options.Search))
~ ├─ ShapeFactoryExtensions.PagerAsync (changes below depth limit)
  ├─ new FeatureProfilesIndexViewModel (depth limit)
  ├─ featureProfiles.Select
  └─ …

  TenantApiController.Create
  ├─ …
  ├─ try
  ├─ catch (Exception ex) when (!ex.IsFatal())
  ├─ if (ModelState.IsValid)
  │  ├─ if (!model.IsNewTenant)
  │  ├─ try
  │  │  ├─ …
  │  │  ├─ ShellSettingsExtensions.AsUninitialized (depth limit)
  │  │  ├─ ShellSettingsExtensions.AsDisposable (depth limit)
~ │  │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  │  ├─ ShellHostExtensions.GetSettings (depth limit)
  │  │  ├─ TenantApiController.CreateSetupToken (depth limit)
  │  │  └─ …
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  └─ ? BadRequest

  TenantApiController.Disable
  ├─ …
  ├─ if (!shellSettings.IsRunning())
  ├─ ShellSettingsExtensions.AsDisabled (depth limit)
~ ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  └─ ? Ok

  TenantApiController.Edit
  ├─ …
  ├─ IShellHost.TryGetSettings → ShellHost.TryGetSettings (depth limit)
  ├─ if (!_shellHost.TryGetSettings(model.Name, out var shellSettings))
  ├─ if (ModelState.IsValid)
  │  ├─ try
  │  │  ├─ ShellSettingsExtensions.IsUninitialized (depth limit)
~ │  │  ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  │  │  └─ ? Ok
  │  └─ catch (Exception ex) when (!ex.IsFatal())
  └─ ? BadRequest

  TenantApiController.Enable
  ├─ …
  ├─ if (!shellSettings.IsDisabled())
  ├─ ShellSettingsExtensions.AsRunning (depth limit)
~ ├─ IShellHost.UpdateShellSettingsAsync → ShellHost.UpdateShellSettingsAsync (changes below depth limit)
  └─ ? Ok

  TenantApiController.Remove
  ├─ …
  ├─ ShellSettingsExtensions.IsRemovable (depth limit)
  ├─ if (!shellSettings.IsRemovable())
~ ├─ IShellRemovalManager.RemoveAsync → ShellRemovalManager.RemoveAsync (changes below depth limit)
  ├─ if (!context.Success)
  └─ ? Ok

  TenantApiController.Setup
  ├─ …
  ├─ else (!(string.IsNullOrEmpty(recipeName)))
  ├─ new SetupContext (depth limit)
~ ├─ ISetupService.SetupAsync → SetupService.SetupAsync (changes below depth limit)
  ├─ if (setupContext.Errors.Count > 0)
  └─ ? Ok

  AdminController.Disable
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ApplyTheme))
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
  ├─ if (feature == null)
~ ├─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Enable
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ApplyTheme))
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
  ├─ if (feature == null)
~ ├─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Index
  ├─ …
  ├─ if (currentSiteThemeExtensionInfo != null)
  ├─ IShellFeaturesManager.GetEnabledFeaturesAsync → ShellFeaturesManager.GetEnabledFeaturesAsync (depth limit)
~ ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).Where
  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).Where(f => { if (f.IsAlwaysEnabled || f.EnabledByDependencyOnly || !f.IsTheme()) { return false; }  var tags = f.Extension.Manifest.Tags.ToArray(); var isHidden = tags.Any(t => string.Equals(t, "hidden", StringComparison.OrdinalIgnoreCase)); if (isHidden) { return false; }  return true; }).Select
  └─ …

  AdminController.SetCurrentTheme
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, Permissions.ApplyTheme))
  ├─ else (!(string.IsNullOrEmpty(id)))
~ │  ├─ IShellFeaturesManager.GetAvailableFeaturesAsync → ShellFeaturesManager.GetAvailableFeaturesAsync (changes below depth limit)
  │  ├─ (await _shellFeaturesManager.GetAvailableFeaturesAsync()).FirstOrDefault
  │  ├─ if (feature == null)
  │  └─ else (!(feature == null))
  │     ├─ …
  │     ├─ else (!(isAdmin))
  │     ├─ IShellFeaturesManager.GetEnabledFeaturesAsync → ShellFeaturesManager.GetEnabledFeaturesAsync (depth limit)
  │     ├─ if (!isEnabled)
~ │     │  ├─ ShellFeaturesManagerExtensions.EnableFeaturesAsync (changes below depth limit)
  │     │  └─ ? _notifier.SuccessAsync
  │     └─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  ThemeService.DisableFeaturesAsync
~ └─ ThemeService.DisableFeaturesAsync (changes below depth limit)

  ThemeService.DisableThemeFeaturesAsync
  ├─ while (themeName != null)
  ├─ ISiteThemeService.GetSiteThemeNameAsync → SiteThemeService.GetSiteThemeNameAsync (depth limit)
  └─ while (themes.Count > 0)
     └─ if (themeId != currentTheme)
~       └─ ThemeService.DisableFeaturesAsync (changes below depth limit)

  ThemeService.EnableFeaturesAsync
~ └─ ThemeService.EnableFeaturesAsync (changes below depth limit)

  ThemeService.EnableThemeFeaturesAsync
  ├─ while (themeName != null)
  └─ while (themes.Count > 0)
~    └─ ThemeService.EnableFeaturesAsync (changes below depth limit)

~ new ResourceManagementOptionsConfiguration (body changed; visible calls unchanged)
  ├─ new ResourceManifest (depth limit)
  ├─ ResourceManifest.DefineScript (depth limit)
  └─ …

  AdminController.Create
  ├─ …
  ├─ if (rule == null)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePOST
  ├─ …
  ├─ if (rule == null)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  ├─ IShellReleaseManager.SuspendReleaseRequest → DefaultShellReleaseManager.SuspendReleaseRequest (depth limit)
  └─ …

  AdminController.Delete
  ├─ …
  ├─ if (rule == null)
  ├─ IRewriteRulesManager.DeleteAsync → RewriteRulesManager.DeleteAsync (depth limit)
~ ├─ IShellReleaseManager.RequestRelease → DefaultShellReleaseManager.RequestRelease (changes below depth limit)
  ├─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  AdminController.Edit
  ├─ …
  ├─ if (rule == null)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPOST
  ├─ …
  ├─ RewriteRule.Clone (depth limit)
  ├─ new RewriteRuleViewModel
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  ├─ IShellReleaseManager.SuspendReleaseRequest → DefaultShellReleaseManager.SuspendReleaseRequest (depth limit)
  └─ …

  AdminController.Index
  ├─ …
  ├─ IRewriteRulesManager.GetAllAsync → RewriteRulesManager.GetAllAsync (depth limit)
  ├─ new ListRewriteRuleViewModel
  ├─ foreach (var rule in rules)
  │  ├─ new RewriteRuleEntry
~ │  └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  ├─ ? new SelectListItem
  └─ ? View

  AccountController.Login
  ├─ …
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ new LoginForm
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  ├─ AccountBaseController.CopyTempDataErrorsToModelState (depth limit)
  └─ ? View

  AccountController.LoginPOST
  ├─ …
  ├─ if (loginSettings.DisableLocalLogin)
  ├─ new LoginForm
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? _loginFormEvents.InvokeAsync
  ├─ if (ModelState.IsValid)
  │  ├─ IUserService.GetUserAsync → UserService.GetUserAsync (depth limit)
  │  ├─ if (user != null)
  │  │  ├─ ? _signInManager.CheckPasswordSignInAsync
  │  │  ├─ if (result.Succeeded)
  │  │  │  ├─ foreach (var loginFormEvent in _loginFormEvents)
  │  │  │  ├─ ? _signInManager.PasswordSignInAsync
  │  │  │  └─ if (result.Succeeded)
  │  │  │     ├─ InvokeExtensions.InvokeAsync (depth limit)
~ │  │  │     └─ AccountBaseController.LoggedInActionResultAsync (changes below depth limit)
  │  │  ├─ if (result.RequiresTwoFactor)
  │  │  └─ if (result.IsLockedOut)
  │  ├─ else (!(user != null))
  │  └─ ? ModelState.AddModelError
  ├─ if (user == null)
  ├─ else (!(user == null))
  └─ …

  AdminController.Create
  ├─ …
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, UsersPermissions.EditUsers, user))
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.CreatePost
  ├─ …
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, UsersPermissions.EditUsers, user))
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ ? _userService.CreateUserAsync
  └─ …

  AdminController.Display
  ├─ …
  ├─ ? _authorizationService.AuthorizeAsync
  ├─ if (!await _authorizationService.AuthorizeAsync(User, UsersPermissions.ViewUsers, user))
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)
  └─ ? View

  AdminController.Edit
  ├─ …
  ├─ if (!editingOwnUser)
  ├─ if (!editingOwnUser && !await _authorizationService.AuthorizeAsync(User, UsersPermissions.EditUse…
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  AdminController.EditPost
  ├─ …
  ├─ if (!editingOwnUser)
  ├─ if (!editingOwnUser && !await _authorizationService.AuthorizeAsync(User, UsersPermissions.EditUse…
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (!ModelState.IsValid)
  ├─ ? _userManager.UpdateAsync
  └─ …

  AdminController.Index
  ├─ …
  ├─ ? new SelectListItem
  ├─ ? roleNames.OrderBy(roleName => roleName).Select
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  └─ ? View

  AdminController.IndexFilterPOST
  ├─ if (!string.Equals(options.SearchText, options.OriginalSearchText, StringComparison.OrdinalIgnore…
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? options.FilterResult.ToString
  ├─ ? options.RouteValues.TryAdd
  └─ …

  RegistrationController.Register
~ ├─ DisplayManagerExtensions.BuildEditorAsync (changes below depth limit)
  └─ ? View

  RegistrationController.RegisterPOST
  ├─ new RegisterUserForm
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ if (ModelState.IsValid)
  └─ ? View

  ResetPasswordController.ForgotPassword
  ├─ SiteServiceExtensions.GetSettingsAsync (depth limit)
  ├─ if (!(await _siteService.GetSettingsAsync<ResetPasswordSettings>()).AllowResetPassword)
~ ├─ DisplayManagerExtensions.BuildEditorAsync (changes below depth limit)
  └─ ? View

  ResetPasswordController.ForgotPasswordPOST
  ├─ …
  ├─ if (!site.TryGet<ResetPasswordSettings>(out var settings) || !settings.AllowResetPassword)
  ├─ new ForgotPasswordForm
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? _passwordRecoveryFormEvents.InvokeAsync
  ├─ if (ModelState.IsValid)
  └─ …

  ResetPasswordController.ResetPassword
  ├─ …
  ├─ if (string.IsNullOrWhiteSpace(code))
  ├─ new ResetPasswordForm
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → DisplayManager<TModel>.BuildEditorAsync (changes below depth limit)
  └─ ? View

  ResetPasswordController.ResetPasswordPOST
  ├─ …
  ├─ if (!(await _siteService.GetSettingsAsync<ResetPasswordSettings>()).AllowResetPassword)
  ├─ new ResetPasswordForm
~ ├─ IDisplayManager<TModel>.UpdateEditorAsync → DisplayManager<TModel>.UpdateEditorAsync (changes below depth limit)
  ├─ ? _passwordRecoveryFormEvents.InvokeAsync
  ├─ if (ModelState.IsValid)
  └─ …

  TwoFactorAuthenticationController.PopulateModelAsync
  ├─ …
  ├─ ? providers.Select
  ├─ ? providers.Select(providerName => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem(providerName, providerName)).ToList
  └─ foreach (var key in TwoFactorOptions.Providers)
     ├─ new TwoFactorMethod
~    └─ IDisplayManager<TModel>.BuildDisplayAsync → DisplayManager<TModel>.BuildDisplayAsync (changes below depth limit)

  ExternalAuthenticationMigrations.Create
  └─ ShellScope.AddDeferredTask (depth limit)
     ├─ …
     ├─ EntityExtensions.Put (depth limit)
     ├─ ISiteService.UpdateSiteSettingsAsync → SiteService.UpdateSiteSettingsAsync (depth limit)
     └─ if (enumValue is not null && enumValue != 1)
~       └─ ShellFeaturesManagerExtensions.DisableFeaturesAsync (changes below depth limit)

  UserEmailService.SendEmailAsync
~ ├─ IDisplayHelper.ShapeExecuteAsync → DisplayHelper.ShapeExecuteAsync (changes below depth limit)
  ├─ ? htmlContent.WriteTo
  └─ EmailServiceExtensions.SendAsync (depth limit)

  LogoutFormEventHandler.LoggedOutAsync
~ └─ IWorkflowManager.TriggerEventAsync → WorkflowManager.TriggerEventAsync (changes below depth limit)

  AdminController.BuildEditor
  ├─ …
  ├─ new WidgetMetadata
  ├─ ContentItemExtensions.Weld (depth limit)
~ ├─ ShapeFactoryExtensions.CreateAsync (changes below depth limit)
  ├─ new BuildEditorViewModel
  └─ ? View

~ new ResourceManagementOptionsConfiguration (body changed; visible calls unchanged)
  ├─ new ResourceManifest (depth limit)
  ├─ ResourceManifest.DefineStyle (depth limit)
  └─ …

  ActivityController.Create
  ├─ …
  ├─ new ActivityRecord
  ├─ IActivityIdGenerator.GenerateUniqueId → ActivityIdGenerator.GenerateUniqueId (depth limit)
~ ├─ IDisplayManager<TModel>.BuildEditorAsync → ActivityDisplayManager.BuildEditorAsync (changes below depth limit)
  ├─ new ActivityEditViewModel
  ├─ if (!activity.HasEditor)
~ │  └─ ActivityController.Create (changes below depth limit)
  └─ ? View

  WorkflowController.Details
  ├─ …
  ├─ if (workflow == null)
  ├─ IWorkflowTypeStore.GetAsync → WorkflowTypeStore.GetAsync (depth limit)
~ ├─ IWorkflowManager.CreateWorkflowExecutionContextAsync → WorkflowManager.CreateWorkflowExecutionContextAsync (changes below depth limit)
  ├─ workflowType.Activities.Select
  ├─ foreach (var activityContext in activityContexts)
~ │  └─ WorkflowController.BuildActivityDisplayAsync (changes below depth limit)
  ├─ foreach (var activityContext in activityContexts)
  ├─ new WorkflowViewModel
  └─ …

  WorkflowController.Restart
  ├─ …
  ├─ DistributedLockExtensions.TryAcquireWorkflowTypeLockAsync (depth limit)
  ├─ if (!locked)
  ├─ else (!(!locked))
  │  ├─ if (workflowType.IsSingleton)
  │  ├─ if (workflowType.IsSingleton && await _workflowStore.HasHaltedInstanceAsync(workflowType.Workflow…
  │  └─ else (!(workflowType.IsSingleton && await _workflowStore.HasHaltedInstanceAsync(workflowType.Work…
~ │     ├─ WorkflowManagerExtensions.RestartWorkflowAsync (changes below depth limit)
  │     └─ ? _notifier.SuccessAsync
  └─ ? RedirectToAction

  WorkflowTypeController.BuildActivityDisplay
~ ├─ IDisplayManager<TModel>.BuildDisplayAsync → ActivityDisplayManager.BuildDisplayAsync (changes below depth limit)
  └─ ? Url.Action

  WorkflowTypeController.Edit
  ├─ …
  ├─ ? _session.QueryIndex<WorkflowIndex>
  ├─ ? _session.QueryIndex<WorkflowIndex>(x => x.WorkflowTypeId == workflowType.WorkflowTypeId).CountAsync
  ├─ foreach (var activity in availableActivities)
~ │  └─ WorkflowTypeController.BuildActivityDisplay (changes below depth limit)
  ├─ foreach (var activityContext in activityContexts)
  ├─ foreach (var activityContext in activityContexts)
  └─ …

  HttpWorkflowController.Invoke
  ├─ …
  ├─ if (httpRequestActivity.ValidateAntiforgeryToken)
  ├─ if (httpRequestActivity.ValidateAntiforgeryToken && (!await _antiforgery.IsRequestValidAsync(Http…
  ├─ if (startActivity.IsStart)
  │  ├─ DistributedLockExtensions.TryAcquireWorkflowTypeLockAsync (depth limit)
  │  └─ if (locked)
  │     ├─ if (!(!workflowType.IsSingleton))
  │     └─ if (!workflowType.IsSingleton || !await _workflowStore.HasHaltedInstanceAsync(workflowType.Workfl…
~ │        └─ IWorkflowManager.StartWorkflowAsync → WorkflowManager.StartWorkflowAsync (changes below depth limit)
  ├─ else (!(startActivity.IsStart))
  │  ├─ IWorkflowStore.ListAsync → WorkflowStore.ListAsync (depth limit)
  │  ├─ if (!workflows.Any())
  │  └─ foreach (var workflow in workflows)
  │     └─ if (blockingActivity != null)
  │        ├─ DistributedLockExtensions.TryAcquireWorkflowLockAsync (depth limit)
  │        ├─ if (workflow.IsAtomic)
  │        └─ if (blockingActivity != null)
~ │           └─ IWorkflowManager.ResumeWorkflowAsync → WorkflowManager.ResumeWorkflowAsync (changes below depth limit)
  └─ HttpWorkflowController.GetWorkflowActionResult (depth limit)

  HttpWorkflowController.Trigger
  ├─ ISecurityTokenService.TryDecryptToken → SecurityTokenService.TryDecryptToken (depth limit)
  ├─ if (!_securityTokenService.TryDecryptToken<SignalPayload>(token, out var payload))
  ├─ if (!string.IsNullOrWhiteSpace(payload.WorkflowId))
  │  ├─ …
  │  ├─ if (signalActivities == null)
  │  ├─ DistributedLockExtensions.TryAcquireWorkflowLockAsync (depth limit)
  │  └─ if (locked)
  │     ├─ if (workflow.IsAtomic)
  │     └─ if (workflow != null)
  │        └─ foreach (var signalActivity in signalActivities)
~ │           └─ IWorkflowManager.ResumeWorkflowAsync → WorkflowManager.ResumeWorkflowAsync (changes below depth limit)
  ├─ else (!(!string.IsNullOrWhiteSpace(payload.WorkflowId)))
~ │  └─ IWorkflowManager.TriggerEventAsync → WorkflowManager.TriggerEventAsync (changes below depth limit)
  └─ HttpWorkflowController.GetWorkflowActionResult (depth limit)

  WorkflowActionFilter.OnActionExecutionAsync.AwaitedWorkflowEntries
  ├─ if (!workflowTypeEntries.Any() && !workflowEntries.Any())
~ └─ WorkflowActionFilter.ProcessWorkflowsAsync (changes below depth limit)

  WorkflowActionFilter.OnActionExecutionAsync.AwaitedWorkflowTypeEntries
  ├─ IWorkflowRouteEntries.GetWorkflowRouteEntriesAsync → WorkflowRouteEntries<TWorkflowRouteDocument>.GetWorkflowRouteEntriesAsync (depth limit)
  ├─ if (!workflowTypeEntries.Any() && !workflowEntries.Any())
~ └─ WorkflowActionFilter.ProcessWorkflowsAsync (changes below depth limit)

  new ResourceManagementOptionsConfiguration
  ├─ new ResourceManifest (depth limit)
  ├─ ResourceManifest.DefineScript (depth limit)
- ├─ ResourceDefinition.SetDependencies (depth limit)
  ├─ ResourceDefinition.SetUrl (depth limit)
  ├─ ResourceDefinition.SetCdn (depth limit)
  ├─ …
  ├─ ResourceDefinition.SetVersion (depth limit)
  ├─ ResourceManifest.DefineScript (depth limit)
+ ├─ ResourceDefinition.SetUrl (depth limit)
+ ├─ ResourceDefinition.SetVersion (depth limit)
+ ├─ ResourceManifest.DefineScript (depth limit)
+ ├─ ResourceDefinition.SetUrl (depth limit)
+ ├─ ResourceDefinition.SetVersion (depth limit)
+ ├─ ResourceManifest.DefineScript (depth limit)
  ├─ ResourceDefinition.SetDependencies (depth limit)
  ├─ ResourceDefinition.SetUrl (depth limit)
  └─ …

  HomeController.ServiceEndpoint
~ ├─ HomeController.DispatchAsync (changes below depth limit)
  ├─ if (methodResponse == null)
  ├─ MemoryStreamFactory.GetStream (depth limit)
  └─ …

  TaxonomyOrchardHelperExtensions.GetInheritedTermsAsync
  ├─ ? orchardHelper.HttpContext.RequestServices.GetService<IContentManager>
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ TaxonomyOrchardHelperExtensions.FindTermHierarchy (depth limit)

  TaxonomyOrchardHelperExtensions.GetTaxonomyTermAsync
  ├─ ? orchardHelper.HttpContext.RequestServices.GetService<IContentManager>
~ ├─ IContentManager.GetAsync → DefaultContentManager.GetAsync (changes below depth limit)
  └─ TaxonomyOrchardHelperExtensions.FindTerm (depth limit)
```
