from pathlib import Path
import hashlib
import json

root = Path.cwd()
hash_file = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
core = root / 'artifacts/receiver-context-stable-build/bin/Callrift.Core/debug/Callrift.Core.dll'
report = {'productionHead': '7cfb72b3a1f11a28fda028f9e5d32e16a4a97d07', 'coreSha256': hash_file(core)}
report['files'] = {str(p.relative_to(root)).replace('\\', '/'): hash_file(p) for p in sorted((root / 'artifacts/receiver-context-core').rglob('*.cs')) if 'obj' not in p.parts}
report['harnesses'] = {}
for directory in ['receiver-context-stable-cli-build/bin/Check/debug', 'receiver-context-stable-boundary-build/bin/Check/debug', 'receiver-context-reviewed-scenarios', 'receiver-context-reviewed-workspaces', 'receiver-context-stable-corpus/build/bin/Check/debug']:
    hashes = {name: hash_file(root / 'artifacts' / directory / name) for name in ['Callrift.Core.dll', 'msbuild/Callrift.Core.dll']}
    assert all(value == report['coreSha256'] for value in hashes.values()), directory
    report['harnesses'][directory] = hashes
report['tests'] = {str(p.relative_to(root)).replace('\\', '/'): hash_file(p) for p in (root / 'artifacts/receiver-context-cli-tests').glob('*.cs')}
(root / 'artifacts/receiver-context-stable-inputs.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
progress = root / 'artifacts/receiver-context-progress.md'
text = progress.read_text(encoding='utf-8')
text += '''
## Latest correction and validation

The first corrected Core (7524fffb) passed all 42 receiver fixture CLI checks and all 22 workspaces in 4m27s. Its two cycle CLI checks failed during fixture setup because GitFixture cannot create an unchanged second commit. No analyzer operation ran in those two cases. Adding a marker file fixes the fixture without changing the source under test.

A separate independently defined check then found a real false edit: adding an override on Right changed sealed Left.Entry through Base.Shared. Receiver sensitivity now depends on the virtual call itself, including when no alternate implementation exists yet. A dispatch reduced to its original declaration is normalized to the direct invocation. The check now preserves Left.Entry and still reports the open Base.Shared path as changed. Two CLI cases exercise this in both modes.

The latest frozen Core is 3863094b98fd0320d9031ae94441e8f8d08f1665861ab2329f302070cb4cfe95. Source and matching parent/worker hashes are receiver-context-stable-inputs.json. All 21 source fixtures pass; the receiver budget fixture passes; both corrected cycle CLI cases plus the durable receiver budget test pass in 6 seconds. The durable draft now has 47 cases: 42 receiver fixture views, two cycle checks, two sibling-override checks, and one state-budget check.

Active runs: session 67359 runs 46 CLI cases from the binary built before the cycle fixture setup correction. Two setup failures are expected; the three-case repeat verifies the corrected cycle and budget tests against the same Core. Session 34153 runs all 313 existing scenarios. Session 27219 repeats 22 workspaces. Session 53285 runs all 81 corpus views. The earlier 7524fffb corpus trial was deliberately stopped after discovering the sibling-override defect; it contributes no accepted output. The obsolete b25cb00a full-scenario session 50836 remains for additional failure discovery. No receiver snapshot has been accepted and the tracked tree remains clean.
'''
progress.write_text(text, encoding='utf-8', newline='\n')
goal = root / 'GOAL.md'
text = goal.read_text(encoding='utf-8').replace('2026-09-25 08:30 PDT: Generic checkpoint', '2026-09-25 08:26 PDT: Generic checkpoint')
text += '\n2026-09-25 08:34 PDT: Receiver work remains isolated. A new independent sibling-override fixture exposed a false unchanged-caller edit; the latest prototype fixes it and preserves the open base path as changed. Exact frozen Core 3863094b is now running 313 existing scenarios, 46 CLI checks, 22 workspaces, and 81 corpus views. The CLI binary still has two known fixture-setup failures; corrected cycle checks and the receiver state-budget check pass separately (three tests, 6s). All 21 source fixtures and the standalone state-budget check pass. No receiver source or snapshot was promoted. Full provenance and active sessions are in artifacts/receiver-context-progress.md.\n'
goal.write_text(text, encoding='utf-8', newline='\n')
print(json.dumps({'coreSha256': report['coreSha256'], 'harnesses': len(report['harnesses'])}))
