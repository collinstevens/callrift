from pathlib import Path
import hashlib
import json
import shutil

artifacts = Path.cwd() / 'artifacts'
for name in ['scenarios', 'corpus']:
    source = artifacts / f'dispatch-cycle-{name}'
    target = artifacts / f'constructor-exact-{name}'
    assert not target.exists()
    target.mkdir()
    for file in source.glob('*.cs'):
        shutil.copy2(file, target / file.name)
    shutil.copy2(source / 'Check.csproj', target / 'Check.csproj')
    (target / 'Snapshots').mkdir()
    for file in (source / 'Snapshots').glob('*.verified.txt'):
        shutil.copy2(file, target / 'Snapshots' / file.name)
    if name == 'scenarios':
        for file in (artifacts / 'constructor-integration-tests').glob('*.cs'):
            shutil.copy2(file, target / file.name)
        shutil.copy2(artifacts / 'ConstructorDiagnosticTests.cs', target / 'ConstructorDiagnosticTests.cs')
        shutil.copy2(Path.cwd() / 'tests/Callrift.Scenarios/GitCancellationTests.cs', target / 'GitCancellationTests.cs')
    else:
        shutil.copytree(source / 'real-world-cases', target / 'real-world-cases')
    inputs = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
    (artifacts / f'constructor-exact-{name}-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared 465 scenarios and 89 accepted corpus views; no constructor expectations accepted.')
