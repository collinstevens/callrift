from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path('artifacts')
directory = root / 'static-initialization-callback-scenarios'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['binaries'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sourcesAndSnapshots'].items():
    assert digest(directory / name) == expected, name
assert digest(root / 'static-six-view-review.json') == inputs['reviewSha256']
reports = list((root / (directory.name + '-results')).glob('*.trx'))
assert len(reports) == 1
trx = reports[0]
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '627'
assert counters['failed'] == counters['error'] == counters['aborted'] == '0'
results = [result.attrib for result in tree.findall('.//{*}UnitTestResult')]
assert len(results) == 627 and all(result['outcome'] == 'Passed' for result in results)
proof = {'core': inputs['binaries']['Callrift.Core.dll'], 'worker': inputs['binaries']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': results}
(root / (directory.name + '-terminal.json')).write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 627 passing scenarios and unchanged frozen candidate binaries, sources, snapshots, and review.')
