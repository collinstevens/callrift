from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
artifacts = root / 'artifacts'
assert 'Build succeeded.' in (artifacts / 'constructor-discovery-cli-build.log').read_text(encoding='utf-8-sig')
build = artifacts / 'constructor-discovery-cli/build/bin/Check/debug'
records = {}
for name, relative in [('baseline', 'dispatch-integrated-serial/build/bin/Check/release'), ('candidate', 'top-level-constructor-cli-tests/candidate-ready')]:
    source = artifacts / relative
    target = artifacts / 'constructor-discovery-cli' / (name + '-ready')
    assert not target.exists()
    shutil.copytree(build, target)
    shutil.copytree(source / 'msbuild', target / 'msbuild', dirs_exist_ok=True)
    for file in ['Callrift.Core.dll', 'Callrift.MSBuild.dll']:
        shutil.copy2(source / file, target / file)
    assert (target / 'Callrift.Core.dll').read_bytes() == (target / 'msbuild/Callrift.Core.dll').read_bytes()
    records[name] = {str(file.relative_to(target)): hashlib.sha256(file.read_bytes()).hexdigest() for file in target.rglob('*') if file.is_file()}
records['tests'] = {str(file.relative_to(root)): hashlib.sha256(file.read_bytes()).hexdigest() for file in [artifacts / 'ConstructorDiscoveryTests.cs', artifacts / 'constructor-aware-dispatch-tests/DispatchCardinalityTests.cs']}
(artifacts / 'constructor-discovery-cli-inputs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Frozen baseline and constructor-aware discovery validation with matching workers.')
