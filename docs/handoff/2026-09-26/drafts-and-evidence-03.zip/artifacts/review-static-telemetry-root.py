from pathlib import Path
import copy
import hashlib
import json
import sys

root = Path('artifacts')
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema

directory = root / 'static-initialization-callback-corpus/Snapshots'
name = 'polly-telemetry-source-msbuild-roots'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def document(path):
    text = path.read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def without_ids(value):
    if isinstance(value, list):
        return [without_ids(item) for item in value]
    if isinstance(value, dict):
        return {key: without_ids(item) for key, item in value.items() if key != 'id'}
    return value

before_path = directory / (name + '-json.verified.txt')
after_path = directory / (name + '-json.received.txt')
before, after = document(before_path), document(after_path)
jsonschema.validate(after, json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8')))
expected = copy.deepcopy(before)
removed = [node for node in expected['trees'] if node['label'] == 'new TelemetrySource']
assert len(removed) == 1 and removed[0]['change'] == 'added'
assert removed[0]['after']['symbolId'] == 'project:src/Polly.Extensions/Polly.Extensions.csproj@net8.0::Polly.Telemetry.TelemetrySource..ctor()'
expected['trees'] = [node for node in expected['trees'] if node not in removed]
assert without_ids(expected) == without_ids(after)
before_text_path = directory / (name + '.verified.txt')
after_text_path = directory / (name + '.received.txt')
before_text = before_text_path.read_text(encoding='utf-8-sig')
after_text = after_text_path.read_text(encoding='utf-8-sig')
removed_text = '\n+ new TelemetrySource\n+ └─ TelemetrySource.GetVersion\n'
assert before_text.count(removed_text) == 2
assert before_text.replace(removed_text, '') == after_text
plain = after_text.split('format: text\nexit: 0\nstdout:\n')[1].split('stderr:\n')[0]
markdown = after_text.split('format: md\nexit: 0\nstdout:\n```diff\n')[1].split('```\nstderr:\n')[0]
assert plain == markdown
evidence_path = root / 'static-polly-telemetry-path-evidence.json'
evidence = json.loads(evidence_path.read_text(encoding='utf-8'))
inputs_path = root / 'static-initialization-callback-corpus-inputs.json'
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
assert inputs['binaries']['Callrift.Core.dll'] == evidence['core']
assert inputs['binaries']['msbuild/Callrift.MSBuild.dll'] == evidence['worker']
for path in [after_path, after_text_path]:
    old = root / 'static-initialization-compatibility-corpus/Snapshots' / path.name
    assert digest(path) == digest(old)
proof = {'view': name, 'core': evidence['core'], 'worker': evidence['worker'], 'allOtherJsonFieldsUnchangedExceptNodeIds': True, 'textMarkdownOnlyRemoveConstructorRoot': True, 'sourceAndCliEvidenceSha256': digest(evidence_path), 'inputManifestSha256': digest(inputs_path), 'files': {path.name: digest(path) for path in [after_path, after_text_path]}, 'repeatStatus': 'pending'}
(root / 'static-telemetry-root-review.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed latest Polly restored automatic view: only standalone private constructor root removed; existing JSON/rendered behavior preserved.')
