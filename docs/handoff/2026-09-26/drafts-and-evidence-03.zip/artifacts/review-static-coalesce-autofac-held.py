from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import document, flatten, rendered, manifest, schema, jsonschema

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus/Snapshots'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for name in ['autofac-held-pipeline-source-roots']:
    autofac = name.startswith('autofac')
    case = manifest['autofac-held-pipeline' if autofac else 'ocelot-route-claims-keys']
    source_path = 'src/Autofac/Core/Resolving/BaseGenericResolveDelegateInvoker.cs' if autofac else 'src/DependencyInjection/ServiceCollectionExtensions.cs'
    line, column = (63, 30) if autofac else (71, 9)
    expression = '_methodParameters ??= GetDelegateParameters()' if autofac else 'configuration ??= services.FindConfiguration(null)'
    label = 'if (_methodParameters is null)' if autofac else 'if (configuration is null)'
    child_label = 'BaseGenericResolveDelegateInvoker.GetDelegateParameters' if autofac else 'ServiceCollectionExtensions.FindConfiguration'
    before_path = directory / (name + '-json.verified.txt')
    after_path = directory / (name + '-json.received.txt')
    before, after = document(before_path), document(after_path)
    jsonschema.validate(after, schema)
    branches = [node for node in flatten(after['trees']) if node['label'] == label]
    assert len(branches) == 1
    node = branches[0]
    assert node['kind'] == 'branch' and node['change'] == 'unchanged' and node['detail'] is None and node['omission'] is None
    assert len(node['children']) == 1 and node['children'][0]['label'] == child_label
    blobs = {}
    for side in ['before', 'after']:
        repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName']
        spec = case[side] + ':' + source_path
        source = subprocess.check_output(['git', '-C', repository, 'show', spec]).decode('utf-8-sig')
        assert source.splitlines()[line - 1][column - 1:column - 1 + len(expression)] == expression
        blobs[side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', spec], text=True).strip()
        location = {'path': source_path, 'startLine': line, 'startColumn': column, 'endLine': line, 'endColumn': column + len(expression)}
        assert node[side] == {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}

    def normalized(value, unwrap=False):
        if isinstance(value, list):
            return [item for node in value for item in (normalized(node['children'], True) if unwrap and isinstance(node, dict) and node.get('label') == label else [normalized(node, unwrap)])]
        if isinstance(value, dict):
            return {key: normalized(item, unwrap) for key, item in value.items() if key != 'id'}
        return value

    assert normalized(before) == normalized(after, True)
    before_text_path = directory / (name + '.verified.txt')
    after_text_path = directory / (name + '.received.txt')
    old_text, old_error = rendered(before_text_path)
    new_text, new_error = rendered(after_text_path)
    assert old_error == new_error
    old_line = '  ├─ ' + child_label + ('' if autofac else ' (depth limit)') + '\n'
    if autofac:
        prefix = '  BaseGenericResolveDelegateInvoker.ResolveWithParametersOrRegistration\n'
        assert old_text.count(prefix + old_line) == 1
        expected_text = old_text.replace(prefix + old_line, prefix + '  ├─ ' + label + '\n')
    else:
        prefix = '  ServiceCollectionExtensions.AddOcelotUsingBuilder\n'
        assert old_text.count(prefix + old_line) == 2
        expected_text = old_text.replace(prefix + old_line, prefix + '  ├─ ' + label + '\n', 1)
    assert expected_text == new_text
    records.append({
        'view': name,
        'snapshotDirectory': directory.as_posix(),
        'sourceRevisions': {side: case[side] for side in ['before', 'after']},
        'sourcePath': source_path,
        'sourceBlobs': blobs,
        'conditionalBranch': label,
        'schemaV1': True,
        'allOtherPriorJsonPreservedExceptTraversalIds': True,
        'textAndMarkdownExactExpectedEdits': True,
        'review': 'The immutable source invokes the RHS only when the cached parameters or supplied configuration is null. One new structural branch has the exact coalescing-expression span on both revisions. Unwrapping only that branch reproduces every prior JSON field except traversal IDs, including call evidence, dispatch targets, roots, diagnostics, ordering and omissions. Human output replaces the unconditional context call with its null guard. The unchanged child remains in JSON and is elided by the existing text context policy.',
        'files': {path.name: digest(path) for path in [after_path, after_text_path]},
        'baselineFiles': {path.name: digest(path) for path in [before_path, before_text_path]},
        'repeatStatus': 'pending'
    })
(root / 'static-coalesce-autofac-held-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed Autofac pipeline automatic view: one independently located conditional branch each; every other prior JSON field preserved.')
