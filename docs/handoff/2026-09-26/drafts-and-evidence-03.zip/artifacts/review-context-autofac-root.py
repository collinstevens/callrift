from pathlib import Path
import copy
import hashlib
import json
import re
import subprocess

root = Path.cwd()
folder = root / 'artifacts/generic-context-label-corpus/Snapshots'
stem = 'autofac-any-key-cache-source-roots'
def read(version):
    text = (folder / f'{stem}-json.{version}.txt').read_text(encoding='utf-8-sig')
    payload, error = text.split('stdout:\n', 1)[1].split('stderr:\n', 1)
    return json.loads(payload), error
old, old_error = read('verified')
new, new_error = read('received')
assert old_error == new_error
assert new == json.loads((root / 'artifacts/generic-context-reviewed-autofac-any-key-cache-source-roots.json').read_text(encoding='utf-8'))
symbol = 'source::Autofac.ResolutionExtensions.ResolveKeyed`1(global::Autofac.IComponentContext,object)'
def identity(node):
    return (node.get('after') or node['before'])['symbolId']
assert len(old['trees']) == 133 and len(new['trees']) == 134
assert symbol not in {identity(node) for node in old['trees']}
extra = [node for node in new['trees'] if identity(node) == symbol]
assert len(extra) == 1
added = extra[0]
assert added['change'] == 'unchanged' and len(added['children']) == 1
assert added['children'][0]['detail'] == 'changes below depth limit'
assert added['children'][0]['omission']['reason'] == 'depth-limit'
def nodes(trees):
    for tree in trees:
        yield tree
        yield from nodes(tree['children'])
candidate = copy.deepcopy(new)
candidate['trees'] = [node for node in candidate['trees'] if identity(node) != symbol]
all_nodes = list(nodes(candidate['trees']))
ids = {node['id']: 'n' + str(index) for index, node in enumerate(all_nodes)}
for node in all_nodes:
    node['id'] = ids[node['id']]
    if node['omission'] and node['omission'].get('referenceId'):
        node['omission']['referenceId'] = ids[node['omission']['referenceId']]
assert candidate == old
trace = [json.loads(line) for line in (root / 'artifacts/generic-context-autofac-roots.log').read_text(encoding='utf-8-sig').splitlines()]
assert len(trace[0]['RawCallers']) == 0 and trace[0]['OpenIsActive']
assert len(trace[1]['RawCallers']) == 4 and len(trace[1]['Contexts']) == 2
assert not trace[1]['OpenCallers'] and not trace[1]['OpenIsActive']
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
locations = []
for node in nodes(extra):
    for side, revision in [('before', trace[0]['Revision']), ('after', trace[1]['Revision'])]:
        for location in [node[side]['definition'], *node[side]['callSites']]:
            if location is None:
                continue
            data = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + location['path']])
            lines = data.decode('utf-8-sig').splitlines()
            assert 1 <= location['startLine'] <= location['endLine'] <= len(lines)
            for prefix in ['start', 'end']:
                assert 1 <= location[prefix + 'Column'] <= len(lines[location[prefix + 'Line'] - 1].encode('utf-16-le')) // 2 + 1
            locations.append({'revision': revision, 'location': location, 'sourceSha256': hashlib.sha256(data).hexdigest()})
before_text = (folder / (stem + '.verified.txt')).read_text(encoding='utf-8-sig')
after_text = (folder / (stem + '.received.txt')).read_text(encoding='utf-8-sig')
pattern = r'format: (text|md)\nexit: 0\nstdout:\n(.*?)stderr:\n(.*?)(?=\nformat: (?:text|md)\n|\Z)'
before_formats, after_formats = re.findall(pattern, before_text, re.S), re.findall(pattern, after_text, re.S)
assert len(before_formats) == len(after_formats) == 2
block = '  ResolutionExtensions.ResolveKeyed\n~ └─ ResolutionExtensions.ResolveKeyed (changes below depth limit)\n\n'
for before, after in zip(before_formats, after_formats):
    assert before[0] == after[0] and before[2] == after[2]
    assert after[1].count(block) == before[1].count(block) + 1
    assert after[1].replace(block, '', 1) == before[1]
files = []
for suffix in ['', '-json']:
    received = folder / (stem + suffix + '.received.txt')
    files.append({'received': received.relative_to(root).as_posix(), 'target': 'tests/Callrift.RealWorldCases/Snapshots/' + stem + suffix + '.verified.txt', 'sha256': hashlib.sha256(received.read_bytes()).hexdigest()})
report = {'view': stem, 'oldRoots': 133, 'newRoots': 134, 'oldNodes': len(all_nodes), 'newNodes': sum(1 for _ in nodes(new['trees'])), 'diagnostics': len(new['diagnostics']), 'onlyEarlierOpenRootAdded': True, 'existingJsonAndRenderedBodiesUnchanged': True, 'locations': locations, 'files': files, 'promoted': False}
(root / 'artifacts/generic-context-autofac-root-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: value for key, value in report.items() if key not in ['locations', 'files']}))
