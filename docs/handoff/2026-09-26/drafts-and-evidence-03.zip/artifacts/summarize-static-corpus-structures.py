from pathlib import Path
import collections
import copy
import json

root = Path('artifacts')
directory = root / 'static-initialization-compatibility-corpus/Snapshots'
inventory = json.loads((root / 'static-initialization-corpus-review-inventory.json').read_text(encoding='utf-8'))

def document(path):
    text = path.read_text(encoding='utf-8-sig')
    if path.name.startswith('serilog-msbuild.'):
        text = text[text.index('format: json'):]
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]

def clean(nodes):
    result = []
    for node in nodes:
        if node['label'].startswith('possible initialization of '):
            continue
        value = copy.deepcopy(node)
        value.pop('id', None)
        value['children'] = clean(value['children'])
        result.append(value)
    return result

records = []
for view in inventory['views']:
    name = view['view']
    prefix = name if name == 'serilog-msbuild' else name + '-json'
    before = document(directory / (prefix + '.verified.txt'))
    after = document(directory / (prefix + '.received.txt'))
    labels = collections.Counter(item['label'] for item in view['initializerOccurrences'])
    unchanged = clean(before['trees']) == clean(after['trees'])
    records.append({'view': name, 'case': view['caseId'], 'priorTreesUnchangedAfterRemovingInitializersAndIds': unchanged, 'rootsAdded': len(view['rootsAdded']), 'rootsRemoved': len(view['rootsRemoved']), 'diagnosticsAdded': len(view['addedDiagnostics']), 'diagnosticsRemoved': len(view['removedDiagnostics']), 'initializers': dict(labels)})
for record in records:
    print(json.dumps(record))
(root / 'static-corpus-structure-summary.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
