from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['core', 'worker']:
    source = root / ('static-initialization-callback-' + suffix)
    target = root / ('static-initialization-event-' + suffix)
    assert not target.exists()
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build'))
path = root / 'static-initialization-event-worker/Callrift.MSBuild.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-initialization-callback-core', 'static-initialization-event-core'), encoding='utf-8', newline='\n')
path = root / 'static-initialization-event-core/Analysis/CallCollector.cs'
text = path.read_text(encoding='utf-8-sig')
old = '''            case AssignmentExpressionSyntax assignment when StaticMember(assignment.Left) is not null:
                if (!assignment.IsKind(SyntaxKind.SimpleAssignmentExpression)) Walk(assignment.Left, result);
                Walk(assignment.Right, result);
                if (assignment.IsKind(SyntaxKind.SimpleAssignmentExpression)) AddStaticMember(assignment.Left, result);
                return;'''
new = '''            case AssignmentExpressionSyntax assignment when StaticMember(assignment.Left) is { } assignedMember:
                var readBeforeAssignment = !assignment.IsKind(SyntaxKind.SimpleAssignmentExpression) && assignedMember is not IEventSymbol;
                if (readBeforeAssignment) Walk(assignment.Left, result);
                Walk(assignment.Right, result);
                if (!readBeforeAssignment) AddStaticMember(assignment.Left, result);
                return;'''
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
target = root / 'static-event-order-cli'
assert not (target / 'Check.csproj').exists()
target.mkdir(exist_ok=True)
project = (root / 'static-initialization-identity-reviewed-cli/Check.csproj').read_text(encoding='utf-8-sig')
project = project[:project.index('    <Compile Include="StaticInitializationTests.cs"')] + '''    <Compile Include="StaticEventOrderTests.cs" />
''' + project[project.index('    <Compile Include="../../tests/Callrift.Scenarios/GitFixture.cs"'):]
(target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared isolated event-assignment ordering correction.')
