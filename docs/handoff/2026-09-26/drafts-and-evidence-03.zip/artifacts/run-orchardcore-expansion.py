from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path.cwd()
repository = Path('C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore')
cli = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug/callrift.dll'
inputs = json.loads((root / 'artifacts/receiver-context-delegate-inputs.json').read_text(encoding='utf-8'))
assert hashlib.sha256((cli.parent / 'Callrift.Core.dll').read_bytes()).hexdigest() == inputs['coreSha256']
assert hashlib.sha256((cli.parent / 'msbuild/Callrift.MSBuild.dll').read_bytes()).hexdigest() == inputs['workerSha256']
candidates = json.loads((root / 'artifacts/orchardcore-expansion-candidates.json').read_text(encoding='utf-8'))
env = dict(os.environ, NO_COLOR='1')
results = []
for candidate in candidates:
    views = [('source-roots', ['--depth', '1'])]
    if candidate['entries']:
        focus = ['--depth', '3', '--externals'] + [argument for entry in candidate['entries'] for argument in ['--entry', entry]]
        views.extend([('source-focused', focus), ('msbuild-focused', focus + ['--project', candidate['project'], '--framework', candidate['framework']])])
    for view, options in views:
        name = candidate['id'] + '-' + view
        output = root / 'artifacts' / (name + '.json')
        error = root / 'artifacts' / (name + '.err')
        command = ['dotnet', str(cli), 'diff', candidate['before'], candidate['after'], '--format', 'json', *options]
        started = time.monotonic()
        with output.open('w', encoding='utf-8', newline='\n') as stdout, error.open('w', encoding='utf-8', newline='\n') as stderr:
            process = subprocess.Popen(command, cwd=repository, env=env, stdout=stdout, stderr=stderr)
            try:
                code = process.wait(timeout=900)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
                process.wait()
                code = 124
        report = {'id': candidate['id'], 'view': view, 'exit': code, 'seconds': round(time.monotonic() - started, 2),
                  'coreSha256': inputs['coreSha256'], 'workerSha256': inputs['workerSha256'], 'accepted': False}
        if code == 0:
            document = json.loads(output.read_text(encoding='utf-8-sig'))
            report.update(roots=len(document['trees']), diagnostics=len(document['diagnostics']), truncated=document['truncated'])
        results.append(report)
        (root / 'artifacts/orchardcore-expansion-trials.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(json.dumps(report), flush=True)
