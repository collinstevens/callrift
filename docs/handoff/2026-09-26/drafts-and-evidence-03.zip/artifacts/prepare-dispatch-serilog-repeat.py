from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

artifacts = Path.cwd() / 'artifacts'
report = json.loads((artifacts / 'dispatch-serilog-review.json').read_text(encoding='utf-8'))
files = list((artifacts / 'dispatch-cycle-corpus-results').glob('*.trx'))
assert len(files) == 1
result = ET.parse(files[0]).getroot()
counters = result.find('.//{*}Counters').attrib
assert (int(counters['passed']), int(counters['failed']), int(counters['total'])) == (88, 1, 89)
failures = [test.attrib['testName'] for test in result.findall('.//{*}UnitTestResult') if test.attrib['outcome'] != 'Passed']
assert len(failures) == 1 and 'serilog-null-key' in failures[0]
assert report['reviewed']
for name, expected in report['snapshots'].items():
    source = artifacts / 'dispatch-cycle-corpus/Snapshots' / name
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    target = source.with_name(name.replace('.received.txt', '.verified.txt'))
    shutil.copy2(source, target)
print('Prepared only the independently reviewed Serilog expectations in the completed private corpus harness.')
