from pathlib import Path

root = Path.cwd()
target = root / 'artifacts/constructor-aware-dispatch-tests'
assert not target.exists()
target.mkdir()
source = (root / 'tests/Callrift.Scenarios/DispatchCardinalityTests.cs').read_text(encoding='utf-8')
old = '''            Assert.Single(roots);
            var nodes = Flatten(roots).ToArray();'''
new = '''            var root = Assert.Single(roots, node => node.GetProperty("label").GetString() == (name.EndsWith("root", StringComparison.Ordinal) ? change.Contract : "Entry.Run"));
            foreach (var other in roots.Where(node => node.GetProperty("id").GetString() != root.GetProperty("id").GetString()))
            {
                Assert.Contains(other.GetProperty("change").GetString(), new[] { "added", "removed" });
                var side = other.GetProperty("after").ValueKind == JsonValueKind.Object ? other.GetProperty("after") : other.GetProperty("before");
                Assert.EndsWith("..ctor()", side.GetProperty("symbolId").GetString());
            }
            var nodes = Flatten([root]).ToArray();'''
assert source.count(old) == 1
source = source.replace(old, new).replace('Assert.Equal(roots[0].GetProperty("id").GetString(),', 'Assert.Equal(root.GetProperty("id").GetString(),')
(target / 'DispatchCardinalityTests.cs').write_text(source, encoding='utf-8', newline='\n')
print('Scoped dispatch preservation checks to the automatically discovered caller and retained checks on additional constructor roots.')
