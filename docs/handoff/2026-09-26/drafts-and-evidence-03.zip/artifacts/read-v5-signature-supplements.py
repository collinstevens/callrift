from pathlib import Path
import json,subprocess,re,sys
sys.stdout.reconfigure(encoding="utf-8")
rs=json.loads(Path("artifacts/declaration-signatures-v5-snapshot-differences.json").read_text(encoding="utf-8"))["signatures"]
done=set(json.loads(Path("artifacts/declaration-signatures-v5-corpus-declaration-review.json").read_text(encoding="utf-8"))["reviewedSignatureIds"])
manifest=json.loads(Path("real-world-cases/manifest.json").read_text(encoding="utf-8"))
batch=[r for r in rs if Path(r["witness"]["file"]).name.startswith(sys.argv[1]+"-") and r["id"] not in done][:int(sys.argv[2])]
seen=set()
for r in batch:
    isctor=bool(re.search(r"\.([\w]+)\.\1\(\)",r["after"])) and r["after"].startswith("private static ")
    if not isctor and "[within " not in r["after"] and " readonly " not in r["after"]:continue
    w=r["witness"];c=max((c for c in manifest if Path(w["file"]).name.startswith(c["id"]+"-")),key=lambda c:len(c["id"]))
    side="before" if w["path"].endswith("/before/signature") else "after"
    key=(c[side],w["definition"]["path"],isctor)
    if key in seen:continue
    seen.add(key)
    lines=subprocess.check_output(["git","-C","C:/Users/Admin/AppData/Local/Callrift/real-world-cases/"+c["cacheName"],"show",c[side]+":"+w["definition"]["path"]]).decode("utf-8-sig").splitlines()
    print(r["id"],c[side],w["definition"]["path"])
    for i,line in enumerate(lines):
        if line.strip().startswith(("/","*")):continue
        if (isctor and "static " in line) or (not isctor and re.search(r"\b(class|interface|struct)\b",line)):
            if isctor:
                print(chr(10).join(lines[i:i+4]))
            else:
                header=[]
                for declaration_line in lines[i:i+60]:
                    header.append(declaration_line)
                    if declaration_line.strip() == "{" or declaration_line.rstrip().endswith(";"):break
                print(chr(10).join(header))
