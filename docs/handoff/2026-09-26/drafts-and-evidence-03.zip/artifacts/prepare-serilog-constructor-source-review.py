from pathlib import Path
import copy
import hashlib
import json

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'constructor-exact-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
calls = []
reports = []

def decode(content):
    index = content.index('{')
    document, count = json.JSONDecoder().raw_decode(content[index:])
    return document, content[:index], content[index + count:]

def all_nodes(nodes):
    for node in nodes:
        yield node
        yield from all_nodes(node['children'])

for view in ['serilog-alignment-guard', 'serilog-allocation', 'serilog-extra-arguments', 'serilog-msbuild']:
    case = next(case for case in manifest if case['id'] == ('serilog-alignment-guard' if view == 'serilog-msbuild' else view))
    suffix = '' if view == 'serilog-msbuild' else '-json'
    before_file = directory / (view + suffix + '.verified.txt')
    after_file = directory / (view + suffix + '.received.txt')
    original, prefix, suffix_text = decode(before_file.read_text(encoding='utf-8-sig'))
    actual, new_prefix, new_suffix = decode(after_file.read_text(encoding='utf-8-sig'))
    expected_text_change = '+ │  │     ├─ new MessageTemplateToken\n'
    if view == 'serilog-msbuild':
        assert new_prefix.replace(expected_text_change, '') == prefix and new_prefix.count(expected_text_change) == 2
    else:
        assert prefix == new_prefix
    assert suffix_text == new_suffix
    reviewed = copy.deepcopy(actual)
    added = []
    def strip(nodes, parent=None):
        result = []
        for node in nodes:
            side = node.get('after') or node.get('before')
            if node['label'] in ['new MessageTemplateToken', 'new LogEventPropertyValue']:
                assert parent is not None
                expected_parents = ['new TextToken', 'new PropertyToken'] if node['label'] == 'new MessageTemplateToken' else ['new ScalarValue']
                assert parent['label'] in expected_parents
                assert node['change'] == parent['change']
                assert not node['children'] and node['kind'] == 'call'
                type_name = 'Serilog.Parsing.MessageTemplateToken' if node['label'] == 'new MessageTemplateToken' else 'Serilog.Events.LogEventPropertyValue'
                for revision_side in ['before', 'after']:
                    value = node[revision_side]
                    assert (value is None) == (parent[revision_side] is None)
                    if value is None:
                        continue
                    identity = ('project:src/Serilog/Serilog.csproj@net10.0::' if view == 'serilog-msbuild' else 'source::') + type_name + '..ctor()'
                    assert value['symbolId'] == identity and value['targetIds'] == [identity]
                    assert value['signature'] == type_name + '.' + type_name.rsplit('.', 1)[1] + '() -> void'
                    assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['candidates'] == []
                    assert len(value['callSites']) == 1
                    assert value['callSites'][0] == parent[revision_side]['definition']
                    calls.append({'view': view, 'revision': case[revision_side], 'type': type_name, 'definition': value['definition'], 'callSite': value['callSites'][0]})
                added.append(node)
            else:
                node['children'] = strip(node['children'], node)
                result.append(node)
        return result
    reviewed['trees'] = strip(reviewed['trees'])
    old_nodes = list(all_nodes(original['trees']))
    current_nodes = list(all_nodes(actual['trees']))
    assert [node['id'] for node in current_nodes] == ['n' + str(index) for index in range(len(current_nodes))]
    stripped_nodes = list(all_nodes(reviewed['trees']))
    assert len(old_nodes) == len(stripped_nodes)
    for old, current in zip(old_nodes, stripped_nodes):
        current['id'] = old['id']
    assert reviewed == original, view
    assert len(added) == {'serilog-alignment-guard': 12, 'serilog-allocation': 4, 'serilog-extra-arguments': 2, 'serilog-msbuild': 12}[view]
    if view != 'serilog-msbuild':
        text_path = directory / (view + '.received.txt')
        if view == 'serilog-alignment-guard':
            old_text = (directory / (view + '.verified.txt')).read_text(encoding='utf-8-sig')
            new_text = text_path.read_text(encoding='utf-8-sig')
            assert new_text.count(expected_text_change) == 2 and new_text.replace(expected_text_change, '') == old_text
        else:
            assert not text_path.exists()
    reports.append({'view': view, 'addedBaseCalls': len(added), 'allOtherJsonExactAfterSequentialIdRenumbering': True,
        'renderedDelta': 'One added base constructor under the new guard, in text and Markdown.' if view in ['serilog-alignment-guard', 'serilog-msbuild'] else 'Text and Markdown unchanged.',
        'falseDepthMarkersPendingCorrection': sum(node['omission'] is not None for node in added), 'sha256': hashlib.sha256(after_file.read_bytes()).hexdigest()})
(artifacts / 'constructor-base-source-review/serilog.json').write_text(json.dumps({'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/serilog', 'calls': calls}, indent=2) + '\n', encoding='utf-8', newline='\n')
(artifacts / 'constructor-serilog-subtree-review.json').write_text(json.dumps({'productionPromoted': False, 'originalSymbolReviewPending': True, 'views': reports}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'views': reports, 'sourceCallOccurrences': len(calls)}))
