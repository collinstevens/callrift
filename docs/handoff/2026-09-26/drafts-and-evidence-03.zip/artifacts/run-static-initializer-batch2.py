from pathlib import Path
import json
import subprocess

root = Path('artifacts/static-initializer-source-batch2-review')
for name in json.loads((root / 'jobs.json').read_text(encoding='utf-8')):
    with (root / (name + '.log')).open('w', encoding='utf-8', newline='\n') as output:
        result = subprocess.run(['dotnet', str(root / 'ready/Check.dll'), str(root / (name + '.json')), str(root / (name + '-report.json'))], stdout=output, stderr=subprocess.STDOUT, timeout=660)
    report_path = root / (name + '-report.json')
    if report_path.exists():
        report = json.loads(report_path.read_text(encoding='utf-8'))
        print(json.dumps({'case': name, 'exitCode': result.returncode, 'passed': report['passed'], 'pending': report['pending']}), flush=True)
    else:
        print(json.dumps({'case': name, 'exitCode': result.returncode, 'reportMissing': True}), flush=True)
