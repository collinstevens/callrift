from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
sources = {}
for suffix, source in [('core', Path('src/Callrift.Core')), ('worker', Path('src/Callrift.MSBuild'))]:
    target = root / ('declaration-signatures-' + suffix)
    assert not target.exists()
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj'))
    for path in target.rglob('*'):
        if path.is_file():
            sources[path.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
project = root / 'declaration-signatures-worker/Callrift.MSBuild.csproj'
project.write_text(project.read_text(encoding='utf-8-sig').replace('../Callrift.Core/', '../declaration-signatures-core/'), encoding='utf-8', newline='\n')
probe = root / 'declaration-signatures-format-probe'
probe.mkdir()
shutil.copy2(root / 'member-signature-format-audit/Program.cs', probe / 'Program.cs')
project = probe / 'Check.csproj'
project.write_text((root / 'member-signature-format-audit/Check.csproj').read_text(encoding='utf-8-sig').replace('static-coalesce-initialization-cli-tests/candidate-ready', 'declaration-signatures-worker/build/bin/Callrift.MSBuild/debug'), encoding='utf-8', newline='\n')
program = probe / 'Program.cs'
program.write_text(program.read_text(encoding='utf-8-sig').replace('artifacts/member-signature-format-audit.json', 'artifacts/declaration-signatures-format-probe.json'), encoding='utf-8', newline='\n')
(root / 'declaration-signatures-original-sources.json').write_text(json.dumps(sources, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared isolated declaration-signature sources and compiler probe.')
