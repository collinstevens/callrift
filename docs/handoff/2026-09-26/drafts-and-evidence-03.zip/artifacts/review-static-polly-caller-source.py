import collections
import json
import re
import subprocess
from static_review_support import root, manifest, flatten, prior_fields_and_diagnostics, initializer_evidence

case_id = 'polly-caller-cancellation'
case = manifest[case_id]
key, proven = initializer_evidence(case_id)
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/polly'
expectations = {
    'src/Polly.Core/Utils/ExceptionUtilities.cs': ['private static readonly FieldInfo StackTraceString = typeof(Exception).GetField', 'private static readonly Type TraceFormat = typeof(StackTrace).GetNestedType', 'private static readonly MethodInfo TraceToString = typeof(StackTrace).GetMethod', 'private static readonly object[] TraceToStringArgs = new[] { Enum.GetValues(TraceFormat).GetValue(0) };'],
    'src/Polly.Core/ResilienceContextPool.cs': ['public static ResilienceContextPool Shared { get; } = new SharedPool();'],
    'src/Polly.Core/ResiliencePipeline.cs': ['public static readonly ResiliencePipeline Empty = new(PipelineComponent.Empty, DisposeBehavior.Ignore, null);']}
blobs = {}
for path, snippets in expectations.items():
    ids = []
    for side in ['before', 'after']:
        revision = case[side]
        text = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
        assert all(snippet in text for snippet in snippets)
        ids.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
    assert ids[0] == ids[1]
    blobs[path] = ids[0]

def focused_render(old, new):
    additions = ['+    │     ├─ possible initialization of ExceptionUtilities\n', '+    │     │  └─ initialization of ExceptionUtilities (depth limit)\n']
    for line in additions:
        assert new.count(line) == 1
        new = new.replace(line, '')
    assert new == old

def roots_render(old, new):
    normalized = lambda text: [re.sub(r'^[ │├└─]*', '', line) for line in text.splitlines() if 'possible initialization of ' not in line]
    left, right = normalized(old), normalized(new)
    index = right.index('ResiliencePipelineBenchmark.ExecuteOutcomeAsync')
    assert right[index + 1] == '…'
    right.pop(index + 1)
    assert left == right

reviews = []
for suffix, render_check, counts in [('source-focused', focused_render, {'possible initialization of ExceptionUtilities': 1}), ('source-roots', roots_render, {'possible initialization of ResilienceContextPool': 5, 'possible initialization of ResiliencePipeline': 1})]:
    before, after, review = prior_fields_and_diagnostics(case_id + '-' + suffix, stdout_check=render_check)
    branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
    assert dict(collections.Counter(node['label'] for node in branches)) == counts
    locations = []
    for branch in branches:
        change = 'added' if suffix == 'source-focused' else 'unchanged'
        assert branch['change'] == change and branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == change and initializer['children'] == []
        assert initializer['omission'] == {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
        for side in ['before', 'after']:
            value = initializer[side]
            structural = branch[side]
            if value is None:
                assert side == 'before' and suffix == 'source-focused' and structural is None
                continue
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural'
            assert structural['symbolId'] is None and structural['targetIds'] == [] and structural['definition'] is None and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source'
            assert value['targetIds'] == [value['symbolId']]
            check = {'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}
            evidence = proven[key(check)]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
    review.update(initializerBranches=len(branches), sourceLocations=locations, unchangedSourceBlobs=blobs, review='The source-only ExceptionUtilities conditional branch retains unresolved reflection calls beneath its depth marker. Pool.Shared and Pipeline.Empty each have source constructor work beneath their depth markers. Existing trees, ordering, identities, diagnostics, and omissions are preserved outside those additions. Rendered context hides one unchanged pool initializer behind ellipsis; every other normalized line is preserved.')
    reviews.append(review)
(root / 'static-polly-caller-source-views-review.json').write_text(json.dumps({'views': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed both caller-cancellation source views: seven initializer branches and 38 independently supported added diagnostics.')
