import collections
import json
import subprocess
from static_review_support import root, manifest, digest, flatten, prior_fields_and_diagnostics, initializer_evidence

case_id = 'orchardcore-elasticsearch-authorization'
case = manifest[case_id]
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
permission_path = 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Security/Permissions/Permission.cs'
elastic_path = 'src/OrchardCore/OrchardCore.Elasticsearch.Core/ElasticsearchPermissions.cs'
index_path = 'src/OrchardCore/OrchardCore.Indexing.Core/IndexingPermissions.cs'
options_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/JOptions.cs'
memory_path = 'src/OrchardCore/OrchardCore.Abstractions/MemoryStreamFactory.cs'
convert_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/JConvert.cs'
controller_path = 'src/OrchardCore.Modules/OrchardCore.Elasticsearch/Controllers/AdminController.cs'
blobs = {}
for path in [permission_path, elastic_path, index_path, options_path, memory_path, convert_path, controller_path]:
    versions = []
    texts = []
    for side in ['before', 'after']:
        revision = case[side]
        source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
        texts.append(source)
        if path == elastic_path:
            assert [line.strip() for line in source.splitlines() if 'static readonly' in line] == ['public static readonly Permission ManageElasticIndexes = new("ManageElasticIndexes", "Manage Elasticsearch Indexes", [IndexingPermissions.ManageIndexes]);', 'public static readonly Permission QueryElasticApi = new("QueryElasticsearchApi", "Query Elasticsearch Api", [ManageElasticIndexes]);']
        elif path == index_path:
            assert source.index('Permission QuerySearchIndex') < source.index('Permission ManageIndexes') < source.index('Permission s_indexPermissionTemplate') < source.index('ConcurrentDictionary<string, Permission> s_permissions')
        elif path == memory_path:
            assert 'private static readonly RecyclableMemoryStreamManager s_manager = new();' in source
            assert 'var options = new RecyclableMemoryStreamManager.Options' in source and 's_manager = new RecyclableMemoryStreamManager(options);' in source
        elif path == convert_path:
            assert source.splitlines()[20].strip() == '=> JsonSerializer.Deserialize<TValue>(json, options ?? JOptions.Default);'
        versions.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
    if path != controller_path:
        assert versions[0] == versions[1], path
    else:
        authorization = 'if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.ManageElasticIndexes))'
        assert texts[1].count(authorization) == texts[0].count(authorization) + 2
        assert [texts[1].splitlines()[line - 1].strip() for line in [68, 94]] == [authorization, authorization]
        assert texts[0].splitlines()[134].strip() == authorization
    blobs[path] = dict(zip(['before', 'after'], versions))
body_report_path = root / 'static-initializer-body-source-review/orchard-permissions-report.json'
body_report = json.loads(body_report_path.read_text(encoding='utf-8'))
assert body_report['failed'] == 0
body_key = lambda value: json.dumps({name: value[name] for name in ['revision', 'definition', 'signature', 'callSites']}, sort_keys=True)
body_records = {body_key(record['check']): record for record in body_report['records']}
key, proven = initializer_evidence(case_id)
depth = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
reviews = []
for suffix in ['source-focused', 'msbuild-focused', 'source-roots']:
    name = case_id + '-' + suffix
    focused = suffix.endswith('focused')
    def prior(value):
        if focused:
            targets = [node for node in flatten(value['trees']) if node['label'] == 'JConvert.DeserializeObject']
            assert len(targets) == 1 and len(targets[0]['children']) == 1
            assert targets[0]['children'][0]['label'] == 'JsonSerializer.Deserialize<TValue>'
            side = {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [{'path': convert_path, 'startLine': 21, 'startColumn': 53, 'endLine': 21, 'endColumn': 80}], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}
            targets[0]['children'].insert(0, {'id': None, 'kind': 'branch', 'change': 'unchanged', 'label': 'if (options is null)', 'detail': None, 'before': side, 'after': side, 'children': [], 'omission': None})
        return value
    def stdout(old):
        if not focused:
            insertion = '+ ├─ possible initialization of ElasticsearchPermissions\n+ │  └─ initialization of ElasticsearchPermissions (depth limit)\n'
            for label in ['IndexInfo', 'QueryIndex']:
                header = '  AdminController.' + label + '\n'
                assert old.count(header) == 1
                old = old.replace(header, header + insertion)
            return old
        first = '+ ├─ possible initialization of ElasticsearchPermissions\n+ │  └─ initialization of ElasticsearchPermissions\n+ │     ├─ possible initialization of IndexingPermissions\n+ │     │  └─ initialization of IndexingPermissions (depth limit)\n+ │     └─ new Permission ×2 (depth limit)\n'
        second = '+ ├─ possible initialization of ElasticsearchPermissions\n+ │  └─ initialization of ElasticsearchPermissions ↑ as above\n'
        old = old.replace('  AdminController.IndexInfo\n', '  AdminController.IndexInfo\n' + first).replace('  AdminController.QueryIndex\n', '  AdminController.QueryIndex\n' + second)
        assert old.endswith('  └─ …\n')
        call = '? _authorizationService.AuthorizeAsync' if suffix.startswith('source') else 'AuthorizationServiceExtensions.AuthorizeAsync'
        return old.removesuffix('  └─ …\n') + '  ├─ …\n  ├─ string.IsNullOrWhiteSpace\n  ├─ else (!(string.IsNullOrWhiteSpace(query)))\n  └─ AdminController.Query\n-    ├─ possible initialization of ElasticsearchPermissions\n-    │  └─ initialization of ElasticsearchPermissions (depth limit)\n     ├─ ' + call + '\n     ├─ if (!await _authorizationService.AuthorizeAsync(User, ElasticsearchPermissions.ManageElasticIndex…\n     └─ …\n'
    before, after, review = prior_fields_and_diagnostics(name, prior_json_transform=prior, stdout_transform=stdout)
    branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
    expected = {('possible initialization of ElasticsearchPermissions', 'added'): 2, ('possible initialization of JOptions', 'unchanged'): 1}
    if focused:
        expected.update({('possible initialization of ElasticsearchPermissions', 'removed'): 1, ('possible initialization of IndexingPermissions', 'added'): 2, ('possible initialization of MemoryStreamFactory', 'unchanged'): 1, ('possible initialization of JOptions', 'unchanged'): 2})
    assert collections.Counter((node['label'], node['change']) for node in branches) == expected
    locations = []
    for branch in branches:
        assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
        initializer = branch['children'][0]
        assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == branch['change']
        expanded = focused and branch['label'] == 'possible initialization of ElasticsearchPermissions' and branch['change'] == 'added'
        assert initializer['omission'] == (None if expanded else depth)
        if expanded:
            assert [node['label'] for node in initializer['children']] == ['possible initialization of IndexingPermissions', 'new Permission', 'new Permission']
            for index, child in enumerate(initializer['children'][1:]):
                assert child['change'] == 'added' and child['before'] is None and child['children'] == [] and child['omission'] == depth
                value = child['after']
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']]
                assert value['callSites'][0]['startLine'] == [8, 10][index]
                assert body_records[body_key({'revision': case['after'], **value})]['passed']
        else:
            assert initializer['children'] == []
        for side in ['before', 'after']:
            value = initializer[side]
            structural = branch[side]
            if value is None:
                assert structural is None
                continue
            assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['symbolId'] is None and structural['callSites'] == value['callSites']
            assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
            evidence = proven[key({'revision': case[side], **value})]
            assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
            locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
    review.update(initializerBranches=len(branches), immutableSourceBlobs=blobs, sourceLocations=locations, permissionBindings={'report': body_report_path.as_posix(), 'sha256': digest(body_report_path)}, review='Added authorization reads move ElasticsearchPermissions initialization ahead of the preexisting Query call. The formerly first read in Query remains a removed initialization possibility. IndexingPermissions initializes before constructing the two Elasticsearch permission objects; self-field access does not recurse. All source constructor work under the chosen boundary retains depth omissions. Conditional default JSON options introduce the unchanged null-options branch. Both full rendered trees were checked, including repeated initializer references and newly visible unchanged context. No other prior JSON fields or roots change.')
    reviews.append(review)
(root / 'static-orchard-elastic-three-review.json').write_text(json.dumps({'views': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed three Elasticsearch views and19 initializer branches; repeats pending.')
