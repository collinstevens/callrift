from pathlib import Path
import copy
import hashlib
import json
import subprocess

root = Path.cwd()
artifacts = root / 'artifacts'
directory = artifacts / 'constructor-exact-corpus/Snapshots'
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
repo = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
source_path = 'src/Autofac/Builder/BuildCallbackService.cs'
def read(path):
    text = path.read_text(encoding='utf-8-sig')
    index = text.index('{')
    value, count = json.JSONDecoder().raw_decode(text[index:])
    return value, text[:index], text[index + count:]
def nodes(items):
    for node in items:
        yield node
        yield from nodes(node['children'])
records = []
blobs = {}
sources = {}
for name in ['autofac-any-key-cache', 'autofac-held-pipeline', 'autofac-multi-service-registration', 'autofac-pipeline-callbacks', 'autofac-service-key-inheritance']:
    case = next(case for case in manifest if case['id'] == name)
    view = name + '-msbuild-roots'
    original, prefix, suffix = read(directory / (view + '-json.verified.txt'))
    received, new_prefix, new_suffix = read(directory / (view + '-json.received.txt'))
    assert prefix == new_prefix and suffix == new_suffix
    expected = copy.deepcopy(original)
    changed = 0
    for node in nodes(expected['trees']):
        for side in ['before', 'after']:
            value = node.get(side)
            if value and value['symbolId'] == 'project:src/Autofac/Autofac.csproj@net10.0::Autofac.Builder.BuildCallbackService..ctor()':
                assert value['signature'] == 'Autofac.Builder.BuildCallbackService.BuildCallbackService()'
                assert value['definition']['path'] == source_path
                value['signature'] += ' -> void'
                changed += 1
    assert changed == 2 and expected == received
    assert not (directory / (view + '.received.txt')).exists()
    for side in ['before', 'after']:
        revision = case[side]
        blob = subprocess.check_output(['git', '-C', repo, 'rev-parse', revision + ':' + source_path], text=True).strip()
        source = subprocess.check_output(['git', '-C', repo, 'show', revision + ':' + source_path]).decode('utf-8-sig')
        assert 'internal class BuildCallbackService\n' in source
        assert 'BuildCallbackService(' not in source
        assert 'private List<Action<ILifetimeScope>> _callbacks = new();' in source
        blobs[revision] = blob
        sources[revision] = source
    assert blobs[case['before']] == blobs[case['after']]
    path = directory / (view + '-json.received.txt')
    records.append({'view': view, 'reviewed': True, 'changedSides': changed, 'allOtherJsonExact': True, 'textAndMarkdownUnchanged': True, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
assert len(set(blobs.values())) == 2
assert len({source.replace('foreach (var callback in _callbacks!)', 'foreach (var callback in _callbacks)') for source in sources.values()}) == 1
report = {'productionPromoted': False, 'sourcePath': source_path, 'immutableSources': blobs, 'sourceDifferences': 'The older held-pipeline source lacks the null-forgiving operator on _callbacks in Execute. Each before/after pair has identical source; constructor and initializer declarations are identical across all pins.', 'reviews': records}
(artifacts / 'constructor-autofac-signature-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed exactly ten signature-field updates across five restored Autofac views; constructor declarations agree at all pins and each pair has identical source.')
