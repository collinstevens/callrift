import collections
import json
import re
import subprocess
from static_review_support import root, snapshots, manifest, document, flatten, clean, rendered, digest, schema, initializer_evidence, jsonschema

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/autofac'
depth_omission = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
metadata_report_path = root / 'static-initializer-call-source-review/autofac-multiservice-report.json'
metadata_report = json.loads(metadata_report_path.read_text(encoding='utf-8'))
assert metadata_report['checks'] == 6 and metadata_report['failures'] == 0
metrics_report_path = root / 'static-root-source-review/autofac-metrics-report.json'
metrics_report = json.loads(metrics_report_path.read_text(encoding='utf-8'))
assert metrics_report['checks'] == 2 and metrics_report['failed'] == 0
proof_key = lambda value: json.dumps(value, sort_keys=True)
metadata_proven = {proof_key(record['check']) for record in metadata_report['records'] if record['passed']}
metrics_proven = {proof_key(record['check']) for record in metrics_report['records'] if record['passed']}
records = []
for case_id in ['autofac-pipeline-callbacks', 'autofac-multi-service-registration']:
    pipeline = case_id == 'autofac-pipeline-callbacks'
    case = manifest[case_id]
    expectations = {
        'src/Autofac/Core/Resolving/Pipeline/ResolvePipelineBuilder.cs': ['private static readonly Action<ResolveRequestContext> _terminateAction = context => { };'],
        'src/Autofac/Diagnostics/AutofacMetrics.cs': ['MetricsEnabled = IsEnabled(DiagnosticsEnvironmentVariable);', 'private static bool IsEnabled(string variableName)', 'var envValue = Environment.GetEnvironmentVariable(variableName);'],
        'src/Autofac/Features/Decorators/DecoratorMiddleware.cs': ['new ServiceRegistration(ServicePipelines.DefaultServicePipeline, _decoratorRegistration),'],
        'src/Autofac/Core/Resolving/Pipeline/ServicePipelines.cs': ['DefaultServicePipeline { get; } = new ResolvePipelineBuilder(PipelineType.Service).UseRange(DefaultMiddleware).Build();']
    } if pipeline else {
        'src/Autofac/Core/ImplicitRegistrationSource.cs': ['_createRegistrationMethod = typeof(ImplicitRegistrationSource).GetDeclaredMethod(nameof(CreateRegistration));', 'return _createRegistrationMethod.MakeGenericMethod(t).CreateDelegate<RegistrationCreator>(this);'],
        'src/Autofac/Features/LazyDependencies/LazyWithMetadataRegistrationSource.cs': ['_createLazyRegistrationMethod = typeof(LazyWithMetadataRegistrationSource).GetDeclaredMethod(nameof(CreateLazyRegistration));', 'return _createLazyRegistrationMethod.MakeGenericMethod(types.Item1, types.Item2).CreateDelegate<RegistrationCreator>(null);'],
        'src/Autofac/Features/Metadata/StronglyTypedMetaRegistrationSource.cs': ['_createMetaRegistrationMethod = typeof(StronglyTypedMetaRegistrationSource).GetDeclaredMethod(nameof(CreateMetaRegistration));', 'return _createMetaRegistrationMethod.MakeGenericMethod(t.Item1, t.Item2).CreateDelegate<RegistrationCreator>(null);'],
        'src/Autofac/Core/Registration/DefaultRegisteredServicesTracker.cs': ['_regInfoFactory = srv => new ServiceRegistrationInfo(srv);', 'return _serviceInfo.GetOrAdd(service, _regInfoFactory);'],
        'src/Autofac/Core/Lifetime/CurrentScopeLifetime.cs': ['Instance { get; } = new CurrentScopeLifetime();'],
        'src/Autofac/Core/KeyedService.cs': ['AnyKey { get; } = new object();'],
        'src/Autofac/Core/ReflectionCacheSet.cs': ['private static readonly object _cacheAllocationLock = new();']}
    blobs = {}
    for path, snippets in expectations.items():
        blobs[path] = {}
        for side in ['before', 'after']:
            source = subprocess.check_output(['git', '-C', repository, 'show', case[side] + ':' + path]).decode('utf-8-sig')
            assert all(snippet in source for snippet in snippets), path
            blobs[path][side] = subprocess.check_output(['git', '-C', repository, 'rev-parse', case[side] + ':' + path], text=True).strip()
    for mode in ['source', 'msbuild']:
        name = case_id + '-' + mode + '-focused'
        json_paths = [snapshots / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
        before, after = map(document, json_paths)
        jsonschema.validate(after, schema)
        assert before['diagnostics'] == after['diagnostics']
        restored = clean(after)
        counts = collections.Counter()
        for item in flatten(restored['trees']):
            if pipeline and item['label'] == '⇢ DecoratorMiddleware.Execute':
                assert item['detail'] == 'changes below depth limit' and item['omission'] == depth_omission
                item['detail'] = 'depth limit'
                counts['decorator'] += 1
            if not pipeline and item['label'] in ['KeyedService.IsAnyKey', 'DefaultRegisteredServicesTracker.GetServiceInfo', 'IRegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.InstancePerLifetimeScope → RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.InstancePerLifetimeScope']:
                assert item['detail'] == 'depth limit' and item['omission'] == depth_omission
                item['detail'], item['omission'] = None, None
                counts[item['label'].split(' → ')[0]] += 1
            if not pipeline:
                removed = [child for child in item['children'] if child['label'] == 'methodCache.GetOrAdd']
                for child in removed:
                    assert child['children'] == [] and child['change'] == 'unchanged' and child['omission'] is None
                    counts['metadata callback parent'] += 1
                item['children'] = [child for child in item['children'] if child not in removed]
        assert clean(before) == restored
        assert counts == ({'decorator': 6} if pipeline else {'KeyedService.IsAnyKey': 2, 'DefaultRegisteredServicesTracker.GetServiceInfo': 1, 'IRegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.InstancePerLifetimeScope': 1, 'metadata callback parent': 3})
        initializer_key, initializer_proven = initializer_evidence(case_id)
        branches = [item for item in flatten(after['trees']) if item['label'].startswith('possible initialization of ')]
        expected_branches = {'ResolvePipelineBuilder': 1, 'AutofacMetrics': 2} if pipeline else {'ReflectionCacheSet': 4, 'ImplicitRegistrationSource': 1, 'CurrentScopeLifetime': 1, 'KeyedService': 1, 'LazyWithMetadataRegistrationSource': 1, 'StronglyTypedMetaRegistrationSource': 1}
        assert collections.Counter(branch['label'].removeprefix('possible initialization of ') for branch in branches) == expected_branches
        for branch in branches:
            assert branch['kind'] == 'branch' and branch['omission'] is None and len(branch['children']) == 1
            initializer = branch['children'][0]
            assert initializer['change'] == branch['change']
            initializer_type = initializer['label'].removeprefix('initialization of ')
            limited = initializer_type in ['ImplicitRegistrationSource', 'CurrentScopeLifetime', 'LazyWithMetadataRegistrationSource', 'StronglyTypedMetaRegistrationSource']
            assert initializer['omission'] == (depth_omission if limited else None)
            assert len(initializer['children']) == (1 if initializer_type == 'AutofacMetrics' else 0)
            expected_relation = 'callback' if initializer_type in ['ImplicitRegistrationSource', 'LazyWithMetadataRegistrationSource', 'StronglyTypedMetaRegistrationSource'] else 'branch'
            for side in ['before', 'after']:
                value, structural = initializer[side], branch[side]
                if value is None:
                    assert structural is None and initializer_type == 'AutofacMetrics'
                    continue
                assert structural['binding'] == 'structural' and structural['origin'] == 'structural' and structural['relation'] == expected_relation and structural['callSites'] == value['callSites']
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']]
                assert initializer_key({'revision': case[side], 'symbolId': value['symbolId'], 'definition': value['definition'], 'callSites': value['callSites']}) in initializer_proven
            for child in initializer['children']:
                assert child['label'] == 'AutofacMetrics.IsEnabled' and child['change'] == initializer['change'] and child['omission'] is None and child['children'] == []
                for side in ['before', 'after']:
                    value = child[side]
                    if value is None:
                        continue
                    assert proof_key({'revision': case[side], 'definition': value['definition'], 'signature': value['signature'], 'callSites': value['callSites']}) in metrics_proven
        for item in flatten(after['trees']):
            if item['label'] != 'methodCache.GetOrAdd':
                continue
            assert not pipeline and item['change'] == 'unchanged' and item['omission'] is None and len(item['children']) == 1
            for side in ['before', 'after']:
                value = item[side]
                assert value['origin'] == 'metadata' and value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['targetIds'] == [value['symbolId']] and value['definition'] is None
                assert value['symbolId'].endswith('::System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>.GetOrAdd(TKey,global::System.Func<TKey, TValue>)')
                assert len(value['callSites']) == 1
                assert proof_key({'revision': case[side], 'location': value['callSites'][0], 'type': 'System.Collections.Concurrent.ConcurrentDictionary<TKey, TValue>', 'name': 'GetOrAdd', 'parameters': ['TKey', 'System.Func<TKey, TValue>']}) in metadata_proven
        text_paths = [snapshots / (name + '.' + suffix + '.txt') for suffix in ['verified', 'received']]
        old_stdout, old_stderr = rendered(text_paths[0])
        new_stdout, new_stderr = rendered(text_paths[1])
        assert old_stderr == new_stderr
        def normalized(text):
            lines = [(line[0], re.sub(r'^[ │├└─]*', '', line[2:])) for line in text.splitlines() if line and 'initialization of ' not in line and 'AutofacMetrics.IsEnabled' not in line]
            return lines
        left, right = normalized(old_stdout), normalized(new_stdout)
        right = [(mark, label.replace('⇢ DecoratorMiddleware.Execute (changes below depth limit)', '⇢ DecoratorMiddleware.Execute (depth limit)')) for mark, label in right]
        if not pipeline:
            right = [(mark, label.removesuffix(' (depth limit)') if label in ['DefaultRegisteredServicesTracker.GetServiceInfo (depth limit)', 'IRegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.InstancePerLifetimeScope → RegistrationBuilder<TLimit, TActivatorData, TRegistrationStyle>.InstancePerLifetimeScope (depth limit)'] else label) for mark, label in right]
        assert left == right
        records.append({'view': name, 'initializerBranches': len(branches), 'reviewedExistingNodeChanges': dict(counts), 'sourceBlobs': blobs, 'metadataReportSha256': digest(metadata_report_path), 'metricsReportSha256': digest(metrics_report_path), 'schemaV1': True, 'textMarkdownParity': True, 'diagnosticsUnchanged': len(after['diagnostics']), 'files': {path.name: digest(path) for path in [json_paths[1], text_paths[1]]}, 'repeatStatus': 'pending', 'review': 'Pipeline initialization exposes the metrics switch helper in its removed and added control-flow positions. Decorator execution reads the default service pipeline and can reach its changed builder through initialization below the displayed depth. Multi-service registration exposes three metadata cache calls because their callbacks read source initializer fields; those branches preserve callback relation. Lifetime, wildcard sentinel, and service-info factory reads explain the other new depth omissions. All remaining fields and rendered output are preserved.'})
(root / 'static-autofac-complex-focused-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed four Autofac focused views, twenty-four initializer branches, and six independently bound cache callback calls.')
