from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, 'artifacts')
from static_review_support import document, flatten, rendered, manifest, schema, jsonschema

root = Path('artifacts')
directory = root / 'static-coalesce-initialization-corpus/Snapshots'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
specifications = {}
for case in ['autofac-any-key-cache', 'autofac-multi-service-registration']:
    specifications[case + '-source-roots'] = {
        'case': case,
        'branches': [('if (_methodParameters is null)', 'src/Autofac/Core/Resolving/BaseGenericResolveDelegateInvoker.cs', 63, 63, 30, 63, 75, '_methodParameters ??= GetDelegateParameters()', ['BaseGenericResolveDelegateInvoker.GetDelegateParameters'])],
        'renderEdits': [('  ├─ BaseGenericResolveDelegateInvoker.GetDelegateParameters\n', '  ├─ if (_methodParameters is null)\n', 1)]
    }
specifications['ocelot-custom-json-merge-source-roots'] = {
    'case': 'ocelot-custom-json-merge',
    'branches': [
        ('if (globalConfiguration is null)', 'src/DependencyInjection/ConfigurationBuilderExtensions.cs', None, 513, 9, 513, 125, 'globalConfiguration ??= MergedConfigJObject.OcelotJSection(nameof(FileConfiguration.GlobalConfiguration)) as JObject', ['possible initialization of ConfigurationBuilderExtensions', '? MergedConfigJObject.OcelotJSection']),
        ('if (current is null)', 'src/DependencyInjection/ConfigurationExtensions.cs', None, 148, 9, 148, 48, 'current ??= OcelotRoutes(configuration)', ['ConfigurationExtensions.OcelotRoutes']),
        ('if (configuration is null)', 'src/DependencyInjection/ServiceCollectionExtensions.cs', 71, 71, 9, 71, 59, 'configuration ??= services.FindConfiguration(null)', ['ServiceCollectionExtensions.FindConfiguration'])
    ],
    'renderEdits': [
        ('+ ConfigurationBuilderExtensions.OcelotJProperty\n+ ├─ possible initialization of ConfigurationBuilderExtensions\n+ │  └─ initialization of ConfigurationBuilderExtensions\n+ ├─ ? MergedConfigJObject.OcelotJSection\n', '+ ConfigurationBuilderExtensions.OcelotJProperty\n+ ├─ if (globalConfiguration is null)\n+ │  ├─ possible initialization of ConfigurationBuilderExtensions\n+ │  │  └─ initialization of ConfigurationBuilderExtensions\n+ │  └─ ? MergedConfigJObject.OcelotJSection\n', 1),
        ('+ ConfigurationExtensions.OcelotProperty\n+ ├─ ConfigurationExtensions.OcelotRoutes\n', '+ ConfigurationExtensions.OcelotProperty\n+ ├─ if (current is null)\n+ │  └─ ConfigurationExtensions.OcelotRoutes\n', 1),
        ('  ServiceCollectionExtensions.AddOcelotUsingBuilder\n  ├─ ServiceCollectionExtensions.FindConfiguration (depth limit)\n', '  ServiceCollectionExtensions.AddOcelotUsingBuilder\n  ├─ if (configuration is null)\n', 2)
    ]
}
authorization_expression = '\n'.join([
    'authorization ??= await _authorizationManager.CreateAsync(',
    '                    identity: identity,',
    '                    subject: identity.GetUserIdentifier(),',
    '                    client: await _applicationManager.GetIdAsync(application),',
    '                    type: AuthorizationTypes.Permanent,',
    '                    scopes: identity.GetScopes())'
])
specifications['orchardcore-openid-logout-msbuild-roots'] = {
    'case': 'orchardcore-openid-logout',
    'branches': [('if (authorization is null)', 'src/OrchardCore.Modules/OrchardCore.OpenId/Controllers/AccessController.cs', line, line, 17, line + 5, 50, authorization_expression, ['OpenIdExtensions.GetUserIdentifier']) for line in [150, 263]],
    'renderEdits': [
        ('  │  ├─ OpenIdExtensions.GetUserIdentifier\n', '  │  ├─ if (authorization is null)\n', 1),
        ('     ├─ OpenIdExtensions.GetUserIdentifier\n', '     ├─ if (authorization is null)\n', 1)
    ]
}
records = []
for name, spec in specifications.items():
    case = manifest[spec['case']]
    repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/' + case['cacheName']
    before_path, after_path = [directory / (name + '-json.' + suffix + '.txt') for suffix in ['verified', 'received']]
    before, after = document(before_path), document(after_path)
    jsonschema.validate(after, schema)
    labels = {item[0] for item in spec['branches']}
    nodes = [node for node in flatten(after['trees']) if node['label'] in labels]
    assert len(nodes) == len(spec['branches'])
    blobs = {}
    for item in spec['branches']:
        label, path, before_line, after_line, column, end_line, end_column, expression, children = item
        candidates = [node for node in nodes if node['label'] == label and node['after']['callSites'][0]['startLine'] == after_line]
        assert len(candidates) == 1
        node = candidates[0]
        assert node['kind'] == 'branch' and node['detail'] is None and node['omission'] is None
        assert node['change'] == ('added' if before_line is None else 'unchanged')
        assert [child['label'] for child in node['children']] == children
        for side, line in [('before', before_line), ('after', after_line)]:
            if line is None:
                assert node[side] is None
                continue
            git_spec = case[side] + ':' + path
            source = subprocess.check_output(['git', '-C', repository, 'show', git_spec]).decode('utf-8-sig')
            lines = source.splitlines()
            expression_lines = lines[line - 1:end_line]
            expression_lines[0] = expression_lines[0][column - 1:]
            expression_lines[-1] = expression_lines[-1][:end_column - 1 if end_line != line else end_column - column]
            assert '\n'.join(expression_lines) == expression
            blobs[git_spec] = subprocess.check_output(['git', '-C', repository, 'rev-parse', git_spec], text=True).strip()
            location = {'path': path, 'startLine': line, 'startColumn': column, 'endLine': end_line, 'endColumn': end_column}
            assert node[side] == {'symbolId': None, 'signature': None, 'binding': 'structural', 'dispatch': 'none', 'targetIds': [], 'definition': None, 'callSites': [location], 'relation': 'branch', 'candidates': None, 'origin': 'structural'}

    def normalized(value, unwrap=False):
        if isinstance(value, list):
            return [item for node in value for item in (normalized(node['children'], True) if unwrap and isinstance(node, dict) and node.get('label') in labels else [normalized(node, unwrap)])]
        if isinstance(value, dict):
            return {key: normalized(item, unwrap) for key, item in value.items() if key != 'id'}
        return value

    assert normalized(before) == normalized(after, True), name
    before_text_path = directory / (name + '.verified.txt')
    after_text_path = directory / (name + '.received.txt')
    old_text, old_error = rendered(before_text_path)
    new_text, new_error = rendered(after_text_path)
    assert old_error == new_error
    expected_text = old_text
    for old, new, count in spec['renderEdits']:
        assert expected_text.count(old) == count
        expected_text = expected_text.replace(old, new, 1)
    assert expected_text == new_text
    records.append({
        'view': name,
        'snapshotDirectory': directory.as_posix(),
        'sourceBlobs': blobs,
        'conditionalBranches': [{'label': item[0], 'afterLine': item[3]} for item in spec['branches']],
        'schemaV1': True,
        'allOtherPriorJsonPreservedExceptTraversalIds': True,
        'textAndMarkdownExactExpectedEdits': True,
        'review': 'The cached parameter lookup, configuration fallbacks, and authorization creation arguments execute only when the existing value is null. Every guard matches the immutable expression span. Unwrapping only these seven guards reproduces all prior JSON fields except traversal IDs across the four views. Existing initializer subtrees, unresolved source calls, dispatch targets, roots, diagnostics, ordering, and depth omissions are preserved. The OpenID restored view hides external package calls under the existing policy but retains the source GetUserIdentifier argument beneath each conditional authorization. Exact text and Markdown edits preserve the unconditional Ocelot overload and all surrounding change markers.',
        'files': {path.name: digest(path) for path in [after_path, after_text_path]},
        'baselineFiles': {path.name: digest(path) for path in [before_path, before_text_path]},
        'repeatStatus': 'pending'
    })
(root / 'static-coalesce-final-four-review.json').write_text(json.dumps({'views': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed seven exact source guards across the final four changed views; all other JSON and rendering preserved.')
