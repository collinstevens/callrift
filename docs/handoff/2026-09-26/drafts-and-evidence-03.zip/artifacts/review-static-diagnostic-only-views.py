import json
import sys
from static_review_support import root, prior_fields_and_diagnostics

arguments = sys.argv[1:]
review_name = arguments.pop(0) if arguments and arguments[0].endswith('.json') else None
reviews = []
for name in arguments:
    before, after, review = prior_fields_and_diagnostics(name)
    assert before['trees'] == after['trees']
    review['review'] = 'Every existing JSON field and rendered tree is unchanged. Only the added, independently compiler-verified static initializer diagnostics and their stderr summary differ.'
    reviews.append(review)
assert reviews
path = root / (review_name or ('static-diagnostic-only-' + str(len(reviews)) + '-views-review.json'))
assert not path.exists()
path.write_text(json.dumps({'views': reviews}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed ' + str(len(reviews)) + ' complete diagnostic-only views.')
