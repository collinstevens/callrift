from pathlib import Path

root = Path.cwd()
artifacts = root / 'artifacts'
source = (artifacts / 'constructor-initialization-matrix/Program.cs').read_text(encoding='utf-8')
table = source[source.index('    ("optional-base"'):source.index('\n};')]
table = table.rstrip().removesuffix(',') + ',\n'
table += '    ("implicit-base", "class Base { protected Base() { Sink.Before(); } } class Derived : Base { public Derived() {} }" + entry, true),\n'
table += '    ("implicit-derived", "class Base { protected Base() { Sink.Before(); } } class Derived : Base {}" + entry, true),\n'
table += '    ("equivalent", "class Derived {}" + entry, false),\n'
table += '    ("cross-project", "class Derived : Base<int> {}" + entry, true)'
template = '''using System.Text.Json;
using Xunit;

namespace Callrift.Scenarios;

public sealed class ConstructorInitializationTests
{
    private const string entry = " static class Entry { public static void Run() { _ = new Derived(); } }";
    private const string sink = " static class Sink { public static int Before() => 0; public static int After() => 0; }";
    private static readonly (string Name, string Source, bool ReachesChange)[] Fixtures =
    [
TABLE
    ];

    public static IEnumerable<object[]> Cases => Fixtures.SelectMany(fixture => new[] { new object[] { fixture.Name, false }, new object[] { fixture.Name, true } });

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task FollowsConstructorInitializationAcrossCommands(string name, bool workspace)
    {
        var example = Fixtures.Single(fixture => fixture.Name == name);
        const string project = "<Project Sdk=\\"Microsoft.NET.Sdk\\"><PropertyGroup><TargetFramework>net11.0</TargetFramework><LangVersion>14.0</LangVersion></PropertyGroup></Project>";
        var before = new Dictionary<string, string> { ["Flow.cs"] = example.Source + sink, ["App.csproj"] = project };
        var after = new Dictionary<string, string>(before) { ["Flow.cs"] = example.Source.Replace("Sink.Before()", "Sink.After()", StringComparison.Ordinal) + sink };
        if (name == "equivalent")
            after["Flow.cs"] = example.Source.Replace("class Derived {}", "class Derived { public Derived() {} }", StringComparison.Ordinal) + sink;
        if (name == "cross-project")
        {
            var referencedProject = project;
            var applicationProject = project.Replace("</Project>", "<ItemGroup><Compile Remove=\\"Base/**/*.cs\\" /><ProjectReference Include=\\"Base/Base.csproj\\" /></ItemGroup></Project>", StringComparison.Ordinal);
            before["App.csproj"] = after["App.csproj"] = applicationProject;
            before["Base/Base.csproj"] = after["Base/Base.csproj"] = referencedProject;
            before["Flow.cs"] = after["Flow.cs"] = example.Source;
            before["Base/Base.cs"] = "public class Base<T> { protected Base(T value = default) { Sink.Before(); } } public static class Sink { public static int Before() => 0; public static int After() => 0; }";
            after["Base/Base.cs"] = before["Base/Base.cs"].Replace("Sink.Before()", "Sink.After()", StringComparison.Ordinal);
        }
        await using var fixture = await GitFixture.CreateAsync(new Scenario("constructor-initialization", "Constructor calls and initializers retain their source-defined effects.", before, after, []));
        string[] mode = workspace ? ["--project", "App.csproj"] : [];
        foreach (var focused in new[] { false, true })
        {
            string[] selection = focused ? ["--entry", "Entry.Run"] : [];
            using var document = Parse(await fixture.RunAsync(["diff", fixture.Before, fixture.After, "--format", "json", "--depth", "14", "--externals", .. selection, .. mode]));
            var roots = document.RootElement.GetProperty("trees").EnumerateArray().Where(node => node.GetProperty("label").GetString() == "Entry.Run").ToArray();
            Assert.Equal(example.ReachesChange, roots.Length != 0);
            if (focused) Assert.Equal(example.ReachesChange, document.RootElement.GetProperty("hasChanges").GetBoolean());
            if (example.ReachesChange)
            {
                var nodes = Flatten(Assert.Single(roots)).ToArray();
                Assert.Contains(nodes, node => node.GetProperty("label").GetString() == "Sink.Before" && node.GetProperty("change").GetString() == "removed");
                Assert.Contains(nodes, node => node.GetProperty("label").GetString() == "Sink.After" && node.GetProperty("change").GetString() == "added");
            }
        }
        using var tree = Parse(await fixture.RunAsync(["tree", fixture.Before, "--entry", "Entry.Run", "--format", "json", "--depth", "14", "--externals", .. mode]));
        var calls = tree.RootElement.GetProperty("trees").EnumerateArray().SelectMany(Flatten).ToArray();
        Assert.Equal(example.ReachesChange, calls.Any(node => node.GetProperty("label").GetString() == "Sink.Before"));
        using var reach = Parse(await fixture.RunAsync(["reach", fixture.Before, "--entry", "Entry.Run", "--to", "Sink.Before", "--format", "json", "--depth", "14", "--externals", .. mode]));
        Assert.Equal(example.ReachesChange, reach.RootElement.GetProperty("paths").GetArrayLength() != 0);
    }

    private static JsonDocument Parse(string output)
    {
        Assert.True(output.StartsWith("exit: 0\\n", StringComparison.Ordinal), output);
        var document = JsonDocument.Parse(output.Split("stdout:\\n", StringSplitOptions.None)[1].Split("stderr:\\n", StringSplitOptions.None)[0]);
        Assert.Empty(document.RootElement.GetProperty("diagnostics").EnumerateArray());
        return document;
    }

    private static IEnumerable<JsonElement> Flatten(JsonElement node) => new[] { node }.Concat(node.GetProperty("children").EnumerateArray().SelectMany(Flatten));
}
'''
target = artifacts / 'ConstructorInitializationTests.cs'
assert not target.exists()
target.write_text(template.replace('TABLE', '\n'.join('    ' + line for line in table.splitlines())), encoding='utf-8', newline='\n')
directory = artifacts / 'constructor-initialization-cli-tests'
directory.mkdir()
project = (artifacts / 'dispatch-cardinality-cli-tests/Check.csproj').read_text(encoding='utf-8').replace('DispatchCardinalityTests.cs', 'ConstructorInitializationTests.cs')
(directory / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
print('Prepared 42 source/restored constructor CLI cases for diff, tree, and reach.')
