import json
from static_review_support import root, manifest

permission_path = 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Security/Permissions/Permission.cs'
workflow_path = 'src/OrchardCore/OrchardCore.Workflows.Abstractions/WorkflowsPermissions.cs'
elastic_path = 'src/OrchardCore/OrchardCore.Elasticsearch.Core/ElasticsearchPermissions.cs'
location = lambda path, line, column, end_line, end_column: dict(path=path, startLine=line, startColumn=column, endLine=end_line, endColumn=end_column)
checks = []
for side in ['before', 'after']:
    for line, column, end_column, implied in [(7, 57, 125, False), (9, 58, 128, False), (11, 64, 140, True)]:
        checks.append({'revision': manifest['orchardcore-workflow-startup'][side], 'definition': location(permission_path, 55 if implied else 39, 5, 58 if implied else 43, 6), 'signature': 'OrchardCore.Security.Permissions.Permission.Permission(string, string, ' + ('System.Collections.Generic.IEnumerable<OrchardCore.Security.Permissions.Permission>, ' if implied else '') + 'bool) -> void', 'callSites': [location(workflow_path, line, column, line, end_column)]})
for line, column, end_column in [(8, 62, 158), (10, 57, 136)]:
    checks.append({'revision': manifest['orchardcore-elasticsearch-authorization']['after'], 'definition': location(permission_path, 55, 5, 58, 6), 'signature': 'OrchardCore.Security.Permissions.Permission.Permission(string, string, System.Collections.Generic.IEnumerable<OrchardCore.Security.Permissions.Permission>, bool) -> void', 'callSites': [location(elastic_path, line, column, line, end_column)]})
path = root / 'static-initializer-body-source-review/orchard-permissions.json'
path.write_text(json.dumps({'repository': 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', 'checks': checks}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Prepared eight independently specified Permission constructor bindings.')
