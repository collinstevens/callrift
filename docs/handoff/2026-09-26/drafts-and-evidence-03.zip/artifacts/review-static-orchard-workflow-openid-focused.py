import collections
import json
import subprocess
from pathlib import Path
from static_review_support import root, manifest, digest, flatten, prior_fields_and_diagnostics, initializer_evidence

repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore'
permission_path = 'src/OrchardCore/OrchardCore.Infrastructure.Abstractions/Security/Permissions/Permission.cs'
workflow_path = 'src/OrchardCore/OrchardCore.Workflows.Abstractions/WorkflowsPermissions.cs'
options_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/JOptions.cs'
array_path = 'src/OrchardCore/OrchardCore.Abstractions/Json/Nodes/JArray.cs'
report_path = root / 'static-initializer-body-source-review/orchard-permissions-report.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
assert report['checks'] == 8 and report['failed'] == 0 and all(record['passed'] for record in report['records'])
body_key = lambda value: json.dumps({name: value[name] for name in ['revision', 'definition', 'signature', 'callSites']}, sort_keys=True)
body_records = {body_key(record['check']): record for record in report['records']}
depth = {'reason': 'depth-limit', 'symbolId': None, 'referenceId': None}
reviews = []
for case_id, suffixes in [('orchardcore-workflow-startup', ['source-focused', 'msbuild-focused', 'source-roots']), ('orchardcore-openid-logout', ['source-focused', 'msbuild-focused'])]:
    case = manifest[case_id]
    key, proven = initializer_evidence(case_id)
    blobs = {}
    for path in ([workflow_path, permission_path, options_path, array_path] if 'workflow' in case_id else [options_path]):
        versions = []
        for side in ['before', 'after']:
            revision = case[side]
            source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
            if path == workflow_path:
                expected = ['public static readonly Permission ManageWorkflows = new("ManageWorkflows", "Manage workflows", isSecurityCritical: true);', 'public static readonly Permission ExecuteWorkflows = new("ExecuteWorkflows", "Execute workflows", isSecurityCritical: true);', 'public static readonly Permission ManageWorkflowSettings = new("ManageWorkflowSettings", "Manage workflow settings", [ManageWorkflows]);']
                assert [line.strip() for line in source.splitlines() if 'static readonly' in line] == expected
            elif path == permission_path:
                assert 'public Permission(string name, string description, bool isSecurityCritical = false) : this(name)' in source
                assert 'public Permission(string name, string description, IEnumerable<Permission> impliedBy, bool isSecurityCritical = false) : this(name, description, isSecurityCritical)' in source
            elif path == array_path:
                assert 'return JsonArray.Create(JsonSerializer.SerializeToElement(obj, options ?? JOptions.Default));' in source
            else:
                assert 'DynamicJsonConverter.Instance,' in source and 'new JsonStringEnumConverter()' in source and 'Default = new JsonSerializerOptions(Base);' in source
                assert 'foreach (var converter in KnownConverters)' in source and 'Default.Converters.Add(converter);' in source
            versions.append(subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip())
        assert versions[0] == versions[1], path
        blobs[path] = versions[0]
    for suffix in suffixes:
        name = case_id + '-' + suffix
        def prior(value):
            if suffix == 'source-roots':
                targets = [node for node in flatten(value['trees']) if node['label'] == 'JArray.FromObject']
                assert len(targets) == 1
                assert targets[0]['detail'] is None and targets[0]['omission'] is None
                targets[0]['detail'] = 'depth limit'
                targets[0]['omission'] = depth
            return value
        before, after, review = prior_fields_and_diagnostics(name, prior_json_transform=prior)
        branches = [node for node in flatten(after['trees']) if node['label'].startswith('possible initialization of ')]
        counts = collections.Counter(branch['label'] for branch in branches)
        expected = {'possible initialization of JOptions': 1}
        if 'workflow' in case_id:
            expected = {'possible initialization of WorkflowsPermissions': 2}
            if suffix.endswith('focused'):
                expected['possible initialization of JOptions'] = 1
        assert counts == expected, (name, counts)
        locations = []
        for branch in branches:
            assert branch['kind'] == 'branch' and branch['change'] == 'unchanged' and branch['omission'] is None and len(branch['children']) == 1
            initializer = branch['children'][0]
            assert initializer['label'] == branch['label'].removeprefix('possible ') and initializer['change'] == 'unchanged'
            expanded = branch['label'] == 'possible initialization of WorkflowsPermissions' and suffix.endswith('focused')
            assert initializer['omission'] == (None if expanded else depth)
            if expanded:
                assert len(initializer['children']) == 3
                for index, child in enumerate(initializer['children']):
                    assert child['label'] == 'new Permission' and child['change'] == 'unchanged' and child['children'] == [] and child['omission'] == depth
                    for side in ['before', 'after']:
                        value = child[side]
                        assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['origin'] == 'source' and value['relation'] == 'call'
                        assert value['targetIds'] == [value['symbolId']]
                        assert value['callSites'][0]['startLine'] == [7, 9, 11][index]
                        evidence = body_records[body_key({'revision': case[side], **value})]
                        assert evidence['passed']
            else:
                assert initializer['children'] == []
            for side in ['before', 'after']:
                value = initializer[side]
                structural = branch[side]
                assert structural['binding'] == 'structural' and structural['relation'] == 'branch' and structural['origin'] == 'structural' and structural['symbolId'] is None
                assert structural['callSites'] == value['callSites']
                assert value['binding'] == 'resolved' and value['dispatch'] == 'direct' and value['relation'] == 'call' and value['origin'] == 'source' and value['targetIds'] == [value['symbolId']]
                evidence = proven[key({'revision': case[side], **value})]
                assert value['signature'] in [constructor['signature'] + ' -> void' for constructor in evidence['record']['constructors']]
                locations.append({'node': initializer['id'], 'side': side, 'report': evidence['path'], 'sha256': evidence['sha256']})
        review.update(initializerBranches=len(branches), initializerCounts=dict(counts), immutableSourceBlobs=blobs, sourceLocations=locations, permissionBindings={'report': report_path.as_posix(), 'sha256': digest(report_path)}, reviewedPriorFieldChanges=['JArray.FromObject gains a depth omission for conditional JOptions.Default initialization.'] if suffix == 'source-roots' else [], review='Workflow permission fields initialize in declaration order; the final permission reads the already initializing ManageWorkflows field. Source Permission constructor chaining justifies depth omissions. JOptions converter fields initialize before its explicit body. Default JSON options are conditional on the null options branch. All prior trees, source locations, roots, and rendered stdout are preserved except the enumerated depth marker and independently proven diagnostics.')
        reviews.append(review)
provenance_paths = [root / 'static-initializer-body-source-review' / name for name in ['Program.cs', 'Check.csproj', 'orchard-permissions.json', 'orchard-permissions-report.json', 'build/bin/Check/debug/Check.dll', 'build/bin/Check/debug/Callrift.Core.dll']]
(root / 'static-orchard-workflow-openid-five-review.json').write_text(json.dumps({'views': reviews, 'independentCompilerProvenance': {path.as_posix(): digest(path) for path in provenance_paths}}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Reviewed five workflow/OpenID views, ten initializer branches, and one justified depth marker; repeats pending.')
