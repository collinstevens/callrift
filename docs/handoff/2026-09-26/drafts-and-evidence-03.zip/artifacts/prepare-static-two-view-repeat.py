from pathlib import Path
import hashlib
import json
import shutil

root = Path('artifacts')
source = root / 'static-initialization-callback-corpus'
target = root / 'static-initialization-two-view-repeat'
assert not target.exists()
shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build', '*-ready', '*.received.*', 'packages.lock.json'))
path = target / 'RealWorldCaseTests.cs'
text = path.read_text(encoding='utf-8-sig')
old = '.SelectMany(e => (e.Views ?? []).Where(v => !Routine || v.Routine).Select(v => new object[] { e.Id, v.Id }));'
new = '.SelectMany(e => (e.Views ?? []).Where(v => new[] { "polly-telemetry-source-msbuild-roots", "autofac-multi-service-registration-msbuild-roots" }.Contains(e.Id + "-" + v.Id)).Select(v => new object[] { e.Id, v.Id }));'
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
for review_name in ['static-telemetry-root-review.json', 'static-autofac-multi-service-roots-review.json']:
    review = json.loads((root / review_name).read_text(encoding='utf-8'))
    for name, expected in review['files'].items():
        original = source / 'Snapshots' / name
        assert hashlib.sha256(original.read_bytes()).hexdigest() == expected
        shutil.copy2(original, target / 'Snapshots' / name.replace('.received.', '.verified.'))
print('Prepared two-view repeat with only four independently reviewed snapshot updates.')
