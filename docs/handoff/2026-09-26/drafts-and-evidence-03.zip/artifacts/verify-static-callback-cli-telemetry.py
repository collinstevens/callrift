from pathlib import Path
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path('artifacts')
sys.path.insert(0, str((root / 'schema-review-python').resolve()))
import jsonschema
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
directory = root / 'static-initialization-callback-complete-cli'
inputs_path = root / (directory.name + '-inputs.json')
inputs = json.loads(inputs_path.read_text(encoding='utf-8'))
for name, expected in inputs['versions']['candidate'].items():
    assert digest(directory / 'candidate-ready' / name) == expected, name
for name, expected in inputs['sources'].items():
    assert digest(Path(name)) == expected, name
trx = next((root / (directory.name + '-results')).glob('*.trx'))
tree = ET.parse(trx)
counters = tree.find('.//{*}Counters').attrib
assert counters['total'] == counters['executed'] == counters['passed'] == '110'
assert counters['failed'] == '0'
proof = {'core': inputs['versions']['candidate']['Callrift.Core.dll'], 'worker': inputs['versions']['candidate']['msbuild/Callrift.MSBuild.dll'], 'inputsSha256': digest(inputs_path), 'trx': trx.as_posix(), 'trxSha256': digest(trx), 'counters': counters, 'results': [result.attrib for result in tree.findall('.//{*}UnitTestResult')]}
(root / 'static-initialization-callback-complete-cli-terminal.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
directory = root / 'static-polly-telemetry-path-review'
schema = json.loads(Path('schemas/output-v1.schema.json').read_text(encoding='utf-8'))
revision = 'b87f20347af528b6f7c6ff1f9e6c1bc02f97856c'
repository = 'C:/Users/Admin/AppData/Local/Callrift/real-world-cases/polly'
sources = {}
for name in ['TelemetrySource.cs', 'TelemetryListenerImpl.cs', 'TelemetryResiliencePipelineBuilderExtensions.cs']:
    path = 'src/Polly.Extensions/Telemetry/' + name
    source = subprocess.check_output(['git', '-C', repository, 'show', revision + ':' + path]).decode('utf-8-sig')
    blob = subprocess.check_output(['git', '-C', repository, 'rev-parse', revision + ':' + path], text=True).strip()
    if name == 'TelemetrySource.cs':
        assert source.splitlines()[8].strip() == 'public static readonly TelemetrySource Instance = new();'
        assert source.splitlines()[12].strip() == 'var version = GetVersion();'
    elif name == 'TelemetryListenerImpl.cs':
        assert source.splitlines()[22].strip() == 'var meter = TelemetrySource.Instance.Meter;'
    else:
        assert source.splitlines()[53].strip() == 'builder.TelemetryListener = new TelemetryListenerImpl(options);'
    sources[path] = blob
paths = []
for mode in ['source', 'msbuild']:
    for suffix in ['', '-tree']:
        path = directory / (mode + suffix + '.json')
        document = json.loads(path.read_text(encoding='utf-8'))
        jsonschema.validate(document, schema)
        assert document['to']['commit'] == revision
        if suffix:
            assert document['command'] == 'tree'
            continue
        assert document['command'] == 'reach' and len(document['paths']) == 1
        nodes = []
        node = document['paths'][0]
        while True:
            nodes.append(node)
            assert node['omission'] is None
            if not node['children']:
                break
            assert len(node['children']) == 1
            node = node['children'][0]
        assert [node['label'] for node in nodes] == ['new TelemetryListenerImpl', 'possible initialization of TelemetrySource', 'initialization of TelemetrySource', 'new TelemetrySource']
        assert nodes[2]['after']['symbolId'].endswith('::Polly.Telemetry.TelemetrySource..cctor()')
        assert nodes[3]['after']['symbolId'].endswith('::Polly.Telemetry.TelemetrySource..ctor()')
        assert nodes[1]['after']['callSites'] == nodes[2]['after']['callSites'] == [{'path': 'src/Polly.Extensions/Telemetry/TelemetryListenerImpl.cs', 'startLine': 23, 'startColumn': 21, 'endLine': 23, 'endColumn': 45}]
        assert nodes[3]['after']['callSites'] == [{'path': 'src/Polly.Extensions/Telemetry/TelemetrySource.cs', 'startLine': 9, 'startColumn': 55, 'endLine': 9, 'endColumn': 60}]
        paths.append({'mode': mode, 'path': path.as_posix(), 'sha256': digest(path), 'labels': [node['label'] for node in nodes]})
evidence = {'revision': revision, 'sources': sources, 'core': proof['core'], 'worker': proof['worker'], 'paths': paths, 'schemaValidatedDocuments': 4, 'review': 'TelemetrySource private constructor now has an incoming path through its singleton field initializer. ConfigureTelemetry constructs TelemetryListenerImpl. The automatic-root removal is supported by immutable source; full latest snapshots remain pending.'}
(root / 'static-polly-telemetry-path-evidence.json').write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified 110 passing CLI tests and both immutable-source-backed telemetry reach paths; four JSON envelopes pass schema v1.')
