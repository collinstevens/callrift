from pathlib import Path

artifacts = Path.cwd() / 'artifacts'
target = artifacts / 'constructor-depth-reach-cli'
assert not target.exists()
target.mkdir()
project = (artifacts / 'constructor-depth-cli/Check.csproj').read_text(encoding='utf-8').replace('DepthVisibilityTests.cs', 'DepthReachTests.cs')
(target / 'Check.csproj').write_text(project, encoding='utf-8', newline='\n')
overlay = (artifacts / 'overlay-constructor-depth-cli.py').read_text(encoding='utf-8').replace('constructor-depth-cli', 'constructor-depth-reach-cli').replace('DepthVisibilityTests.cs', 'DepthReachTests.cs')
(artifacts / 'overlay-constructor-depth-reach.py').write_text(overlay, encoding='utf-8', newline='\n')
print('Prepared four independent absent-path CLI checks in both analysis modes.')
