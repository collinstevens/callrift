from pathlib import Path
import shutil

root = Path('artifacts')
for suffix in ['core', 'worker']:
    source = root / ('static-initialization-event-' + suffix)
    target = root / ('static-initialization-callback-state-' + suffix)
    assert not target.exists()
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('bin', 'obj', 'build'))
path = root / 'static-initialization-callback-state-worker/Callrift.MSBuild.csproj'
path.write_text(path.read_text(encoding='utf-8-sig').replace('static-initialization-event-core', 'static-initialization-callback-state-core'), encoding='utf-8', newline='\n')
core = root / 'static-initialization-callback-state-core'
path = core / 'Graph/Models.cs'
text = path.read_text(encoding='utf-8-sig')
assert text.count('    public string Relation { get; init; } = "call";') == 1
text = text.replace('    public string Relation { get; init; } = "call";', '    public string Relation { get; init; } = "call";\n    public int? CallbackGroup { get; init; }')
path.write_text(text, encoding='utf-8', newline='\n')
path = core / 'Analysis/CallCollector.cs'
text = path.read_text(encoding='utf-8-sig')
text = text.replace('        var callbacks = new List<CallStep>();\n        foreach (var argument in arguments)', '        var callbacks = new List<CallStep>();\n        var argumentIndex = 0;\n        foreach (var argument in arguments)')
text = text.replace('            var expression = argument.Expression;', '            var callbackStart = callbacks.Count;\n            var expression = argument.Expression;')
old = '''            else
                Walk(expression, result);
        }
        var info = model.GetSymbolInfo(invocation, cancellationToken);'''
new = '''            else
                Walk(expression, result);
            for (var index = callbackStart; index < callbacks.Count; index++)
                callbacks[index] = callbacks[index] with { CallbackGroup = argumentIndex };
            argumentIndex++;
        }
        var info = model.GetSymbolInfo(invocation, cancellationToken);'''
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
path = core / 'Analysis/TypeInitialization.cs'
text = path.read_text(encoding='utf-8-sig')
assert text.count('                    result.Add(trigger);') == 1
path.write_text(text.replace('                    result.Add(trigger);', '                    result.Add(trigger with { Relation = call.Relation, CallbackGroup = call.CallbackGroup });'), encoding='utf-8', newline='\n')
path = core / 'Diffing/TreeExpander.cs'
text = path.read_text(encoding='utf-8-sig')
start = text.index('    private IReadOnlyList<CallTree> ExpandCalls(')
end = text.index('    private bool HasVisibleCalls', start)
section = text[start:end]
section = section.replace('        var trees = new List<CallTree>();', '        var trees = new List<CallTree>();\n        var callbackInitializations = new Dictionary<int, HashSet<string>>();')
section = section.replace('            cancellationToken.ThrowIfCancellationRequested();', '''            cancellationToken.ThrowIfCancellationRequested();
            var currentInitializations = initialized;
            if (call.CallbackGroup is { } group)
            {
                if (!callbackInitializations.TryGetValue(group, out var callbackState))
                    callbackInitializations[group] = callbackState = new HashSet<string>(initialized, StringComparer.Ordinal);
                currentInitializations = callbackState;
            }''', 1)
section = section.replace('!initialized.Add(initializer.Key)', '!currentInitializations.Add(initializer.Key)')
section = section.replace('new HashSet<string>(initialized, StringComparer.Ordinal)', 'new HashSet<string>(currentInitializations, StringComparer.Ordinal)')
section = section.replace('call.IsInitialization ? initialized :', 'call.IsInitialization ? currentInitializations :')
section = section.replace('ExpandMember(call.Key, active, depth, initialized)', 'ExpandMember(call.Key, active, depth, currentInitializations)')
path.write_text(text[:start] + section + text[end:], encoding='utf-8', newline='\n')
print('Prepared independent callback state and preserved initializer callback relationships.')
