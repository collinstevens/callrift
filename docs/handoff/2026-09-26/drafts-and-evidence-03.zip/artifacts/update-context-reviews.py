from pathlib import Path
import json

root = Path.cwd()
manifest = json.loads((root / 'real-world-cases/manifest.json').read_text(encoding='utf-8'))
def read_case(entry, view):
    text = (root / 'tests/Callrift.RealWorldCases/Snapshots' / (entry['id'] + '-' + view['id'] + '-json.verified.txt')).read_text(encoding='utf-8-sig')
    return json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
def count_nodes(nodes):
    return sum(1 + count_nodes(node['children']) for node in nodes)
for entry in manifest:
    if not (entry['id'].startswith('polly-') or entry['id'].startswith('orchardcore-')):
        continue
    path = root / 'real-world-cases' / entry['review']
    text = path.read_text(encoding='utf-8')
    lines = text.splitlines()
    for view in entry['views']:
        data = read_case(entry, view)
        for index, line in enumerate(lines):
            if line.startswith('| ') and line.split('|')[1].strip().replace(' ', '-') == view['id']:
                label = line.split('|')[1].strip()
                lines[index] = f"| {label} | {len(data['trees'])} | {count_nodes(data['trees'])} | {len(data['diagnostics'])} | {'yes' if data['truncated'] else 'no'} |"
    text = '\n'.join(lines) + '\n'
    if entry['id'].startswith('polly-'):
        text = text.replace('All restored views have zero diagnostics.', 'Restored binding has no unresolved-call diagnostics. Generic invocation limits remain visible.')
        text += '\nThe [generic-context review](generic-context.md) supersedes the earlier diagnostic counts and truncation flags. Every JSON call tree and rendered stdout body remains identical. The graph now retains instantiated callback state until its explicit expansion bound. Repeated delegating/bridge wrappers grow that state shape; the resulting `generic-context-limit` diagnostics name the affected declarations. Bounds apply to the analyzed graph, so a focused result can report truncation even when its displayed subtree has no omitted child. Coverage is partial.\n'
    elif entry['id'] == 'orchardcore-role-submission':
        text += '\nThe [generic-context review](generic-context.md) adds 41 explicit total-state limit diagnostics to each source view. The two roots, every JSON call tree, and rendered stdout remain identical. Restored views remain unchanged. The source graph includes all eligible projects and exhausts its 65,536 additional-state budget; a focused selector does not hide this limitation.\n'
    else:
        text += '\nThe [generic-context review](generic-context.md) retains inherited display-driver instantiations separately. `ActivityDisplayManager` calls `DisplayManager<IActivity>`. The focused callback now contains 82 source and 31 restored instantiations of the same two implementation declarations, including 67 and 24 concrete activity types respectively. The remaining instances include open generic constraints and the common activity-model base context. Each repeated node is unchanged and depth-limited; all other tree fields agree after traversal-ID renumbering. Text/Markdown stdout and declaration target lists are unchanged. Source views gain 41 explicit total-state limit diagnostics. Restored diagnostics remain the same six dynamic-call diagnostics.\n'
    path.write_text(text, encoding='utf-8', newline='\n')
path = root / 'real-world-cases/reviews/autofac-any-key-cache.md'
text = path.read_text(encoding='utf-8').replace('It supersedes the source counts below; restored and focused graph structures are unchanged.', 'The generic-context update below supersedes its automatic source counts; restored and focused graph structures are unchanged.')
text += '\nGeneric invocation contexts retain the earlier open `ResolveKeyed<TService>(IComponentContext, object)` root. Before the change it has no in-scope callers. The new benchmark introduces four calls using two concrete service interfaces; these do not replace the earlier open entry context. The method delegates to its `IEnumerable<Parameter>` overload and reaches the changed resolution/cache path below the depth bound. The added root does not claim an edit to the wrapper itself. All 133 previously accepted roots remain exactly identical after traversal-ID renumbering. The automatic source view now has 134 roots, 748 nodes, and the same 174 diagnostics. Six new definition/call-site occurrences were checked against both immutable revisions. A separate fixture verifies that a newly added integer caller cannot hide an earlier open string-handler path. The updated view passed its repeat. See the [generic-context review](generic-context.md).\n'
path.write_text(text, encoding='utf-8', newline='\n')
draft = (root / 'artifacts/generic-context-review-draft.md').read_text(encoding='utf-8')
draft = draft.replace('Status: implementation draft; broad validation and changed-snapshot review are pending. No snapshot from this draft is accepted.', 'Status: implementation and snapshot review completed locally; the full updated corpus repeat and supported-OS CI remain pending.')
draft = draft.replace('Production marks', 'The earlier implementation marked').replace('pass the draft', 'pass the implementation').replace('The draft carries', 'The implementation carries').replace('the prototype preserves', 'the implementation preserves')
draft = draft.replace('A refined intermediate build expanded 32,953 declarations into 57,738 states without a context limit. Repeat this trace against the final frozen build before integration.', 'The frozen final traversal expands 32,953 declarations into 41,910 states without a context limit.')
draft = draft.replace('The corrected draft preserves', 'The corrected implementation preserves')
start = draft.index('Validation records and exact DLL/source hashes')
draft = draft[:start] + '''The complete initial corpus run executed all 81 checks: 54 matched and 27 differed. Review accounted for every difference before promotion. Twenty-three views change only diagnostics, coverage, and truncation; all their JSON trees and text/Markdown stdout are exact matches. The two focused OrchardCore workflow views retain 82 source and 31 restored instantiations of the same two depth-limited declarations. Immutable driver declarations support 67 and 24 concrete activity types, respectively. Other contexts retain conservative open constraints and the shared activity-model base. Existing node fields, target lists, and rendered stdout remain unchanged. All 458 new diagnostic occurrences were checked against 219 immutable source inputs.

Autofac's source automatic view gains the earlier open `ResolveKeyed<TService>(IComponentContext, object)` root. Its new benchmark adds four callers with two closed service types. Those callers do not cover the earlier open context. The added two-node subtree matches the pinned wrapper and delegated overload; all 133 existing root subtrees and diagnostics remain exact matches. The per-pair review records the source and location checks. A separate regression ensures that a newly added integer caller does not hide an earlier open string-handler path.

The first run also exposed an incorrect `generic arguments changed` label on an added ASP.NET Core implementation. A zero-diagnostic independent reproducer failed before the correction. Invocation arguments are now compared independently of the possible implementation set. Both ASP.NET views match the original accepted snapshots after the correction. No ASP.NET expectation was changed.

The reviewed promotion contains 51 files. The full corpus repeat uses matching parent/worker Core SHA256 `c0a7a7c07a827e9d709b29e5d5dba2dbdbfac53910c5d8217ddd9c5be652ccc9`. It began with Autofac's earlier expectation while that final source review was in progress; the corrected Autofac view passed a separate repeat. Preserve this distinction when reading the run results.

Validation: all 272 existing scenarios passed in 31m51s before the narrow labeling correction; all 40 new regressions passed in 5m38s afterward. Adding the earlier-open-root case gives 41 new tests; the final eleven direct boundary checks pass. All 22 workspace checks passed in 4m31s. Current package smoke exercises the library, installed source/restored tool, bundled worker, separate consumer, and dnx. Formatting passes. Full corpus repeat and final supported-OS CI remain pending. No performance claim is made for this correctness change.
'''
(root / 'real-world-cases/reviews/generic-context.md').write_text(draft, encoding='utf-8', newline='\n')
print('Updated eight pair reviews and the generic-context review.')
