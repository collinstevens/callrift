from pathlib import Path
import json
import os
import subprocess
import time

root = Path.cwd()
case = next(case for case in json.loads((root / 'artifacts/orchardcore-expansion-candidates.json').read_text(encoding='utf-8')) if case['id'] == 'orchardcore-esmodule-localization')
cli = root / 'artifacts/receiver-context-delegate-cli-build/bin/Check/debug/callrift.dll'
focus = ['--depth', '2', '--externals', '--entry', 'JSLocalizerExtensions.GetMergedLocalizations', '--entry', 'OrchardCore.Resources.ResourceManagementOptionsConfiguration.BuildManifest()']
results = []
for view, options, formats in [('source-roots', ['--depth', '1'], ['text', 'md']), ('source-focused', focus, ['json', 'text', 'md'])]:
    for format in formats:
        stem = case['id'] + '-' + view
        output = root / 'artifacts' / (stem + '.' + format)
        error = root / 'artifacts' / (stem + '.' + format + '.err')
        assert not output.exists()
        started = time.monotonic()
        with output.open('w', encoding='utf-8', newline='\n') as stdout, error.open('w', encoding='utf-8', newline='\n') as stderr:
            result = subprocess.run(['dotnet', str(cli), 'diff', case['before'], case['after'], '--format', format, '--color', 'never', *options], cwd='C:/Users/Admin/AppData/Local/Callrift/real-world-cases/orchardcore', env=dict(os.environ, NO_COLOR='1'), stdout=stdout, stderr=stderr, timeout=600)
        record = {'view': view, 'format': format, 'exit': result.returncode, 'seconds': round(time.monotonic() - started, 2), 'accepted': False}
        results.append(record)
        (root / 'artifacts/orchardcore-esmodule-views.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(json.dumps(record), flush=True)
        assert result.returncode == 0
